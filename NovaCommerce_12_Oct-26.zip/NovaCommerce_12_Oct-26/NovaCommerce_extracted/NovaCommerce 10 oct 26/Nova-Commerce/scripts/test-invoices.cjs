/* Test de non-régression : facturation et caisse (factures à encaisser).
 * - Règles pures : desktop/invoice-rules.cjs (brouillon, validation, stock, crédit, encaissement, trop-perçu, double saisie).
 * - Chemin d'écriture réel : desktop/main.cjs (evaluateStateWrite) exécuté dans un bac à sable vm, base SQLite en mémoire
 *   (better-sqlite3). Les refus proviennent donc du processus principal, pas de l'interface.
 * - Parité : le code réel de app.js extrait (creditCollectionRatios, invoiceSettlement) comparé aux règles sur un corpus aléatoire.
 * - Droits : cohérence entre les profils par défaut de l'interface et ceux du processus principal.
 * Lancer avec : npm run test:invoices  (nécessite better-sqlite3 pour les tests de persistance et d'écriture) */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');

const NL = String.fromCharCode(10);
const ROOT = path.join(__dirname, '..');
const appLines = fs.readFileSync(path.join(ROOT, 'app.js'), 'utf8').split(NL);
const mainSource = fs.readFileSync(path.join(ROOT, 'desktop', 'main.cjs'), 'utf8');
const rules = require(path.join(ROOT, 'desktop', 'invoice-rules.cjs'));

function extract(lines, marker) {
  const start = lines.findIndex((line) => line.indexOf(marker) >= 0);
  if (start < 0) throw new Error('bloc introuvable : ' + marker);
  const first = lines[start];
  if (first.indexOf('{') < 0 && first.indexOf('}') < 0 && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < lines.length; i += 1) {
    for (const ch of lines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return lines.slice(start, i + 1).join(NL);
  }
  throw new Error('bloc non terminé : ' + marker);
}

let checks = 0;
const results = [];
const ok = (name, fn) => {
  try {
    fn();
    checks += 1;
    results.push(name);
    console.log(`  ✓ ${name}`);
  } catch (error) {
    console.log(`  ✗ ${name} — ${error.message}`);
    throw error;
  }
};
const clone = (value) => JSON.parse(JSON.stringify(value));
const money2 = (value) => Math.round(Number(value) * 100) / 100;

// ---------- fixtures ----------
const line = (quantity, unitPrice) => ({ productId: 'p1', storeId: 'st1', quantity, unitPrice, costPrice: 100 });
const base = () => ({
  settings: { businessName: 'Test Facturation', defaultStoreId: 'st1', allowNegative: false },
  license: {}, initialSetupCompleted: true, blankDatabase: false,
  categories: [{ id: 'cat1', name: 'Cat', active: true }],
  stores: [{ id: 'st1', name: 'Magasin', active: true }],
  suppliers: [], supplierProducts: [], deliverers: [], deliveries: [], supplierPayments: [], expenses: [], orders: [], quotes: [],
  stockEntries: [], stockExits: [], stockTransfers: [], inventory: [], inventoryReports: [], inventoryCounts: [], stockMovements: [],
  activities: [], refunds: [], roles: [],
  users: [
    { id: 'user-admin', username: 'admin', name: 'Admin', profile: 'Administrateur', active: true, passwordHash: 'x' },
    { id: 'user-vendeur', username: 'vendeur', name: 'Vendeur', profile: 'Vendeur', active: true, passwordHash: 'x' },
    { id: 'user-compta', username: 'compta', name: 'Comptable', profile: 'Comptable', active: true, passwordHash: 'x' },
  ],
  clients: [{ id: 'cli1', name: 'Client A', phone: '', email: '', address: '', creditLimit: 0, receivable: 0, advance: 0, openingReceivable: 0, active: true }],
  products: [{ id: 'p1', code: 'P1', name: 'Eau', categoryId: 'cat1', brand: '', model: '', supplierId: '', storeId: 'st1', purchasePrice: 100, salePrice: 150, wholesalePrice: 0, promoPrice: 0, stockByStore: { st1: 10 }, stock: 10, minStock: 0, maxStock: 0, presentation: 'Pièce', batch: '', expiry: '', barcode: '', barcodeType: '', image: '', active: true }],
  sales: [], customerPayments: [], creditNotes: [],
});
const invoice = (over = {}) => clone({ id: 'inv1', number: 'FAC-20261010-001', date: '2026-10-10T08:00:00.000Z', storeId: 'st1', clientId: 'cli1', clientName: 'Client A', items: [line(2, 150)], total: 300, payment: 'credit', priceType: 'retail', priceLabel: 'Prix de vente', status: 'Validée', kind: 'invoice', userId: 'user-vendeur', validatedBy: 'user-vendeur', validatedAt: '2026-10-10T08:00:00.000Z', ...over });
const draft = (over = {}) => invoice({ id: 'bro1', number: 'BRO-20261010-001', status: 'Brouillon', validatedBy: '', validatedAt: '', ...over });
const payment = (over = {}) => clone({ id: 'pay1', number: 'REG-20261010-001', clientId: 'cli1', date: '2026-10-10', amount: 100, method: 'cash', reference: '', note: '', status: 'Validé', userId: 'user-vendeur', createdAt: '2026-10-10T09:00:00.000Z', saleId: 'inv1', requestId: 'req-1', ...over });
const direct = (over = {}) => clone({ id: 'sale1', number: 'VTE-20261010-001', date: '2026-10-10T07:00:00.000Z', storeId: 'st1', clientId: 'counter', clientName: 'Client comptoir', items: [line(1, 150)], total: 150, payment: 'cash', priceType: 'retail', priceLabel: 'Prix de vente', status: 'Validée', userId: 'user-vendeur', ...over });
const stockFor = (product, storeId) => Number(product.stockByStore?.[storeId] ?? product.stock ?? 0);
const withStock = (state, qty) => { state.products[0].stockByStore = { st1: qty }; state.products[0].stock = qty; return state; };
const check = (previous, next) => rules.invoiceWriteCheck(previous, next, { stockFor });

// ---------- montage du processus principal (desktop/main.cjs) ----------
let Database = null;
try { Database = require('better-sqlite3'); } catch (_) { Database = null; }
if (!Database) {
  console.error('better-sqlite3 introuvable : installez-le (npm install) ou exposez-le via NODE_PATH. Tests de persistance et d’écriture non exécutables.');
  process.exit(2);
}
const noop = () => {};
const electron = {
  app: { whenReady: () => new Promise(noop), on: noop, getPath: () => path.join(require('node:os').tmpdir(), 'nova-invoices-test'), quit: noop, requestSingleInstanceLock: () => true, setAsDefaultProtocolClient: noop, isPackaged: false, getVersion: () => '1.0.0', commandLine: { appendSwitch: noop }, disableHardwareAcceleration: noop },
  BrowserWindow: class { constructor() { return { loadFile: noop, on: noop, webContents: { on: noop, send: noop, session: {} } }; } static getAllWindows() { return []; } },
  ipcMain: { handle: noop, on: noop, removeHandler: noop },
  dialog: { showSaveDialog: noop, showOpenDialog: noop, showMessageBox: noop },
  Menu: { buildFromTemplate: () => ({}), setApplicationMenu: noop },
  shell: { openExternal: noop }, session: {}, globalShortcut: { register: noop, unregister: noop },
};
const sandbox = {
  require: (name) => (name === 'electron' ? electron : name === 'better-sqlite3' ? Database : name === './barcode-rules.cjs' ? require(path.join(ROOT, 'desktop', 'barcode-rules.cjs')) : name === './invoice-rules.cjs' ? rules : require(name)),
  module: { exports: {} }, exports: {}, __dirname: path.join(ROOT, 'desktop'), __filename: path.join(ROOT, 'desktop', 'main.cjs'),
  console, process, Buffer, setTimeout, clearTimeout, setInterval, clearInterval, Promise, URL, TextEncoder, TextDecoder, Date, Math, JSON, Object, Array, Set, Map, String, Number, Boolean, Error, RegExp, Symbol, Uint8Array, ArrayBuffer, Reflect, Proxy, Intl, Function,
};
sandbox.global = sandbox; sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(mainSource, sandbox, { filename: 'main.cjs' });
const run = (code) => vm.runInContext(code, sandbox);
run("database = new Database(':memory:'); database.pragma('foreign_keys = ON'); createSchema();");
const persist = (state) => run(`replaceRelationalState(${JSON.stringify(state)})`);
const readBack = () => run('buildRelationalState()');
const evaluate = (userId, next) => run(`evaluateStateWrite(${JSON.stringify(userId)}, ${JSON.stringify(next)})`);
// État tel que la base le relit : point de départ de toute écriture simulée (comme l'application au chargement).
const fromDb = (state) => { persist(state); return readBack(); };

console.log('1. Brouillons');
ok('T01 brouillon : création sans sortie de stock ni encaissement ; droit invoices.create seul', () => {
  const prev = fromDb(base());
  const next = clone(prev); next.sales = [draft()];
  const result = check(prev, next);
  assert.strictEqual(result.refusal, null);
  assert.deepStrictEqual(result.permissions, ['invoices.create']);
  assert.strictEqual(next.products[0].stock, prev.products[0].stock, 'stock inchangé');
  assert.strictEqual(next.customerPayments.length, 0, 'aucun règlement créé');
  const decision = evaluate('user-vendeur', next);
  assert.strictEqual(decision.allowed, true, 'un agent crée un brouillon');
  const refused = evaluate('user-compta', next);
  assert.strictEqual(refused.allowed, false);
  assert.strictEqual(refused.reason, 'droits');
  assert.strictEqual(refused.permission, 'invoices.create');
});

console.log('2. Validation et stock');
ok('T02 validation : numéro FAC, statut Validée, sortie de stock exactement une fois (droit invoices.validate)', () => {
  const prev = base(); prev.sales = [draft()];
  const next = withStock(base(), 8); next.sales = [invoice()];
  const result = check(prev, next);
  assert.strictEqual(result.refusal, null);
  assert.ok(result.permissions.includes('invoices.validate'));
  assert.ok(!result.permissions.includes('sales.validate'), 'une facture ne demande pas sales.validate');
  assert.strictEqual(next.products[0].stockByStore.st1, prev.products[0].stockByStore.st1 - 2, 'un seul décompte de 2 unités');
});
ok('T03 validation refusée sans client enregistré (comptoir ou identifiant inconnu)', () => {
  for (const clientId of ['counter', 'inconnu']) {
    const prev = base(); prev.sales = [draft({ clientId })];
    const next = withStock(base(), 8); next.sales = [invoice({ clientId })];
    const result = check(prev, next);
    assert.strictEqual(result.refusal?.reason, 'facture-client', clientId);
  }
});
ok('T04 validation refusée si le stock est insuffisant (aucune écriture acceptée)', () => {
  const prev = fromDb(base());
  const next = clone(prev); next.sales = [invoice({ items: [line(11, 150)], total: 1650 })];
  const result = check(prev, next);
  assert.strictEqual(result.refusal?.reason, 'stock-insuffisant');
  const decision = evaluate('user-admin', next);
  assert.strictEqual(decision.allowed, false);
  assert.strictEqual(decision.reason, 'stock-insuffisant');
});
ok('T05 validation refusée au-delà de la limite de crédit du client', () => {
  const prev = base(); prev.clients[0].creditLimit = 200; prev.sales = [draft()];
  const next = withStock(base(), 8); next.clients[0].creditLimit = 200; next.sales = [invoice()];
  assert.strictEqual(check(prev, next).refusal?.reason, 'limite-credit');
});
ok('T06 validation refusée : numéro FAC en double ou montant falsifié', () => {
  const prev = base(); prev.sales = [draft()];
  const dup = withStock(base(), 6); dup.sales = [invoice(), invoice({ id: 'inv2' })];
  assert.strictEqual(check(prev, dup).refusal?.reason, 'facture-numero');
  const forged = withStock(base(), 8); forged.sales = [invoice({ total: 999 })];
  assert.strictEqual(check(prev, forged).refusal?.reason, 'facture-montant');
});

console.log('3. Intégrité d’une facture validée');
ok('T07 facture validée : ni modification, ni suppression, ni seconde sortie de stock (persistance réelle)', () => {
  const state = withStock(base(), 8); state.sales = [invoice()];
  persist(state);
  const previous = readBack();
  const edited = clone(previous); edited.sales[0].items[0].quantity = 1; edited.sales[0].total = 150;
  assert.strictEqual(evaluate('user-admin', edited).reason, 'integrite-vente', 'modification bloquée');
  const removed = clone(previous); removed.sales = [];
  assert.strictEqual(evaluate('user-admin', removed).reason, 'integrite-vente', 'suppression bloquée');
  const backToDraft = clone(previous); backToDraft.sales[0].status = 'Brouillon';
  assert.strictEqual(evaluate('user-admin', backToDraft).reason, 'integrite-vente', 'retour en brouillon bloqué (pas de nouvelle sortie possible)');
  const resave = clone(previous);
  const same = evaluate('user-vendeur', resave);
  assert.strictEqual(same.allowed, true, 'réécriture identique d’une facture validée sans nouveau droit requis');
});

console.log('4. Encaissement (règlements ciblés)');
ok('T08 une facture validée sans règlement n’est pas un encaissement : aucun règlement créé, statut Non payée', () => {
  const state = withStock(base(), 8); state.sales = [invoice()];
  const settlement = rules.invoiceSettlement(state, state.sales[0]);
  assert.strictEqual(settlement.status, 'Non payée');
  assert.strictEqual(settlement.balance, 300);
  assert.strictEqual(state.customerPayments.length, 0);
});
ok('T09 encaissement partiel : règlement rattaché à la facture, statut Partiellement payée, solde = net − payé', () => {
  const state = withStock(base(), 8); state.sales = [invoice()];
  persist(state);
  const next = readBack(); next.customerPayments = [payment({ amount: 100 })];
  const refusedVendeur = evaluate('user-vendeur', next);
  assert.strictEqual(refusedVendeur.allowed, false, 'agent sans invoices.collect');
  assert.strictEqual(refusedVendeur.permission, 'invoices.collect');
  const decision = evaluate('user-admin', next);
  assert.strictEqual(decision.allowed, true, decision.detail || decision.reason);
  persist(next);
  const back = readBack();
  assert.strictEqual(back.customerPayments[0].saleId, 'inv1');
  assert.strictEqual(back.customerPayments[0].requestId, 'req-1');
  const settlement = rules.invoiceSettlement(back, back.sales[0]);
  assert.strictEqual(settlement.paid, 100);
  assert.strictEqual(settlement.balance, 200);
  assert.strictEqual(settlement.status, 'Partiellement payée');
});
ok('T10 trop-perçu refusé : au-delà du solde restant, sans mécanisme de surpaiement', () => {
  const sale = invoice(); const state = withStock(base(), 8); state.sales = [sale];
  const over = clone(state); over.customerPayments = [payment({ amount: 301 })];
  assert.strictEqual(check(state, over).refusal?.reason, 'trop-percu');
  const exact = clone(state); exact.customerPayments = [payment({ amount: 300 })];
  assert.strictEqual(check(state, exact).refusal, null, 'solde exact accepté');
  const partial = clone(state); partial.customerPayments = [payment({ amount: 100 })];
  const second = clone(partial); second.customerPayments.push(payment({ id: 'pay2', number: 'REG-2', amount: 250, requestId: 'req-2' }));
  assert.strictEqual(check(partial, second).refusal?.reason, 'trop-percu', 'cumul au-delà du solde refusé');
});
ok('T11 facture soldée : aucun nouvel encaissement ; brouillon non encaissable', () => {
  const state = withStock(base(), 8); state.sales = [invoice()]; state.customerPayments = [payment({ amount: 300 })];
  const more = clone(state); more.customerPayments.push(payment({ id: 'pay2', number: 'REG-2', amount: 10, requestId: 'req-2' }));
  assert.strictEqual(check(state, more).refusal?.reason, 'facture-soldee');
  const draftState = base(); draftState.sales = [draft()];
  const toDraft = clone(draftState); toDraft.customerPayments = [payment({ amount: 50, saleId: 'bro1' })];
  assert.strictEqual(check(draftState, toDraft).refusal?.reason, 'facture-non-validee');
});
ok('T12 double saisie : un même identifiant de demande ne peut être enregistré deux fois', () => {
  const state = withStock(base(), 8); state.sales = [invoice()];
  const next = clone(state); next.customerPayments = [payment({ amount: 50 }), payment({ id: 'pay2', number: 'REG-2', amount: 50, requestId: 'req-1' })];
  assert.strictEqual(check(state, next).refusal?.reason, 'paiement-doublon');
});
ok('T13 règlement validé : suppression et modification refusées ; annulation exige un motif et le droit dédié', () => {
  const state = withStock(base(), 8); state.sales = [invoice()]; state.customerPayments = [payment({ amount: 100 })];
  persist(state);
  const previous = readBack();
  const removed = clone(previous); removed.customerPayments = [];
  assert.strictEqual(evaluate('user-admin', removed).reason, 'integrite-paiement', 'suppression');
  const edited = clone(previous); edited.customerPayments[0].amount = 200;
  assert.strictEqual(evaluate('user-admin', edited).reason, 'integrite-paiement', 'modification');
  const noReason = clone(previous); noReason.customerPayments[0].status = 'Annulé';
  assert.strictEqual(evaluate('user-admin', noReason).reason, 'motif-annulation');
  const withReason = clone(previous); Object.assign(withReason.customerPayments[0], { status: 'Annulé', cancelReason: 'Erreur de saisie', cancelledBy: 'user-admin', cancelledAt: '2026-10-10T10:00:00.000Z' });
  assert.strictEqual(evaluate('user-admin', withReason).allowed, true, 'annulation motivée par un profil autorisé');
  const byVendeur = clone(previous); Object.assign(byVendeur.customerPayments[0], { status: 'Annulé', cancelReason: 'Erreur', cancelledBy: 'user-vendeur', cancelledAt: '2026-10-10T10:00:00.000Z' });
  const denied = evaluate('user-vendeur', byVendeur);
  assert.strictEqual(denied.allowed, false);
  assert.strictEqual(denied.permission, 'invoices.payment.cancel');
});

console.log('5. Vente directe, droits et parité');
ok('T14 vente directe inchangée : acceptée avec sales.validate, refusée sans ce droit', () => {
  const prev = fromDb(base());
  const next = withStock(clone(prev), 9); next.sales = [direct()];
  const result = check(prev, next);
  assert.strictEqual(result.refusal, null);
  assert.deepStrictEqual(result.permissions, ['sales.validate']);
  assert.strictEqual(evaluate('user-vendeur', next).allowed, true);
  const denied = evaluate('user-compta', next);
  assert.strictEqual(denied.allowed, false);
  assert.strictEqual(denied.permission, 'sales.validate');
});
ok('T15 droits : profils par défaut identiques entre interface (app.js) et processus principal (main.cjs)', () => {
  const ctx = { console };
  vm.createContext(ctx);
  vm.runInContext(['const num = (v) => Number(v) || 0;', extract(appLines, '  const DEFAULT_ROLE_PERMISSIONS = '), extract(appLines, '  const VIEW_PERMISSIONS = '), 'globalThis.ui = { DEFAULT_ROLE_PERMISSIONS, VIEW_PERMISSIONS };'].join(NL), ctx);
  const mainLines = mainSource.split(NL);
  const fallbackBlock = extract(mainLines, 'const FALLBACK_ROLE_PERMISSIONS = ');
  const back = vm.runInNewContext(`${fallbackBlock}; FALLBACK_ROLE_PERMISSIONS`, {});
  const invoiceRights = (list) => list.filter((right) => right.startsWith('invoices.')).sort();
  for (const profile of ['Gérant', 'Vendeur', 'Comptable']) {
    assert.strictEqual(JSON.stringify(invoiceRights(back[profile])), JSON.stringify(invoiceRights(ctx.ui.DEFAULT_ROLE_PERMISSIONS[profile])), `droits factures : ${profile}`);
  }
  assert.ok(ctx.ui.VIEW_PERMISSIONS.invoices === 'invoices.view' && ctx.ui.VIEW_PERMISSIONS.collect === 'invoices.collect', 'ouverture des vues');
});
ok('T16 non-régression de la caisse : relecture avec sommes sans double comptage (paiements, factures, avoirs)', () => {
  const state = withStock(base(), 8);
  state.sales = [invoice(), direct({ id: 'sale2', number: 'VTE-2', total: 50, clientId: 'counter' })];
  state.customerPayments = [payment({ amount: 120 }), payment({ id: 'pay9', number: 'REG-9', amount: 40, saleId: '', requestId: 'req-9' })];
  const alloc = rules.collectionAllocation(state);
  const invoicePaid = rules.invoiceSettlement(state, state.sales[0], alloc).paid;
  const collectedOnCredit = state.sales.filter((sale) => sale.status === 'Validée' && sale.payment === 'credit').reduce((sum, sale) => sum + (alloc.paid[sale.id] || 0), 0);
  const cashTotal = state.customerPayments.reduce((sum, item) => sum + item.amount, 0);
  // Règlement ciblé 120 + règlement libre 40 imputé en FIFO sur l'unique créance à crédit du client (solde 300) : 160 au total.
  assert.strictEqual(invoicePaid, 160, 'facture : 120 ciblés + 40 libres imputés en FIFO');
  assert.ok(collectedOnCredit <= cashTotal + 1e-9, 'le montant encaissé sur crédit ne dépasse jamais les règlements');
  assert.strictEqual(cashTotal, 160, 'total encaissé = somme des règlements, montants de factures non ajoutés');
  assert.strictEqual(state.sales.find((sale) => sale.id === 'sale2').payment, 'cash', 'la vente directe reste un encaissement comptant');
  assert.strictEqual(state.sales[0].payment, 'credit', 'la facture n’est pas un encaissement comptant');
});
ok('T17 parité app.js / règles sur 300 états aléatoires : imputation, avoirs, statut et solde des factures', () => {
  const extracted = [
    extract(appLines, '  const num = '),
    extract(appLines, '  function creditNoteSale('),
    extract(appLines, '  function noteBelongsToCredit('),
    extract(appLines, '  function creditNoteTotal('),
    extract(appLines, '  function creditNoteMargin('),
    extract(appLines, '  function validCreditNotes('),
    extract(appLines, '  function creditNoteAdjustmentsBySale('),
    extract(appLines, '  function validSales('),
    extract(appLines, '  function saleTotal('),
    extract(appLines, '  function creditPaymentsTotal('),
    extract(appLines, '  function creditCollectionRatios('),
    extract(appLines, '  const invoiceCents = '),
    extract(appLines, '  function invoiceSettlement('),
  ];
  const ctx = { todayKey: () => '2026-10-10', state: null, console, Number, String, Math, Set, Map, Array, Object, JSON };
  ctx.productById = (id) => (ctx.state.products || []).find((item) => item.id === id);
  vm.createContext(ctx);
  vm.runInContext(extracted.join(NL) + NL + 'globalThis.api = { creditCollectionRatios, invoiceSettlement };', ctx);
  let seed = 20261010;
  const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  const pick = (list) => list[Math.floor(rnd() * list.length)];
  let comparisons = 0;
  for (let run0 = 0; run0 < 300; run0 += 1) {
    const state = { clients: [0, 1, 2].map((i) => ({ id: 'c' + i, name: 'C' + i, openingReceivable: Math.floor(rnd() * 50), creditLimit: 0 })), sales: [], creditNotes: [], customerPayments: [] };
    const sales = [];
    for (let i = 0; i < 10; i += 1) {
      const total = 100 + Math.floor(rnd() * 900);
      const status = pick(['Validée', 'Validée', 'Validée', 'Brouillon', 'Annulée']);
      sales.push({ id: 's' + i, number: 'VTE-' + i, date: '2026-0' + (1 + Math.floor(rnd() * 9)) + '-1' + Math.floor(rnd() * 9) + 'T10:00:00.000Z', clientId: pick(['c0', 'c1', 'c2']), payment: pick(['cash', 'credit', 'credit']), status, kind: rnd() < 0.3 ? 'invoice' : 'direct', items: [{ productId: 'p', quantity: 1, unitPrice: total, costPrice: 1 }], total, dueDate: '' });
    }
    state.sales = sales;
    const creditIds = sales.filter((sale) => sale.status === 'Validée' && sale.payment === 'credit').map((sale) => sale.id);
    for (let n = 0; n < Math.floor(rnd() * 4); n += 1) {
      state.creditNotes.push({ id: 'n' + n, number: 'AV-' + n, status: 'Validée', originalSaleId: pick(sales).id, total: Math.floor(rnd() * 150), lines: [], payment: 'credit', type: 'avoir' });
    }
    for (let k = 0; k < Math.floor(rnd() * 12); k += 1) {
      const saleId = creditIds.length && rnd() < 0.5 ? pick(creditIds) : '';
      state.customerPayments.push({ id: 'p' + k, number: 'REG-' + k, clientId: pick(['c0', 'c1', 'c2']), amount: 1 + Math.floor(rnd() * 300), status: rnd() < 0.85 ? 'Validé' : 'Annulé', saleId, requestId: 'r' + k });
    }
    ctx.state = state;
    const appCollection = vm.runInContext('api.creditCollectionRatios()', ctx);
    const ruleCollection = rules.collectionAllocation(state);
    for (const sale of sales) {
      if (sale.status !== 'Validée' || sale.payment !== 'credit' || !state.clients.some((c) => c.id === sale.clientId)) continue;
      assert.ok(Math.abs(appCollection.paid[sale.id] - ruleCollection.paid[sale.id]) < 0.01, `paid ${sale.id} (corpus ${run0})`);
      assert.ok(Math.abs(appCollection.ratios[sale.id] - ruleCollection.ratios[sale.id]) < 1e-9, `ratio ${sale.id} (corpus ${run0})`);
      comparisons += 1;
    }
    for (const sale of sales.filter((item) => item.kind === 'invoice' && item.status === 'Validée')) {
      ctx.state = state;
      const a = vm.runInContext(`api.invoiceSettlement(${JSON.stringify(sale)}, ${JSON.stringify(appCollection)})`, ctx);
      const r = rules.invoiceSettlement(state, sale, ruleCollection);
      for (const field of ['total', 'credited', 'net', 'paid', 'balance']) {
        assert.ok(Math.abs(a[field] - r[field]) < 0.01, `${field} facture ${sale.id} (corpus ${run0}) : app ${a[field]} / règles ${r[field]}`);
      }
      assert.strictEqual(a.status, r.status, `statut facture ${sale.id} (corpus ${run0})`);
      comparisons += 1;
    }
  }
  assert.ok(comparisons > 500, 'corpus suffisant : ' + comparisons);
  console.log(`      (${comparisons} comparaisons)`);
});
ok('T18 persistance : colonnes, index et aller-retour SQLite des factures, brouillons et règlements', () => {
  run("database = new Database(':memory:'); database.pragma('foreign_keys = ON'); createSchema();");
  const salesCols = run("database.prepare('PRAGMA table_info(sales)').all().map((c) => c.name)");
  ['kind', 'validated_by', 'validated_at', 'due_date', 'observations'].forEach((c) => assert.ok(salesCols.includes(c), 'sales.' + c));
  const payCols = run("database.prepare('PRAGMA table_info(customer_payments)').all().map((c) => c.name)");
  ['sale_id', 'request_id', 'cancel_reason', 'cancelled_by', 'cancelled_at'].forEach((c) => assert.ok(payCols.includes(c), 'customer_payments.' + c));
  assert.ok(run("!!database.prepare(\"SELECT name FROM sqlite_master WHERE type='index' AND name='idx_customer_payments_request'\").get()"), 'index unique des demandes');
  assert.strictEqual(run("database.prepare(\"SELECT value FROM app_meta WHERE key='schema_version'\").get().value"), '12');
  const state = withStock(base(), 7);
  state.sales = [invoice({ dueDate: '2026-11-30', observations: 'Livraison au comptoir' }), draft({ id: 'bro2', number: 'BRO-2' })];
  state.customerPayments = [payment({ amount: 100 })];
  persist(state);
  const back = readBack();
  const inv = back.sales.find((sale) => sale.id === 'inv1');
  assert.strictEqual(inv.kind, 'invoice'); assert.strictEqual(inv.status, 'Validée');
  assert.strictEqual(inv.dueDate, '2026-11-30'); assert.strictEqual(inv.observations, 'Livraison au comptoir');
  assert.strictEqual(inv.validatedBy, 'user-vendeur');
  const bro = back.sales.find((sale) => sale.id === 'bro2');
  assert.strictEqual(bro.status, 'Brouillon'); assert.strictEqual(bro.kind, 'invoice');
  assert.strictEqual(back.sales.length, 2, 'aucune vente fictive ajoutée à la persistance');
  const pay = back.customerPayments[0];
  assert.strictEqual(pay.saleId, 'inv1'); assert.strictEqual(pay.requestId, 'req-1');
  assert.strictEqual(evaluate('user-admin', back).allowed, true, 'état relu identique accepté (aucune fausse modification)');
  const unchangedDraftByComptable = evaluate('user-compta', back);
  assert.strictEqual(unchangedDraftByComptable.allowed, true, 'un brouillon non modifié ne demande pas invoices.create: ' + (unchangedDraftByComptable.permission || unchangedDraftByComptable.reason));
});

console.log(`\nTOUS LES TESTS FACTURATION : OK (${results.length} tests, ${checks} vérifications principales)`);
