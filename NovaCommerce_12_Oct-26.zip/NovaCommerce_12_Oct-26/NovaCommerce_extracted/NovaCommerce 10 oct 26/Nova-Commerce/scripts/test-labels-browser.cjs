/* Scénario navigateur : codes-barres de la fiche article et étiquettes A4 (Chrome headless + Puppeteer).
 * - Copie www/ dans un dossier temporaire et y ajoute un point d'accès de test (window.__novaDebug).
 *   Le livrable n'en contient pas : seule la copie de test est modifiée.
 * - Sert la copie sur un port libre, joue les parcours au clavier et à la souris, vérifie l'écran et le document imprimé.
 * - N'imprime sur aucune imprimante : window.print() est intercepté. Le document imprimé est rendu dans un
 *   autre onglet (PDF + capture) pour contrôler le nombre de pages et les dimensions.
 * Lancer avec : npm run test:labels:browser
 * Prérequis : dépendances installées (npm ci) ; Puppeteer télécharge Chrome au premier usage.
 * Variables facultatives : PUPPETEER_PATH (module puppeteer de remplacement), SHOTS_DIR (captures). */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');

const ROOT = path.join(__dirname, '..');
const SHOTS = process.env.SHOTS_DIR || path.join(os.tmpdir(), 'nova-labels-shots');
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon' };

let failures = 0;
let total = 0;
const check = (name, ok, detail = '') => { total += 1; if (!ok) failures += 1; console.log(`  ${ok ? '✓' : '✗'} ${name}${!ok && detail ? ' — ' + detail : ''}`); };

// 1. Copie de test avec point d'accès
const site = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-labels-site-'));
fs.cpSync(path.join(ROOT, 'www'), site, { recursive: true });
let appJs = fs.readFileSync(path.join(site, 'app.js'), 'utf8');
const hook = '\n  window.__novaDebug = { get state() { return state; }, setUser(u) { currentUser = u; }, setView(v) { activeView = v; render(); }, render, saveState };\n';
const closing = appJs.lastIndexOf('})();');
if (closing < 0) throw new Error('fin de l’IIFE introuvable dans app.js');
fs.writeFileSync(path.join(site, 'app.js'), appJs.slice(0, closing) + hook + appJs.slice(closing));

// 2. Serveur statique local (port libre)
const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  const file = path.join(site, urlPath === '/' ? 'index.html' : urlPath);
  if (!file.startsWith(site) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});

(async () => {
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const BASE = `http://127.0.0.1:${server.address().port}/index.html`;
  fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const errors = [];
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1360, height: 900 });
    page.on('pageerror', (e) => errors.push(String(e.message || e)));
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('dialog', (d) => d.accept());
    // Intercepte l'impression : on capture le document rendu, rien n'est envoyé à une imprimante.
    await page.evaluateOnNewDocument(() => {
      window.__printCalls = 0;
      window.__printHtml = '';
      window.print = () => { window.__printCalls += 1; window.__printHtml = document.getElementById('print-root').innerHTML; };
    });

    await page.goto(BASE, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 });
    await sleep(4500);
    const firstRun = await page.evaluate(() => { const el = document.querySelector('#first-run-screen'); return !!el && getComputedStyle(el).display !== 'none'; });
    if (firstRun) {
      await page.evaluate(() => { const b = Array.from(document.querySelectorAll('button')).find((x) => x.innerText.includes('Charger la démonstration')); if (b) b.click(); });
      await sleep(3000);
    }
    await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 });
    await page.evaluate(() => { const d = window.__novaDebug; d.setUser(d.state.users.find((u) => u.profile === 'Administrateur')); d.setView('products'); });
    await sleep(500);

    const products = () => page.evaluate(() => window.__novaDebug.state.products.map((p) => ({ id: p.id, name: p.name, barcode: p.barcode, stock: p.stock, salePrice: p.salePrice })));
    const countBarcode = (code) => page.evaluate((c) => window.__novaDebug.state.products.filter((p) => p.barcode === c).length, code);
    const toastHas = (text) => page.evaluate((t) => document.body.innerText.includes(t), text);
    const openNewProduct = async () => { await page.evaluate(() => document.querySelector('[data-action="add-product"]').click()); await sleep(300); };
    const fillProduct = (code, name) => page.evaluate((c, n) => {
      const f = document.querySelector('#product-form');
      f.elements.categoryId.value = Array.from(f.elements.categoryId.options).find((o) => o.value)?.value || '';
      f.elements.code.value = c; f.elements.name.value = n; f.elements.salePrice.value = '150'; f.elements.purchasePrice.value = '100';
    }, code, name);
    const submitProduct = async () => { await page.evaluate(() => document.querySelector('#product-form').requestSubmit()); await sleep(400); };

    console.log('1. Fiche article : génération, saisie, scanner, doublons');
    await openNewProduct();
    await page.evaluate(() => document.querySelector('#product-barcode-generate').click()); await sleep(150);
    const gen1 = await page.$eval('#product-barcode', (el) => el.value);
    const flag1 = await page.$eval('#product-barcode-generated', (el) => el.value);
    check('génération : code interne NC-########', /^NC-\d{8}$/.test(gen1), gen1);
    check('génération : indicateur « généré » posé', flag1 === '1');
    check('aperçu du code généré affiché', await page.evaluate(() => !!document.querySelector('#product-barcode-preview svg')));
    await page.evaluate(() => document.querySelector('#product-barcode-generate').click()); await sleep(150);
    const gen2 = await page.$eval('#product-barcode', (el) => el.value);
    check('régénération avant enregistrement : nouveau code, différent', /^NC-\d{8}$/.test(gen2) && gen2 !== gen1, `${gen1} → ${gen2}`);
    await fillProduct('GEN-001', 'Article généré test');
    await submitProduct();
    check('article enregistré avec le code généré', (await countBarcode(gen2)) === 1);
    const storedGen = (await products()).find((p) => p.barcode === gen2);
    check('code généré stable après enregistrement (chaîne)', typeof storedGen?.barcode === 'string' && storedGen.barcode === gen2);

    await openNewProduct();
    await page.click('#product-barcode');
    await page.keyboard.type('4006381333931');
    await page.keyboard.press('Enter');
    await sleep(150);
    check('scanner : Entrée ne soumet pas le formulaire', await page.evaluate(() => !!document.querySelector('#product-form')));
    const hint1 = await page.$eval('#product-barcode-hint', (el) => el.textContent);
    check('code EAN-13 valide confirmé', hint1.includes('Code valide') && hint1.includes('EAN-13'), hint1);
    check('focus passé au nom après Entrée', await page.evaluate(() => document.activeElement?.name === 'name'));
    await fillProduct('EAN-001', 'Savon de test');
    await submitProduct();
    check('article enregistré avec l’EAN-13', (await countBarcode('4006381333931')) === 1);

    await openNewProduct();
    await page.click('#product-barcode');
    await page.keyboard.type('4006381333931');
    await page.keyboard.press('Enter');
    await sleep(150);
    const dupHint = await page.$eval('#product-barcode-hint', (el) => el.textContent);
    check('doublon signalé avec lien vers l’article propriétaire', dupHint.includes('Déjà utilisé par Savon de test') && await page.evaluate(() => !!document.getElementById('product-barcode-open-owner')), dupHint);
    await fillProduct('EAN-002', 'Doublon test');
    await submitProduct();
    check('doublon refusé à l’enregistrement', (await countBarcode('4006381333931')) === 1 && await toastHas('Code-barres déjà utilisé'));

    await page.evaluate(() => { const i = document.querySelector('#product-barcode'); i.value = ''; i.focus(); });
    await page.click('#product-barcode');
    await page.keyboard.type('4006381333932');
    await page.keyboard.press('Enter');
    await sleep(120);
    const badHint = await page.$eval('#product-barcode-hint', (el) => el.textContent);
    check('EAN-13 à clé de contrôle fausse refusé', badHint.startsWith('Code refusé'), badHint);

    await page.evaluate(() => { const i = document.querySelector('#product-barcode'); i.value = '0012345678905'; i.dispatchEvent(new Event('input', { bubbles: true })); });
    await fillProduct('UPC-001', 'Sucre test');
    await submitProduct();
    check('zéro initial conservé (UPC/EAN saisi avec 0)', (await countBarcode('0012345678905')) === 1);

    await openNewProduct();
    await page.evaluate(() => document.querySelector('#product-barcode-scan').click());
    check('bouton Scanner : focus et sélection dans le champ', await page.evaluate(() => document.activeElement?.id === 'product-barcode'));
    await page.evaluate(() => document.querySelector('#product-barcode-camera').click()); await sleep(300);
    const cameraWarned = await toastHas('Lecture par caméra indisponible');
    const cameraOpened = await page.evaluate(() => { const h = document.getElementById('barcode-camera'); return !!h && !h.hidden; });
    check('caméra : indisponible ou ouverte (selon la plateforme), jamais bloquée', cameraWarned || cameraOpened, 'ni message ni caméra');
    await page.evaluate(() => { document.querySelector('[data-close-modal]')?.click(); });
    await sleep(300);

    console.log('2. Liste des articles : cases, sélection et filtrage');
    const withCode = (await products()).filter((p) => /^\d{8,13}$|^NC-\d{8}$/.test(p.barcode)).length;
    const boxes = await page.$$eval('[data-label-check]', (els) => els.length);
    check('une case par article ayant un code valide (les autres : tiret)', boxes === withCode, `cases ${boxes}, codes ${withCode}`);
    const noBox = await page.$$eval('#products-table-body tr', (rows) => rows.filter((r) => !r.querySelector('[data-label-check]')).map((r) => r.textContent.includes('—')));
    check('article sans code valide : tiret à la place de la case', noBox.every(Boolean), JSON.stringify(noBox));

    const savon = (await products()).find((p) => p.barcode === '4006381333931');
    const generated = (await products()).find((p) => p.barcode === gen2);
    const beforeLabels = JSON.stringify(await products());
    await page.evaluate((id) => { const b = document.querySelector(`[data-label-check="${id}"]`); if (b) { b.click(); } }, savon.id);
    await page.evaluate((id) => { const b = document.querySelector(`[data-label-check="${id}"]`); if (b) { b.click(); } }, generated.id);
    await sleep(150);
    const selCount = await page.$eval('#label-selection-count', (el) => el.textContent);
    check('sélection de deux articles cochés (compteur)', selCount === '2', selCount);

    console.log('3. Dialogue d’impression : quantités, format, aperçu');
    await page.evaluate(() => document.querySelector('[data-action="label-open"]').click()); await sleep(400);
    check('dialogue ouvert avec la sélection', await page.evaluate(() => !!document.getElementById('label-dialog')));
    const dialogSummary = () => page.$eval('#label-summary', (el) => el.textContent);
    check('compte initial : 2 étiquettes (1 par article)', (await dialogSummary()).includes('2 étiquette(s)'), await dialogSummary());
    await page.$eval(`[data-label-copies="${savon.id}"]`, (el) => { el.value = '30'; el.dispatchEvent(new Event('change', { bubbles: true })); });
    await sleep(120);
    check('30 étiquettes pour un article (quantité indépendante du stock)', (await dialogSummary()).includes('31 étiquette(s)'), await dialogSummary());
    check('format compact par défaut : 65 par page (5 × 13)', (await dialogSummary()).includes('65 étiquettes par page (5 × 13)'));
    const preview1 = await page.$$eval('#label-preview .label-page', (els) => els.length);
    const cells1 = await page.$$eval('#label-preview .label-page', (els) => els.reduce((n, p) => n + p.children.length, 0));
    check('aperçu : 1 page et 31 étiquettes', preview1 === 1 && cells1 === 31, `pages ${preview1}, étiquettes ${cells1}`);
    await page.$eval('[data-label-preset]', (el) => { el.value = 'standard'; el.dispatchEvent(new Event('change', { bubbles: true })); });
    await sleep(150);
    check('format standard : 21 par page (3 × 7), 2 pages pour 31 étiquettes', (await dialogSummary()).includes('21 étiquettes par page (3 × 7)') && (await dialogSummary()).includes('2 page(s)'), await dialogSummary());
    const cells2 = await page.$$eval('#label-preview .label-page', (els) => els.map((p) => p.children.length));
    check('aperçu standard : 21 + 10 étiquettes, sans page vide', cells2.length === 2 && cells2[0] === 21 && cells2[1] === 10, JSON.stringify(cells2));
    await page.screenshot({ path: path.join(SHOTS, 'dialogue-standard.png') });
    await page.$eval('[data-label-preset]', (el) => { el.value = 'compact'; el.dispatchEvent(new Event('change', { bubbles: true })); });
    await sleep(120);
    await page.$eval(`[data-label-copies="${savon.id}"]`, (el) => { el.value = '130'; el.dispatchEvent(new Event('change', { bubbles: true })); });
    await sleep(120);
    check('130 + 1 = 131 étiquettes : 3 pages A4 (65 + 65 + 1)', (await dialogSummary()).includes('131 étiquette(s)') && (await dialogSummary()).includes('3 page(s) A4'), await dialogSummary());
    check('bouton d’impression indique le nombre d’étiquettes', (await page.$eval('#label-print', (el) => el.textContent)).includes('131'));

    // 999 + 2 = 1001 : au-delà de la limite de 1000 étiquettes par lot (999 + 1 = 1000 reste accepté)
    await page.$eval(`[data-label-copies="${savon.id}"]`, (el) => { el.value = '999'; el.dispatchEvent(new Event('change', { bubbles: true })); });
    await page.$eval(`[data-label-copies="${generated.id}"]`, (el) => { el.value = '2'; el.dispatchEvent(new Event('change', { bubbles: true })); });
    await sleep(120);
    const warnText = await page.$eval('#label-warnings', (el) => el.textContent);
    check('lot au-delà de 1000 étiquettes : impression refusée avec message', (await page.$eval('#label-print', (el) => el.disabled)) === true && warnText.includes('1000'), warnText.slice(0, 120));
    await page.$eval(`[data-label-copies="${savon.id}"]`, (el) => { el.value = '130'; el.dispatchEvent(new Event('change', { bubbles: true })); });
    await page.$eval(`[data-label-copies="${generated.id}"]`, (el) => { el.value = '1'; el.dispatchEvent(new Event('change', { bubbles: true })); });
    await sleep(120);

    console.log('4. Impression (interceptée) : document, pages, étiquettes, stock');
    // Les notifications (toasts) recouvrent le pied de page : on attend leur disparition, comme un utilisateur.
    await page.waitForFunction("!document.querySelector('#toast-stack .toast')", { timeout: 20000 }).catch(() => {});
    const clickable = await page.evaluate(() => { const b = document.getElementById('label-print'); const r = b.getBoundingClientRect(); const hit = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2); return !!hit && (hit === b || b.contains(hit)); });
    check('bouton Imprimer visible et cliquable (non recouvert)', clickable);
    await page.click('#label-print');
    await sleep(200);
    const printed = await page.evaluate(() => ({ calls: window.__printCalls, html: window.__printHtml }));
    check('une seule demande d’impression', printed.calls === 1, String(printed.calls));
    check('document A4 portrait, marges nulles', printed.html.includes('size: A4 portrait; margin: 0;'));
    const pageCount = (printed.html.match(/class="label-page"/g) || []).length;
    check('document : 3 pages, aucune page vide', pageCount === 3, String(pageCount));
    const labelCount = (printed.html.match(/aria-label="Code-barres /g) || []).length;
    check('document : 131 codes-barres (aucune perte, aucune duplication)', labelCount === 131, String(labelCount));
    const vectorOnly = !printed.html.includes('<img') && printed.html.includes('<svg');
    check('codes-barres vectoriels (SVG, pas d’image bitmap)', vectorOnly);
    check('stock et données articles inchangés après l’impression', JSON.stringify(await products()) === beforeLabels);
    const savedLayout = await page.evaluate(() => localStorage.getItem('nova-label-layout-v1'));
    check('format mémorisé dans les préférences', !!savedLayout && JSON.parse(savedLayout).preset === 'compact', String(savedLayout).slice(0, 80));

    // Rendu du document imprimé dans un autre onglet : contrôle des dimensions et capture de la première page.
    const printPage = await browser.newPage();
    await printPage.setViewport({ width: 900, height: 1200 });
    await printPage.setContent(`<!doctype html><html><head><meta charset="utf-8"></head><body style="margin:0">${printed.html}</body></html>`, { waitUntil: 'load' });
    const dims = await printPage.$$eval('.label-page', (els) => els.map((el) => ({ w: el.getBoundingClientRect().width, h: el.getBoundingClientRect().height })));
    const a4px = { w: 210 / 25.4 * 96, h: 297 / 25.4 * 96 };
    check('chaque page mesure 210 × 297 mm (794 × 1123 px à 96 dpi)', dims.length === 3 && dims.every((d) => Math.abs(d.w - a4px.w) < 1.5 && Math.abs(d.h - a4px.h) < 1.5), JSON.stringify(dims[0]));
    const firstCell = await printPage.$eval('.label-page > div', (el) => ({ left: el.style.left, top: el.style.top, width: el.style.width, height: el.style.height }));
    const mm = (v) => parseFloat(String(v).replace('mm', ''));
    check('première étiquette : marge gauche/haute 4,8 / 10,7 mm, 38,1 × 21,2 mm (valeurs CSS)', Math.abs(mm(firstCell.left) - 4.8) < 0.01 && Math.abs(mm(firstCell.top) - 10.7) < 0.01 && Math.abs(mm(firstCell.width) - 38.1) < 0.01 && Math.abs(mm(firstCell.height) - 21.2) < 0.01, JSON.stringify(firstCell));
    const pdf = await printPage.pdf({ printBackground: true, preferCSSPageSize: true });
    const pdfPages = (Buffer.from(pdf).toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    check('PDF généré depuis le document : 3 pages', pdfPages === 3, String(pdfPages));
    fs.writeFileSync(path.join(SHOTS, 'etiquettes-131.pdf'), pdf);
    await printPage.screenshot({ path: path.join(SHOTS, 'page-1.png'), fullPage: false, clip: { x: 0, y: 0, width: a4px.w, height: a4px.h } });
    await printPage.close();

    console.log('5. Parcours par ligne, fermeture, synchronisation des cases');
    await page.evaluate(() => document.querySelector('[data-close-modal]')?.click()); await sleep(200);
    check('fermeture : dialogue retiré', await page.evaluate(() => !document.getElementById('label-dialog')));
    await page.evaluate((id) => document.querySelector(`[data-action="label-product"][data-id="${id}"]`).click(), generated.id);
    await sleep(400);
    const rows = await page.$$eval('#label-selection tbody tr', (els) => els.length);
    check('bouton de ligne : une seule ligne (remplace la sélection)', rows === 1, String(rows));
    await page.evaluate(() => document.querySelector('[data-close-modal]')?.click()); await sleep(200);
    const boxState = await page.evaluate((a, b) => ({ a: document.querySelector(`[data-label-check="${a}"]`)?.checked, b: document.querySelector(`[data-label-check="${b}"]`)?.checked }), generated.id, savon.id);
    check('cases synchronisées après fermeture (seul l’article ouvert est coché)', boxState.a === true && boxState.b === false, JSON.stringify(boxState));

    console.log('6. Pages d’erreurs JavaScript');
    check('aucune erreur JavaScript pendant le parcours', errors.length === 0, errors.slice(0, 3).join(' | '));
    await page.screenshot({ path: path.join(SHOTS, 'liste-articles.png') });
  } catch (error) {
    failures += 1;
    console.log(`  ✗ scénario interrompu — ${error.message}`);
    if (errors.length) console.log(`  erreurs JavaScript relevées : ${errors.slice(0, 5).join(' | ')}`);
  } finally {
    await browser.close();
    server.close();
    fs.rmSync(site, { recursive: true, force: true });
  }
  console.log(`\n${total - failures}/${total} vérifications OK. Captures : ${SHOTS}`);
  console.log(failures ? 'ÉCHEC : TESTS NAVIGATEUR ÉTIQUETTES' : 'TOUS LES TESTS NAVIGATEUR ÉTIQUETTES : OK');
  process.exit(failures ? 1 : 0);
})();
