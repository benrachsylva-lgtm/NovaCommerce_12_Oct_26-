/* Test de non-régression : nouveaux indicateurs du tableau de bord.
 * Exécute le VRAI renderDashboard() de app.js sur un jeu de démonstration
 * et contrôle les 4 cartes + 2 panneaux (livraisons + recouvrement).
 * Lancer avec : npm run test:dashboard */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

const blocks = [
  ...['ICON_PATHS', 'clamp', 'num', 'money', 'number', 'esc', 'localDate', 'shortDate', 'dateTime',
    'monthKey', 'todayKey', 'currentMonthKey', 'isoDate', 'dayLabel', 'daysUntil', 'withinDays',
    'productTone', 'productImage', 'categoryPalette'].map((name) => extract(`  const ${name} = `)),
  ...['validSales', 'saleTotal', 'saleMargin', 'validCreditNotes', 'creditNoteTotal', 'creditNoteMargin',
    'creditPaymentsTotal', 'creditNoteSale', 'noteBelongsToCredit', 'creditNoteAdjustmentsBySale',
    'creditCollectionRatios', 'saleCollectedMargin', 'collectedMarginOf', 'activeProducts',
    'normalizeProductStock', 'productById', 'totalStock', 'productStockState', 'productSalesRanking',
    'categoryName', 'productName', 'clientName', 'userName', 'delivererName', 'paymentLabel',
    'paymentBadge', 'statusBadge', 'emptyState', 'panel', 'icon', 'metricCard', 'disabledModules',
    'isModuleDisabled', 'renderDashboard'].map((name) => extract(`  function ${name}(`)),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let state = null;
let currentUser = { id: 'u1', name: 'Awa Gérant' };
const TKEY = todayKey();
const MKEY = currentMonthKey();
const prev = new Date(TKEY + 'T12:00:00');
prev.setMonth(prev.getMonth() - 1);
const PKEY = prev.getFullYear() + '-' + String(prev.getMonth() + 1).padStart(2, '0');
const mkSale = (id, payment, clientId, date, number, qty, unitPrice, costPrice) => (
  { id, payment, clientId, date, number, status: 'Validée', userId: 'u1', items: [{ productId: 'p1', quantity: qty, unitPrice, costPrice }] }
);
state = {
  settings: { businessName: 'NOVA Démo', disabledModules: [] },
  users: [{ id: 'u1', name: 'Awa Gérant' }],
  stores: [{ id: 'st1', name: 'Magasin central' }],
  categories: [{ id: 'c1', name: 'Alimentation' }],
  products: [
    { id: 'p1', name: 'Riz 5kg', categoryId: 'c1', purchasePrice: 3000, salePrice: 5000, stock: 50, stockByStore: { st1: 50 }, storeId: 'st1', minStock: 10, maxStock: 200, active: true },
    { id: 'p2', name: 'Huile 1L', categoryId: 'c1', purchasePrice: 2500, salePrice: 4000, stock: 3, stockByStore: { st1: 3 }, storeId: 'st1', minStock: 10, maxStock: 100, active: true }
  ],
  clients: [{ id: 'ca', name: 'Client A', phone: '70 00 00 01', receivable: 30000, creditLimit: 100000, openingReceivable: 0 }],
  sales: [
    mkSale('v1', 'cash', 'counter', TKEY, 'V-101', 4, 5000, 3000),
    mkSale('v2', 'credit', 'ca', TKEY, 'V-102', 2, 5000, 3000),
    { id: 'v3', payment: 'mobile', clientId: 'counter', date: MKEY + '-05', number: 'V-103', status: 'Validée', userId: 'u1', items: [{ productId: 'p2', quantity: 2, unitPrice: 4000, costPrice: 2500 }] }
  ],
  creditNotes: [],
  expenses: [{ status: 'Validée', date: TKEY, amount: 2000 }],
  customerPayments: [
    { status: 'Validé', clientId: 'ca', date: TKEY, amount: 3000, method: 'cash', reference: 'TICKET-1' },
    { status: 'Validé', clientId: 'ca', date: PKEY + '-15', amount: 1000, method: 'mobile', reference: '' }
  ],
  deliverers: [{ id: 'liv1', firstName: 'Ibrahim', lastName: 'Kaboré', active: true }],
  deliveries: [
    { id: 'd1', saleId: 'v1', saleNumber: 'V-101', delivererId: 'liv1', fee: 1000, assignedAt: TKEY + 'T10:00:00' },
    { id: 'd2', saleId: 'v3', saleNumber: 'V-103', delivererId: 'liv1', fee: 1500, assignedAt: MKEY + '-05T14:00:00' },
    { id: 'd3', saleId: 'v0', saleNumber: 'V-099', delivererId: 'liv1', fee: 2000, assignedAt: PKEY + '-20T09:00:00' }
  ],
  stockEntries: [], stockExits: [], stockTransfers: []
};
// ---------- scénario ----------
const report = [];
const html = renderDashboard();
assert.ok(html.includes('Taux d’encaissement'), 'carte taux');
assert.ok(html.includes('84 %'), 'taux 84 %');
assert.ok(html.includes(money(12600) + ' encaissés'), 'montant encaissé');
assert.ok(html.includes('Règlements reçus'), 'carte règlements');
assert.ok(html.includes(money(3000)), 'total règlements');
assert.ok(html.includes('1 règlement'), 'compte règlements');
assert.ok(html.includes('Livraisons du jour'), 'carte livraisons jour');
assert.ok(html.includes(money(1000) + ' de frais'), 'frais jour');
assert.ok(html.includes('Livraisons du mois'), 'carte livraisons mois');
assert.ok(html.includes(money(2500) + ' de frais'), 'frais mois');
assert.ok(html.includes('Dernières livraisons'), 'panneau livraisons');
assert.ok(html.includes('V-101 → Ibrahim Kaboré'), 'ligne livraison');
assert.ok(html.includes('Derniers règlements'), 'panneau règlements');
assert.ok(html.includes('Client A'), 'ligne règlement');
assert.ok(html.includes('TICKET-1'), 'référence règlement');
assert.strictEqual((html.match(/class="metric-card /g) || []).length, 14, '14 cartes');
assert.strictEqual((html.match(/<section class="panel">/g) || []).length, 8, '8 panneaux');
report.push('Cartes + panneaux: 4 cartes, 2 panneaux, valeurs OK');
// historique conservé
assert.ok(html.includes('Chiffre d’affaires du jour'), 'carte CA jour');
assert.ok(html.includes('Bénéfice net encaissé'), 'carte nette encaissé');
assert.ok(html.includes('Dernières ventes'), 'panneau ventes');
assert.ok(html.includes('Mouvements de stock'), 'panneau stock');
report.push('Historique: cartes et panneaux existants OK');
// module livreurs désactivé via l’espace concepteur
state.settings.disabledModules = ['deliverers'];
const masked = renderDashboard();
assert.ok(!masked.includes('Livraisons du jour'), 'carte jour masquée');
assert.ok(!masked.includes('Livraisons du mois'), 'carte mois masquée');
assert.ok(!masked.includes('Dernières livraisons'), 'panneau masqué');
assert.ok(masked.includes('Taux d’encaissement'), 'recouvrement conservé');
assert.ok(masked.includes('Derniers règlements'), 'règlements conservés');
assert.strictEqual((masked.match(/class="metric-card /g) || []).length, 12, '12 cartes');
report.push('Concepteur: livraisons masquées si module désactivé OK');
return { report };
`;

const result = new Function('assert', harness)(assert);
console.log('NOVA Commerce — test indicateurs tableau de bord');
result.report.forEach((line) => console.log(line));
console.log('Rendu : OK');

// ---------- câblage (vérifications statiques) ----------
const appSrc = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const readme = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
[
  'collectionRate', 'recentDeliveries', 'recentPayments', 'monthPaymentsTotal',
  "metricCard('truck', 'Livraisons du jour'", "metricCard('truck', 'Livraisons du mois'",
  "isModuleDisabled('deliverers') ? '' : metricCard", 'Dernières livraisons', 'Derniers règlements',
  'data-view="deliverers">Livreurs →', 'data-view="clients">Clients →',
].forEach((anchor) => assert.ok(appSrc.includes(anchor), `câblage ${anchor}`));
assert.ok(readme.includes('taux d’encaissement'), 'README');
console.log('Câblage : OK');
console.log('\nTOUS LES TESTS TABLEAU DE BORD : OK');
