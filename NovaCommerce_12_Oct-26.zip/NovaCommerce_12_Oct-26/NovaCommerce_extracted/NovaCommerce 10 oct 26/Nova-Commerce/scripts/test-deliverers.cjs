/* Test de non-régression : module Livreurs + affectation aux ventes.
 * Exécute le VRAI code de app.js (seed + helpers + affectation + rendus) et valide le SQL
 * de persistance de desktop/main.cjs. Lancer avec : npm run test:deliverers */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

const blocks = [
  ...['PROTECTED_ADMIN_USERNAME', 'SEED_PASSWORD_HASHES', 'num', 'esc', 'uid',
    'isoDate', 'isoDateTime', 'localDate', 'dateTime', 'money', 'number',
    'todayKey', 'seedState', 'PAGED_TABLE_SIZE'].map((name) => extract(`  const ${name} = `)),
  ...['dateCode', 'dateOnly', 'delivererName', 'deliveryForSale', 'assignDelivery',
    'currentUserId', 'addActivity', 'clientName', 'userName', 'paymentLabel', 'paymentBadge',
    'saleTotal', 'statusBadge', 'actionButtons', 'pageHeading', 'toolbar', 'emptyTable',
    'inActivePeriod', 'periodItems', 'netSalesRevenue', 'validSales', 'validCreditNotes',
    'creditNoteTotal', 'decodeEntities', 'splitTableRows', 'pagedRowMeta', 'pagedVisible',
    'pagedSlice', 'pagedTbody', 'renderSales', 'renderDeliverers', 'openDeliveryModal'].map((name) => extract(`  function ${name}(`)),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let activeDateFilter = {};
let currentUser = { id: 'user-admin', profile: 'Administrateur' };
let state = null;
let pagedRowStore = {};
let tablePages = {};
const requirePermission = () => true;
const isReadOnly = () => false;
const toast = () => {};
const render = () => {};
let lastModal = null;
const openModal = (title, subtitle, body, size, footer) => { lastModal = { title, subtitle, body, size, footer }; };
const saveState = () => true;
const window = { confirm: () => true };
const $ = () => ({ addEventListener: () => {}, value: '' });
const document = { querySelectorAll: () => [] };
// ---------- scénario démo ----------
state = seedState();
const report = [];
report.push('Démo: ' + state.deliverers.length + ' livreurs, ' + state.deliveries.length + ' livraison(s), ' + state.sales.length + ' ventes');
assert.strictEqual(state.deliverers.length, 15, '15 livreurs démo');
assert.strictEqual(state.deliveries.length, 500, '500 livraisons démo');
assert.strictEqual(delivererName('liv-01'), 'Ibrahim Kaboré');
assert.strictEqual(delivererName('xxx'), '—');
assert.strictEqual(deliveryForSale('sale-02').delivererId, 'liv-01');
assert.strictEqual(deliveryForSale('sale-01'), null);
const salesBefore = JSON.stringify(state.sales);
const actsBefore = state.activities.length;
// affectation
assert.strictEqual(assignDelivery('sale-04', 'liv-02', 1500), true);
assert.strictEqual(state.deliveries.length, 501);
const d = deliveryForSale('sale-04');
assert.strictEqual(d.delivererId, 'liv-02');
assert.strictEqual(d.fee, 1500);
assert.strictEqual(d.saleNumber, state.sales.find((s) => s.id === 'sale-04').number);
assert.ok(d.assignedAt && d.assignedBy === 'user-admin');
assert.strictEqual(JSON.stringify(state.sales), salesBefore, 'vente validée immuable');
assert.strictEqual(state.activities.length, actsBefore + 1);
assert.strictEqual(state.activities[0].module, 'Livraisons');
assert.strictEqual(state.activities[0].action, 'Affectation d’un livreur');
report.push('Affectation: ' + d.saleNumber + ' → ' + delivererName(d.delivererId) + ' (' + money(d.fee) + ')');
// réaffectation (même vente, un seul enregistrement)
assert.strictEqual(assignDelivery('sale-04', 'liv-01', 1000), true);
assert.strictEqual(state.deliveries.length, 501, 'pas de doublon');
assert.strictEqual(deliveryForSale('sale-04').delivererId, 'liv-01');
assert.strictEqual(deliveryForSale('sale-04').fee, 1000);
assert.strictEqual(state.activities[0].action, 'Réaffectation d’un livreur');
// cas invalides
assert.strictEqual(assignDelivery('nope', 'liv-01', 0), false);
assert.strictEqual(assignDelivery('sale-01', 'nope', 0), false);
assert.strictEqual(assignDelivery('', '', ''), false);
assert.strictEqual(state.deliveries.length, 501);
// frais négatifs bornés à 0
assert.strictEqual(assignDelivery('sale-01', 'liv-01', -50), true);
assert.strictEqual(deliveryForSale('sale-01').fee, 0);
// rendu historique des ventes
const html = renderSales();
const allRows = pagedRowStore['sales-table-body'].map((row) => row.html).join('');
assert.ok(html.includes('<th>Livreur</th>'), 'colonne Livreur');
assert.ok(allRows.includes('data-action="assign-delivery"'), 'bouton Livraison');
assert.ok(allRows.includes('🚚'), 'icône livraison');
assert.ok(allRows.includes('Ibrahim Kaboré'), 'livreur affiché');
assert.ok(allRows.includes('Non affecté'), 'ventes sans livreur');
// 4000 ventes + 7 factures de démo validées (les 2 brouillons ne figurent pas dans l'historique)
assert.strictEqual(pagedRowStore['sales-table-body'].length, 4007, '4007 lignes en magasin');
const keptSales = state.sales;
state.sales = [];
assert.ok(renderSales().includes('colspan="9"'), 'colspan ajusté');
state.sales = keptSales;
const keptDeliverers = state.deliverers;
state.deliverers = [];
assert.ok(renderDeliverers().includes('Aucun livreur enregistré'), 'module vide');
state.deliverers = keptDeliverers;
// modale de livraison (bouton Livraison)
openDeliveryModal('sale-05');
assert.ok(lastModal.title.includes('Livraison'), 'modale livraison');
assert.ok(lastModal.body.includes('id="delivery-form"'), 'formulaire');
assert.ok(lastModal.body.includes('name="delivererId"'), 'liste radio');
assert.ok(lastModal.body.includes('Ibrahim Kaboré'), 'livreur proposé');
assert.ok(lastModal.body.includes('Awa Sawadogo'), 'livreuse proposée');
assert.ok(!lastModal.body.includes('Pascal Zongo'), 'inactif exclu');
assert.ok(lastModal.body.includes('id="delivery-fee"'), 'champ frais');
assert.ok(lastModal.body.includes('Valider le livreur'), 'bouton valider');
openDeliveryModal('sale-02');
assert.ok(lastModal.body.includes('livreur actuel'), 'réaffectation signalée');
state.deliverers = [];
openDeliveryModal('sale-05');
assert.ok(lastModal.body.includes('Aucun livreur actif'), 'cas sans livreur');
assert.ok(lastModal.body.includes('data-action="add-deliverer"'), 'raccourci création');
state.deliverers = keptDeliverers;
report.push('Modale livraison: liste + validation + cas vide OK');
// rendu module livreurs
const htmlD = renderDeliverers();
assert.ok(htmlD.includes('Nouveau livreur'), 'bouton création');
assert.ok(htmlD.includes('Tarif de base'), 'colonne tarif');
assert.ok(htmlD.includes('CIN'), 'colonne CIN');
assert.ok(htmlD.includes('toggle-deliverer'), 'activation/désactivation');
assert.ok(htmlD.includes('Pascal Zongo'), 'livreur inactif listé');
assert.ok(htmlD.includes('Inactif'), 'badge inactif');
report.push('Rendus: historique + module OK');
return { report };
`;

const result = new Function('assert', harness)(assert);
console.log('NOVA Commerce — test Livreurs (données de démonstration)');
result.report.forEach((line) => console.log(line));
console.log('Seed + affectation + rendus : OK');

// ---------- câblage interface (vérifications statiques) ----------
const appSrc = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const htmlSrc = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
assert.ok(appSrc.includes("deliverers: ['Exploitation', 'Livreurs']"), 'VIEW_META');
assert.ok(appSrc.includes("deliverers: 'deliverers.view'"), 'VIEW_PERMISSIONS');
assert.ok(appSrc.includes("'add-deliverer': 'deliverers.manage'"), 'ACTION add');
assert.ok(appSrc.includes("'edit-deliverer': 'deliverers.manage'"), 'ACTION edit');
assert.ok(appSrc.includes("'toggle-deliverer': 'deliverers.manage'"), 'ACTION toggle');
assert.ok(appSrc.includes("'assign-delivery': 'sales.validate'"), 'ACTION assign');
assert.ok(appSrc.includes("'deliverer-form': 'deliverers.manage'"), 'FORM livreur');
assert.ok(appSrc.includes("'delivery-form': 'sales.validate'"), 'FORM livraison');
const readOnlySet = appSrc.match(/const READ_ONLY_ACTIONS = new Set\(\[([^\]]+)\]\)/)[1];
['add-deliverer', 'edit-deliverer', 'toggle-deliverer', 'assign-delivery'].forEach((a) => assert.ok(readOnlySet.includes(`'${a}'`), `lecture seule: ${a}`));
assert.ok(appSrc.includes("case 'deliverers': return renderDeliverers();"), 'routeur');
assert.ok(appSrc.includes("case 'export-deliverers': exportCurrent('deliverers');"), 'dispatcher export');
assert.ok(appSrc.includes("['export-deliverers', 'Livreurs']"), 'journal exports');
assert.ok(appSrc.includes('function openDeliveryModal(saleId)'), 'modale livraison');
assert.ok(appSrc.includes('name="delivererId"'), 'choix radio livreur');
assert.ok(appSrc.includes('id="delivery-form"'), 'formulaire livraison');
assert.ok(appSrc.includes('Valider le livreur'), 'bouton valider');
assert.ok(appSrc.includes("['deliverers', 'Livreurs'"), 'guide');
assert.ok(appSrc.includes("['deliverers.view', 'Consulter les livreurs']"), 'rôle: consulter');
assert.ok(appSrc.includes("['deliverers.manage', 'Gérer les livreurs']"), 'rôle: gérer');
assert.ok(/Gérant: \[[^\]]*'deliverers\.manage'/.test(appSrc), 'Gérant gère');
assert.ok(/Vendeur: \[[^\]]*'deliverers\.view'/.test(appSrc), 'Vendeur consulte');
assert.ok(htmlSrc.includes('data-view="deliverers"'), 'sidebar');
console.log('Câblage interface : OK (permissions, routeur, sidebar, guide, rôles)');

// ---------- validation du SQL de persistance (desktop/main.cjs) ----------
const mainSrc = fs.readFileSync(path.join(__dirname, '..', 'desktop', 'main.cjs'), 'utf8');
function checkInsert(table, cols) {
  const insertMatch = mainSrc.match(new RegExp(`database\\.prepare\\('(INSERT INTO ${table} [^']+)'\\)`));
  assert.ok(insertMatch, `INSERT ${table} trouvé`);
  const insertSql = insertMatch[1];
  cols.forEach((c) => assert.ok(insertSql.includes(c), `${table}: colonne ${c}`));
  const placeholders = (insertSql.match(/\?/g) || []).length;
  assert.strictEqual(placeholders, cols.length, `${table}: ${cols.length} placeholders`);
  return insertSql;
}
function checkArgs(varName, expected) {
  const runMatch = mainSrc.match(new RegExp(varName + '\\.run\\((.*)\\);'));
  assert.ok(runMatch, `${varName}.run() trouvé`);
  let depth = 0;
  let argCount = 1;
  for (const ch of runMatch[1]) {
    if (ch === '(') depth += 1;
    else if (ch === ')') depth -= 1;
    else if (ch === ',' && depth === 0) argCount += 1;
  }
  assert.strictEqual(argCount, expected, `${varName}: parité placeholders/arguments`);
}
const delivererCols = ['id', 'last_name', 'first_name', 'phone', 'secondary', 'address', 'base_rate', 'cin', 'notes', 'active'];
const deliveryCols = ['id', 'sale_id', 'sale_number', 'deliverer_id', 'fee', 'assigned_at', 'assigned_by'];
const insertDeliverer = checkInsert('deliverers', delivererCols);
const insertDelivery = checkInsert('deliveries', deliveryCols);
checkArgs('insertDeliverer', delivererCols.length);
checkArgs('insertDelivery', deliveryCols.length);
assert.ok(mainSrc.includes('CREATE TABLE IF NOT EXISTS deliverers ('), 'CREATE deliverers');
assert.ok(mainSrc.includes('CREATE TABLE IF NOT EXISTS deliveries ('), 'CREATE deliveries');
assert.ok(mainSrc.includes('lastName: row.last_name'), 'relecture lastName');
assert.ok(mainSrc.includes('baseRate: number(row.base_rate)'), 'relecture baseRate');
assert.ok(mainSrc.includes('saleId: row.sale_id'), 'relecture saleId');
assert.ok(mainSrc.includes('delivererId: row.deliverer_id'), 'relecture delivererId');
assert.ok(mainSrc.includes('fee: number(row.fee)'), 'relecture fee');
assert.ok(/return \{[^}]*deliverers, deliveries,/.test(mainSrc), 'relecture exposée');
assert.ok(mainSrc.includes("'deliveries', 'deliverers'"), 'DELETE miroir');
assert.ok(mainSrc.includes("collectionChanged(previous, nextState, 'deliverers')) checks.push('deliverers.manage')"), 'droit deliverers');
assert.ok(mainSrc.includes("collectionChanged(previous, nextState, 'deliveries')) checks.push('sales.validate')"), 'droit deliveries');
assert.strictEqual((mainSrc.match(/'inventoryReports', 'deliverers', 'deliveries'/g) || []).length, 2, 'listes base neuve (2)');
assert.ok(mainSrc.includes("VALUES ('schema_version', '12')"), 'schema v12');
console.log('Persistance SQL : OK (tables + INSERT + relecture + droits + v10)');

// ---------- round-trip SQLite réel si better-sqlite3 est disponible ----------
try {
  const Database = require('better-sqlite3');
  const createSql = (table) => {
    const start = mainSrc.indexOf(`CREATE TABLE IF NOT EXISTS ${table} (`);
    return mainSrc.slice(start, mainSrc.indexOf(');', start) + 2);
  };
  const db = new Database(':memory:');
  db.exec(createSql('deliverers'));
  db.exec(createSql('deliveries'));
  assert.ok(db.prepare('PRAGMA table_info(deliverers)').all().some((c) => c.name === 'base_rate'));
  assert.ok(db.prepare('PRAGMA table_info(deliveries)').all().some((c) => c.name === 'deliverer_id'));
  db.prepare(insertDeliverer).run('liv-01', 'Kaboré', 'Ibrahim', '+22670000000', '', 'Cissin', 1000, 'B 1', '', 1);
  db.prepare(insertDelivery).run('dlv-01', 'sale-02', 'VTE-260921-014', 'liv-01', 1000, '2026-09-20T18:05:00', 'user-admin');
  const back = db.prepare('SELECT d.last_name, d.first_name, l.fee FROM deliveries l JOIN deliverers d ON d.id = l.deliverer_id WHERE l.sale_id = ?').get('sale-02');
  assert.strictEqual(back.last_name, 'Kaboré');
  assert.strictEqual(back.first_name, 'Ibrahim');
  assert.strictEqual(back.fee, 1000);
  console.log('Round-trip SQLite (better-sqlite3) : OK (livreur + affectation relus)');
} catch (error) {
  if (error.code === 'MODULE_NOT_FOUND') {
    console.log('Round-trip SQLite : ignoré (better-sqlite3 non installé — validé séparément sur le même moteur)');
  } else throw error;
}
console.log('\nTOUS LES TESTS LIVREURS : OK');
