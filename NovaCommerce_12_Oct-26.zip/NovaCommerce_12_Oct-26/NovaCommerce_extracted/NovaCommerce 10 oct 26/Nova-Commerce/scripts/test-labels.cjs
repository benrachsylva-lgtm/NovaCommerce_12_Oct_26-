/* Test de non-régression : étiquettes autocollantes A4 (codes-barres des articles).
 * - Exécute le VRAI code de www/app.js extrait par marqueurs (même méthode que test-barcodes.cjs).
 * - Vérifie la mise en page (formules de colonnes et de lignes), la répartition du contenu, la pagination,
 *   les quantités par article, la génération de codes internes, le HTML d'impression et l'absence d'effet de bord
 *   (stock, prix, données articles inchangés).
 * - Ne prouve PAS l'impression physique : aucune imprimante n'est utilisée ici.
 * Lancer avec : npm run test:labels */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');

const NL = String.fromCharCode(10);
const ROOT = path.join(__dirname, '..');
const appLines = fs.readFileSync(path.join(ROOT, 'www', 'app.js'), 'utf8').split(NL);

function extract(marker) {
  const start = appLines.findIndex((line) => line.indexOf(marker) >= 0);
  if (start < 0) throw new Error('bloc introuvable : ' + marker);
  const first = appLines[start];
  if (first.indexOf('{') < 0 && first.indexOf('}') < 0 && first.indexOf(';') >= 0) return first; // constante sur une ligne (commentaire toléré)
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join(NL);
  }
  throw new Error('bloc non terminé : ' + marker);
}

const barcodeConstants = ['CODE128_PATTERNS', 'CODE128_START_B', 'CODE128_START_C', 'CODE128_STOP', 'EAN_L_CODES', 'EAN_G_CODES', 'EAN_R_CODES', 'EAN13_PARITY', 'BARCODE_INTERNAL_RE', 'BARCODE_QUIET_ZONE', 'GS1_LENGTH_TYPES'];
const labelConstants = ['LABEL_PAGE_MM', 'LABEL_PRESETS', 'LABEL_PRESET_NAMES', 'LABEL_GEOMETRY_KEYS', 'LABEL_MARGIN_WARNING_MM', 'LABEL_MIN_MODULE_MM', 'LABEL_MIN_BAR_MM', 'LABEL_MAX_COPIES', 'LABEL_MAX_TOTAL', 'LABEL_EPS'];
const barcodeFunctions = ['normalizeBarcode', 'gs1CheckDigit', 'barcodeCheck', 'barcodeKey', 'findProductByBarcode', 'nextInternalBarcode', 'code128Symbols', 'ean13Bits', 'ean8Bits', 'bitsToWidths', 'barcodeWidths', 'barcodeSvg'];
const labelFunctions = ['labelMm', 'barcodeUnits', 'barcodeLabelSvg', 'labelSheetLayout', 'wrapLineCount', 'fitLabelName', 'labelContentPlan', 'labelEntriesFor', 'paginateLabels', 'buildLabelJob', 'labelCellHtml', 'labelPageHtml', 'labelDocumentHtml'];

const blocks = [extract('  const num = '), extract('  const esc = '), extract('  const clamp = '), extract('  const money = ')];
barcodeConstants.forEach((name) => blocks.push(extract(`  const ${name} = `)));
labelConstants.forEach((name) => blocks.push(extract(`  const ${name} = `)));
[...barcodeFunctions, ...labelFunctions].forEach((name) => blocks.push(extract(`  function ${name}(`)));

const context = {
  state: { products: [], stores: [] },
  esc: (text) => String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'),
  Number, String, Math, Set, Map, Array, Object, JSON, RegExp, Error, Intl,
};
vm.createContext(context);
const exported = [...barcodeConstants, ...labelConstants, ...barcodeFunctions, ...labelFunctions, 'clamp', 'money'];
vm.runInContext(blocks.join(NL) + NL + 'globalThis.api = { ' + exported.join(', ') + ' };', context);
const api = context.api;
context.num = (value) => Number(value) || 0;

let checks = 0;
const ok = (name, fn) => {
  try { fn(); checks += 1; console.log(`  ✓ ${name}`); }
  catch (error) { console.log(`  ✗ ${name} — ${error.message}`); throw error; }
};

const COMPACT = { ...api.LABEL_PRESETS.compact, orientation: 'portrait', preset: 'compact', barPct: 100, fontPct: 100, showText: true };
const STANDARD = { ...api.LABEL_PRESETS.standard, orientation: 'portrait', preset: 'standard', barPct: 100, fontPct: 100, showText: true };
const PRODUCTS = [
  { id: 'p1', name: 'Savon de Marseille', barcode: '4006381333931', salePrice: 1500, stock: 120, active: true },
  { id: 'p2', name: 'Huile d’arachide 1 L', barcode: 'NC-00000007', salePrice: 2500, stock: 3, active: true },
  { id: 'p3', name: 'Article sans code', barcode: '', salePrice: 900, stock: 10, active: true },
  { id: 'p4', name: 'Code faux', barcode: '4006381333932', salePrice: 700, stock: 5, active: true },
  { id: 'p5', name: 'Sucre cristallisé', barcode: '0012345678905', salePrice: 1200, stock: 0, active: false },
];

console.log('Mise en page (formules de colonnes et de lignes)');
ok('compact portrait : 5 colonnes × 13 lignes = 65 étiquettes par page', () => {
  const sheet = api.labelSheetLayout(COMPACT);
  assert.strictEqual(sheet.ok, true);
  assert.strictEqual(sheet.columns, 5);
  assert.strictEqual(sheet.rows, 13);
  assert.strictEqual(sheet.perPage, 65);
});
ok('standard portrait : 3 colonnes × 7 lignes = 21 étiquettes par page', () => {
  const sheet = api.labelSheetLayout(STANDARD);
  assert.strictEqual(sheet.columns, 3);
  assert.strictEqual(sheet.rows, 7);
  assert.strictEqual(sheet.perPage, 21);
});
ok('paysage : dimensions de page inversées et nombre d’étiquettes recalculé', () => {
  const sheet = api.labelSheetLayout({ ...COMPACT, orientation: 'landscape' });
  assert.strictEqual(sheet.pageW, 297);
  assert.strictEqual(sheet.pageH, 210);
  assert.strictEqual(sheet.columns, 7); // floor((297 - 9.6) / 38.1)
  assert.strictEqual(sheet.rows, 8); // floor((210 - 21.3) / 21.2)
  assert.strictEqual(sheet.perPage, 56);
});
ok('formule des colonnes : espacement pris en compte (partie entière)', () => {
  // (210 - 2×7) = 196 ; (196 + 2.5) / (63.5 + 2.5) = 3.0015 → 3 colonnes
  const sheet = api.labelSheetLayout({ ...STANDARD, marginLeft: 7, marginRight: 7 });
  assert.strictEqual(sheet.columns, 3);
});
ok('étiquette trop grande pour la page : refus avec message', () => {
  const sheet = api.labelSheetLayout({ ...COMPACT, labelW: 250 });
  assert.strictEqual(sheet.ok, false);
  assert.ok(sheet.error.length > 0);
});
ok('valeurs non numériques ou négatives : refus', () => {
  assert.strictEqual(api.labelSheetLayout({ ...COMPACT, labelW: 'abc' }).ok, false);
  assert.strictEqual(api.labelSheetLayout({ ...COMPACT, marginTop: -1 }).ok, false);
  assert.strictEqual(api.labelSheetLayout({ ...COMPACT, labelH: 0 }).ok, false);
});
ok('marge inférieure à 4 mm : avertissement, pas de refus', () => {
  const sheet = api.labelSheetLayout({ ...COMPACT, marginLeft: 2 });
  assert.strictEqual(sheet.ok, true);
  assert.strictEqual(sheet.warnings.length, 1);
  assert.strictEqual(api.labelSheetLayout(COMPACT).warnings.length, 0);
});

console.log('Contenu d’une étiquette (zones en mm, sans chevauchement)');
ok('zones nom / code-barres / code / prix ordonnées, dans l’étiquette, sans chevauchement', () => {
  const sheet = api.labelSheetLayout(COMPACT);
  const plan = api.labelContentPlan(sheet, 'Savon de Marseille', '4006381333931', COMPACT);
  const nameBottom = plan.name.y + plan.name.h;
  const barTop = plan.bar.y;
  const barBottom = plan.bar.y + plan.bar.h;
  const textTop = plan.text.y;
  const priceTop = plan.price.y;
  assert.ok(nameBottom <= barTop + 1e-9, 'nom au-dessus du code-barres');
  assert.ok(barBottom <= textTop + 1e-9, 'code-barres au-dessus du texte');
  assert.ok(plan.text.y + plan.text.h <= priceTop + 1e-9, 'texte au-dessus du prix');
  assert.ok(priceTop + plan.price.h <= sheet.labelH + 1e-9, 'prix dans l’étiquette');
  assert.ok(plan.bar.x >= 0 && plan.bar.x + plan.bar.w <= sheet.labelW + 1e-9, 'code-barres dans la largeur');
});
ok('module du code-barres : ≥ 0,25 mm sur le format compact', () => {
  const sheet = api.labelSheetLayout(COMPACT);
  const plan = api.labelContentPlan(sheet, 'Savon', '4006381333931', COMPACT);
  assert.ok(plan.bar.moduleMm >= api.LABEL_MIN_MODULE_MM, `module ${plan.bar.moduleMm}`);
  assert.strictEqual(plan.warnings.filter((w) => w.includes('trop long')).length, 0);
});
ok('code trop long pour une très petite étiquette : avertissement', () => {
  const tiny = api.labelSheetLayout({ ...COMPACT, labelW: 20, labelH: 12, marginLeft: 5, marginRight: 5, marginTop: 5, marginBottom: 5 });
  assert.strictEqual(tiny.ok, true);
  const plan = api.labelContentPlan(tiny, 'Article', 'NC-00000001', { ...COMPACT, showText: true });
  assert.ok(plan.warnings.length >= 1, 'un avertissement attendu');
});
ok('nom trop long : réduction de police puis troncature signalée', () => {
  const sheet = api.labelSheetLayout(COMPACT);
  const long = 'Désignation extrêmement longue '.repeat(6);
  const plan = api.labelContentPlan(sheet, long, '4006381333931', COMPACT);
  assert.ok(plan.warnings.some((w) => w.includes('tronqué')));
  assert.ok(plan.name.fontMm >= 1.8);
});
ok('texte lisible : coupure aux espaces (wrapLineCount)', () => {
  assert.strictEqual(api.wrapLineCount('Huile d’arachide', 8), 3); // « Huile » + « d’arachide » (10 car.) coupé en 2
  assert.strictEqual(api.wrapLineCount('', 8), 0);
  assert.strictEqual(api.wrapLineCount('abc', 2), 2); // mot plus long que la ligne : coupé
});

console.log('Codes-barres vectoriels');
ok('SVG en millimètres, sans déformation (preserveAspectRatio="none", viewBox en modules)', () => {
  const svg = api.barcodeLabelSvg('4006381333931', 0.3, 12);
  assert.ok(svg.startsWith('<svg'));
  assert.ok(svg.includes('preserveAspectRatio="none"'));
  assert.ok(/width="[0-9.]+mm"/.test(svg) && /height="12\.000mm"/.test(svg));
  assert.ok(svg.includes('viewBox="0 0 '));
});
ok('zéro initial conservé dans le SVG et dans le libellé accessible', () => {
  const svg = api.barcodeLabelSvg('0012345678905', 0.3, 12);
  assert.ok(svg.includes('0012345678905'));
});
ok('code invalide : aucun SVG', () => {
  assert.strictEqual(api.barcodeLabelSvg('4006381333932', 0.3, 12), '');
});

console.log('Sélection, quantités et articles écartés');
ok('quantités développées dans l’ordre de sélection, indépendamment du stock', () => {
  const selection = [{ productId: 'p1', copies: 30 }, { productId: 'p2', copies: 2 }];
  const { entries, skipped } = api.labelEntriesFor(selection, PRODUCTS);
  assert.strictEqual(entries.length, 32);
  assert.strictEqual(entries.filter((e) => e.productId === 'p1').length, 30);
  assert.strictEqual(entries[0].productId, 'p1');
  assert.strictEqual(entries[31].productId, 'p2');
  assert.strictEqual(skipped.length, 0);
  // Stock 120 pour p1 : 30 étiquettes ; stock 3 pour p2 : 2 étiquettes. Le stock n'intervient pas.
});
ok('article sans code, code invalide, article introuvable, quantité hors bornes : écartés et signalés', () => {
  const selection = [
    { productId: 'p3', copies: 1 }, { productId: 'p4', copies: 1 }, { productId: 'zzz', copies: 1 },
    { productId: 'p1', copies: 0 }, { productId: 'p1', copies: 1000 }, { productId: 'p1', copies: 999 },
  ];
  const { entries, skipped } = api.labelEntriesFor(selection, PRODUCTS);
  assert.strictEqual(entries.length, 999);
  assert.strictEqual(skipped.length, 5);
});
ok('article inactif avec code valide : imprimable', () => {
  const { entries } = api.labelEntriesFor([{ productId: 'p5', copies: 1 }], PRODUCTS);
  assert.strictEqual(entries.length, 1);
  assert.strictEqual(entries[0].code, '0012345678905');
});
ok('prix affiché au format monétaire existant (FCFA)', () => {
  const { entries } = api.labelEntriesFor([{ productId: 'p1', copies: 1 }], PRODUCTS);
  const html = api.labelCellHtml(entries[0], api.labelSheetLayout(COMPACT), COMPACT, 0, 0);
  assert.ok(html.includes('FCFA'));
  assert.ok(html.includes(context.esc(api.money(1500))));
});

console.log('Pagination et lot');
ok('130 étiquettes sur 65 par page : 2 pages pleines, sans page vide', () => {
  const pages = api.paginateLabels(Array.from({ length: 130 }, (_, i) => ({ i })), 65);
  assert.strictEqual(pages.length, 2);
  assert.ok(pages.every((page) => page.length === 65));
});
ok('66 étiquettes : 2 pages (65 + 1), aucune perte ni duplication, ordre conservé', () => {
  const items = Array.from({ length: 66 }, (_, i) => ({ i }));
  const pages = api.paginateLabels(items, 65);
  assert.strictEqual(pages.length, 2);
  assert.strictEqual(pages[1].length, 1);
  const flat = pages.flat().map((x) => x.i);
  // JSON : les tableaux créés dans le contexte vm ne sont pas comparables par deepStrictEqual (autre realm)
  assert.strictEqual(JSON.stringify(flat), JSON.stringify(items.map((x) => x.i)));
});
ok('aucune étiquette : aucune page', () => {
  assert.strictEqual(api.paginateLabels([], 65).length, 0);
});
ok('lot de plus de 1000 étiquettes : refusé avec message', () => {
  const job = api.buildLabelJob([{ productId: 'p1', copies: 999 }, { productId: 'p2', copies: 2 }], PRODUCTS, COMPACT);
  assert.strictEqual(job.ok, false);
  assert.ok(job.error.includes('1000'));
});
ok('lot de 1000 étiquettes exactement : accepté', () => {
  const job = api.buildLabelJob([{ productId: 'p1', copies: 999 }, { productId: 'p2', copies: 1 }], PRODUCTS, COMPACT);
  assert.strictEqual(job.ok, true);
  assert.strictEqual(job.total, 1000);
  assert.strictEqual(job.pages.length, Math.ceil(1000 / 65));
});
ok('job complet : total = somme des quantités, pages pleines sauf la dernière', () => {
  const job = api.buildLabelJob([{ productId: 'p1', copies: 30 }, { productId: 'p2', copies: 40 }], PRODUCTS, COMPACT);
  assert.strictEqual(job.total, 70);
  assert.strictEqual(job.pages.length, 2);
  assert.strictEqual(job.pages[0].length, 65);
  assert.strictEqual(job.pages[1].length, 5);
});
ok('document d’impression : @page A4 orientation, marges nulles, nombre de pages exact', () => {
  const job = api.buildLabelJob([{ productId: 'p1', copies: 70 }], PRODUCTS, COMPACT);
  const html = api.labelDocumentHtml(job, COMPACT);
  assert.ok(html.includes('@page { size: A4 portrait; margin: 0; }'));
  assert.strictEqual((html.match(/class="label-page"/g) || []).length, 2);
  const landscape = api.buildLabelJob([{ productId: 'p1', copies: 1 }], PRODUCTS, { ...COMPACT, orientation: 'landscape' });
  assert.ok(api.labelDocumentHtml(landscape, { ...COMPACT, orientation: 'landscape' }).includes('size: A4 landscape'));
});
ok('dernière page sans saut de page final (pas de page vide imprimée)', () => {
  const job = api.buildLabelJob([{ productId: 'p1', copies: 65 }], PRODUCTS, COMPACT);
  const html = api.labelDocumentHtml(job, COMPACT);
  assert.strictEqual((html.match(/class="label-page"/g) || []).length, 1);
  assert.ok(!html.includes('break-after:page'));
});
ok('aucun effet de bord : produits et stock inchangés après la préparation', () => {
  const before = JSON.stringify(PRODUCTS);
  api.buildLabelJob([{ productId: 'p1', copies: 30 }], PRODUCTS, COMPACT);
  api.labelDocumentHtml(api.buildLabelJob([{ productId: 'p1', copies: 30 }], PRODUCTS, COMPACT), COMPACT);
  assert.strictEqual(JSON.stringify(PRODUCTS), before);
  assert.strictEqual(PRODUCTS[0].stock, 120);
});

console.log('Codes internes (génération et collision)');
ok('code interne suivant : plus haut numéro + 1', () => {
  const products = [{ barcode: 'NC-00000005' }, { barcode: 'NC-00000002' }, { barcode: '4006381333931' }];
  assert.strictEqual(api.nextInternalBarcode(products), 'NC-00000006');
});
ok('code exclu (non enregistré) : sauté, pas de collision', () => {
  const products = [{ barcode: 'NC-00000005' }];
  assert.strictEqual(api.nextInternalBarcode(products, ['NC-00000006']), 'NC-00000007');
});
ok('liste vide : premier code NC-00000001', () => {
  assert.strictEqual(api.nextInternalBarcode([]), 'NC-00000001');
});
ok('unicité : un code interne déjà pris n’est jamais renvoyé', () => {
  const products = [{ barcode: 'NC-00000001' }, { barcode: 'NC-00000003' }];
  const code = api.nextInternalBarcode(products);
  assert.notStrictEqual(code, 'NC-00000001');
  assert.notStrictEqual(code, 'NC-00000003');
  assert.strictEqual(api.findProductByBarcode(code, products, ''), null);
});

console.log(`\n${checks} vérifications OK.`);
