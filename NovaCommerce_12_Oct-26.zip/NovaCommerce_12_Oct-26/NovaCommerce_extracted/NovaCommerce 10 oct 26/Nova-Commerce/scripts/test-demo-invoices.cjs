/* Test de non-régression : factures de démonstration (facturation séparée de l'encaissement).
 * Exécute le VRAI seedState de app.js puis contrôle les factures de démo avec les règles backend
 * (desktop/invoice-rules.cjs) : statuts et soldes, règlements liés, stock, avoir d'annulation,
 * numérotation, dates et contrôle global invoiceWriteCheck.
 * Lancer avec : npm run test:demo-invoices */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');
const rules = require('../desktop/invoice-rules.cjs');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

const blocks = [
  ...['PROTECTED_ADMIN_USERNAME', 'SEED_PASSWORD_HASHES', 'num', 'isoDate', 'isoDateTime',
    'seedState'].map((name) => extract(`  const ${name} = `)),
  ...['dateCode', 'validSales', 'validCreditNotes', 'saleTotal', 'creditNoteTotal',
    'creditNotesTotalForClient', 'creditSalesTotal', 'creditPaymentsTotal',
    'validRefunds', 'clientRefundsTotal', 'clientPositionValues',
    'refreshClientReceivables', 'productById'].map((name) => extract(`  function ${name}(`)),
];

const harness = `
${blocks.join('\n')}
let state = seedState();
return { state, refreshClientReceivables: () => refreshClientReceivables() };
`;
const { state, refreshClientReceivables } = new Function(harness)();
refreshClientReceivables();

let checks = 0;
const ok = (cond, label) => { assert.ok(cond, label); checks += 1; };
const same = (a, b, label) => { assert.strictEqual(a, b, `${label} : attendu ${b}, obtenu ${a}`); checks += 1; };
const near = (a, b, label) => { assert.ok(Math.abs(Number(a) - Number(b)) < 0.01, `${label} : attendu ${b}, obtenu ${a}`); checks += 1; };

const invoices = state.sales.filter((sale) => sale.kind === 'invoice');
const byKey = (key) => state.sales.find((sale) => sale.id === `sale-inv-${key.toLowerCase()}`);
const EXPECTED = {
  A: { status: rules.VALID, settlement: 'Non payée', payments: 0 },
  B: { status: rules.VALID, settlement: 'Non payée', payments: 0 },
  C: { status: rules.VALID, settlement: 'Partiellement payée', payments: 1 },
  D: { status: rules.VALID, settlement: 'Partiellement payée', payments: 2 },
  E: { status: rules.VALID, settlement: 'Payée intégralement', payments: 1 },
  F: { status: rules.VALID, settlement: 'Payée intégralement', payments: 2 },
  G: { status: rules.VALID, settlement: 'Annulée', payments: 0 },
  H: { status: rules.DRAFT, settlement: null, payments: 0 },
  I: { status: rules.DRAFT, settlement: null, payments: 0 }
};

// ----- 1. Effectifs et statuts -----
same(invoices.length, 9, 'nombre de factures de démo');
same(invoices.filter((s) => s.status === rules.DRAFT).length, 2, 'brouillons');
same(invoices.filter((s) => s.status === rules.VALID).length, 7, 'factures validées');
Object.entries(EXPECTED).forEach(([key, exp]) => {
  const sale = byKey(key);
  ok(sale, `facture ${key} présente`);
  same(sale.status, exp.status, `statut ${key}`);
  same(sale.payment, 'credit', `mode de paiement ${key} (facture = à crédit)`);
});

// ----- 2. Numérotation et montants -----
const numbers = new Set();
invoices.forEach((sale) => {
  ok(/^(FAC|BRO)-\d{6}-\d{3}$/.test(sale.number), `numéro ${sale.number}`);
  const prefix = sale.status === rules.DRAFT ? 'BRO' : 'FAC';
  ok(sale.number.startsWith(prefix + '-'), `préfixe ${sale.number} pour ${sale.status}`);
  ok(!numbers.has(sale.number), `numéro unique ${sale.number}`);
  numbers.add(sale.number);
  ok(sale.items.length > 0, `lignes ${sale.id}`);
  const lineIds = sale.items.map((item) => item.productId);
  ok(new Set(lineIds).size === lineIds.length, `produit non dupliqué ${sale.id}`);
  sale.items.forEach((item) => {
    ok(Number(item.quantity) > 0 && Number(item.unitPrice) >= 0, `ligne ${sale.id} quantité/prix`);
    ok(state.products.some((p) => p.id === item.productId), `produit existant ${item.productId}`);
    same(item.storeId, 'store-main', `magasin de ligne ${sale.id}`);
  });
  const computed = sale.items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
  near(sale.total, computed, `total ${sale.id} = somme des lignes`);
  ok(state.clients.some((c) => c.id === sale.clientId && c.name === sale.clientName), `client ${sale.id}`);
  ok(sale.clientId !== 'counter', `facture rattachée à un client enregistré ${sale.id}`);
  ok(Date.now() - new Date(sale.date).getTime() < 31 * 86400000 && new Date(sale.date).getTime() <= Date.now() + 86400000, `date récente ${sale.id}`);
});

// ----- 3. Règlements : liés, valides, dans le solde -----
const payments = state.customerPayments.filter((p) => p.saleId && invoices.some((s) => s.id === p.saleId));
const allNumbers = new Set();
state.customerPayments.forEach((p) => { ok(!allNumbers.has(p.number), `numéro de règlement unique ${p.number}`); allNumbers.add(p.number); });
const requestIds = new Set();
payments.forEach((p) => {
  const sale = byKey(p.saleId.replace('sale-inv-', ''));
  same(p.status, 'Validé', `statut règlement ${p.id}`);
  ok(Number(p.amount) > 0, `montant > 0 ${p.id}`);
  same(p.clientId, sale.clientId, `client du règlement ${p.id}`);
  ok(['cash', 'mobile', 'card', 'cheque'].includes(p.method), `mode ${p.id}`);
  ok(!requestIds.has(p.requestId), `requestId unique ${p.id}`);
  requestIds.add(p.requestId);
  ok(p.date >= sale.date.slice(0, 10), `règlement postérieur à la facture ${p.id}`);
  ok(p.date <= new Date().toISOString().slice(0, 10), `règlement non daté dans le futur ${p.id}`);
});
// Une facture soldée ne doit pas recevoir plus que son total ; un brouillon ou une facture annulée n'a aucun règlement.
Object.entries(EXPECTED).forEach(([key, exp]) => {
  const sale = byKey(key);
  const mine = payments.filter((p) => p.saleId === sale.id);
  same(mine.length, exp.payments, `nombre de règlements ${key}`);
});

// ----- 4. Situation calculée par le backend (même moteur qu'à l'écran) -----
const allocation = rules.collectionAllocation(state);
Object.entries(EXPECTED).forEach(([key, exp]) => {
  const sale = byKey(key);
  if (exp.settlement === null) {
    ok(allocation.paid[sale.id] === undefined, `brouillon ${key} hors caisse`);
    return;
  }
  const s = rules.invoiceSettlement(state, sale, allocation);
  same(s.status, exp.settlement, `statut de règlement ${key}`);
  if (key === 'C') near(s.paid, Math.floor(sale.total * 0.4 / 100) * 100, 'encaissé C');
  if (key === 'E' || key === 'F') { near(s.paid, sale.total, `encaissé ${key}`); near(s.balance, 0, `solde ${key}`); }
  if (key === 'A' || key === 'B') { near(s.paid, 0, `encaissé ${key}`); near(s.balance, sale.total, `solde ${key}`); }
  ok(s.paid <= s.net + 0.01 && s.balance >= 0, `cohérence encaissé/solde ${key}`);
});

// ----- 5. Avoir d'annulation (facture G) -----
const creditG = state.creditNotes.find((n) => n.originalSaleId === byKey('G').id);
ok(creditG, 'avoir de la facture G');
same(creditG.status, 'Validée', 'statut de l\'avoir');
same(creditG.restock, true, 'retour en stock de l\'avoir');
same(creditG.stockApplied, true, 'stock appliqué');
near(creditG.total, byKey('G').total, 'montant de l\'avoir = total de la facture');
same(state.creditNotes.length, 1, 'un seul avoir de démo');

// ----- 6. Stock : jamais négatif, cohérent avec les dépôts -----
// Les produits fixes (prod-01 à prod-08) n'ont pas de stockByStore dans le seed : l'application le dérive
// au chargement (normalizeProductStock) depuis storeId et stock. Le test applique la même règle.
const balancesOf = (p) => (p.stockByStore && Object.keys(p.stockByStore).length ? p.stockByStore : { [p.storeId]: p.stock });
state.products.forEach((p) => {
  const balances = balancesOf(p);
  Object.values(balances).forEach((q) => ok(Number(q) >= 0, `stock positif ${p.id}`));
  near(p.stock, Object.values(balances).reduce((s, q) => s + Number(q), 0), `stock = somme des dépôts ${p.id}`);
});

// ----- 7. Contrôle global par les règles backend (même fonction que les écritures réelles) -----
const stockFor = (product, storeId) => Number(balancesOf(product)[storeId] || 0);
const writeOpts = { stockFor: (productOrId, storeId) => stockFor(typeof productOrId === 'string' ? state.products.find((p) => p.id === productOrId) : productOrId, storeId) };
const cloneState = (value) => JSON.parse(JSON.stringify(value));
const validated = invoices.filter((s) => s.status === rules.VALID && s.id !== byKey('G').id);

// Étape 1 : validation des factures. Avant : sans factures, stock remis (sortie non encore faite).
// Après : factures présentes, stock déduit une seule fois. Les règlements et l'avoir ne sont pas encore là.
const step1Prev = cloneState(state);
step1Prev.sales = step1Prev.sales.filter((s) => s.kind !== 'invoice');
step1Prev.customerPayments = step1Prev.customerPayments.filter((p) => !p.saleId);
step1Prev.creditNotes = [];
step1Prev.products.forEach((p) => {
  p.stockByStore = { ...balancesOf(p) };
  validated.forEach((s) => s.items.forEach((item) => { if (item.productId === p.id) p.stockByStore['store-main'] += item.quantity; }));
  p.stock = Object.values(p.stockByStore).reduce((sum, q) => sum + q, 0);
});
const step1Next = cloneState(state);
step1Next.customerPayments = step1Next.customerPayments.filter((p) => !p.saleId);
step1Next.creditNotes = [];
const check1 = rules.invoiceWriteCheck(step1Prev, step1Next, writeOpts);
same(check1.refusal, null, 'validation des factures de démo : refus inattendu');
ok(check1.permissions.includes('invoices.validate'), 'permission invoices.validate requise');

// Étape 2 : encaissement des règlements sur les factures déjà validées (sans avoir).
const step2Prev = cloneState(step1Next);
step2Prev.customerPayments = step2Prev.customerPayments.filter((p) => !p.saleId);
const step2Next = cloneState(state);
step2Next.creditNotes = [];
const check2 = rules.invoiceWriteCheck(step2Prev, step2Next, writeOpts);
same(check2.refusal, null, 'encaissement des règlements de démo : refus inattendu');
ok(check2.permissions.includes('invoices.collect'), 'permission invoices.collect requise');

// Étape 3 : contrôles négatifs. Un règlement supérieur au solde et un règlement sur un brouillon sont refusés.
const unpaid = byKey('A');
const overpay = cloneState(step2Prev);
overpay.customerPayments.push({ id: 'pay-test-over', number: 'REG-TEST-001', clientId: unpaid.clientId, saleId: unpaid.id, date: new Date().toISOString().slice(0, 10), amount: unpaid.total + 100, method: 'cash', reference: '', note: '', status: 'Validé', userId: 'user-admin', createdAt: new Date().toISOString(), requestId: 'test-over' });
const checkOver = rules.invoiceWriteCheck(step2Prev, overpay, writeOpts);
same(checkOver.refusal && checkOver.refusal.reason, 'trop-percu', 'trop-perçu refusé par le backend');
const draftPay = cloneState(step2Prev);
draftPay.customerPayments.push({ id: 'pay-test-draft', number: 'REG-TEST-002', clientId: byKey('H').clientId, saleId: byKey('H').id, date: new Date().toISOString().slice(0, 10), amount: 100, method: 'cash', reference: '', note: '', status: 'Validé', userId: 'user-admin', createdAt: new Date().toISOString(), requestId: 'test-draft' });
const checkDraft = rules.invoiceWriteCheck(step2Prev, draftPay, writeOpts);
ok(checkDraft.refusal && checkDraft.refusal.reason === 'facture-non-validee', 'règlement sur brouillon refusé (facture-non-validee)');

console.log(`Factures de démo : ${invoices.length} (${invoices.filter((s) => s.status === rules.DRAFT).length} brouillons, ${invoices.filter((s) => s.status === rules.VALID).length} validées), ${payments.length} règlements liés, 1 avoir`);
Object.entries(EXPECTED).forEach(([key, exp]) => {
  const sale = byKey(key);
  const s = exp.settlement === null ? null : rules.invoiceSettlement(state, sale, allocation);
  console.log(`  ${key} ${sale.number.padEnd(16)} ${String(sale.total).padStart(8)} FCFA  ${(s ? s.status : 'brouillon').padEnd(22)} payé ${s ? s.paid : 0}`);
});
console.log(`\nTOUS LES TESTS FACTURES DE DÉMO : OK (${checks} vérifications)`);
