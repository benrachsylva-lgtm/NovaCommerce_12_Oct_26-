/* Test de non-régression : avances clients, remboursements d'avoirs, trop-perçus.
 * Exécute le VRAI code de app.js (soldes, plafonds, prorata FIFO, journal) et
 * vérifie le panneau Guide, le câblage UI et la persistance desktop (main.cjs).
 * Lancer avec : npm run test:credit */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const NL = String.fromCharCode(10);
const appSource = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const appLines = appSource.split(NL);
const mainSource = fs.readFileSync(path.join(__dirname, '..', 'desktop', 'main.cjs'), 'utf8');

function extract(marker) {
  const start = appLines.findIndex((line) => line.indexOf(marker) >= 0);
  if (start < 0) throw new Error('bloc introuvable : ' + marker);
  const first = appLines[start];
  if (first.indexOf('{') < 0 && first.indexOf('}') < 0 && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    const line = appLines[i];
    for (const ch of line) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join(NL);
  }
  throw new Error('bloc non terminé : ' + marker);
}

const blocks = [extract('  const num = '), extract('  const money = ')];
['saleTotal', 'saleMargin', 'creditNoteTotal', 'creditNoteMargin', 'validSales', 'validCreditNotes',
  'creditNotesTotalForClient', 'creditSalesTotal', 'creditPaymentsTotal', 'validRefunds', 'clientRefundsTotal',
  'clientPositionValues', 'creditNoteRefunded', 'noteRefundableMax', 'refundValidation', 'noteOverpayment',
  'creditNoteSale', 'noteBelongsToCredit', 'creditNoteAdjustmentsBySale', 'creditCollectionRatios',
  'saleCollectedMargin', 'collectedMarginOf', 'refreshClientReceivables', 'clientLedger', 'paymentLabel',
  'userName'].forEach((name) => blocks.push(extract('  function ' + name + '(')));

const stubs = [
  'let state = null;',
  'function productById() { return null; }',
  "function mkSale(id, payment, clientId, date, number, qty, unitPrice, costPrice) { return { id: id, status: 'Validée', payment: payment, clientId: clientId, date: date, number: number, items: [{ productId: 'p1', quantity: qty, unitPrice: unitPrice, costPrice: costPrice }] }; }",
  "function mkNote(id, status, payment, clientId, saleId, qty, unitPrice, costPrice) { return { id: id, status: status, payment: payment, clientId: clientId, originalSaleId: saleId, lines: [{ productId: 'p1', quantity: qty, unitPrice: unitPrice, costPrice: costPrice }] }; }",
  "function mkClient(id, opening) { return { id: id, name: 'Client ' + id, openingReceivable: opening, receivable: 0, advance: 0 }; }",
  "function mkPayment(id, clientId, amount) { return { id: id, status: 'Validé', clientId: clientId, amount: amount, date: '2026-09-15' }; }",
  "function mkRefund(id, number, noteId, notePayment, clientId, amount) { return { id: id, number: number, status: 'Validée', noteId: noteId, notePayment: notePayment, clientId: clientId, amount: amount, date: '2026-09-21', method: 'cash' }; }",
].join(NL);

const scenarios = [
  "state = { users: [{ id: 'u1', name: 'Caissier' }], clients: [mkClient('ca', 0), mkClient('cb', 0)],",
  "  sales: [mkSale('s1', 'credit', 'ca', '2026-09-02', 'V-001', 10, 10000, 6000), mkSale('s2', 'credit', 'ca', '2026-09-10', 'V-002', 5, 10000, 6000), mkSale('s3', 'cash', 'counter', '2026-09-03', 'V-003', 5, 10000, 6000)],",
  "  creditNotes: [], customerPayments: [], refunds: [] };",
  "refreshClientReceivables();",
  "assert.strictEqual(state.clients[0].receivable, 150000, 'T1 encours');",
  "assert.strictEqual(state.clients[0].advance, 0, 'T1 avance');",
  "report.push('T1 position de base : encours 150000, avance 0');",
  "state.customerPayments = [mkPayment('p1', 'ca', 170000)];",
  "refreshClientReceivables();",
  "assert.strictEqual(state.clients[0].receivable, 0, 'T2 encours');",
  "assert.strictEqual(state.clients[0].advance, 20000, 'T2 avance');",
  "report.push('T2 trop-perçu 170000 sur 150000 : avance 20000');",
  "state.sales.push(mkSale('s4', 'credit', 'ca', '2026-09-20', 'V-004', 5, 10000, 6000));",
  "refreshClientReceivables();",
  "assert.strictEqual(state.clients[0].receivable, 30000, 'T3 encours');",
  "assert.strictEqual(state.clients[0].advance, 0, 'T3 avance');",
  "report.push('T3 nouvelle vente 50000 : avance imputée, encours 30000');",
  "state = { users: [{ id: 'u1', name: 'Caissier' }], clients: [mkClient('ca', 0)],",
  "  sales: [mkSale('s1', 'credit', 'ca', '2026-09-02', 'V-001', 10, 10000, 6000), mkSale('s3', 'cash', 'counter', '2026-09-03', 'V-003', 5, 10000, 6000)],",
  "  creditNotes: [mkNote('n1', 'Validée', 'credit', 'ca', 's1', 10, 10000, 6000), mkNote('n3', 'Validée', 'cash', 'counter', 's3', 5, 10000, 6000)],",
  "  customerPayments: [mkPayment('p1', 'ca', 60000)], refunds: [] };",
  "state.creditNotes[0].number = 'AV-001'; state.creditNotes[1].number = 'AV-002';",
  "refreshClientReceivables();",
  "assert.strictEqual(state.clients[0].receivable, 0, 'T4 encours');",
  "assert.strictEqual(state.clients[0].advance, 60000, 'T4 avance');",
  "assert.strictEqual(noteOverpayment(state.creditNotes[0], 0), 60000, 'T4 trop-perçu');",
  "assert.strictEqual(noteOverpayment(state.creditNotes[0], 10000), 50000, 'T4 trop-perçu delta');",
  "assert.strictEqual(noteOverpayment(state.creditNotes[1], 0), 0, 'T4 comptant ignoré');",
  "report.push('T4 avoir 100000 + règlement 60000 : avance 60000, trop-perçu 60000');",
  "assert.strictEqual(noteRefundableMax(state.creditNotes[0]), 60000, 'T5 plafond crédit');",
  "assert.strictEqual(refundValidation(state.creditNotes[0], 70000).ok, false, 'T5 plafond dépassé');",
  "assert.strictEqual(refundValidation(state.creditNotes[0], 25000).ok, true, 'T5 montant ok');",
  "assert.strictEqual(refundValidation(state.creditNotes[0], 0).ok, false, 'T5 montant nul');",
  "assert.strictEqual(noteRefundableMax(mkNote('nx', 'En cours', 'credit', 'ca', 's1', 1, 10000, 6000)), 0, 'T5 brouillon');",
  "assert.strictEqual(noteRefundableMax(state.creditNotes[1]), 50000, 'T5 comptant sans cap avance');",
  "assert.strictEqual(refundValidation(state.creditNotes[1], 50000).ok, true, 'T5 comptant ok');",
  "assert.strictEqual(noteRefundableMax(mkNote('ng', 'Validée', 'credit', 'ghost', 's1', 1, 10000, 6000)), 0, 'T5 client inconnu');",
  "report.push('T5 plafonds : crédit ≤ avance, comptant ≤ reste, brouillon 0');",
  "state.refunds = [mkRefund('r1', 'REM-0001', 'n1', 'credit', 'ca', 25000), { id: 'rx', status: 'Annulée', noteId: 'n1', notePayment: 'credit', clientId: 'ca', amount: 999999 }];",
  "refreshClientReceivables();",
  "assert.strictEqual(state.clients[0].advance, 35000, 'T6 avance après remboursement');",
  "assert.strictEqual(creditNoteRefunded('n1'), 25000, 'T6 total remboursé');",
  "assert.strictEqual(noteRefundableMax(state.creditNotes[0]), 35000, 'T6 plafond résiduel');",
  "assert.strictEqual(clientRefundsTotal('ca'), 25000, 'T6 total client');",
  "report.push('T6 remboursement 25000 : avance 35000, annulé ignoré');",
  "state.refunds.push(mkRefund('r2', 'REM-0002', 'n3', 'cash', 'counter', 50000));",
  "refreshClientReceivables();",
  "assert.strictEqual(state.clients[0].advance, 35000, 'T7 avance inchangée');",
  "assert.strictEqual(clientRefundsTotal('ca'), 25000, 'T7 total crédit seul');",
  "assert.strictEqual(refundValidation(state.creditNotes[1], 1000).ok, false, 'T7 comptant soldé');",
  "report.push('T7 remboursement comptant : position crédit inchangée');",
  "state = { users: [{ id: 'u1', name: 'Caissier' }], clients: [mkClient('ca', 0)],",
  "  sales: [mkSale('s1', 'credit', 'ca', '2026-09-02', 'V-001', 10, 10000, 6000), mkSale('s2', 'credit', 'ca', '2026-09-10', 'V-002', 5, 10000, 6000)],",
  "  creditNotes: [], customerPayments: [mkPayment('p1', 'ca', 120000)], refunds: [] };",
  "const before = creditCollectionRatios();",
  "assert.strictEqual(before.ratios.s1, 1, 'T8 ratio s1');",
  "assert.strictEqual(before.ratios.s2, 0.4, 'T8 ratio s2');",
  "assert.strictEqual(saleCollectedMargin(state.sales[0], before), 40000, 'T8 marge s1');",
  "assert.strictEqual(saleCollectedMargin(state.sales[1], before), 8000, 'T8 marge s2');",
  "state.refunds = [mkRefund('r1', 'REM-0001', 'n1', 'credit', 'ca', 10000)];",
  "const after = creditCollectionRatios();",
  "assert.deepStrictEqual(after, before, 'T8 ratios intacts');",
  "assert.strictEqual(saleCollectedMargin(state.sales[1], after), 8000, 'T8 marge intacte');",
  "Object.values(after.ratios).forEach((ratio) => assert.ok(ratio >= 0 && ratio <= 1, 'T8 ratio borné'));",
  "report.push('T8 FIFO : ratios {s1:1, s2:0.4} inchangés malgré remboursement');",
  "state = { users: [{ id: 'u1', name: 'Caissier' }], clients: [mkClient('ca', 0)], sales: [mkSale('s1', 'credit', 'ca', '2026-09-02', 'V-001', 10, 10000, 6000)], creditNotes: [], customerPayments: [mkPayment('p1', 'ca', 100000)], refunds: [] };",
  "refreshClientReceivables();",
  "assert.strictEqual(state.clients[0].receivable, 0, 'T9 encours');",
  "assert.strictEqual(state.clients[0].advance, 0, 'T9 avance');",
  "report.push('T9 règlement exact : avance 0 (non-régression)');",
  "state = { users: [{ id: 'u1', name: 'Caissier' }], clients: [mkClient('ca', 0)],",
  "  sales: [mkSale('s1', 'credit', 'ca', '2026-09-02', 'V-001', 10, 10000, 6000)],",
  "  creditNotes: [], customerPayments: [mkPayment('p1', 'ca', 60000)],",
  "  refunds: [mkRefund('r1', 'REM-0001', 'n1', 'credit', 'ca', 25000), mkRefund('r2', 'REM-0002', 'n3', 'cash', 'counter', 50000)] };",
  "state.refunds[0].noteNumber = 'AV-001';",
  "const ledger = clientLedger('ca');",
  "const refundEntry = ledger.find((entry) => entry.type === 'Remboursement');",
  "assert.ok(refundEntry, 'T10 écriture présente');",
  "assert.strictEqual(refundEntry.debit, 25000, 'T10 débit');",
  "assert.strictEqual(refundEntry.credit, 0, 'T10 crédit');",
  "assert.strictEqual(refundEntry.reference, 'REM-0001', 'T10 référence');",
  "assert.strictEqual(ledger.filter((entry) => entry.type === 'Remboursement').length, 1, 'T10 comptant exclu');",
  "const dates = ledger.map((entry) => entry.sortDate);",
  "assert.deepStrictEqual(dates.slice().sort(), dates, 'T10 tri chrono');",
  "report.push('T10 journal : remboursement en débit, trié, comptant exclu');",
].join(NL);

const report = [];
new Function('assert', 'report', blocks.join(NL) + NL + stubs + NL + scenarios)(assert, report);

function mustContain(source, needle, label) {
  assert.ok(source.indexOf(needle) >= 0, label + ' manquant : ' + needle);
  report.push(label);
}

['Avoirs, avances et remboursements', 'Trop-perçu', 'imputée automatiquement', 'non comptée en charges', 'Rembourser', 'encours − avance']
  .forEach((needle) => mustContain(appSource, needle, 'T11 Guide : ' + needle));
assert.ok(appSource.indexOf('Aucun encours') < 0, 'garde encours-nul supprimée');
report.push('T11 garde « Aucun encours » supprimée');

['CREATE TABLE IF NOT EXISTS refunds (', 'INSERT INTO refunds', 'SELECT * FROM refunds', "collectionChanged(previous, nextState, 'refunds')", "'refunds', 'credit_note_lines'"]
  .forEach((needle) => mustContain(mainSource, needle, 'T12 main.cjs : ' + needle));

["'refund-credit-note': 'sales.reverse'", 'openRefundModal', 'openOverpaymentChoiceModal', 'customer-payment-amount', 'Remboursement d’un avoir']
  .forEach((needle) => mustContain(appSource, needle, 'T13 câblage : ' + needle));
assert.strictEqual(appSource.split("'refund-credit-note'").length - 1, 3, 'T13 occurrences simple-quote (permissions, lecture seule, dispatcher)');
assert.strictEqual(appSource.split('"refund-credit-note"').length - 1, 2, 'T13 boutons (détail avoir, choix trop-perçu)');
report.push('T13 câblage : 3 refs + 2 boutons refund-credit-note');

const guideFiles = ['guides/guide-indicateurs.pdf', 'guides/guide-caissiers.pdf'];
guideFiles.forEach((rel) => {
  ['.', 'www', 'android/app/src/main/assets/public'].forEach((base) => {
    const buf = fs.readFileSync(path.join(__dirname, '..', base, rel));
    assert.ok(buf.length > 10000, 'T14 taille ' + base + '/' + rel);
    assert.strictEqual(buf.toString('latin1', 0, 4), '%PDF', 'T14 PDF ' + base + '/' + rel);
  });
  report.push('T14 guide synchronisé : ' + rel);
});
['Guides téléchargeables', 'print-guide', 'printGuidePdf', 'guide-indicateurs.pdf', 'guide-caissiers.pdf'].forEach((needle) => mustContain(appSource, needle, 'T14 appli : ' + needle));
const pkgGuides = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
assert.ok(pkgGuides.build.files.indexOf('guides/**/*') >= 0, 'T14 electron inclus');
report.push('T14 electron : guides empaquetés');
const swSource = fs.readFileSync(path.join(__dirname, '..', 'service-worker.js'), 'utf8');
guideFiles.forEach((rel) => mustContain(swSource, './' + rel, 'T14 hors-ligne : ' + rel));
console.log(report.join(NL));
console.log('test:credit — ' + report.length + ' vérifications OK');
