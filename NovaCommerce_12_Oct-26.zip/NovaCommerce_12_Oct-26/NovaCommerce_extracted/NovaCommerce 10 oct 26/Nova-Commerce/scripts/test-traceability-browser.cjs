// Test navigateur : traçabilité facturation / encaissements sur les reçus et les rapports.
// Parcours réel sur la base de démonstration (profil Gérant de test) :
//   1. encaissement partiel d'une facture déjà partiellement payée → reçu (rang, net, avant règlement, solde) ;
//   2. détail de facture → bouton « Reçu » sur chaque règlement ;
//   3. impression d'une facture → document « Facture » avec ses règlements (et non un ticket « À crédit ») ;
//   4. rapport des ventes → tableau « Factures et encaissements » et répartition « Facture à encaisser ».
// Lancer avec : BASE_URL=http://127.0.0.1:4190/index.html NODE_PATH=<dossier contenant puppeteer> node scripts/test-traceability-browser.cjs
const puppeteer = require('puppeteer');
const crypto = require('crypto');
const KEY = 'nova-commerce-state-v1';
const SALT = 'nova-test-traceabilite';
const HASH = `pbkdf2-sha256$${SALT}$120000$${crypto.pbkdf2Sync('Test-1234!', SALT, 120000, 32, 'sha256').toString('hex')}`;
const BASE = process.env.BASE_URL || 'http://127.0.0.1:4190/index.html';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let failures = 0;
const check = (ok, label, detail = '') => { console.log(`${ok ? 'OK   ' : 'ECHEC'} ${label}${detail ? ' — ' + detail : ''}`); if (!ok) failures += 1; };

(async () => {
  const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 1000 });
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e.message)));
  page.on('dialog', (d) => d.accept());
  try {
    await page.goto(BASE, { waitUntil: 'networkidle0' });
    await page.waitForSelector('[data-database-mode="demo"]', { timeout: 30000 });
    await sleep(1500);
    await page.evaluate(() => document.querySelector('[data-database-mode="demo"]').click());
    await sleep(2500);
    await page.waitForFunction(() => { const i = document.querySelector('input[name="username"]'); return i && i.offsetParent !== null; }, { timeout: 30000 });
    await page.evaluate((key, hash) => {
      const s = JSON.parse(localStorage.getItem(key));
      const u = s.users.find((x) => x.username === 'mariam');
      u.passwordHash = hash; u.profile = 'Gérant';
      localStorage.setItem(key, JSON.stringify(s));
    }, KEY, HASH);
    await page.reload({ waitUntil: 'networkidle0' });
    await page.waitForFunction(() => { const i = document.querySelector('input[name="username"]'); return i && i.offsetParent !== null; }, { timeout: 30000 });
    await page.type('input[name="username"]', 'mariam');
    await page.type('input[name="password"]', 'Test-1234!');
    await page.keyboard.press('Enter');
    await page.waitForSelector('[data-view="collect"]', { timeout: 30000 });
    // Capture le contenu de #print-root au moment de l'impression (le rappel de printCurrentPage le vide ensuite).
    await page.evaluate(() => { window.__printed = ''; window.print = () => { window.__printed = document.querySelector('#print-root')?.innerHTML || ''; }; });

    const go = async (view) => {
      try { await page.click(`[data-view="${view}"]`, { timeout: 4000 }); } catch (_) { await page.evaluate((v) => document.querySelector(`[data-view="${v}"]`)?.click(), view); }
      await sleep(700);
    };
    const modalText = () => page.evaluate(() => document.querySelector('#modal-root .modal')?.innerText || '');
    const clickRowAction = (action, invoiceNumber) => page.evaluate((a, n) => {
      const row = Array.from(document.querySelectorAll('tr, .data-row')).find((r) => r.innerText.includes(n));
      const btn = row && Array.from(row.querySelectorAll(`[data-action="${a}"]`)).find((b) => b.offsetParent !== null);
      if (!btn) return false; btn.click(); return true;
    }, action, invoiceNumber);

    // 1. Encaissement partiel sur FAC-260930-004 (déjà partiellement payée)
    await go('collect');
    const target = 'FAC-260930-004';
    await page.waitForSelector('#collect-search', { timeout: 15000 });
    await page.type('#collect-search', target);
    await sleep(500);
    check(await clickRowAction('open-invoice-payment', target), 'caisse : bouton Encaisser de ' + target + ' présent');
    await sleep(600);
    await page.evaluate(() => { const i = document.querySelector('#invoice-payment-form [name="amount"]'); i.value = ''; });
    await page.type('#invoice-payment-form [name="amount"]', '1000');
    await page.click('[data-invoice-pay-submit]');
    await sleep(900);
    const receipt = await modalText();
    const rank = receipt.match(/Règlement\s+n° (\d+) sur (\d+)/);
    check(/Reçu REG-/.test(receipt), 'reçu : numéro de règlement REG- affiché');
    check(/Facture\s+FAC-260930-004 du/.test(receipt), 'reçu : facture et date de facturation');
    check(/Net facturé/.test(receipt) && /Encaissé avant ce règlement/.test(receipt), 'reçu : net facturé et encaissé avant ce règlement');
    check(rank && Number(rank[1]) === Number(rank[2]) && Number(rank[2]) >= 2, 'reçu : rang du règlement', rank ? `n° ${rank[1]} sur ${rank[2]}` : 'absent');
    check(/Solde restant/.test(receipt), 'reçu : solde restant');
    const regNumber = (receipt.match(/REG-[\w-]+/) || [''])[0];
    await page.evaluate(() => document.querySelector('#modal-root [data-close-modal]')?.click());
    await sleep(400);

    // 2. Détail de facture : bouton Reçu sur chaque règlement
    check(await clickRowAction('view-invoice', target), 'facturation/caisse : ouverture du détail ' + target);
    await sleep(700);
    const receiptButtons = await page.evaluate(() => document.querySelectorAll('#modal-root .modal [data-action="print-payment-receipt"]').length);
    check(receiptButtons >= 2, 'détail : bouton « Reçu » sur chaque règlement validé', `${receiptButtons} bouton(s)`);

    // 3. Impression d'une facture : document facture
    await page.evaluate(() => Array.from(document.querySelectorAll('#modal-root .modal button')).find((b) => b.innerText.trim() === 'Imprimer')?.click());
    await sleep(700);
    const printed = await page.evaluate(() => window.__printed || '');
    check(/Facture FAC-260930-004/.test(printed), 'impression : document « Facture » avec son numéro');
    check(/Solde à encaisser/.test(printed) && /Encaissements/.test(printed), 'impression : totaux et liste des encaissements');
    check(/Le total facturé n’est pas un encaissement/.test(printed), 'impression : mention « facturé ≠ encaissé »');
    check(regNumber && printed.includes(regNumber), 'impression : le règlement récent figure dans le document', regNumber);
    check(!/À crédit/.test(printed), 'impression : pas de mention « À crédit » sur la facture');
    await page.evaluate(() => { document.querySelector('#modal-root [data-close-modal]')?.click(); });
    await sleep(300);

    // 4a. Rapport des ventes (imprimable) : journal facturé / encaissé et répartition
    await go('reports');
    await page.evaluate(() => { window.__printed = ''; });
    const clickedReport = await page.evaluate(() => { const b = document.querySelector('[data-action="print-full-report"][data-report="ventes"]'); if (!b) return false; b.click(); return true; });
    check(clickedReport, 'rapports : bouton « Rapport des ventes » présent');
    await sleep(900);
    const report = await page.evaluate(() => window.__printed || '');
    check(/Factures et encaissements/.test(report), 'rapport des ventes : tableau « Factures et encaissements »');
    check(report.includes(target), 'rapport des ventes : facture ' + target + ' listée');
    check(regNumber && report.includes(regNumber), 'rapport des ventes : règlement ' + regNumber + ' listé', regNumber);
    check(/Facture à encaisser/.test(report), 'rapport des ventes : répartition « Facture à encaisser »');
    check(/non additionn/.test(report), 'rapport des ventes : facturé et encaissé présentés séparément');
    check(!/Factures et encaissements[\s\S]*Aucune facture/.test(report) || report.includes(target), 'rapport des ventes : journal non vide');

    // 4c. Créances (imprimable) : « Derniers règlements » avec colonnes Facture et Caissier
    await go('reports');
    await page.evaluate(() => { window.__printed = ''; });
    const clickedDebts = await page.evaluate(() => { const b = document.querySelector('[data-action="print-full-report"][data-report="creances"]'); if (!b) return false; b.click(); return true; });
    check(clickedDebts, 'rapports : bouton « Rapport des créances » présent');
    await sleep(900);
    const debts = await page.evaluate(() => window.__printed || '');
    check(/Derniers règlements/.test(debts) && /<th>Facture<\/th>/.test(debts) && /<th>Caissier<\/th>/.test(debts), 'créances : « Derniers règlements » avec colonnes Facture et Caissier');
    check(debts.includes(regNumber), 'créances : règlement ' + regNumber + ' listé avec sa facture');

    // 4b. Bilan des ventes à l'écran : la répartition des paiements ne classe plus les factures dans « À crédit »
    await go('sales-report');
    const screen = await page.evaluate(() => document.body.innerText);
    check(/Facture à encaisser/.test(screen), 'bilan des ventes (écran) : compartiment « Facture à encaisser »');

    check(errors.length === 0, 'aucune erreur JavaScript', errors.slice(0, 3).join(' | '));
  } catch (e) {
    failures += 1;
    console.log('ECHEC (exception) — ' + e.message);
  } finally {
    await browser.close();
  }
  console.log(failures === 0 ? '\nTOUS LES TESTS TRAÇABILITÉ (navigateur) : OK' : `\n${failures} échec(s)`);
  process.exit(failures === 0 ? 0 : 1);
})();
