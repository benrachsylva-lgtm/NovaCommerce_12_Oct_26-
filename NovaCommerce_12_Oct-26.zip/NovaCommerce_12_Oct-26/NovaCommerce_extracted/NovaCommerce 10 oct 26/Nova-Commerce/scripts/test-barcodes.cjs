/* Test de non-régression : codes-barres des articles et scan dans la vente.
 * - Exécute le VRAI code de app.js extrait (validation GS1, unicité, génération, rendu Code 128 / EAN, décision de scan).
 * - Compare le rendu aux motifs de référence (bwip-js, vérifié hors projet) : Code 128 (jeux B et C), EAN-13, UPC-A, EAN-8.
 * - Exécute la migration SQLite et l'aller-retour réel de desktop/main.cjs si better-sqlite3 est installé.
 * Lancer avec : npm run test:barcodes */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');

const NL = String.fromCharCode(10);
const ROOT = path.join(__dirname, '..');
const appLines = fs.readFileSync(path.join(ROOT, 'app.js'), 'utf8').split(NL);
const mainSource = fs.readFileSync(path.join(ROOT, 'desktop', 'main.cjs'), 'utf8');

function extract(marker) {
  const start = appLines.findIndex((line) => line.indexOf(marker) >= 0);
  if (start < 0) throw new Error('bloc introuvable : ' + marker);
  const first = appLines[start];
  if (first.indexOf('{') < 0 && first.indexOf('}') < 0 && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join(NL);
  }
  throw new Error('bloc non terminé : ' + marker);
}

const constantNames = ['CODE128_PATTERNS', 'CODE128_START_B', 'CODE128_START_C', 'CODE128_STOP', 'EAN_L_CODES', 'EAN_G_CODES', 'EAN_R_CODES', 'EAN13_PARITY', 'BARCODE_INTERNAL_RE', 'BARCODE_QUIET_ZONE', 'GS1_LENGTH_TYPES'];
const functionNames = ['normalizeBarcode', 'gs1CheckDigit', 'barcodeCheck', 'barcodeKey', 'findProductByBarcode', 'nextInternalBarcode', 'code128Symbols', 'ean13Bits', 'ean8Bits', 'bitsToWidths', 'barcodeWidths', 'barcodeSvg', 'resolveCartAddition', 'resolveScanForCart'];
const blocks = [extract('  const num = '), extract('  const esc = ')].filter(Boolean);
constantNames.forEach((name) => blocks.push(extract(`  const ${name} = `)));
functionNames.forEach((name) => blocks.push(extract(`  function ${name}(`)));
const context = {
  state: { products: [], stores: [] },
  esc: (text) => String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'),
  Number, String, Math, Set, Map, Array, Object, JSON, RegExp, Error,
};
vm.createContext(context);
vm.runInContext(blocks.join(NL) + NL + 'globalThis.api = { ' + [...constantNames, ...functionNames].join(', ') + ' };', context);
const api = context.api;

// Vérifie que le bloc extrait contient bien la fonction num (utilisée par resolveCartAddition)
context.num = (value) => Number(value) || 0;

let checks = 0;
const ok = (name, fn) => { try { fn(); checks += 1; console.log(`  ✓ ${name}`); } catch (error) { console.log(`  ✗ ${name} — ${error.message}`); throw error; } };
const widthsOf = (value) => api.barcodeWidths(value).widths.join(',');

console.log('1. Validation des codes commerciaux (clé de contrôle GS1)');
ok('EAN-13 valides acceptés', () => ['4006381333931', '5901234123457'].forEach((code) => assert.strictEqual(api.barcodeCheck(code).valid, true, code)));
ok('EAN-13 à clé fausse refusé avec un motif clair', () => { const r = api.barcodeCheck('4006381333932'); assert.strictEqual(r.valid, false); assert.match(r.reason, /clé de contrôle EAN-13/); });
ok('EAN-8 et UPC-A valides / invalides', () => {
  assert.strictEqual(api.barcodeCheck('96385074').type, 'EAN-8');
  assert.strictEqual(api.barcodeCheck('012345678905').type, 'UPC-A');
  assert.strictEqual(api.barcodeCheck('96385075').valid, false);
  assert.strictEqual(api.barcodeCheck('012345678906').valid, false);
});
ok('texte ASCII imprimable accepté en Code 128, caractères hors ASCII refusés', () => {
  assert.deepStrictEqual([api.barcodeCheck('NC-00000001').type, api.barcodeCheck('ABC-123').type], ['Interne', 'Code 128']);
  assert.strictEqual(api.barcodeCheck('CAFÉ').valid, false);
  assert.strictEqual(api.barcodeCheck('A'.repeat(49)).valid, false);
});
ok('valeur vide = pas de code-barres (article sans code accepté)', () => { const r = api.barcodeCheck('   '); assert.strictEqual(r.valid, true); assert.strictEqual(r.type, ''); });

console.log('2. Normalisation, zéros initiaux et unicité');
ok('espaces de bord supprimés, espaces internes des codes numériques supprimés', () => { assert.strictEqual(api.normalizeBarcode('  4006 381 333931 '), '4006381333931'); });
ok('zéros initiaux conservés (0012345 ≠ 12345)', () => { assert.strictEqual(api.normalizeBarcode('0012345'), '0012345'); assert.notStrictEqual(api.barcodeKey('0012345'), api.barcodeKey('12345')); });
ok('UPC-A et EAN-13 précédé d’un zéro sont le même article', () => assert.strictEqual(api.barcodeKey('012345678905'), api.barcodeKey('0012345678905')));
const catalogue = [
  { id: 'a', code: 'A', name: 'Eau', barcode: '4006381333931', active: true },
  { id: 'b', code: 'B', name: 'Ancien', barcode: '', active: false },
  { id: 'c', code: 'C', name: 'Zéro', barcode: '0012345', active: true },
];
ok('recherche par code-barres exact', () => assert.strictEqual(api.findProductByBarcode('4006381333931', catalogue).id, 'a'));
ok('code inconnu → aucun article', () => assert.strictEqual(api.findProductByBarcode('5901234123457', catalogue), null));
ok('article inactif toujours retrouvé (pour signaler « inactif »)', () => assert.strictEqual(api.findProductByBarcode('0012345', catalogue).id, 'c'));
ok('un article ne se considère pas en doublon de lui-même', () => assert.strictEqual(api.findProductByBarcode('4006381333931', catalogue, 'a'), null));
ok('doublon détecté par équivalence UPC-A / EAN-13', () => assert.strictEqual(api.findProductByBarcode('0012345678905', [{ id: 'x', barcode: '012345678905' }]).id, 'x'));

console.log('3. Génération des codes internes');
ok('premier code interne NC-00000001 dans un catalogue sans code interne', () => assert.strictEqual(api.nextInternalBarcode(catalogue), 'NC-00000001'));
ok('numéro suivant après le plus haut existant, sans réutilisation', () => assert.strictEqual(api.nextInternalBarcode([{ barcode: 'NC-00000007' }, { barcode: 'NC-00000002' }]), 'NC-00000008'));
ok('deux générations successives sont différentes', () => { const list = []; const first = api.nextInternalBarcode(list); list.push({ barcode: first }); assert.notStrictEqual(first, api.nextInternalBarcode(list)); });
ok('les codes commerciaux ne perturbent pas la numérotation', () => assert.strictEqual(api.nextInternalBarcode([{ barcode: '4006381333931' }]), 'NC-00000001'));

console.log('4. Rendu Code 128 et EAN (référence bwip-js)');
ok('Code 128 jeu B : « Ab1 » identique à la référence', () => assert.strictEqual(widthsOf('Ab1'), '2,1,1,2,1,4,1,1,1,3,2,3,1,2,1,4,2,1,1,2,3,2,2,1,2,3,1,2,1,2,2,3,3,1,1,1,2'));
ok('Code 128 jeu B : « ABC-123 » identique à la référence', () => assert.strictEqual(widthsOf('ABC-123'), '2,1,1,2,1,4,1,1,1,3,2,3,1,3,1,1,2,3,1,3,1,3,2,1,1,2,2,1,3,2,1,2,3,2,2,1,2,2,3,2,1,1,2,2,1,1,3,2,1,1,2,4,1,2,2,3,3,1,1,1,2'));
ok('Code 128 jeu C : « 1234567890 » identique à la référence (pas un format GS1)', () => assert.strictEqual(widthsOf('1234567890'), '2,1,1,2,3,2,1,1,2,2,3,2,1,3,1,1,2,3,3,3,1,1,2,1,2,4,1,1,1,2,2,1,4,1,2,1,1,2,4,2,1,1,2,3,3,1,1,1,2'));
ok('8 chiffres = format EAN-8 : clé fausse refusée', () => assert.strictEqual(api.barcodeCheck('12345678').valid, false));
ok('EAN-13 « 4006381333931 » identique à la référence (95 modules)', () => { assert.strictEqual(widthsOf('4006381333931'), '1,1,1,3,2,1,1,1,1,2,3,1,1,1,4,1,4,1,1,3,1,2,1,1,2,2,2,1,1,1,1,1,1,4,1,1,1,4,1,1,1,4,1,1,3,1,1,2,1,4,1,1,2,2,2,1,1,1,1'); });
ok('UPC-A « 012345678905 » identique à la référence', () => assert.strictEqual(widthsOf('012345678905'), '1,1,1,3,2,1,1,2,2,2,1,2,1,2,2,1,4,1,1,1,1,3,2,1,2,3,1,1,1,1,1,1,1,1,1,4,1,3,1,2,1,2,1,3,3,1,1,2,3,2,1,1,1,2,3,1,1,1,1'));
ok('EAN-8 « 96385074 » identique à la référence', () => assert.strictEqual(widthsOf('96385074'), '1,1,1,3,1,1,2,1,1,1,4,1,4,1,1,1,2,1,3,1,1,1,1,1,1,2,3,1,3,2,1,1,1,3,1,2,1,1,3,2,1,1,1'));
ok('Code 128 : les motifs de contrôle hors ASCII (valeurs 95 à 102) sont présents', () => { for (let v = 0; v <= 102; v += 1) assert.match(api.CODE128_PATTERNS[v], /^[1-4]{6}$/, `motif ${v}`); });
ok('un code interne est rendu en Code 128, un EAN-13 en EAN-13', () => { assert.strictEqual(api.barcodeWidths('NC-00000001').symbology, 'Code 128'); assert.strictEqual(api.barcodeWidths('4006381333931').symbology, 'EAN-13'); });
ok('SVG : une barre par élément sombre, texte lisible, code invalide sans rendu', () => {
  const svg = api.barcodeSvg('4006381333931');
  assert.match(svg, /^<svg /); assert.match(svg, />4006381333931</);
  const bars = (svg.match(/<rect x=/g) || []).length;
  assert.strictEqual(bars, api.barcodeWidths('4006381333931').widths.filter((_, i) => i % 2 === 0).length);
  assert.strictEqual(api.barcodeSvg('4006381333932'), '');
});

console.log('5. Décision de scan dans le panier (même règle que la recherche manuelle)');
const store = 'st1';
const products = [
  { id: 'p1', name: 'Eau', code: 'P1', barcode: '4006381333931', active: true, stock: 5 },
  { id: 'p2', name: 'Pain', code: 'P2', barcode: 'NC-00000001', active: true, stock: 0 },
  { id: 'p3', name: 'Vieux', code: 'P3', barcode: '5901234123457', active: false, stock: 9 },
];
const stockOf = (product) => product.stock;
const makeCtx = (cart, extra = {}) => ({ products, cart, allowNegative: false, storeFor: () => store, stockFor: (product) => stockOf(product), priceFor: (product) => (product.id === 'p1' ? 150 : 20), ...extra });
ok('code inconnu (EAN-13 valide absent du catalogue) → « notfound », panier intact', () => { const cart = []; assert.strictEqual(api.resolveScanForCart('9780306406157', makeCtx(cart)).status, 'notfound'); assert.strictEqual(cart.length, 0); });
ok('code invalide → « invalid » avec motif', () => { const r = api.resolveScanForCart('4006381333932', makeCtx([])); assert.strictEqual(r.status, 'invalid'); assert.match(r.reason, /clé de contrôle/); });
ok('article inactif → « inactive »', () => assert.strictEqual(api.resolveScanForCart('5901234123457', makeCtx([])).status, 'inactive'));
ok('premier scan : ligne nouvelle, quantité 1, prix et magasin appliqués', () => { const r = api.resolveScanForCart('4006381333931', makeCtx([])); assert.strictEqual(r.status, 'added'); assert.strictEqual(r.quantity, 1); assert.strictEqual(r.unitPrice, 150); assert.strictEqual(r.storeId, store); assert.strictEqual(r.existing, false); });
ok('scan répété : quantité +1 sur la ligne existante, prix conservé', () => { const cart = [{ productId: 'p1', storeId: store, quantity: 2, unitPrice: 120 }]; const r = api.resolveScanForCart('4006381333931', makeCtx(cart)); assert.strictEqual(r.quantity, 3); assert.strictEqual(r.unitPrice, 120); assert.strictEqual(r.existing, true); });
ok('stock insuffisant → « stock » avec la quantité disponible, sans ligne ajoutée', () => { const cart = []; const r = api.resolveScanForCart('NC-00000001', makeCtx(cart)); assert.strictEqual(r.status, 'stock'); assert.strictEqual(r.available, 0); assert.strictEqual(cart.length, 0); });
ok('stock négatif autorisé par le paramètre existant : ajout accepté', () => assert.strictEqual(api.resolveScanForCart('NC-00000001', makeCtx([], { allowNegative: true })).status, 'added'));
ok('stock atteint : le dernier scan possible passe, le suivant est refusé', () => {
  const cart = [{ productId: 'p1', storeId: store, quantity: 4, unitPrice: 150 }];
  assert.strictEqual(api.resolveScanForCart('4006381333931', makeCtx(cart)).status, 'added');
  cart[0].quantity = 5;
  assert.strictEqual(api.resolveScanForCart('4006381333931', makeCtx(cart)).status, 'stock');
});
ok('scan vide → « empty »', () => assert.strictEqual(api.resolveScanForCart('   ', makeCtx([])).status, 'empty'));
ok('un scan ne décrémente jamais le stock (fonction pure, aucun effet de bord)', () => { const before = products[0].stock; api.resolveScanForCart('4006381333931', makeCtx([])); assert.strictEqual(products[0].stock, before); });

console.log('6. Desktop : migration et aller-retour SQLite réels');
let Database = null;
try { Database = require('better-sqlite3'); } catch (_) { Database = null; }
if (!Database) {
  console.log('  - better-sqlite3 non installé : migration et aller-retour non exécutés (npm install requis).');
} else {
  const noop = () => {};
  const electron = {
    app: { whenReady: () => new Promise(noop), on: noop, getPath: () => path.join(require('node:os').tmpdir(), 'nova-barcodes-test'), quit: noop, requestSingleInstanceLock: () => true, setAsDefaultProtocolClient: noop, isPackaged: false, getVersion: () => '1.0.0', commandLine: { appendSwitch: noop }, disableHardwareAcceleration: noop, setPath: noop, getAppPath: () => ROOT },
    BrowserWindow: class { constructor() { return { loadFile: noop, on: noop, webContents: { on: noop, send: noop, session: {} } }; } static getAllWindows() { return []; } },
    ipcMain: { handle: noop, on: noop, removeHandler: noop },
    dialog: { showSaveDialog: noop, showOpenDialog: noop, showMessageBox: noop },
    Menu: { buildFromTemplate: () => ({}), setApplicationMenu: noop },
    shell: { openExternal: noop }, session: {}, globalShortcut: { register: noop, unregister: noop },
  };
  const sandbox = {
    require: (name) => (name === 'electron' ? electron : name === 'better-sqlite3' ? Database : name === './barcode-rules.cjs' ? require(path.join(ROOT, 'desktop', 'barcode-rules.cjs')) : name === './invoice-rules.cjs' ? require(path.join(ROOT, 'desktop', 'invoice-rules.cjs')) : require(name)),
    module: { exports: {} }, exports: {}, __dirname: path.join(ROOT, 'desktop'), __filename: path.join(ROOT, 'desktop', 'main.cjs'),
    console, process, Buffer, setTimeout, clearTimeout, setInterval, clearInterval, Promise, URL, TextEncoder, TextDecoder, Date, Math, JSON, Object, Array, Set, Map, String, Number, Boolean, Error, RegExp, Symbol, Uint8Array, ArrayBuffer, Reflect, Proxy, Intl, Function,
  };
  sandbox.global = sandbox; sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(mainSource, sandbox, { filename: 'main.cjs' });
  const run = (code) => vm.runInContext(code, sandbox);
  const stateFixture = `({
    settings: { businessName: 'Test', defaultStoreId: 'st1' }, license: {}, initialSetupCompleted: true, blankDatabase: false,
    categories: [{ id: 'cat1', name: 'Cat', active: true }], stores: [{ id: 'st1', name: 'Magasin', active: true }],
    suppliers: [], supplierProducts: [], deliverers: [], deliveries: [], clients: [], customerPayments: [], supplierPayments: [],
    refunds: [], sales: [], creditNotes: [], stockEntries: [], stockExits: [], stockTransfers: [], expenses: [], orders: [], quotes: [],
    users: [], roles: [], activities: [], inventory: [], inventoryReports: [], inventoryCounts: [], stockMovements: [],
    products: [
      { id: 'p1', code: 'P1', name: 'Eau', categoryId: 'cat1', brand: '', model: '', supplierId: '', storeId: 'st1', purchasePrice: 100, salePrice: 150, wholesalePrice: 0, promoPrice: 0, stockByStore: { st1: 5 }, stock: 5, minStock: 1, maxStock: 10, presentation: 'Pièce', batch: '', expiry: '', barcode: '4006381333931', barcodeType: 'EAN-13', active: true },
      { id: 'p2', code: 'P2', name: 'Pain', categoryId: 'cat1', brand: '', model: '', supplierId: '', storeId: 'st1', purchasePrice: 10, salePrice: 20, wholesalePrice: 0, promoPrice: 0, stockByStore: { st1: 2 }, stock: 2, minStock: 1, maxStock: 10, presentation: 'Pièce', batch: '', expiry: '', barcode: 'NC-00000001', barcodeType: 'Interne', active: true },
      { id: 'p3', code: 'P3', name: 'Sans code', categoryId: 'cat1', brand: '', model: '', supplierId: '', storeId: 'st1', purchasePrice: 1, salePrice: 2, wholesalePrice: 0, promoPrice: 0, stockByStore: {}, stock: 0, minStock: 0, maxStock: 0, presentation: 'Pièce', batch: '', expiry: '', barcode: '', barcodeType: '', active: true }
    ]
  })`;
  ok('schéma neuf : colonnes code-barres, index unique et version 12', () => {
    run("database = new Database(':memory:'); database.pragma('foreign_keys = ON'); createSchema();");
    const cols = run("database.prepare('PRAGMA table_info(products)').all().map((c) => c.name)");
    assert.ok(cols.includes('barcode') && cols.includes('barcode_type'));
    assert.ok(run("!!database.prepare(\"SELECT name FROM sqlite_master WHERE type='index' AND name='idx_products_barcode'\").get()"));
    assert.strictEqual(run("database.prepare(\"SELECT value FROM app_meta WHERE key='schema_version'\").get().value"), '12');
  });
  ok('aller-retour : codes EAN, internes et vides relus à l’identique', () => {
    run(`replaceRelationalState(${stateFixture})`);
    const back = run('buildRelationalState()');
    const byId = Object.fromEntries(back.products.map((p) => [p.id, p]));
    assert.strictEqual(byId.p1.barcode, '4006381333931'); assert.strictEqual(byId.p1.barcodeType, 'EAN-13');
    assert.strictEqual(byId.p2.barcode, 'NC-00000001'); assert.strictEqual(byId.p2.barcodeType, 'Interne');
    assert.strictEqual(byId.p3.barcode, '');
  });
  ok('écriture (evaluateStateWrite) : un code invalide est refusé avec le motif et l’article', () => {
    run(`replaceRelationalState(${stateFixture})`);
    const next = JSON.parse(JSON.stringify(run('buildRelationalState()')));
    const decision = run(`evaluateStateWrite('user-none', ${JSON.stringify(next)})`);
    assert.strictEqual(decision.allowed, true, 'état inchangé accepté');
    next.products.push({ id: 'bad', code: 'BAD-1', name: 'Article fautif', barcode: '4006381333932', stockByStore: {}, stock: 0, active: true });
    const refused = run(`evaluateStateWrite('user-none', ${JSON.stringify(next)})`);
    assert.strictEqual(refused.allowed, false);
    assert.strictEqual(refused.reason, 'code-barres');
    assert.match(refused.detail, /Article fautif/); assert.match(refused.detail, /clé de contrôle EAN-13/);
  });
  ok('écriture : un doublon détenu par un article historique est refusé, les articles historiques sont préservés', () => {
    run(`replaceRelationalState(${stateFixture})`);
    const next = JSON.parse(JSON.stringify(run('buildRelationalState()')));
    next.products.push({ id: 'dup', code: 'DUP-1', name: 'Copie', barcode: '4006381333931', stockByStore: {}, stock: 0, active: true });
    const refused = run(`evaluateStateWrite('user-none', ${JSON.stringify(next)})`);
    assert.strictEqual(refused.allowed, false); assert.strictEqual(refused.reason, 'code-barres');
    assert.match(refused.detail, /« Eau »/);
  });
  ok('écriture : un code libre saisi avec espaces est accepté, persisté normalisé, type recalculé côté base', () => {
    run(`replaceRelationalState(${stateFixture})`);
    const next = JSON.parse(JSON.stringify(run('buildRelationalState()')));
    next.products[2].barcode = ' 9 780306 406157 ';
    next.products[2].barcodeType = 'Forcé';
    const decision = run(`evaluateStateWrite('user-none', ${JSON.stringify(next)})`);
    assert.notStrictEqual(decision.reason, 'code-barres', 'code libre accepté');
    run(`replaceRelationalState(${JSON.stringify(next)})`);
    const back = run('buildRelationalState()');
    const p3 = back.products.find((p) => p.id === 'p3');
    assert.strictEqual(p3.barcode, '9780306406157'); assert.strictEqual(p3.barcodeType, 'EAN-13');
  });
  ok('index unique : un doublon est refusé par la base, les codes vides sont acceptés', () => {
    assert.throws(() => run("database.prepare(\"INSERT INTO products (id, code, name, barcode) VALUES ('dup','DUP','Doublon','4006381333931')\").run()"), /UNIQUE/);
    run("database.prepare(\"INSERT INTO products (id, code, name, barcode) VALUES ('e1','E1','Vide 1',''), ('e2','E2','Vide 2','')\").run()");
  });
  ok('migration d’une base version 10 : articles conservés, colonnes ajoutées', () => {
    run(`database = new Database(':memory:'); database.pragma('foreign_keys = ON');
      database.exec("CREATE TABLE products (id TEXT PRIMARY KEY NOT NULL, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, category_id TEXT NOT NULL DEFAULT '', brand TEXT NOT NULL DEFAULT '', model TEXT NOT NULL DEFAULT '', supplier_id TEXT NOT NULL DEFAULT '', default_store_id TEXT NOT NULL DEFAULT '', purchase_price REAL NOT NULL DEFAULT 0, sale_price REAL NOT NULL DEFAULT 0, wholesale_price REAL NOT NULL DEFAULT 0, promo_price REAL NOT NULL DEFAULT 0, min_stock REAL NOT NULL DEFAULT 0, max_stock REAL NOT NULL DEFAULT 0, presentation TEXT NOT NULL DEFAULT '', batch TEXT NOT NULL DEFAULT '', expiry TEXT NOT NULL DEFAULT '', image TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1)");
      database.exec("INSERT INTO products (id, code, name, sale_price) VALUES ('old1','OLD-1','Ancien article', 990)");
      database.exec("CREATE TABLE app_meta (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)");
      database.exec("INSERT INTO app_meta (key, value) VALUES ('schema_version', '10')");
      createSchema();`);
    const row = run("database.prepare(\"SELECT code, name, sale_price, barcode FROM products WHERE id='old1'\").get()");
    assert.deepStrictEqual({ ...row }, { code: 'OLD-1', name: 'Ancien article', sale_price: 990, barcode: '' });
    assert.strictEqual(run("database.prepare(\"SELECT value FROM app_meta WHERE key='schema_version'\").get().value"), '12');
  });
}

console.log('7. Contrôle côté persistance (desktop/barcode-rules.cjs) et parité avec app.js');
const rules = require(path.join(ROOT, 'desktop', 'barcode-rules.cjs'));
const corpus = ['4006381333931', '4006381333932', '96385074', '96385075', '012345678905', '012345678906', '0012345678905', '1234567890', 'NC-00000001', 'NC-1', 'ABC-123', 'CAFÉ', '', '   ', ' 400 638 133 3931 ', '9780306406157', 'A'.repeat(49)];
ok('parité : normalisation, validation et clé identiques à app.js sur un corpus', () => {
  for (const value of corpus) {
    assert.strictEqual(rules.normalizeBarcode(value), api.normalizeBarcode(value), `normalize ${value}`);
    assert.deepStrictEqual({ ...rules.barcodeCheck(value) }, { ...api.barcodeCheck(value) }, `check ${value}`);
    assert.strictEqual(rules.barcodeKey(value), api.barcodeKey(value), `key ${value}`);
  }
});
const article = (id, name, barcode, code = id.toUpperCase()) => ({ id, name, code, barcode });
ok('refus : code EAN à clé fausse, avec l’article concerné', () => {
  const r = rules.productBarcodeRefusal([], [article('a1', 'Eau', '4006381333932')]);
  assert.strictEqual(r.reason, 'code-barres'); assert.match(r.message, /clé de contrôle EAN-13/); assert.match(r.message, /« Eau »/);
});
ok('refus : doublon, le message nomme l’article qui détient déjà le code', () => {
  const r = rules.productBarcodeRefusal([article('a1', 'Eau', '4006381333931', 'P1')], [article('a1', 'Eau', '4006381333931', 'P1'), article('a2', 'Pain', '4006381333931', 'P2')]);
  assert.ok(r, 'doublon refusé'); assert.match(r.message, /« Eau »/); assert.match(r.message, /P1/);
});
ok('refus : doublon après normalisation (espaces) et doublon interne au même envoi', () => {
  assert.ok(rules.productBarcodeRefusal([], [article('a1', 'Eau', '4006381333931'), article('a2', 'Pain', ' 400 638 133 3931 ')]));
});
ok('refus : UPC-A et EAN-13 avec zéro initial = même produit', () => {
  assert.strictEqual(rules.barcodeCheck('0012345678905').valid, true, 'EAN-13 valide');
  const r = rules.productBarcodeRefusal([], [article('a1', 'Riz', '012345678905'), article('a2', 'Sel', '0012345678905')]);
  assert.ok(r, 'même clé refusée');
});
ok('accepté : article sans code, code libre inédit, code vidé', () => {
  assert.strictEqual(rules.productBarcodeRefusal([], [article('a1', 'Sans code', '')]), null);
  assert.strictEqual(rules.productBarcodeRefusal([], [article('a1', 'Interne', 'NC-00000001'), article('a2', 'Pain', 'ABC-123')]), null);
  assert.strictEqual(rules.productBarcodeRefusal([article('a1', 'Eau', '4006381333931')], [article('a1', 'Eau', '')]), null);
});
ok('historique : un article existant au code invalide n’est pas bloqué s’il n’est pas modifié', () => {
  const legacy = [article('old', 'Ancien', '4006381333932', 'OLD')];
  assert.strictEqual(rules.productBarcodeRefusal(legacy, [article('old', 'Ancien renommé', '4006381333932', 'OLD')]), null);
  assert.strictEqual(rules.productBarcodeRefusal(legacy, [...legacy, article('new', 'Nouveau', '4006381333939', 'NEW')]) !== null, true, 'nouvel article invalide refusé');
});
ok('édition : un article garde son code, un autre prend un code libre', () => {
  const prev = [article('a1', 'Eau', '4006381333931', 'P1'), article('a2', 'Pain', '', 'P2')];
  assert.strictEqual(rules.productBarcodeRefusal(prev, [article('a1', 'Eau', '4006381333931', 'P1'), article('a2', 'Pain', 'NC-00000002', 'P2')]), null);
});

console.log('8. Garde du scan dans la vente (code réel de app.js : permissions, lecture seule, panier)');
{
  const scanNames = ['normalizeBarcode', 'gs1CheckDigit', 'barcodeCheck', 'barcodeKey', 'findProductByBarcode', 'setSaleScanNotice', 'resolveCartAddition', 'resolveScanForCart', 'cartContext', 'applyCartAddition', 'handleSaleScan'];
  const scanBlocks = ['BARCODE_INTERNAL_RE', 'GS1_LENGTH_TYPES'].map((name) => extract(`  const ${name} = `));
  scanNames.forEach((name) => scanBlocks.push(extract(`  function ${name}(`)));
  const scanContext = {
    state: { products: [], settings: { allowNegative: false } }, saleCart: [], saleScanNotice: null, renders: 0,
    allowed: true, readOnly: false, permissionAsked: [], num: (value) => Number(value) || 0,
    isReadOnly: () => scanContext.readOnly,
    requirePermission: (permission) => { scanContext.permissionAsked.push(permission); return scanContext.allowed; },
    render: () => { scanContext.renders += 1; }, filterTarget: () => {}, storeName: (id) => String(id), number: (value) => String(value), money: (value) => `${value} €`,
    productSaleStore: () => 'st1', productPriceForSale: (product) => product.salePrice,
    stockFor: (product, storeId) => Number(product.stockByStore?.[storeId] || 0),
    document: { querySelector: () => null },
    Number, String, Math, Set, Map, Array, Object, JSON, RegExp, Error,
  };
  vm.createContext(scanContext);
  vm.runInContext(scanBlocks.join(NL) + NL + 'globalThis.handleSaleScan = handleSaleScan;', scanContext);
  const catalogue = () => [{ id: 'p1', name: 'Eau', code: 'P1', barcode: '4006381333931', active: true, salePrice: 150, stockByStore: { st1: 3 } }];
  const reset = (cart = []) => { scanContext.state.products = catalogue(); scanContext.saleCart = cart; scanContext.saleScanNotice = null; scanContext.renders = 0; scanContext.permissionAsked = []; };
  ok('scan refusé sans droit sales.create : message d’erreur, panier et stock inchangés', () => {
    reset(); scanContext.allowed = false;
    scanContext.handleSaleScan('4006381333931');
    assert.deepStrictEqual(scanContext.permissionAsked, ['sales.create']);
    assert.strictEqual(scanContext.saleCart.length, 0);
    assert.strictEqual(scanContext.saleScanNotice.kind, 'error');
    assert.match(scanContext.saleScanNotice.text, /ne peut pas préparer une vente/);
    assert.strictEqual(scanContext.state.products[0].stockByStore.st1, 3);
  });
  ok('scan refusé en lecture seule (licence expirée) : aucun ajout au panier', () => {
    reset(); scanContext.readOnly = true;
    scanContext.handleSaleScan('4006381333931');
    assert.strictEqual(scanContext.saleCart.length, 0);
    assert.strictEqual(scanContext.saleScanNotice.kind, 'warning');
    assert.match(scanContext.saleScanNotice.text, /lecture seule/);
    assert.deepStrictEqual(scanContext.permissionAsked, [], 'contrôle de lecture seule avant les droits');
  });
  ok('scan autorisé : ajout qty 1 puis +1 ; le stock n’est jamais modifié par le scan', () => {
    reset(); scanContext.allowed = true; scanContext.readOnly = false;
    scanContext.handleSaleScan('4006381333931');
    scanContext.handleSaleScan('4006381333931');
    assert.strictEqual(scanContext.saleCart.length, 1);
    assert.strictEqual(scanContext.saleCart[0].quantity, 2);
    assert.strictEqual(scanContext.state.products[0].stockByStore.st1, 3);
  });
  ok('scan autorisé sans stock disponible : panier inchangé, quantité disponible annoncée', () => {
    reset([{ productId: 'p1', storeId: 'st1', quantity: 3, unitPrice: 150 }]);
    const before = JSON.stringify(scanContext.saleCart);
    scanContext.handleSaleScan('4006381333931');
    assert.strictEqual(JSON.stringify(scanContext.saleCart), before);
    assert.strictEqual(scanContext.saleScanNotice.kind, 'warning');
    assert.match(scanContext.saleScanNotice.text, /3 unité\(s\) disponible/);
  });
  ok('refus d’un scan ne touche pas une vente déjà en cours (lignes et quantités conservées)', () => {
    const cart = [{ productId: 'p1', storeId: 'st1', quantity: 1, unitPrice: 150 }];
    reset(cart); scanContext.allowed = false;
    scanContext.handleSaleScan('4006381333931');
    assert.deepStrictEqual(scanContext.saleCart, cart);
  });
}

console.log('9. Message de refus affiché à l’utilisateur (describeWriteFailure de app.js)');
{
  const diagBlock = extract('  function describeWriteFailure(');
  const diagContext = { Number, String, Math, Error, RegExp, Object, JSON, navigator: {}, window: {}, storageUsage: () => ({ ratio: 0.1, used: 0, quota: 1 }) };
  vm.createContext(diagContext);
  vm.runInContext(diagBlock + NL + 'globalThis.describeWriteFailure = describeWriteFailure;', diagContext);
  ok('refus code-barres : titre dédié et motif précis (article, valeur) conservés', () => {
    const error = new Error('Code-barres « 4006381333932 » refusé pour l’article « Eau » : clé de contrôle EAN-13 incorrecte.');
    error.code = 'NOVA_BARCODE_REFUSED';
    const d = diagContext.describeWriteFailure(error);
    assert.strictEqual(d.kind, 'barcode'); assert.strictEqual(d.title, 'Code-barres refusé');
    assert.match(d.message, /« Eau »/); assert.match(d.message, /4006381333932/);
  });
}

console.log(`\n${checks} vérifications OK`);
console.log('TOUS LES TESTS CODES-BARRES : OK');
