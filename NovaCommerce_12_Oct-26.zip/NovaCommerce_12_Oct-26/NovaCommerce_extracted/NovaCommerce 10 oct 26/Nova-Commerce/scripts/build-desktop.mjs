import { copyFileSync, mkdirSync, readdirSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const mode = process.argv[2] || 'win';
// Dossier de sortie : `desktop-dist/` par défaut. NOVA_DESKTOP_OUTPUT_DIR permet
// de le rediriger (utile en intégration continue pour ne pas alourdir le dépôt).
const defaultOutput = resolve('desktop-dist');
const outputDirectory = process.env.NOVA_DESKTOP_OUTPUT_DIR ? resolve(process.env.NOVA_DESKTOP_OUTPUT_DIR) : defaultOutput;
// Signature de code désactivée : tous les builds Windows sont non signés
// (voir `win.signExecutable: false` dans package.json ; SmartScreen à l'installation).
const commands = {
  win: ['--win', 'nsis', '--x64'],
  portable: ['--win', 'portable', '--x64'],
  linux: ['--linux', 'AppImage', '--x64'],
  dir: ['--dir']
};

if (!commands[mode]) {
  console.error(`Mode inconnue : ${mode}. Utilisez win, portable, linux ou dir.`);
  process.exit(1);
}

function prepareSqliteBinary() {
  const electronVersion = require('electron/package.json').version;
  const prebuildInstall = require.resolve('prebuild-install/bin.js');
  const targetPlatform = ['win', 'portable'].includes(mode) ? 'win32' : process.platform;
  const targetArch = 'x64';
  const betterSqliteDirectory = resolve('node_modules', 'better-sqlite3');
  console.log(`Préparation du module SQLite pour Electron ${electronVersion} (${targetPlatform}/${targetArch})…`);
  const result = spawnSync(process.execPath, [
    prebuildInstall,
    '--runtime', 'electron',
    '--target', electronVersion,
    '--platform', targetPlatform,
    '--arch', targetArch,
    '--force'
  ], { cwd: betterSqliteDirectory, stdio: 'inherit', shell: false });
  if (result.error) {
    console.error(`ERREUR : impossible de lancer prebuild-install (${result.error.message}).`);
    process.exit(1);
  }
  if (result.status !== 0) {
    console.error('Impossible de récupérer le binaire SQLite compatible avec Electron.');
    console.error('Vérifiez votre connexion réseau puis relancez (les binaires viennent de github.com).');
    process.exit(result.status || 1);
  }
}

prepareSqliteBinary();
// Sous Linux/macOS, le build Windows n'exige Wine que pour extraire l'uninstaller :
// le correctif remplace cette étape par le lecteur NSIS en JavaScript intégré.
if (process.platform !== 'win32' && ['win', 'portable'].includes(mode)) {
  spawnSync(process.execPath, [resolve('scripts', 'patch-nsis-linux.mjs')], { stdio: 'inherit' });
}
mkdirSync(outputDirectory, { recursive: true });
// Utilise l'electron-builder LOCAL (jamais npx) : aucun téléchargement surprise,
// et message clair si `npm install` est manquant ou incomplet.
let electronBuilderCli;
try {
  electronBuilderCli = require.resolve('electron-builder/out/cli/cli.js');
} catch (_) {
  console.error('ERREUR : electron-builder introuvable dans node_modules.');
  console.error('Supprimez le dossier node_modules puis relancez : npm install');
  process.exit(1);
}
const builderArgs = [...commands[mode]];
if (outputDirectory !== defaultOutput) builderArgs.push(`--config.directories.output=${outputDirectory}`);
const result = spawnSync(process.execPath, [electronBuilderCli, ...builderArgs], { stdio: 'inherit', shell: false });
if (result.error) {
  console.error(`ERREUR : impossible de lancer electron-builder (${result.error.message}).`);
  process.exit(1);
}
if (result.status !== 0) process.exit(result.status || 1);

const outputFiles = readdirSync(outputDirectory).filter((file) => {
  if (mode === 'win') return file.endsWith('.exe') && file.includes('Setup');
  if (mode === 'portable') return file.endsWith('.exe');
  if (mode === 'linux') return file.endsWith('.AppImage');
  return false;
});

if (!outputFiles.length) {
  console.log('Packaging terminé. Les artefacts sont dans desktop-dist/.');
  process.exit(0);
}

const source = join(outputDirectory, outputFiles.sort()[0]);
const destination = mode === 'win'
  ? 'NOVA-Commerce-Setup.exe'
  : mode === 'portable'
    ? 'NOVA-Commerce-Portable.exe'
    : 'NOVA-Commerce.AppImage';
copyFileSync(source, destination);
console.log(`Artefact copié : ${destination}`);
if (outputDirectory !== defaultOutput) console.log(`(intermédiaires dans ${outputDirectory})`);
