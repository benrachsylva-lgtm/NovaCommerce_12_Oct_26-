/* Test de non-régression : matrice d’accès exhaustive (Profils & droits).
 * Exécute le VRAI code de app.js (seed + renderRoles) et vérifie que la matrice
 * couvre tous les modules du sidebar (sauf Guide et Contact).
 * Lancer avec : npm run test:roles */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

function extractBlock(startMarker, endLine) {
  const start = appLines.findIndex((line) => line.includes(startMarker));
  const end = appLines.findIndex((line, idx) => idx > start && line === endLine);
  if (start < 0 || end < 0) throw new Error(`bloc introuvable: ${startMarker}`);
  return appLines.slice(start, end + 1).join('\n');
}

const blocks = [
  ...['PROTECTED_ADMIN_USERNAME', 'SEED_PASSWORD_HASHES', 'num', 'esc', 'uid',
    'isoDate', 'isoDateTime', 'number', 'seedState', 'VIEW_PERMISSIONS',
    'MODULE_MANAGE_PERMISSIONS', 'DEFAULT_ROLE_PERMISSIONS'
  ].map((name) => extract(`  const ${name} = `)),
  extractBlock('  const ROLE_MATRIX_MODULES = [', '  ];'),
  ...['dateCode', 'pageHeading', 'statusBadge', 'renderRoles'].map((name) => extract(`  function ${name}(`)),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let currentUser = { id: 'user-admin', profile: 'Administrateur' };
let state = null;
state = seedState();
state.roles.forEach((r) => { r.permissions = DEFAULT_ROLE_PERMISSIONS[r.name] || []; });
// ---------- structure de la matrice ----------
const matrixViews = ROLE_MATRIX_MODULES.flatMap(([, modules]) => modules.map(([view]) => view));
assert.strictEqual(ROLE_MATRIX_MODULES.length, 5, '5 sections');
assert.strictEqual(matrixViews.length, 30, '30 modules (dont Facturation et Factures à encaisser)');
assert.strictEqual(new Set(matrixViews).size, 30, 'vues uniques');
matrixViews.forEach((view) => assert.ok(VIEW_PERMISSIONS[view], 'droit ouverture ' + view));
Object.keys(MODULE_MANAGE_PERMISSIONS).forEach((view) => assert.ok(matrixViews.includes(view), 'gestion rattachée ' + view));
assert.ok(!matrixViews.includes('guide') && !matrixViews.includes('contact'), 'exclusions');
const html = renderRoles();
const report = [];
report.push('Matrice: ' + matrixViews.length + ' modules x ' + state.roles.slice(0, 5).length + ' profils');
// ---------- contenu rendu ----------
['Exploitation', 'Catalogue', 'Stocks', 'Finance', 'Administration'].forEach((g) => assert.ok(html.includes('>' + g + '<'), 'groupe ' + g));
const modules = ['Tableau de bord', 'Nouvelle vente', 'Historique des ventes', 'Clients', 'Livreurs', 'Produits', 'Catégories', 'Magasins', 'Fournisseurs', 'Entrées de stock', 'Sorties de stock', 'Transferts inter-magasins', 'Commandes', 'Inventaire', 'Devis', 'Avoirs &amp; annulations', 'Dettes fournisseurs', 'Bilan des achats', 'Bilan des ventes', 'Dépenses', 'Bilan des dépenses', 'Comptabilité', 'Rapports', 'Utilisateurs', 'Profils &amp; droits', 'Journal d’activité', 'Licence', 'Paramètres'];
modules.push('Facturation', 'Factures à encaisser');
assert.strictEqual(modules.length, 30);
modules.forEach((m) => assert.ok(html.includes('<strong>' + m + '</strong>'), 'module ' + m));
assert.ok(!html.includes('<strong>Guide utilisateur</strong>'), 'guide exclu des lignes');
assert.ok(!html.includes('<strong>Nous contacter</strong>'), 'contact exclu des lignes');
assert.ok(html.includes('Guide utilisateur et Nous contacter exclus.'), 'exclusion annoncée en légende');
assert.ok(!html.includes('data-view="guide"'), 'aucun lien guide');
['sales.create', 'sales.validate', 'sales.reverse', 'clients.view', 'clients.manage', 'deliverers.view', 'deliverers.manage', 'products.view', 'products.manage', 'catalog.manage', 'stores.view', 'stores.manage', 'suppliers.view', 'suppliers.manage', 'stock.view', 'stock.create', 'stock.validate', 'stock.transfer', 'orders.view', 'orders.manage', 'inventory.view', 'inventory.manage', 'quotes.view', 'quotes.manage', 'reports.view', 'reports.export', 'expenses.view', 'expenses.manage', 'accounting.view', 'audit.view', 'users.manage', 'roles.manage', 'license.view', 'license.activate', 'settings.view', 'settings.manage', 'dashboard.view'].forEach((k) => assert.ok(html.includes('<code class="perm-key">' + k + '</code>'), 'clé ' + k));
assert.ok(html.includes('matrix-legend'), 'légende');
assert.ok(html.includes('matrix-group-row'), 'lignes de section');
report.push('Rendu: 30 modules + clés + légende OK');
// ---------- sémantique des badges ----------
const roleNames = state.roles.slice(0, 5).map((r) => r.name);
assert.deepStrictEqual(roleNames, ['Administrateur', 'Gérant', 'Vendeur', 'Magasinier', 'Comptable']);
function cellBadges(moduleLabel, roleName) {
  const row = html.split('<tr>').find((chunk) => chunk.includes('<strong>' + moduleLabel + '</strong>'));
  assert.ok(row, 'ligne ' + moduleLabel);
  const cells = row.split('</td>');
  const cell = cells[2 + roleNames.indexOf(roleName)];
  return [(cell.match(/Autorisé/g) || []).length, (cell.match(/Limité/g) || []).length];
}
assert.deepStrictEqual(cellBadges('Transferts inter-magasins', 'Administrateur'), [3, 0]);
assert.deepStrictEqual(cellBadges('Transferts inter-magasins', 'Magasinier'), [3, 0]);
assert.deepStrictEqual(cellBadges('Transferts inter-magasins', 'Vendeur'), [0, 3]);
assert.deepStrictEqual(cellBadges('Nouvelle vente', 'Vendeur'), [2, 0]);
assert.deepStrictEqual(cellBadges('Nouvelle vente', 'Magasinier'), [0, 2]);
assert.deepStrictEqual(cellBadges('Commandes', 'Vendeur'), [0, 2]);
assert.deepStrictEqual(cellBadges('Commandes', 'Magasinier'), [2, 0]);
assert.deepStrictEqual(cellBadges('Journal d’activité', 'Comptable'), [1, 0]);
assert.deepStrictEqual(cellBadges('Licence', 'Gérant'), [1, 1]);
assert.deepStrictEqual(cellBadges('Licence', 'Vendeur'), [1, 1]);
assert.deepStrictEqual(cellBadges('Catégories', 'Vendeur'), [0, 1]);
assert.deepStrictEqual(cellBadges('Livreurs', 'Gérant'), [2, 0]);
assert.deepStrictEqual(cellBadges('Livreurs', 'Vendeur'), [1, 1]);
assert.deepStrictEqual(cellBadges('Avoirs &amp; annulations', 'Vendeur'), [2, 1]);
assert.deepStrictEqual(cellBadges('Bilan des ventes', 'Comptable'), [2, 0]);
report.push('Badges: 15 cas profils x modules OK');
return { report };
`;

const result = new Function('assert', harness)(assert);
console.log('NOVA Commerce — test matrice Profils & droits');
result.report.forEach((line) => console.log(line));
console.log('Structure + rendu + badges : OK');

// ---------- la matrice couvre exactement le sidebar (moins guide/contact) ----------
const htmlSrc = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const navSrc = htmlSrc.slice(htmlSrc.indexOf('<nav class="sidebar-nav"'), htmlSrc.indexOf('</nav>'));
const sidebarViews = [...new Set([...navSrc.matchAll(/data-view="([a-z-]+)"/g)].map((m) => m[1]))].filter((v) => v !== 'guide' && v !== 'contact');
const appSrc = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const matrixSrc = appSrc.slice(appSrc.indexOf('const ROLE_MATRIX_MODULES = ['), appSrc.indexOf('const MODULE_MANAGE_PERMISSIONS = {'));
const matrixViews = [...matrixSrc.matchAll(/\['([a-z-]+)', '/g)].map((m) => m[1]);
assert.deepStrictEqual([...matrixViews].sort(), [...sidebarViews].sort(), 'matrice == sidebar');
assert.ok(!appSrc.includes("[['Ventes', 'sales.view']"), 'ancienne matrice supprimée');
console.log(`Sidebar == matrice : OK (${matrixViews.length} modules, guide/contact exclus)`);

// ---------- styles présents ----------
const cssSrc = fs.readFileSync(path.join(__dirname, '..', 'styles.css'), 'utf8');
['.matrix-group-row', '.matrix-badges', '.matrix-legend', '.perm-key'].forEach((cls) => assert.ok(cssSrc.includes(cls), `style ${cls}`));
console.log('Styles matrice : OK');
console.log('\nTOUS LES TESTS MATRICE : OK');
