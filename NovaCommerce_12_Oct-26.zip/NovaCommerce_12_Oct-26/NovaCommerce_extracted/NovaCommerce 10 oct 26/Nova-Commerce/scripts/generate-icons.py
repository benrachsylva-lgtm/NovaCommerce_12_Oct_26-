#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Génère les icônes de l'application Android NOVA Commerce à partir de l'image
de marque, selon la géométrie officielle des icônes adaptatives Android.

Géométrie (référence : « Adaptive icons » — developer.android.com) :
  · toile (canvas)          : 108 × 108 dp
  · zone visible selon le   : 66 dp de diamètre (zone de sécurité) à
    masque du lanceur         72 dp dans les coins (masques carrés/arrondis)
  · l'image est donc inscrite dans le cercle de 66 dp pour que la marque reste
    entièrement lisible quel que soit le masque (cercle, goutte, écusson…).

Résultat (dans android/app/src/main/res/) :
  mipmap-{m,h,xh,xxh,xxxh}dpi/ic_launcher.png            icône classique (API < 26)
  mipmap-{m,h,xh,xxh,xxxh}dpi/ic_launcher_round.png      icône ronde (API < 26)
  mipmap-{m,h,xh,xxh,xxxh}dpi/ic_launcher_foreground.png couche avant adaptative (API 26+)
  values/ic_launcher_background.xml                      couleur de la couche de fond (API 26+)

Usage :
    python3 scripts/generate-icons.py [chemin/vers/image.png|.webp]
Par défaut : assets/icon-app-rayira.webp

Dépendance : Pillow (pip install Pillow)
"""
import os
import re
import sys

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_SOURCE = os.path.join(ROOT, "assets", "icon-app-rayira.webp")
RES_DIR = os.path.join(ROOT, "android", "app", "src", "main", "res")

# Bleu marine de la marque (rappel : fond du hijab) — sert de couche de fond et
# de cadre lorsque le masque du lanceur dépasse le cercle de 66 dp.
BACKGROUND_HEX = "#172554"
BACKGROUND_RGB = (0x17, 0x25, 0x54)

# Insère la marque dans la zone visible de 66 dp, avec une petite marge : le
# rapport 0.615 laisse la marque légèrement à l'intérieur du cercle de sécurité.
BRAND_RATIO = 0.615

# Icônes classiques (API < 26) : la marque est un peu plus grande, avec un cadre
# marine visible, pour rester cohérente avec l'icône adaptative.
LEGACY_BRAND_RATIO = 0.80

# densité : (côté icône classique en px, côté toile adaptative en px = 108 dp)
DENSITIES = {
    "mdpi": (48, 108),
    "hdpi": (72, 162),
    "xhdpi": (96, 216),
    "xxhdpi": (144, 324),
    "xxxhdpi": (192, 432),
}


def fill_background(canvas: Image.Image, rgb=BACKGROUND_RGB) -> Image.Image:
    background = Image.new("RGB", canvas.size, rgb)
    background.paste(canvas, (0, 0), canvas if canvas.mode == "RGBA" else None)
    return background


def make_foreground(brand: Image.Image, canvas_size: int) -> Image.Image:
    """Couche avant de l'icône adaptative : fond marine + marque centrée."""
    canvas = Image.new("RGB", (canvas_size, canvas_size), BACKGROUND_RGB)
    side = max(1, round(canvas_size * BRAND_RATIO))
    logo = brand.resize((side, side), Image.LANCZOS)
    offset = (canvas_size - side) // 2
    canvas.paste(logo, (offset, offset))
    return canvas


def make_legacy(brand: Image.Image, icon_size: int, round_shape: bool) -> Image.Image:
    """Icône classique (API < 26) : cadre marine + marque centrée."""
    canvas = Image.new("RGB", (icon_size, icon_size), BACKGROUND_RGB)
    side = max(1, round(icon_size * LEGACY_BRAND_RATIO))
    logo = brand.resize((side, side), Image.LANCZOS)
    offset = (icon_size - side) // 2
    canvas.paste(logo, (offset, offset))
    if round_shape:
        # Masque circulaire doux : le lanceur applique lui-même sa forme, mais
        # certains affichent l'icône telle quelle (rendu circulaire attendu).
        mask = Image.new("L", (icon_size, icon_size), 0)
        from PIL import ImageDraw
        ImageDraw.Draw(mask).ellipse((0, 0, icon_size - 1, icon_size - 1), fill=255)
        canvas.putalpha(255)
        canvas = canvas.convert("RGBA")
        canvas.putalpha(mask)
    return canvas


def write_background_color() -> str:
    """Met à jour values/ic_launcher_background.xml (couleur de fond adaptative)."""
    path = os.path.join(RES_DIR, "values", "ic_launcher_background.xml")
    content = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        "<resources>\n"
        '    <color name="ic_launcher_background">%s</color>\n'
        "</resources>\n" % BACKGROUND_HEX
    )
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(content)
    return path


def main() -> int:
    source = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_SOURCE
    if not os.path.exists(source):
        print("Image source introuvable : %s" % source)
        return 1
    if not os.path.isdir(RES_DIR):
        print("Dossier de ressources Android introuvable : %s" % RES_DIR)
        return 1

    brand = Image.open(source).convert("RGB")
    if brand.width != brand.height:
        side = min(brand.width, brand.height)
        left = (brand.width - side) // 2
        top = (brand.height - side) // 2
        brand = brand.crop((left, top, left + side, top + side))
        print("Image recadrée au carré : %d × %d" % (side, side))

    generated = []
    for density, (icon_size, canvas_size) in DENSITIES.items():
        folder = os.path.join(RES_DIR, "mipmap-%s" % density)
        os.makedirs(folder, exist_ok=True)

        foreground = make_foreground(brand, canvas_size)
        foreground.save(os.path.join(folder, "ic_launcher_foreground.png"), "PNG", optimize=True)
        generated.append("%s/ic_launcher_foreground.png (%dpx)" % (density, canvas_size))

        for name, round_shape in (("ic_launcher.png", False), ("ic_launcher_round.png", True)):
            icon = make_legacy(brand, icon_size, round_shape)
            icon.save(os.path.join(folder, name), "PNG", optimize=True)
            generated.append("%s/%s (%dpx)" % (density, name, icon_size))

    generated.append(write_background_color())

    print("Icônes générées depuis %s :" % os.path.relpath(source, ROOT))
    for line in generated:
        print("  · %s" % line)
    print("\nRappel : recompiler l'APK (npm run mobile:apk:debug) pour l'embarquer.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
