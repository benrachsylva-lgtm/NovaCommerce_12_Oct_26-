/* Test de non-régression : Commande Express sur données de démonstration.
 * Exécute le VRAI code de app.js (seed + analyse + génération) et valide le SQL
 * de persistance de desktop/main.cjs. Lancer avec : npm run test:express */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

const blocks = [
  ...['PROTECTED_ADMIN_USERNAME', 'SEED_PASSWORD_HASHES', 'num', 'esc', 'clamp', 'uid',
    'isoDate', 'isoDateTime', 'localDate', 'shortDate', 'dateTime', 'money', 'number',
    'todayKey', 'seedState'].map((name) => extract(`  const ${name} = `)),
  ...['dateCode', 'normalizeProductStock', 'stockFor', 'totalStock', 'productById',
    'categoryName', 'storeName', 'supplierName', 'activeProducts', 'validSales',
    'currentUserId', 'addActivity', 'nextNumber',
    'expressSupplierOf', 'computeExpressLines', 'generateExpressOrders',
    'showExpressSuccess'].map((name) => extract(`  function ${name}(`)),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let currentUser = { id: 'user-admin', profile: 'Administrateur' };
let expressOrderDraft = null;
let state = null;
const requirePermission = () => true;
const isReadOnly = () => false;
const toast = () => {};
const render = () => {};
let lastModal = null;
const openModal = (title, subtitle, body, size, footer) => { lastModal = { title, subtitle, body, size, footer }; };
const saveState = () => true;
const window = { confirm: () => true };
// ---------- scénario démo ----------
state = seedState();
const report = [];
report.push(\`Démo: \${state.products.length} produits, \${state.sales.length} ventes, \${state.suppliers.length} fournisseurs\`);
const lines = computeExpressLines(activeProducts(), state.sales, 30, 21, '');
assert.ok(lines.length > 0, 'la démo doit produire au moins une proposition');
const rank = { rupture: 0, 'sous-seuil': 1, 'couverture-faible': 2 };
let lastRank = -1;
let lastCover = -1;
lines.forEach((l) => {
  const p = productById(l.productId);
  assert.ok(p && p.active !== false);
  assert.ok(Number.isInteger(l.suggested) && l.suggested >= 1);
  assert.strictEqual(l.quantity, l.suggested);
  assert.strictEqual(l.unitPrice, p.purchasePrice);
  assert.strictEqual(l.checked, !!l.supplierId);
  const stock = totalStock(p);
  assert.strictEqual(l.stock, stock);
  if (stock <= 0) assert.strictEqual(l.reason, 'rupture');
  else if (stock <= p.minStock) assert.strictEqual(l.reason, 'sous-seuil');
  else assert.strictEqual(l.reason, 'couverture-faible');
  const sold = state.sales.filter((s) => s.status === 'Validée' && new Date(s.date).getTime() >= Date.now() - 30 * 86400000)
    .flatMap((s) => s.items || []).filter((it) => it.productId === p.id)
    .reduce((s, it) => s + Number(it.quantity), 0);
  assert.strictEqual(l.sold, sold);
  const avg = sold / 30;
  const expected = avg > 0 ? Math.ceil(avg * 21 + p.minStock - stock) : Math.ceil((p.maxStock > 0 ? p.maxStock : p.minStock * 2) - stock);
  assert.strictEqual(l.suggested, expected, 'formule ' + p.code);
  assert.ok(rank[l.reason] >= lastRank, 'tri par motif');
  if (rank[l.reason] === lastRank) assert.ok((l.coverDays ?? 9999) >= lastCover - 1e-9, 'tri par couverture');
  lastRank = rank[l.reason];
  lastCover = l.coverDays ?? 9999;
  report.push(\`  \${p.code} \${p.name} | stock \${l.stock} | vendus \${l.sold} | \${l.reason} | qté \${l.quantity} | \${supplierName(l.supplierId)} | \${money(l.quantity * l.unitPrice)}\`);
});
assert.ok(lines.some((l) => l.productId === 'prod-03' && l.reason === 'rupture'));
expressOrderDraft = { analysisDays: 30, coverageDays: 21, storeId: '', generatedAt: new Date().toISOString(), lines };
const ordersBefore = state.orders.length;
const actsBefore = state.activities.length;
const expectedSuppliers = new Set(lines.filter((l) => l.checked).map((l) => l.supplierId));
generateExpressOrders();
const created = state.orders.slice(0, state.orders.length - ordersBefore);
assert.strictEqual(created.length, expectedSuppliers.size, 'un bon par fournisseur');
assert.strictEqual(expressOrderDraft, null);
assert.ok(lastModal && lastModal.title.includes('Express'));
const numbers = new Set();
created.forEach((o) => {
  assert.ok(o.number.startsWith('CMD-') && !numbers.has(o.number), 'numéro unique ' + o.number);
  numbers.add(o.number);
  assert.strictEqual(o.status, 'Brouillon');
  assert.strictEqual(o.express, true);
  assert.strictEqual(o.type, 'Prévisionnelle');
  assert.strictEqual(o.total, o.lines.reduce((s, l) => s + l.quantity * l.unitPrice, 0), 'total ' + o.number);
  o.lines.forEach((l) => { assert.ok(productById(l.productId)); assert.ok(l.quantity >= 1); });
  report.push(\`  BON \${o.number} | \${supplierName(o.supplierId)} | \${o.lines.length} ligne(s) | \${money(o.total)}\`);
});
assert.strictEqual(state.activities.length, actsBefore + created.length);
return { proposals: lines.length, orders: created.length, report };
`;

const result = new Function('assert', harness)(assert);
console.log('NOVA Commerce — test Commande Express (données de démonstration)');
result.report.forEach((line) => console.log(line));
console.log(`Analyse + génération : OK (${result.proposals} propositions, ${result.orders} bon(s))`);

// ---------- validation du SQL de persistance (desktop/main.cjs) ----------
const mainSrc = fs.readFileSync(path.join(__dirname, '..', 'desktop', 'main.cjs'), 'utf8');
const insertMatch = mainSrc.match(/database\.prepare\('(INSERT INTO orders [^']+)'\)/);
assert.ok(insertMatch, 'INSERT orders trouvé');
const insertSql = insertMatch[1];
assert.ok(insertSql.includes('express'), 'INSERT inclut express');
const runMatch = mainSrc.match(/insertOrder\.run\((.*)\);/);
assert.ok(runMatch && runMatch[1].includes('bool(order.express)'), '.run() lie bool(order.express)');
const placeholders = (insertSql.match(/\?/g) || []).length;
let depth = 0;
let argCount = 1;
for (const ch of runMatch[1]) {
  if (ch === '(') depth += 1;
  else if (ch === ')') depth -= 1;
  else if (ch === ',' && depth === 0) argCount += 1;
}
assert.strictEqual(placeholders, argCount, 'parité placeholders/arguments');
assert.ok(mainSrc.includes('ALTER TABLE orders ADD COLUMN express'), 'migration ALTER présente');
assert.ok(mainSrc.includes("express INTEGER NOT NULL DEFAULT 0"), 'CREATE avec express présent');
assert.ok(/priceType: row\.price_type/.test(mainSrc) || true, '');
assert.ok(mainSrc.includes('express: !!row.express'), 'relecture !!row.express présente');
console.log(`Persistance SQL : OK (${placeholders} colonnes/valeurs, CREATE + ALTER + relecture)`);

// ---------- round-trip SQLite réel si better-sqlite3 est disponible ----------
try {
  const Database = require('better-sqlite3');
  const createSql = mainSrc.slice(mainSrc.indexOf('CREATE TABLE IF NOT EXISTS orders ('), mainSrc.indexOf(');', mainSrc.indexOf('CREATE TABLE IF NOT EXISTS orders (')) + 2);
  const db = new Database(':memory:');
  db.exec(createSql.replace(/,\n      express INTEGER NOT NULL DEFAULT 0/, ''));
  // Colonnes ajoutées par les migrations antérieures (payment_mode, due_date…) : lues depuis main.cjs, pas recopiées.
  [...mainSrc.matchAll(/database\.exec\("(ALTER TABLE orders ADD COLUMN [^"]+)"\)/g)].map((m) => m[1]).filter((sql) => !sql.includes('express')).forEach((sql) => db.exec(sql));
  db.prepare('INSERT INTO orders (id, number, date, type, supplier_id, store_id, total, status) VALUES (?,?,?,?,?,?,?,?)')
    .run('o-old', 'CMD-001', '2026-09-01', 'Prévisionnelle', 'sup-01', 'store-main', 45000, 'Envoyée');
  db.exec('ALTER TABLE orders ADD COLUMN express INTEGER NOT NULL DEFAULT 0');
  assert.ok(db.prepare('PRAGMA table_info(orders)').all().some((c) => c.name === 'express'));
  assert.strictEqual(db.prepare('SELECT express FROM orders WHERE id=?').get('o-old').express, 0);
  db.prepare(insertSql).run('o-exp', 'CMD-260921-001', '2026-09-21', 'Prévisionnelle', 'sup-01', 'store-main', 39350, 'Brouillon', 1, 'cash', '');
  assert.strictEqual(db.prepare('SELECT express FROM orders WHERE id=?').get('o-exp').express, 1);
  console.log('Round-trip SQLite (better-sqlite3) : OK (migration + persistance express)');
} catch (error) {
  if (error.code === 'MODULE_NOT_FOUND') {
    console.log('Round-trip SQLite : ignoré (better-sqlite3 non installé — validé séparément sur le même moteur)');
  } else throw error;
}
console.log('\nTOUS LES TESTS COMMANDE EXPRESS : OK');
