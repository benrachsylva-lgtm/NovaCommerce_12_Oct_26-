/* Test de non-régression : garde-fou d'écriture sur l'encours client (desktop/main.cjs).
 * Charge le VRAI desktop/main.cjs (module electron simulé, base SQLite temporaire) et vérifie que :
 *  - une réception de commande (stock seul) n'est pas refusée, quel que soit le dossier client
 *    (sans encours, ancien dossier avec règlement, remboursement, ouverture + règlement, avance) ;
 *  - une modification directe du solde reste refusée ('encours-client-modifie') ;
 *  - un règlement ou une vente à crédit légitime reste autorisé ;
 *  - deux sauvegardes successives restent autorisées et l'ouverture est bien persistée.
 * Le recalcul de l'état côté interface reprend les formules de www/app.js (creditSalesTotal,
 * creditPaymentsTotal, clientRefundsTotal, clientPositionValues), y compris la clé `advance`.
 * Lancer avec : npm run test:guard */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const Module = require('node:module');
const assert = require('node:assert');

const ROOT = path.join(__dirname, '..');
const MAIN = path.join(ROOT, 'desktop', 'main.cjs');

// --- Electron simulé : seules app.getPath et les appels de démarrage comptent ---
let userData = '';
const createdDirs = [];
function makeStub() {
  const fn = function () { return stub; };
  const stub = new Proxy(fn, {
    get(target, prop) {
      if (prop === 'then') return () => stub;
      if (prop === Symbol.toPrimitive) return () => '';
      if (prop === 'getPath') return () => userData;
      if (prop === 'getVersion') return () => '0.0.0-test';
      if (prop === 'isPackaged') return false;
      return stub;
    },
    apply() { return stub; },
    construct() { return stub; },
  });
  return stub;
}
const electronStub = new Proxy({}, { get: () => makeStub() });

function loadMain() {
  const originalLoad = Module._load;
  Module._load = function (request) {
    if (request === 'electron') return electronStub;
    return originalLoad.apply(this, arguments);
  };
  try {
    const src = fs.readFileSync(MAIN, 'utf8') + '\nmodule.exports.__t = { openDatabase, replaceRelationalState, buildRelationalState, evaluateStateWrite, getDb: () => database };\n';
    const m = new Module(MAIN, null);
    m.filename = MAIN;
    m.paths = Module._nodeModulePaths(path.dirname(MAIN));
    m._compile(src, MAIN);
    return m.exports.__t;
  } finally {
    Module._load = originalLoad;
  }
}

const t = loadMain();
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };

function baseState(clients, extra = {}) {
  return {
    version: 11, settings: {},
    license: { activated: true, licenseKey: 'TEST', licenseKeyDigest: 'x', activatedAt: '2026-01-01T00:00:00.000Z' },
    users: [{ id: 'u-admin', name: 'Admin', username: 'admin', profile: 'Administrateur', active: true, passwordHash: 'x' }],
    roles: [{ id: 'r-admin', name: 'Administrateur', description: '', color: 'neutral', permissions: ['*'], users: 1 }],
    categories: [], suppliers: [], supplierProducts: [], deliverers: [], deliveries: [],
    stores: [{ id: 's1', name: 'Boutique', code: 'B1', type: 'boutique', manager: '', active: true }],
    products: [], clients, sales: [], customerPayments: [], supplierPayments: [], refunds: [],
    creditNotes: [], stockEntries: [], stockExits: [], stockTransfers: [], expenses: [], orders: [],
    quotes: [], inventoryReports: [], activities: [], ...extra,
  };
}

// État tel que l'interface le renvoie après refreshClientReceivables (www/app.js).
function uiRefresh(state) {
  const next = JSON.parse(JSON.stringify(state));
  const saleTotal = (s) => num(s.total) || (s.items || []).reduce((a, i) => a + num(i.quantity) * num(i.unitPrice), 0);
  const noteTotal = (n) => num(n.total) || (n.lines || []).reduce((a, l) => a + num(l.quantity) * num(l.unitPrice), 0);
  (next.clients || []).forEach((client) => {
    const id = client.id;
    const creditSales = (next.sales || []).filter((s) => s.status === 'Validée' && s.payment === 'credit' && s.clientId === id).reduce((a, s) => a + saleTotal(s), 0)
      - (next.creditNotes || []).filter((n) => n.status === 'Validée' && n.payment === 'credit' && n.clientId === id).reduce((a, n) => a + noteTotal(n), 0);
    const payments = (next.customerPayments || []).filter((p) => p.status === 'Validé' && p.clientId === id).reduce((a, p) => a + num(p.amount), 0);
    const refunds = (next.refunds || []).filter((r) => r.status === 'Validée' && r.notePayment === 'credit' && r.clientId === id).reduce((a, r) => a + num(r.amount), 0);
    const movement = creditSales - payments + refunds;
    if (client.openingReceivable == null) client.openingReceivable = num(client.receivable) > 0 ? num(client.receivable) - movement : -Math.max(0, movement);
    const net = num(client.openingReceivable) + movement;
    client.receivable = Math.max(0, net);
    client.advance = Math.max(0, -net);
  });
  return next;
}

function seedAndRead(state) {
  userData = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-guard-'));
  createdDirs.push(userData);
  t.openDatabase();
  t.replaceRelationalState(state);
  const read = t.buildRelationalState();
  assert.ok(read, 'base illisible');
  return read;
}

const client = (id, receivable, opening = 0) => ({ id, name: 'Client ' + id, phone: '', email: '', address: '', creditLimit: 0, openingReceivable: opening, receivable, active: true });
const sale = (id, clientId, total) => ({ id, number: 'V-' + id, date: '2026-10-01', clientId, clientName: 'C', storeId: 's1', items: [], total, payment: 'credit', priceType: 'retail', status: 'Validée', userId: 'u-admin', createdAt: '2026-10-01T10:00:00.000Z' });
const pay = (id, clientId, amount) => ({ id, number: 'R-' + id, clientId, date: '2026-10-02', amount, method: 'Espèces', reference: '', note: '', status: 'Validé', userId: 'u-admin', createdAt: '2026-10-02T10:00:00.000Z' });
const refund = (id, clientId, amount) => ({ id, number: 'RB-' + id, date: '2026-10-03', noteId: 'n1', noteNumber: 'AV-1', notePayment: 'credit', clientId, amount, method: 'Espèces', reference: '', note: '', status: 'Validée', userId: 'u-admin', createdAt: '2026-10-03T10:00:00.000Z' });
const product = (id, stock) => ({ id, code: id, name: 'Produit ' + id, categoryId: '', brand: '', model: '', supplierId: '', storeId: 's1', purchasePrice: 0, salePrice: 100, wholesalePrice: 0, promoPrice: 0, minStock: 0, maxStock: 0, presentation: '', batch: '', expiry: '', image: '', barcode: '', barcodeType: '', active: true, stock, stockByStore: { s1: stock } });
const order = (id, status) => ({ id, number: 'CMD-' + id, date: '2026-10-05', type: 'Fournisseur', supplierId: '', storeId: 's1', lines: [{ productId: 'P1', quantity: 120, unitPrice: 100 }], total: 12000, status, express: false, paymentMode: 'cash', dueDate: '' });

// Réception de commande : seuls le stock et le statut de la commande changent.
function receive(state) {
  const previous = seedAndRead(state);
  const next = uiRefresh(previous);
  next.products = next.products.map((p) => (p.id === 'P1' ? { ...p, stock: p.stock + 120, stockByStore: { s1: p.stock + 120 } } : p));
  next.orders = next.orders.map((o) => (o.id === 'O1' ? { ...o, status: 'Réceptionnée' } : o));
  return { previous, next, decision: t.evaluateStateWrite('u-admin', next) };
}

let passed = 0;
const failures = [];
function check(name, fn) {
  try { fn(); passed += 1; console.log('OK    ' + name); }
  catch (e) { failures.push(name); console.log('ECHEC ' + name + ' : ' + e.message); }
}

const reception = (clients, extra = {}) => baseState(clients, { products: [product('P1', 42)], orders: [order('O1', 'En cours')], ...extra });

check('R1 réception, client sans encours : autorisée', () => {
  const r = receive(reception([client('c1', 0, 0)]));
  assert.strictEqual(r.decision.allowed, true, r.decision.reason);
});
check('R2 réception, dossier ancien (ouverture 0) + règlement 20 : autorisée', () => {
  const r = receive(reception([client('c1', 30, 0)], { customerPayments: [pay('p1', 'c1', 20)] }));
  assert.strictEqual(r.decision.allowed, true, r.decision.reason);
});
check('R3 réception, vente 100 + remboursement 20 (ouverture 0) : autorisée', () => {
  const r = receive(reception([client('c1', 120, 0)], { sales: [sale('s1', 'c1', 100)], refunds: [refund('r1', 'c1', 20)] }));
  assert.strictEqual(r.decision.allowed, true, r.decision.reason);
});
check('R4 réception, ouverture 50 + vente 100 + règlement 30 : autorisée', () => {
  const r = receive(reception([client('c1', 120, 50)], { sales: [sale('s1', 'c1', 100)], customerPayments: [pay('p1', 'c1', 30)] }));
  assert.strictEqual(r.decision.allowed, true, r.decision.reason);
});
check('R5 réception, avance réelle 30 (règlement sans vente) : avance lue 30, autorisée', () => {
  const r = receive(reception([client('c1', 0, 0)], { customerPayments: [pay('p1', 'c1', 30)] }));
  assert.strictEqual(r.previous.clients[0].advance, 30, 'avance lue ' + r.previous.clients[0].advance);
  assert.strictEqual(r.decision.allowed, true, r.decision.reason);
});
check('T1 solde modifié à la main, sans vente ni règlement : refusée', () => {
  const previous = seedAndRead(baseState([client('c1', 50, 50)]));
  const next = uiRefresh(previous);
  next.clients[0].receivable = 999;
  const d = t.evaluateStateWrite('u-admin', next);
  assert.strictEqual(d.allowed, false);
  assert.strictEqual(d.reason, 'encours-client-modifie');
});
check('T2 dossier ancien, solde 30 forcé à 10 sans règlement : refusée', () => {
  const previous = seedAndRead(baseState([client('c1', 30, 0)], { customerPayments: [pay('p1', 'c1', 20)] }));
  const next = uiRefresh(previous);
  next.clients[0].receivable = 10;
  const d = t.evaluateStateWrite('u-admin', next);
  assert.strictEqual(d.allowed, false);
  assert.strictEqual(d.reason, 'encours-client-modifie');
});
check('V1 règlement ajouté : autorisé', () => {
  const previous = seedAndRead(baseState([client('c1', 30, 0)], { customerPayments: [pay('p1', 'c1', 20)] }));
  const next = uiRefresh(previous);
  next.customerPayments.push(pay('p2', 'c1', 10));
  const d = t.evaluateStateWrite('u-admin', next);
  assert.strictEqual(d.allowed, true, d.reason);
});
check('V2 vente à crédit ajoutée : autorisée', () => {
  const previous = seedAndRead(baseState([client('c1', 0, 0)]));
  const next = uiRefresh(previous);
  next.sales.push(sale('s9', 'c1', 50));
  next.clients[0].receivable = 50;
  const d = t.evaluateStateWrite('u-admin', next);
  assert.strictEqual(d.allowed, true, d.reason);
});
check('S1 deux réceptions successives : ouverture persistée, seconde autorisée', () => {
  const r1 = receive(reception([client('c1', 30, 0)], { customerPayments: [pay('p1', 'c1', 20)] }));
  assert.strictEqual(r1.decision.allowed, true, r1.decision.reason);
  t.replaceRelationalState(r1.next);
  const stored = t.getDb().prepare('SELECT opening_receivable AS o, receivable AS r FROM clients WHERE id = ?').get('c1');
  assert.strictEqual(stored.o, 50, 'ouverture stockée ' + stored.o);
  assert.strictEqual(stored.r, 30, 'solde stocké ' + stored.r);
  const next2 = uiRefresh(t.buildRelationalState());
  next2.products = next2.products.map((p) => ({ ...p, stock: p.stock + 5, stockByStore: { s1: p.stock + 5 } }));
  const d2 = t.evaluateStateWrite('u-admin', next2);
  assert.strictEqual(d2.allowed, true, d2.reason);
});

console.log(`\n${passed} OK, ${failures.length} échec(s) sur ${passed + failures.length}`);
for (const dir of createdDirs) { try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) { /* ignore */ } }
if (failures.length) process.exit(1);
