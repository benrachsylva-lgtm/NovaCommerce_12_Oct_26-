const puppeteer = require('puppeteer');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:4190/index.html'; // serveur statique requis (ex. python3 -m http.server dans le dossier de build)
let failures = 0;
const check = (name, ok, detail = '') => { if (!ok) failures += 1; console.log(`${ok ? '  ✓' : '  ✗'} ${name}${detail ? ' — ' + detail : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let clickSelGlobal = null;

(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e.message)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('dialog', async (d) => { await d.accept(); });

  await page.goto(BASE, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 });
  await sleep(800);
  await page.evaluate(() => { const d = window.__novaDebug; d.user = d.state.users.find((u) => u.profile === 'Administrateur'); d.render(); });
  await sleep(300);

  clickSelGlobal = (sel) => page.evaluate((q) => { const el = document.querySelector(q); if (!el) throw new Error('introuvable: ' + q); el.click(); }, sel);
  const clickSel = (sel) => clickSelGlobal(typeof sel === 'string' ? sel : String(sel));
  const toasts = () => page.evaluate(() => Array.from(document.querySelectorAll('#toast-stack .toast')).map((t) => t.innerText.replace(/\s+/g, ' ').trim()).join(' | '));
  const clearToasts = () => page.evaluate(() => { document.querySelectorAll('#toast-stack .toast').forEach((t) => t.remove()); });

  console.log('=== 1. DONNÉES DE DÉMONSTRATION ===');
  const seed = await page.evaluate(() => { const d = window.__novaDebug; return { credit: d.creditOrders().length, payments: d.state.supplierPayments.length, openDue: d.creditOrders().reduce((s, o) => s + d.orderBalance(o), 0), limits: d.state.suppliers.map((s) => s.creditLimit) }; });
  check('Commandes à crédit présentes dans la démo', seed.credit > 0, `${seed.credit} commandes`);
  check('Règlements fournisseurs présents dans la démo', seed.payments > 0, `${seed.payments} règlements`);
  check('Plafonds fournisseurs renseignés', seed.limits.includes(2000000), JSON.stringify(seed.limits));

  console.log('\n=== 2. LISTE DES COMMANDES ===');
  await page.evaluate(() => window.__novaDebug.setView('orders'));
  await sleep(400);
  const listText = await page.evaluate(() => document.querySelector('#view')?.innerText || '');
  check('Colonne Règlement et indicateurs affichés', listText.toUpperCase().includes('RÈGLEMENT') && listText.includes('Commandes à crédit ouvertes') && listText.includes('Solde fournisseurs dû'));

  console.log('\n=== 3. CRÉATION D’UNE COMMANDE À CRÉDIT ===');
  const before = await page.evaluate(() => window.__novaDebug.state.orders.length);
  const idsBefore = await page.evaluate(() => window.__novaDebug.state.orders.map((o) => o.id));
  await clickSel('[data-action="add-order"]');
  await sleep(400);
  const formExists = await page.$('#order-form');
  check('Formulaire de commande ouvert', !!formExists);
  const hintHidden = await page.evaluate(() => document.querySelector('#order-due-field')?.style.display === 'none');
  check('Échéance masquée en mode Comptant', hintHidden);
  await page.select('#order-form select[name="supplierId"]', 'sup-02');
  await page.select('#order-form select[name="paymentMode"]', 'credit');
  await sleep(100);
  const dueShown = await page.evaluate(() => document.querySelector('#order-due-field')?.style.display !== 'none');
  check('Échéance affichée en mode À crédit', dueShown);
  const addLine = async (qty, price) => {
    await page.evaluate((q, p) => {
      const d = window.__novaDebug;
      const prod = d.state.products.find((x) => x.active !== false);
      document.querySelector('#order-line-product').value = prod.id;
      document.querySelector('#order-line-quantity').value = q;
      document.querySelector('#order-line-unit-price').value = p;
    }, qty, price);
    await clickSel('[data-action="add-order-line"]');
    await sleep(120);
  };
  await addLine(10, 5000); // 50 000 FCFA
  // a) échéance absente → refus
  await clearToasts();
  await page.evaluate(() => document.querySelector('#order-form').requestSubmit());
  await sleep(250);
  let t = await toasts();
  check('Refus sans échéance', t.includes('Échéance obligatoire'), t);
  check('Aucune commande créée sans échéance', (await page.evaluate(() => window.__novaDebug.state.orders.length)) === before);
  // b) échéance antérieure à la date → refus
  await page.evaluate(() => { const f = document.querySelector('#order-form'); f.elements.dueDate.value = '2020-01-01'; f.elements.dueDate.dispatchEvent(new Event('change', { bubbles: true })); });
  await clearToasts();
  await page.evaluate(() => document.querySelector('#order-form').requestSubmit());
  await sleep(250);
  t = await toasts();
  check('Refus si échéance antérieure à la commande', t.includes('Échéance invalide'), t);
  // c) plafond dépassé (sup-02 : 1 000 000) → refus
  await page.evaluate(() => { const f = document.querySelector('#order-form'); f.elements.dueDate.value = '2027-03-31'; });
  await addLine(300, 5000); // 1 500 000 FCFA au total → plafond dépassé
  await clearToasts();
  await page.evaluate(() => document.querySelector('#order-form').requestSubmit());
  await sleep(250);
  t = await toasts();
  check('Refus si le plafond fournisseur est dépassé', t.includes('Plafond fournisseur dépassé'), t);
  check('Aucune commande créée au-delà du plafond', (await page.evaluate(() => window.__novaDebug.state.orders.length)) === before);
  // d) nouvelle commande valide (formulaire repris à zéro)
  await clickSel('[data-close-modal]');
  await sleep(200);
  await clickSel('[data-action="add-order"]');
  await sleep(400);
  await page.select('#order-form select[name="supplierId"]', 'sup-02');
  await page.select('#order-form select[name="paymentMode"]', 'credit');
  await page.evaluate(() => { const f = document.querySelector('#order-form'); f.elements.dueDate.value = '2027-03-31'; });
  await addLine(10, 5000);
  await clearToasts();
  await page.evaluate(() => document.querySelector('#order-form').requestSubmit());
  await sleep(300);
  t = await toasts();
  if (t) console.log('    (toast) ' + t);
  const created = await page.evaluate((prev) => { const d = window.__novaDebug; const o = d.state.orders.find((x) => !prev.includes(x.id)) || d.state.orders[0]; return { n: d.state.orders.length, number: o.number, mode: o.paymentMode, due: o.dueDate, total: o.total, supplier: o.supplierId }; }, idsBefore);
  check('Commande à crédit enregistrée', created.n === before + 1 && created.mode === 'credit' && created.due === '2027-03-31', JSON.stringify(created));
  const orderId = await page.evaluate((prev) => window.__novaDebug.state.orders.find((o) => !prev.includes(o.id)).id, idsBefore);
  const debtAfterCreate = await page.evaluate((s) => window.__novaDebug.supplierDebt(s), created.supplier);
  check('Encours fournisseur = solde de la nouvelle commande (inclus)', debtAfterCreate >= created.total, `encours ${debtAfterCreate}`);

  console.log('\n=== 4. RÈGLEMENTS PAR COMMANDE ===');
  await page.evaluate(() => window.__novaDebug.setView('orders'));
  await sleep(300);
  const rowHasPay = await page.$(`button[data-action="add-supplier-payment"][data-id="${orderId}"]`);
  check('Bouton ₣ présent sur la commande à crédit', !!rowHasPay);
  await clickSel(`button[data-action="add-supplier-payment"][data-id="${orderId}"]`);
  await sleep(300);
  const amountField = await page.$('#supplier-payment-amount');
  check('Formulaire de règlement ouvert avec le solde proposé', !!amountField && (await page.evaluate(() => document.querySelector('#supplier-payment-amount').value)) === String(created.total));
  const partial = Math.floor(created.total / 2 / 100) * 100;
  await page.evaluate((amt) => { document.querySelector('#supplier-payment-form').elements.amount.value = amt; document.querySelector('#supplier-payment-form').elements.reference.value = 'VIR-001'; document.querySelector('#supplier-payment-form').elements.method.value = 'mobile'; }, partial);
  await clearToasts();
  await page.evaluate(() => document.querySelector('#supplier-payment-form').requestSubmit());
  await sleep(300);
  let st = await page.evaluate((id) => { const d = window.__novaDebug; const o = d.state.orders.find((x) => x.id === id); return { pays: d.orderPayments(id).length, bal: d.orderBalance(o), label: d.orderCreditState(o).label, number: d.orderPayments(id)[0]?.number, ref: d.orderPayments(id)[0]?.reference, method: d.orderPayments(id)[0]?.method, user: d.orderPayments(id)[0]?.userId }; }, orderId);
  check('Règlement partiel enregistré et imputé à la commande', st.pays === 1 && st.bal === created.total - partial && /^RGF-/.test(st.number || ''), JSON.stringify(st));
  check('État « Partiellement réglée »', st.label === 'Partiellement réglée', st.label);
  check('Référence et mode conservés', st.ref === 'VIR-001' && st.method === 'mobile');
  // dépassement du solde → refus
  await clickSel(`button[data-action="add-supplier-payment"][data-id="${orderId}"]`);
  await sleep(300);
  await page.evaluate((amt) => { document.querySelector('#supplier-payment-form').elements.amount.value = amt; }, created.total);
  await clearToasts();
  const nativeBlocked = await page.evaluate(() => { const f = document.querySelector('#supplier-payment-form'); return !f.checkValidity(); });
  check('Surpaiement bloqué par la validation du champ (max = solde)', nativeBlocked);
  // Contournement de l'attribut max : la garde métier doit refuser quand même
  await page.evaluate(() => { document.querySelector('#supplier-payment-amount').removeAttribute('max'); document.querySelector('#supplier-payment-form').requestSubmit(); });
  await sleep(250);
  t = await toasts();
  check('Surpaiement refusé par la règle métier', t.includes('Montant supérieur au solde'), t);
  check('Aucun règlement en trop', (await page.evaluate((id) => window.__novaDebug.orderPayments(id).length, orderId)) === 1);
  // solde complet → commande soldée
  await page.evaluate((amt) => { document.querySelector('#supplier-payment-form').elements.amount.value = amt; }, created.total - partial);
  await clearToasts();
  await page.evaluate(() => document.querySelector('#supplier-payment-form').requestSubmit());
  await sleep(300);
  st = await page.evaluate((id) => { const d = window.__novaDebug; const o = d.state.orders.find((x) => x.id === id); return { bal: d.orderBalance(o), label: d.orderCreditState(o).label, pays: d.orderPayments(id).length }; }, orderId);
  check('Commande soldée après le dernier règlement', st.bal === 0 && st.label === 'Soldée' && st.pays === 2, JSON.stringify(st));
  check('Plus de bouton ₣ sur une commande soldée', !(await page.$(`button[data-action="add-supplier-payment"][data-id="${orderId}"]`)));

  console.log('\n=== 5. DÉTAIL ET TRAÇABILITÉ ===');
  await clickSel(`button[data-action="view-order"][data-id="${orderId}"]`);
  await sleep(300);
  const detail = await page.evaluate(() => document.querySelector('.modal')?.innerText || '');
  check('Détail : commande, mode à crédit et échéance', detail.includes('À crédit') && detail.includes('Échéance'));
  check('Détail : liste des deux règlements avec leur numéro', (detail.match(/RGF-/g) || []).length >= 2, `${(detail.match(/RGF-/g) || []).length} numéros`);
  check('Détail : état soldé', detail.includes('Soldée'));
  await page.evaluate(() => document.querySelector('[data-close-modal]')?.click());
  await sleep(150);

  console.log('\n=== 6. MODIFICATION ENCADRÉE ===');
  await page.evaluate((id) => { const d = window.__novaDebug; const o = d.state.orders.find((x) => x.id === id); d.openOrderModal(id); }, orderId);
  await sleep(300);
  await page.select('#order-form select[name="paymentMode"]', 'cash');
  await clearToasts();
  await page.evaluate(() => document.querySelector('#order-form').requestSubmit());
  await sleep(250);
  t = await toasts();
  check('Passage en comptant refusé après règlement', t.includes('ne peuvent plus être modifiés'), t);
  await page.evaluate(() => document.querySelector('[data-close-modal]')?.click());
  await sleep(150);

  console.log('\n=== 7. PAGE DETTES FOURNISSEURS ===');
  await page.evaluate(() => window.__novaDebug.setView('supplier-debts'));
  await sleep(400);
  const debtsText = await page.evaluate(() => document.querySelector('#view')?.innerText || '');
  check('Page « Dettes fournisseurs » affichée', debtsText.includes('Dettes fournisseurs') && debtsText.includes('Encours par fournisseur'));
  check('Table des règlements présente', debtsText.toUpperCase().includes('RÈGLEMENT') && debtsText.includes('RGF-'));
  const navOk = await page.evaluate(() => !!document.querySelector('[data-view="supplier-debts"]'));
  check('Entrée de menu Finance « Dettes fournisseurs »', navOk);

  console.log('\n=== 8. ARTICLE COMPTANT INCHANGÉ ===');
  const cashOk = await page.evaluate(() => { const d = window.__novaDebug; const cash = d.state.orders.find((o) => o.paymentMode !== 'credit'); return { exists: !!cash, label: cash ? d.orderCreditState(cash).label : '', bal: cash ? d.orderBalance(cash) : -1 }; });
  check('Commande comptant : libellé « Comptant », solde 0', cashOk.exists && cashOk.label === 'Comptant' && cashOk.bal === 0, JSON.stringify(cashOk));

  console.log('\n=== 9. PERSISTANCE APRÈS RECHARGEMENT ===');
  await page.evaluate(() => window.__novaDebug.save());
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 });
  await sleep(800);
  const persisted = await page.evaluate((id) => { const d = window.__novaDebug; const o = d.state.orders.find((x) => x.id === id); return { pays: d.orderPayments(id).length, mode: o.paymentMode, due: o.dueDate, bal: d.orderBalance(o) }; }, orderId);
  check('Commandes et règlements conservés après rechargement', persisted.pays === 2 && persisted.mode === 'credit' && persisted.due === '2027-03-31' && persisted.bal === 0, JSON.stringify(persisted));

  console.log('\n=== 10. ERREURS JAVASCRIPT ===');
  check('Aucune erreur JavaScript pendant le parcours', errors.length === 0, errors.slice(0, 3).join(' || '));

  await browser.close();
  console.log(failures === 0 ? '\nTOUS LES TESTS COMMANDES À CRÉDIT : OK' : `\n${failures} ÉCHEC(S)`);
  process.exit(failures === 0 ? 0 : 1);
})().catch((e) => { console.error('ERREUR TEST:', e); process.exit(2); });
