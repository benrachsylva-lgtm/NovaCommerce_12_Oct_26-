#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Génère les trois affiches A4 de promotion de NOVA Commerce.

Format : A4 portrait 210 × 297 mm à 300 dpi = 2480 × 3508 px (PDF + PNG).
Usage  : python3 scripts/generate-posters.py [dossier_de_sortie]
Défaut : ./affiches

Polices : Poppins (assets/fonts/, licence OFL — voir assets/fonts/OFL.txt).
Dépendance : Pillow.
"""
import io
import os
import sys

import segno
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT_DIR = os.path.join(ROOT, "assets", "fonts")
LOGO = os.path.join(ROOT, "assets", "icon.png")

DPI = 300
W, H = 2480, 3508            # A4 portrait à 300 dpi
MARGIN = 150

NAVY = (13, 23, 38)          # #0d1726 (couleur de l'application)
NAVY_2 = (23, 38, 58)        # #17263a
NAVY_3 = (34, 52, 76)        # #22344c
GOLD = (212, 162, 68)        # accent doré
GOLD_LIGHT = (238, 206, 138)
CANVAS = (244, 246, 250)     # #f4f6fa
WHITE = (255, 255, 255)
INK = (22, 35, 56)           # #162338
MUTED = (96, 112, 134)
PALE = (203, 214, 230)

FONTS = {}

# Adresse encodée dans le QR code des affiches (téléchargement de l'APK Android).
# Modifiable sans toucher au script :
#   python3 scripts/generate-posters.py [dossier] --url https://votre-domaine/nova-commerce.apk
#   ou via la variable d'environnement NOVA_APK_URL.
# Un QR code ne peut pas contenir l'APK (4,7 Mo) : il pointe toujours vers une adresse web.
ADRESSE_APK_PAR_DEFAUT = "https://example.com/nova-commerce.apk"
ADRESSE_APK = os.environ.get("NOVA_APK_URL", ADRESSE_APK_PAR_DEFAUT)


def font(weight, size):
    key = (weight, size)
    if key not in FONTS:
        FONTS[key] = ImageFont.truetype(os.path.join(FONT_DIR, "Poppins-%s.ttf" % weight), size)
    return FONTS[key]


# --------------------------------------------------------------------------- outils

def rounded(draw, box, radius, fill=None, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def wrap(draw, text, font_obj, max_width):
    lines, current = [], ""
    for mot in text.split():
        essai = (current + " " + mot).strip()
        if draw.textlength(essai, font=font_obj) <= max_width or not current:
            current = essai
        else:
            lines.append(current)
            current = mot
    if current:
        lines.append(current)
    return lines


def text_block(draw, xy, text, font_obj, fill, max_width, spacing=1.32, align="left"):
    x, y = xy
    hauteur = font_obj.size * spacing
    for ligne in wrap(draw, text, font_obj, max_width):
        largeur = draw.textlength(ligne, font=font_obj)
        if align == "center":
            draw.text((x + (max_width - largeur) / 2, y), ligne, font=font_obj, fill=fill)
        else:
            draw.text((x, y), ligne, font=font_obj, fill=fill)
        y += hauteur
    return y


def spacing_text(draw, xy, texte, font_obj, fill, tracking):
    """Texte en capitales légèrement espacées (kickers)."""
    x, y = xy
    for caractere in texte:
        draw.text((x, y), caractere, font=font_obj, fill=fill)
        x += draw.textlength(caractere, font=font_obj) + tracking
    return x


def icon(kind, size, color, stroke=None):
    """Icône linéaire dessinée en vectoriel, rendue en haute définition."""
    grossissement = 4
    s = size * grossissement
    image = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(image)
    ep = stroke or max(6, int(s * 0.075))
    c = color
    r = int(s * 0.08)

    if kind == "cart":
        d.rounded_rectangle((s * 0.18, s * 0.30, s * 0.86, s * 0.68), radius=r, outline=c, width=ep)
        d.line((s * 0.06, s * 0.16, s * 0.20, s * 0.16, s * 0.30, s * 0.42), fill=c, width=ep, joint="curve")
        d.ellipse((s * 0.30, s * 0.74, s * 0.42, s * 0.86), outline=c, width=ep)
        d.ellipse((s * 0.64, s * 0.74, s * 0.76, s * 0.86), outline=c, width=ep)
        d.line((s * 0.40, s * 0.44, s * 0.40, s * 0.58), fill=c, width=ep)
        d.line((s * 0.62, s * 0.44, s * 0.62, s * 0.58), fill=c, width=ep)
    elif kind == "card":
        d.rounded_rectangle((s * 0.10, s * 0.24, s * 0.90, s * 0.76), radius=r, outline=c, width=ep)
        d.line((s * 0.10, s * 0.40, s * 0.90, s * 0.40), fill=c, width=ep)
        d.rounded_rectangle((s * 0.18, s * 0.56, s * 0.40, s * 0.66), radius=r // 2, fill=c)
    elif kind == "receipt":
        d.line((s * 0.24, s * 0.12, s * 0.76, s * 0.12), fill=c, width=ep)
        d.line((s * 0.24, s * 0.12, s * 0.24, s * 0.78), fill=c, width=ep)
        d.line((s * 0.76, s * 0.12, s * 0.76, s * 0.78), fill=c, width=ep)
        for index, y in enumerate((0.32, 0.46, 0.60)):
            d.line((s * 0.34, s * y, s * (0.66 if index else 0.56), s * y), fill=c, width=ep // 2)
        d.line((s * 0.24, s * 0.78, s * 0.36, s * 0.90), fill=c, width=ep)
        d.line((s * 0.36, s * 0.90, s * 0.50, s * 0.78), fill=c, width=ep)
        d.line((s * 0.76, s * 0.78, s * 0.64, s * 0.90), fill=c, width=ep)
        d.line((s * 0.64, s * 0.90, s * 0.50, s * 0.78), fill=c, width=ep)
    elif kind == "shield":
        d.line((s * 0.50, s * 0.10, s * 0.86, s * 0.24), fill=c, width=ep, joint="curve")
        d.line((s * 0.86, s * 0.24, s * 0.86, s * 0.52), fill=c, width=ep)
        d.line((s * 0.86, s * 0.52, s * 0.50, s * 0.90), fill=c, width=ep, joint="curve")
        d.line((s * 0.50, s * 0.90, s * 0.14, s * 0.52), fill=c, width=ep, joint="curve")
        d.line((s * 0.14, s * 0.52, s * 0.14, s * 0.24), fill=c, width=ep)
        d.line((s * 0.14, s * 0.24, s * 0.50, s * 0.10), fill=c, width=ep, joint="curve")
        d.line((s * 0.34, s * 0.50, s * 0.46, s * 0.62), fill=c, width=ep, joint="curve")
        d.line((s * 0.46, s * 0.62, s * 0.68, s * 0.36), fill=c, width=ep, joint="curve")
    elif kind == "truck":
        d.rounded_rectangle((s * 0.08, s * 0.28, s * 0.58, s * 0.70), radius=r, outline=c, width=ep)
        d.line((s * 0.58, s * 0.40, s * 0.76, s * 0.40, s * 0.90, s * 0.56, s * 0.90, s * 0.70, s * 0.58, s * 0.70),
               fill=c, width=ep, joint="curve")
        d.ellipse((s * 0.18, s * 0.66, s * 0.32, s * 0.80), outline=c, width=ep)
        d.ellipse((s * 0.68, s * 0.66, s * 0.82, s * 0.80), outline=c, width=ep)
    elif kind == "cube":
        d.rounded_rectangle((s * 0.16, s * 0.32, s * 0.84, s * 0.86), radius=r, outline=c, width=ep)
        d.line((s * 0.16, s * 0.44, s * 0.84, s * 0.44), fill=c, width=ep // 2)
        d.line((s * 0.50, s * 0.44, s * 0.50, s * 0.86), fill=c, width=ep // 2)
        d.line((s * 0.30, s * 0.20, s * 0.70, s * 0.20), fill=c, width=ep)
    elif kind == "arrows":
        d.line((s * 0.16, s * 0.34, s * 0.80, s * 0.34), fill=c, width=ep)
        d.line((s * 0.66, s * 0.20, s * 0.84, s * 0.34, s * 0.66, s * 0.48), fill=c, width=ep, joint="curve")
        d.line((s * 0.84, s * 0.68, s * 0.20, s * 0.68), fill=c, width=ep)
        d.line((s * 0.34, s * 0.54, s * 0.16, s * 0.68, s * 0.34, s * 0.82), fill=c, width=ep, joint="curve")
    elif kind == "clipboard":
        d.rounded_rectangle((s * 0.18, s * 0.18, s * 0.82, s * 0.90), radius=r, outline=c, width=ep)
        d.rounded_rectangle((s * 0.36, s * 0.10, s * 0.64, s * 0.26), radius=r // 2, fill=c)
        d.line((s * 0.32, s * 0.44, s * 0.44, s * 0.56), fill=c, width=ep // 2, joint="curve")
        d.line((s * 0.44, s * 0.56, s * 0.68, s * 0.34), fill=c, width=ep // 2, joint="curve")
        d.line((s * 0.32, s * 0.72, s * 0.68, s * 0.72), fill=c, width=ep // 2)
    elif kind == "bolt":
        d.line((s * 0.56, s * 0.08, s * 0.26, s * 0.54, s * 0.48, s * 0.54, s * 0.40, s * 0.92,
                s * 0.72, s * 0.44, s * 0.50, s * 0.44, s * 0.56, s * 0.08), fill=c, width=ep, joint="curve")
    elif kind == "chart":
        d.line((s * 0.14, s * 0.14, s * 0.14, s * 0.86, s * 0.88, s * 0.86), fill=c, width=ep, joint="curve")
        d.line((s * 0.30, s * 0.70, s * 0.30, s * 0.50), fill=c, width=int(ep * 1.5))
        d.line((s * 0.50, s * 0.70, s * 0.50, s * 0.34), fill=c, width=int(ep * 1.5))
        d.line((s * 0.70, s * 0.70, s * 0.70, s * 0.22), fill=c, width=int(ep * 1.5))
    elif kind == "coins":
        # pile de trois pièces
        for y in (0.24, 0.44, 0.64):
            d.ellipse((s * 0.22, s * y, s * 0.78, s * (y + 0.22)), outline=c, width=ep)
    elif kind == "clock":
        d.ellipse((s * 0.12, s * 0.12, s * 0.88, s * 0.88), outline=c, width=ep)
        d.line((s * 0.50, s * 0.30, s * 0.50, s * 0.52, s * 0.68, s * 0.62), fill=c, width=ep, joint="curve")
    elif kind == "doc":
        d.rounded_rectangle((s * 0.22, s * 0.10, s * 0.78, s * 0.90), radius=r, outline=c, width=ep)
        for y in (0.34, 0.48, 0.62, 0.76):
            d.line((s * 0.34, s * y, s * (0.52 if y == 0.76 else 0.66), s * y), fill=c, width=ep // 2)
    elif kind == "cloud":
        d.ellipse((s * 0.14, s * 0.38, s * 0.52, s * 0.76), outline=c, width=ep)
        d.ellipse((s * 0.34, s * 0.24, s * 0.74, s * 0.64), outline=c, width=ep)
        d.ellipse((s * 0.56, s * 0.38, s * 0.92, s * 0.76), outline=c, width=ep)
        d.rectangle((s * 0.20, s * 0.66, s * 0.88, s * 0.78), fill=(0, 0, 0, 0))
        d.line((s * 0.42, s * 0.82, s * 0.54, s * 0.94), fill=c, width=ep, joint="curve")
        d.line((s * 0.54, s * 0.94, s * 0.74, s * 0.70), fill=c, width=ep, joint="curve")
    elif kind == "download":
        # flèche vers un bac : « exporter / sauvegarder »
        d.line((s * 0.14, s * 0.70, s * 0.14, s * 0.90, s * 0.86, s * 0.90, s * 0.86, s * 0.70),
               fill=c, width=ep, joint="curve")
        d.line((s * 0.50, s * 0.12, s * 0.50, s * 0.62), fill=c, width=ep)
        d.line((s * 0.30, s * 0.42, s * 0.50, s * 0.62, s * 0.70, s * 0.42), fill=c, width=ep, joint="curve")
    elif kind == "android":
        d.arc((s * 0.18, s * 0.32, s * 0.82, s * 0.84), start=180, end=360, fill=c, width=ep)
        d.line((s * 0.18, s * 0.58, s * 0.82, s * 0.58), fill=c, width=ep)
        d.line((s * 0.34, s * 0.32, s * 0.42, s * 0.18), fill=c, width=ep // 2)
        d.line((s * 0.66, s * 0.32, s * 0.58, s * 0.18), fill=c, width=ep // 2)
        d.ellipse((s * 0.38, s * 0.40, s * 0.45, s * 0.47), fill=c)
        d.ellipse((s * 0.55, s * 0.40, s * 0.62, s * 0.47), fill=c)
        d.line((s * 0.36, s * 0.58, s * 0.36, s * 0.72), fill=c, width=ep // 2)
        d.line((s * 0.64, s * 0.58, s * 0.64, s * 0.72), fill=c, width=ep // 2)
    elif kind == "windows":
        d.rounded_rectangle((s * 0.12, s * 0.16, s * 0.88, s * 0.84), radius=r, outline=c, width=ep)
        d.line((s * 0.50, s * 0.18, s * 0.50, s * 0.82), fill=c, width=ep // 2)
        d.line((s * 0.14, s * 0.50, s * 0.86, s * 0.50), fill=c, width=ep // 2)
    elif kind == "globe":
        d.ellipse((s * 0.12, s * 0.12, s * 0.88, s * 0.88), outline=c, width=ep)
        d.ellipse((s * 0.36, s * 0.12, s * 0.64, s * 0.88), outline=c, width=ep // 2)
        d.line((s * 0.14, s * 0.50, s * 0.86, s * 0.50), fill=c, width=ep // 2)
    else:
        raise ValueError("icône inconnue : %s" % kind)

    return image.resize((size, size), Image.LANCZOS)


# --------------------------------------------------------------------------- QR code

def image_qr(adresse, cote):
    """QR code haute définition : modules nets (jamais rééchantillonnés), marge
    blanche réglementaire de 4 modules, correction d'erreur élevée (H, 30 %) pour
    rester lisible sur un support imprimé, même abîmé."""
    qr = segno.make(adresse, error="q")
    modules = qr.symbol_size(scale=1, border=4)[0]      # côté exprimé en modules
    echelle = max(1, cote // modules)
    tampon = io.BytesIO()
    qr.save(tampon, kind="png", scale=echelle, border=4, dark="#0d1726", light="#ffffff")
    image = Image.open(tampon).convert("RGB")
    if image.width < cote:                              # centrage sur fond blanc
        fond = Image.new("RGB", (cote, cote), WHITE)
        fond.paste(image, ((cote - image.width) // 2, (cote - image.height) // 2))
        image = fond
    return image


# --------------------------------------------------------------------------- affiches

AFFICHES = [
    {
        "numero": "1 / 3",
        "categorie": "CAISSE & VENTES",
        "titre": "Vendez plus vite,\nencaissez juste.",
        "accroche": "La caisse complète pour votre boutique : encaissement rapide, crédit "
                    "maîtrisé et livraisons suivies, sans cahier ni calculatrice.",
        "points": [
            ("cart", "Vente rapide",
             "Panier multi-produits, remise, TVA et totaux calculés automatiquement. Recherche instantanée du produit."),
            ("card", "Tous les moyens de paiement",
             "Espèces, Mobile Money, carte bancaire… et vente à crédit liée au client, avec contrôle de sa limite de crédit."),
            ("receipt", "Ticket de caisse imprimé",
             "Imprimante thermique par Bluetooth, USB ou Web Serial — et impression système en secours."),
            ("shield", "Crédit clients maîtrisé",
             "Solde, règlements partiels et historique détaillé : vous savez qui doit quoi, et depuis quand."),
            ("truck", "Livraisons organisées",
             "Affectez un livreur à chaque vente et suivez les courses du jour depuis l'historique."),
        ],
        "encart": [
            ("android", "Android"),
            ("windows", "Windows"),
            ("globe", "Navigateur web"),
        ],
    },
    {
        "numero": "2 / 3",
        "categorie": "STOCK & INVENTAIRE",
        "titre": "Votre stock,\nsous contrôle.",
        "accroche": "Entrées, sorties, inventaire et réassort : fini les ruptures et les "
                    "écarts qui ne s'expliquent pas.",
        "points": [
            ("cube", "Stock par magasin",
             "Un bilan produit × magasin pour chaque point de vente : vous savez exactement ce qui est où."),
            ("arrows", "Entrées et sorties fiables",
             "Une opération en cours ne touche pas le stock ; une opération validée ne le modifie qu'une seule fois."),
            ("clipboard", "Inventaire et écarts",
             "Comptage réel, écarts calculés, rapport daté et historique de tous les inventaires déjà réalisés."),
            ("bolt", "Réception fournisseurs express",
             "Recevez une commande multi-lignes en un clic : le stock de chaque produit est mis à jour."),
            ("chart", "Commande Express",
             "L'application analyse vos ventes et votre stock, puis propose le réassort par fournisseur."),
        ],
        "encart": [
            ("android", "Android"),
            ("windows", "Windows"),
            ("globe", "Navigateur web"),
        ],
    },
    {
        "numero": "3 / 3",
        "categorie": "RAPPORTS & RECOUVREMENT",
        "titre": "Des chiffres clairs\npour décider.",
        "accroche": "Tableau de bord, créances clients et rapports prêts à imprimer ou à "
                    "exporter : pilotez votre commerce avec des faits.",
        "points": [
            ("chart", "Tableau de bord complet",
             "Chiffre d'affaires, marge, dépenses, résultat, stock, créances et alertes, jour après jour."),
            ("coins", "Bénéfice en deux temps",
             "Voyez le bénéfice « avec créances » et le bénéfice « encaissé » : ce qui est réellement rentré en caisse."),
            ("clock", "Recouvrement suivi",
             "Taux d'encaissement, règlements reçus, derniers règlements et relances clients."),
            ("doc", "Rapports PDF par période",
             "Ventes, achats, stocks, dépenses, créances, bénéfices : mois passé, mois en cours, année."),
            ("download", "Exports et sauvegarde",
             "CSV de toutes vos tables, sauvegarde complète horodatée et restauration contrôlée."),
        ],
        "encart": [
            ("android", "Android"),
            ("windows", "Windows"),
            ("globe", "Navigateur web"),
        ],
    },
]


def dessiner_entete(image, affiche):
    """Bandeau supérieur marine : logo, catégorie, titre et accroche."""
    d = ImageDraw.Draw(image)
    hauteur = 1180
    # dégradé diagonal discret
    degrade = Image.new("RGB", (W, hauteur))
    gd = ImageDraw.Draw(degrade)
    for y in range(hauteur):
        t = y / hauteur
        gd.line((0, y, W, y), fill=(int(13 + 21 * t), int(23 + 29 * t), int(38 + 38 * t)))
    masque = Image.new("L", (W, hauteur), 0)
    ImageDraw.Draw(masque).rounded_rectangle((0, 0, W, hauteur + 80), radius=0, fill=255)
    image.paste(degrade, (0, 0), masque)

    # filet doré de séparation
    d.rectangle((0, hauteur, W, hauteur + 12), fill=GOLD)

    # logo + nom
    taille_logo = 190
    logo = Image.open(LOGO).convert("RGBA").resize((taille_logo, taille_logo), Image.LANCZOS)
    rond = Image.new("L", (taille_logo, taille_logo), 0)
    ImageDraw.Draw(rond).ellipse((0, 0, taille_logo - 1, taille_logo - 1), fill=255)
    image.paste(logo, (MARGIN, 120), rond)
    d = ImageDraw.Draw(image)
    d.text((MARGIN + taille_logo + 40, 150), "NOVA", font=font("Bold", 78), fill=WHITE)
    d.text((MARGIN + taille_logo + 40, 232), "Commerce", font=font("Medium", 62), fill=GOLD_LIGHT)

    # étiquette de catégorie
    etiquette = affiche["categorie"]
    f_kick = font("SemiBold", 40)
    largeur = d.textlength(etiquette, font=f_kick) + 108
    rounded(d, (W - MARGIN - largeur, 150, W - MARGIN, 258), 54, outline=GOLD, width=4)
    d.text((W - MARGIN - largeur + 54, 176), etiquette, font=f_kick, fill=GOLD_LIGHT)

    # titre
    y = 430
    for ligne in affiche["titre"].split("\n"):
        d.text((MARGIN, y), ligne, font=font("Bold", 132), fill=WHITE)
        y += 176

    # accroche
    text_block(d, (MARGIN, y + 24), affiche["accroche"], font("Regular", 50), PALE, W - 2 * MARGIN - 420, spacing=1.42)

    # motif doré discret (rappel des touches dorées de la marque)
    motif = Image.new("RGBA", (560, 260), (0, 0, 0, 0))
    md = ImageDraw.Draw(motif)
    for index, (dy, ep) in enumerate(((0, 20), (54, 11), (94, 6))):
        md.rounded_rectangle((0, dy, 480 - index * 90, dy + ep), radius=ep // 2, fill=(212, 162, 68, 110))
    motif = motif.rotate(-18, expand=True, resample=Image.BICUBIC)
    image.paste(motif, (W - motif.width - 60, hauteur - motif.height - 24), motif)

    # numéro d'affiche
    etiquette = "AFFICHE %s" % affiche["numero"]
    d.text((W - MARGIN - d.textlength(etiquette, font=font("SemiBold", 44)), 1010), etiquette,
           font=font("SemiBold", 44), fill=GOLD_LIGHT)
    return hauteur + 12


def dessiner_point(image, y, kind, titre, description):
    d = ImageDraw.Draw(image)
    taille_pastille = 168
    x = MARGIN
    # pastille
    rounded(d, (x, y, x + taille_pastille, y + taille_pastille), 44, fill=WHITE)
    d.rounded_rectangle((x, y, x + taille_pastille, y + taille_pastille), radius=44, outline=(226, 232, 240), width=3)
    ic = icon(kind, 104, NAVY)
    image.paste(ic, (x + (taille_pastille - 104) // 2, y + (taille_pastille - 104) // 2), ic)

    tx = x + taille_pastille + 48
    d.text((tx, y + 6), titre, font=font("SemiBold", 58), fill=INK)
    text_block(d, (tx, y + 92), description, font("Regular", 42), MUTED, W - tx - MARGIN, spacing=1.36)


def dessiner_encart(image, y):
    d = ImageDraw.Draw(image)
    hauteur = 232
    rounded(d, (MARGIN, y, W - MARGIN, y + hauteur), 40, fill=NAVY)
    d.text((MARGIN + 56, y + 34), "Disponible sur", font=font("SemiBold", 42), fill=GOLD_LIGHT)
    positions = [(MARGIN + 56, y + 116), (MARGIN + 56 + 520, y + 116), (MARGIN + 56 + 1040, y + 116)]
    for (kind, libelle), (px, py) in zip(AFFICHES[0]["encart"], positions):
        ic = icon(kind, 58, WHITE)
        image.paste(ic, (px, py + 6), ic)
        d.text((px + 78, py), libelle, font=font("Medium", 44), fill=WHITE)
    # pastille « essai gratuit »
    texte = "Essai gratuit 3 mois"
    f = font("SemiBold", 42)
    largeur = d.textlength(texte, font=f) + 88
    rounded(d, (W - MARGIN - 56 - largeur, y + 26, W - MARGIN - 56, y + 110), 42, fill=GOLD)
    d.text((W - MARGIN - 56 - largeur + 44, y + 48), texte, font=f, fill=NAVY)
    return y + hauteur


def dessiner_pied(image, y):
    """Pied de page ancré au bas de la feuille : contacts à gauche, QR à droite."""
    d = ImageDraw.Draw(image)
    d.rectangle((0, y, W, H), fill=NAVY)
    d.rectangle((0, y, W, y + 10), fill=GOLD)

    # logo réduit + coordonnées
    taille = 112
    logo = Image.open(LOGO).convert("RGBA").resize((taille, taille), Image.LANCZOS)
    rond = Image.new("L", (taille, taille), 0)
    ImageDraw.Draw(rond).ellipse((0, 0, taille - 1, taille - 1), fill=255)
    image.paste(logo, (MARGIN, y + 76), rond)
    d.text((MARGIN + taille + 36, y + 82), "IAFAD Consulting", font=font("SemiBold", 50), fill=WHITE)
    d.text((MARGIN + taille + 36, y + 146), "Ouagadougou, Burkina Faso", font=font("Regular", 40), fill=PALE)

    # contact
    d.text((MARGIN, y + 232), "Téléphone / WhatsApp : +226 76 83 04 82",
           font=font("SemiBold", 50), fill=GOLD_LIGHT)
    d.text((MARGIN, y + 306), "NOVA Commerce — gestion commerciale, ventes et stocks · français · FCFA",
           font=font("Regular", 36), fill=PALE)
    d.text((MARGIN, y + 358), "Données conservées sur votre appareil · Fonctionne hors ligne",
           font=font("Regular", 36), fill=(150, 168, 194))
    d.text((MARGIN, y + 410), "Application Android : APK de 4,5 Mo · Android 5.0 et plus",
           font=font("Regular", 36), fill=(150, 168, 194))

    # --- QR code de téléchargement de l'APK Android (côté droit) ---
    carte = 420
    marge_carte = 20
    cx = W - MARGIN - carte
    cy = y + 56
    rounded(d, (cx - marge_carte, cy - marge_carte, cx + carte + marge_carte, cy + carte + marge_carte),
            28, fill=WHITE)
    image.paste(image_qr(ADRESSE_APK, carte), (cx, cy))

    f_legende = font("SemiBold", 34)
    f_url = font("Regular", 26)
    centre = cx - marge_carte + (carte + 2 * marge_carte) / 2
    for index, ligne in enumerate(("Scannez pour installer", "l'application Android")):
        d.text((centre - d.textlength(ligne, font=f_legende) / 2, cy + carte + 40 + index * 42),
               ligne, font=f_legende, fill=WHITE)
    adresse_courte = ADRESSE_APK.replace("https://", "").replace("http://", "").rstrip("/")
    lignes_adresse = wrap(d, adresse_courte, f_url, carte + 2 * marge_carte)
    for index, ligne in enumerate(lignes_adresse[:2]):
        d.text((centre - d.textlength(ligne, font=f_url) / 2, cy + carte + 130 + index * 32),
               ligne, font=f_url, fill=(150, 168, 194))


def generer(affiche, dossier):
    image = Image.new("RGB", (W, H), CANVAS)
    d = ImageDraw.Draw(image)
    # fond très légèrement tramé
    for y in range(0, H, 8):
        d.line((0, y, W, y), fill=(246, 248, 251))

    y = dessiner_entete(image, affiche)

    # points forts
    y += 70
    for kind, titre, description in affiche["points"]:
        dessiner_point(image, y, kind, titre, description)
        y += 240

    y = dessiner_encart(image, y + 24)

    # Le pied de page est ancré au bas de la feuille (hauteur fixe) : le QR code et
    # les contacts gardent ainsi la même place sur les trois affiches.
    hauteur_pied = 715
    dessiner_pied(image, H - hauteur_pied)

    base = os.path.join(dossier, "affiche-%s-nova-commerce" % affiche["numero"].replace(" / ", "-"))
    image.save(base + ".png", "PNG", optimize=True, dpi=(DPI, DPI))
    image.save(base + ".pdf", "PDF", resolution=DPI)
    return base


def main():
    global ADRESSE_APK
    arguments = [a for a in sys.argv[1:]]
    if "--url" in arguments:
        position = arguments.index("--url")
        ADRESSE_APK = arguments[position + 1]
        del arguments[position:position + 2]
    dossier = arguments[0] if arguments else os.path.join(ROOT, "affiches")
    os.makedirs(dossier, exist_ok=True)
    for affiche in AFFICHES:
        base = generer(affiche, dossier)
        print("  · %s.png / .pdf" % os.path.relpath(base, ROOT))
    print("\n%d affiches A4 (210 × 297 mm, 300 dpi) générées dans %s" % (len(AFFICHES), os.path.relpath(dossier, ROOT)))
    print("QR code : %s" % ADRESSE_APK)
    if ADRESSE_APK == ADRESSE_APK_PAR_DEFAUT:
        print("⚠ ADRESSE PAR DÉFAUT (exemple) : relancez avec --url https://votre-adresse/… "
              "avant impression.")


if __name__ == "__main__":
    main()
