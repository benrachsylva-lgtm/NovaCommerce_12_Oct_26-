// Scénario navigateur : codes-barres (saisie, génération, doublons, scan vers le panier, stock, validation).
// Clavier réel (frappe + Entrée = comportement d'un scanner USB/Bluetooth en mode clavier).
// Nécessite le build instrumenté (hook window.__novaDebug) et un serveur statique sur BASE_URL.
const puppeteer = require('puppeteer');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:4190/index.html';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let failures = 0; let total = 0;
const check = (name, ok, detail = '') => { total += 1; if (!ok) failures += 1; console.log(`  ${ok ? '✓' : '✗'} ${name}${!ok && detail ? ' — ' + detail : ''}`); };
const errors = [];
async function boot(page) {
  await page.goto(BASE, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 });
  await sleep(4500);
  const firstRun = await page.evaluate(() => { const el = document.querySelector('#first-run-screen'); return !!el && getComputedStyle(el).display !== 'none'; });
  if (firstRun) { await page.evaluate(() => { const b = Array.from(document.querySelectorAll('button')).find((x) => x.innerText.includes('Charger la démonstration')); if (b) b.click(); }); await sleep(3000); }
  await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 });
  await page.evaluate(() => { const d = window.__novaDebug; d.user = d.state.users.find((u) => u.profile === 'Administrateur'); d.render(); });
  await sleep(500);
}
const dbg = (page, fn, ...args) => page.evaluate(new Function('args', `const d = window.__novaDebug; const [${args.map((_, i) => 'a' + i).join(',')}] = args; return (${fn})(d, ...args);`).toString().replace(/^function anonymous\(args\n\) \{\n/, '').replace(/\n\}$/, ''), args);
(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1360, height: 860 });
  page.on('pageerror', (e) => errors.push(String(e.message || e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('dialog', (d) => d.accept());
  await boot(page);

  const productCount = (code) => page.evaluate((c) => window.__novaDebug.state.products.filter((p) => p.barcode === c).length, code);
  const toastHas = (text) => page.evaluate((t) => document.body.innerText.includes(t), text);

  console.log('1. Saisie d’un code-barres à la création d’un article');
  await page.evaluate(() => { window.__novaDebug.setView('products'); }); await sleep(400);
  await page.evaluate(() => document.querySelector('[data-action="add-product"]').click()); await sleep(400);
  await page.evaluate(() => { const f = document.querySelector('#product-form'); f.elements.categoryId.value = Array.from(f.elements.categoryId.options).find((o) => o.value)?.value || ''; f.elements.code.value = 'SCAN-001'; f.elements.name.value = 'Eau minérale test'; f.elements.salePrice.value = '150'; f.elements.purchasePrice.value = '100'; });
  await page.click('#product-barcode');
  await page.keyboard.type('4006381333931');
  await page.keyboard.press('Enter');
  await sleep(150);
  const hint1 = await page.$eval('#product-barcode-hint', (el) => el.textContent);
  check('le code valide est confirmé à l’écran', hint1.includes('Code valide') && hint1.includes('EAN-13'), hint1);
  check('Entrée du scanner ne soumet pas le formulaire', await page.evaluate(() => !!document.querySelector('#product-form')));
  check('aperçu du code-barres affiché', await page.evaluate(() => !!document.querySelector('#product-barcode-preview svg')));
  await page.evaluate(() => document.querySelector('#product-form').requestSubmit()); await sleep(400);
  check('article enregistré avec le code-barres', (await productCount('4006381333931')) === 1);

  console.log('2. Génération d’un code interne (Code 128)');
  await page.evaluate(() => document.querySelector('[data-action="add-product"]').click()); await sleep(400);
  await page.evaluate(() => { const f = document.querySelector('#product-form'); f.elements.categoryId.value = Array.from(f.elements.categoryId.options).find((o) => o.value)?.value || ''; f.elements.code.value = 'GEN-001'; f.elements.name.value = 'Article généré'; f.elements.salePrice.value = '200'; f.elements.purchasePrice.value = '50'; });
  await page.click('#product-barcode-generate'); await sleep(150);
  const gen1 = await page.$eval('#product-barcode', (el) => el.value);
  check('code interne généré au format NC-00000001', gen1 === 'NC-00000001', gen1);
  await page.evaluate(() => document.querySelector('#product-form').requestSubmit()); await sleep(400);
  const saved = await page.evaluate(() => { const p = window.__novaDebug.state.products.find((x) => x.code === 'GEN-001'); return p ? { barcode: p.barcode, type: p.barcodeType, name: p.name } : null; });
  check('code interne enregistré avec son type « Interne »', !!saved && saved.barcode === 'NC-00000001' && saved.type === 'Interne' && saved.name === 'Article généré', JSON.stringify(saved));
  await page.evaluate(() => document.querySelector('[data-action="add-product"]').click()); await sleep(400);
  await page.evaluate(() => { const f = document.querySelector('#product-form'); f.elements.categoryId.value = Array.from(f.elements.categoryId.options).find((o) => o.value)?.value || ''; f.elements.code.value = 'GEN-002'; f.elements.name.value = 'Autre généré'; });
  await page.click('#product-barcode-generate'); await sleep(100);
  const gen2 = await page.$eval('#product-barcode', (el) => el.value);
  check('deuxième génération : numéro suivant, jamais réutilisé', gen2 === 'NC-00000002', gen2);
  await page.evaluate(() => { document.querySelector('#modal-root [data-close-modal]')?.click() || window.__novaDebug.render(); }); await sleep(200);

  console.log('3. Refus des doublons et des codes invalides');
  await page.evaluate(() => document.querySelector('[data-action="add-product"]').click()); await sleep(400);
  await page.evaluate(() => { const f = document.querySelector('#product-form'); f.elements.categoryId.value = Array.from(f.elements.categoryId.options).find((o) => o.value)?.value || ''; f.elements.code.value = 'DUP-001'; f.elements.name.value = 'Doublon'; f.elements.salePrice.value = '150'; });
  await page.click('#product-barcode'); await page.keyboard.type('4006381333931'); await page.keyboard.press('Enter'); await sleep(120);
  const dupHint = await page.$eval('#product-barcode-hint', (el) => el.textContent);
  check('doublon signalé avant enregistrement', dupHint.includes('Déjà utilisé') && dupHint.includes('Eau minérale test'), dupHint);
  await page.evaluate(() => document.querySelector('#product-form').requestSubmit()); await sleep(300);
  check('doublon refusé à l’enregistrement', (await productCount('4006381333931')) === 1 && await toastHas('Code-barres déjà utilisé'));
  await page.evaluate(() => { const f = document.querySelector('#product-form'); f.elements.categoryId.value = Array.from(f.elements.categoryId.options).find((o) => o.value)?.value || ''; f.elements.barcode.value = ''; });
  await page.click('#product-barcode'); await page.keyboard.type('4006381333932'); await page.keyboard.press('Enter'); await sleep(120);
  const badHint = await page.$eval('#product-barcode-hint', (el) => el.textContent);
  check('clé de contrôle fausse signalée', badHint.includes('Code refusé') && badHint.includes('clé de contrôle'), badHint);
  await page.evaluate(() => document.querySelector('#product-form').requestSubmit()); await sleep(300);
  check('code invalide non enregistré', (await page.evaluate(() => window.__novaDebug.state.products.some((p) => p.code === 'DUP-001'))) === false);
  await page.evaluate(() => { document.querySelector('#modal-root .modal-backdrop')?.remove(); });

  console.log('4. Zéros initiaux et codes distincts');
  await page.evaluate(() => { const d = window.__novaDebug; const base = d.state.products; base.push({ ...base[0], id: 'zz-zero', code: 'ZERO-1', name: 'Zéro initial', barcode: '0012345', barcodeType: 'Code 128', stock: 3, stockByStore: { [d.state.stores[0].id]: 3 } }); base.push({ ...base[0], id: 'zz-plain', code: 'ZERO-2', name: 'Sans zéro', barcode: '12345', barcodeType: 'Code 128', stock: 3, stockByStore: { [d.state.stores[0].id]: 3 } }); d.save(); d.render(); });
  check('0012345 et 12345 sont deux articles distincts', (await page.evaluate(() => window.__novaDebug.state.products.filter((p) => ['0012345', '12345'].includes(p.barcode)).length)) === 2);

  console.log('5. Scan dans la vente (clavier réel)');
  await page.evaluate(() => { window.__novaDebug.setView('sale'); }); await sleep(500);
  const focusId = await page.evaluate(() => document.activeElement && document.activeElement.id);
  check('le focus est sur le champ de scan à l’ouverture de la vente', focusId === 'sale-scan-input', focusId);
  await page.evaluate(() => { const d = window.__novaDebug; const p = d.state.products.find((x) => x.barcode === '4006381333931'); p.stockByStore[d.state.stores[0].id] = 10; p.stock = 10; d.save(); d.render(); });
  await sleep(300);
  await page.evaluate(() => { const s = document.querySelector('#sale-client'); if (s) { const opt = Array.from(s.options).find((o) => o.value !== 'counter'); if (opt) { s.value = opt.value; s.dispatchEvent(new Event('change')); } } });
  await sleep(300);
  const clientBefore = await page.$eval('#sale-client', (el) => el.value).catch(() => '');
  await page.evaluate(() => document.querySelector('[data-action="set-payment"][data-payment="mobile"]').click()); await sleep(300);
  await page.evaluate(() => { const i = document.getElementById('sale-scan-input'); i && i.focus(); });
  const stockBefore = await page.evaluate(() => window.__novaDebug.state.products.find((x) => x.barcode === '4006381333931').stock);
  await page.keyboard.type('4006381333931'); await page.keyboard.press('Enter'); await sleep(300);
  const line1 = await page.evaluate(() => { const t = document.querySelector('.cart-count'); return t ? t.textContent : ''; });
  const status1 = await page.$eval('#sale-scan-status', (el) => el.textContent).catch(() => '');
  check('un scan ajoute l’article au panier (quantité 1)', line1.includes('1 u.') && status1.includes('ajouté'), `${line1} | ${status1}`);
  await page.keyboard.type('4006381333931'); await page.keyboard.press('Enter'); await sleep(300);
  const qty2 = await page.evaluate(() => { const i = document.querySelector('[data-cart-input]'); return i ? Number(i.value) : -1; });
  check('un second scan incrémente la quantité (pas de ligne en double)', qty2 === 2 && (await page.$$('[data-cart-input]')).length === 1, String(qty2));
  const stockAfterScan = await page.evaluate(() => window.__novaDebug.state.products.find((x) => x.barcode === '4006381333931').stock);
  check('le scan ne modifie pas le stock avant validation', stockAfterScan === stockBefore, `${stockBefore} -> ${stockAfterScan}`);
  const clientAfter = await page.$eval('#sale-client', (el) => el.value).catch(() => '');
  const payActive = await page.evaluate(() => (document.querySelector('[data-action="set-payment"][data-payment="mobile"]') || {}).className || '');
  check('client et mode de paiement conservés après scan', clientAfter === clientBefore && payActive.includes('active'), `${clientBefore}/${clientAfter}`);
  check('focus restauré sur le champ de scan', (await page.evaluate(() => document.activeElement && document.activeElement.id)) === 'sale-scan-input');

  console.log('6. Cas d’erreur');
  await page.keyboard.type('5901234123457'); await page.keyboard.press('Enter'); await sleep(300);
  const nf = await page.$eval('#sale-scan-status', (el) => el.textContent).catch(() => '');
  const searchVal = await page.$eval('#sale-product-search', (el) => el.value).catch(() => '');
  check('code inconnu : message « introuvable » et pas de ligne fictive', nf.includes('introuvable') && (await page.$$('[data-cart-input]')).length === 1, nf);
  check('recherche manuelle lancée avec le code', searchVal === '5901234123457', searchVal);
  await page.keyboard.type('4006381333932'); await page.keyboard.press('Enter'); await sleep(250);
  const inv = await page.$eval('#sale-scan-status', (el) => el.textContent).catch(() => '');
  check('code invalide : message dédié, panier inchangé', inv.includes('invalide') && (await page.$$('[data-cart-input]')).length === 1, inv);
  await page.evaluate(() => { const d = window.__novaDebug; const p = d.state.products.find((x) => x.id === 'zz-plain'); p.active = false; d.save(); d.render(); }); await sleep(300);
  await page.evaluate(() => document.getElementById('sale-scan-input')?.focus());
  await page.keyboard.type('12345'); await page.keyboard.press('Enter'); await sleep(250);
  const ina = await page.$eval('#sale-scan-status', (el) => el.textContent).catch(() => '');
  check('article inactif refusé', ina.includes('inactif'), ina);
  await page.evaluate(() => document.getElementById('sale-scan-input')?.focus());
  await page.keyboard.type('0012345'); await page.keyboard.press('Enter'); await sleep(250);
  const z = await page.$eval('#sale-scan-status', (el) => el.textContent).catch(() => '');
  check('0012345 scanné trouve bien l’article « Zéro initial »', z.includes('Zéro initial'), z);
  await page.evaluate(() => { const d = window.__novaDebug; const p = d.state.products.find((x) => x.id === 'zz-zero'); p.stockByStore[d.state.stores[0].id] = 1; p.stock = 1; d.save(); d.render(); }); await sleep(300);
  await page.evaluate(() => document.getElementById('sale-scan-input')?.focus());
  await page.keyboard.type('0012345'); await page.keyboard.press('Enter'); await sleep(250);
  await page.keyboard.type('0012345'); await page.keyboard.press('Enter'); await sleep(250);
  const st = await page.$eval('#sale-scan-status', (el) => el.textContent).catch(() => '');
  check('stock insuffisant : refus avec la quantité disponible', st.includes('Stock insuffisant') && st.includes('1 unité'), st);

  console.log('7. Validation de la vente (une seule sortie de stock)');
  const before = await page.evaluate(() => { const d = window.__novaDebug; return { stock: d.state.products.find((x) => x.barcode === '4006381333931').stock, sales: d.state.sales.length }; });
  await page.evaluate(() => { const b = document.querySelector('[data-action="validate-sale"]'); b.click(); b.click(); });
  await sleep(500);
  const after = await page.evaluate(() => { const d = window.__novaDebug; return { stock: d.state.products.find((x) => x.barcode === '4006381333931').stock, sales: d.state.sales.length }; });
  check('double clic : une seule vente créée', after.sales === before.sales + 1, `${before.sales} -> ${after.sales}`);
  check('stock décrémenté une seule fois (quantité 2)', after.stock === before.stock - 2, `${before.stock} -> ${after.stock}`);
  await page.keyboard.press('Escape'); await sleep(200);
  const scanStatusAfter = await page.$eval('#sale-scan-status', (el) => el.textContent).catch(() => '');
  check('après validation : panier vide et message de prêt', scanStatusAfter.includes('Prêt'), scanStatusAfter);

  console.log('8. Persistance et recherche manuelle');
  await page.evaluate(() => window.__novaDebug.save()); await sleep(200);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction('!!window.__novaDebug', { timeout: 30000 }); await sleep(4000);
  const persisted = await page.evaluate(() => { const s = window.__novaDebug.state; return { eau: s.products.find((p) => p.barcode === '4006381333931')?.barcodeType, interne: s.products.find((p) => p.barcode === 'NC-00000001')?.barcodeType, zero: s.products.some((p) => p.barcode === '0012345') }; });
  check('codes-barres relus après rechargement', persisted.eau === 'EAN-13' && persisted.interne === 'Interne' && persisted.zero === true, JSON.stringify(persisted));

  console.log('9. Erreurs JavaScript');
  const relevant = errors.filter((e) => !/favicon|service-worker|ServiceWorker|Failed to load resource/i.test(e));
  check('aucune erreur JavaScript', relevant.length === 0, relevant.slice(0, 3).join(' | '));
  await browser.close();
  console.log(`\n${total - failures}/${total} vérifications OK`);
  if (failures) { console.log('ÉCHEC'); process.exit(1); }
  console.log('TOUS LES TESTS CODES-BARRES (NAVIGATEUR) : OK');
})().catch((e) => { console.error('ERREUR TEST', e); process.exit(1); });
