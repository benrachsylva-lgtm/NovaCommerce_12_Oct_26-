/**
 * NOVA Commerce — test licence d'appareil (nom boutique + UUID).
 *
 * Couvre : normalisation canonique, codec Crockford Base32, interopérabilité
 * de signature ECDSA (outil générateur -> app + Desktop), textos SMS, câblage
 * des vues (Nous contacter / Licence), synchronisation de la clé publique aux
 * trois endroits (app.js, main.cjs, cle-privee.json) et suppression de
 * l'ancien code partagé.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { subtle } = require('node:crypto').webcrypto;

const appSrc = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const mainSrc = fs.readFileSync(path.join(__dirname, '..', 'desktop', 'main.cjs'), 'utf8');
const preloadSrc = fs.readFileSync(path.join(__dirname, '..', 'desktop', 'preload.cjs'), 'utf8');
const readme = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');

const toolDir = process.env.NOVA_LICENCE_TOOL
  || path.resolve(__dirname, '..', '..', '..', '..', 'Nova-Licence-Generator');
const toolHtml = fs.readFileSync(path.join(toolDir, 'Nova-Licence-Generator.html'), 'utf8');
const toolKeyFile = JSON.parse(fs.readFileSync(path.join(toolDir, 'cle-privee.json'), 'utf8'));

function grabFunction(src, name) {
  let start = src.indexOf(`function ${name}(`);
  assert.ok(start >= 0, `fonction ${name} présente`);
  if (src.slice(Math.max(0, start - 6), start) === 'async ') start -= 6;
  let depth = 0;
  let i = src.indexOf('{', start);
  for (; i < src.length; i += 1) {
    if (src[i] === '{') depth += 1;
    if (src[i] === '}') { depth -= 1; if (!depth) break; }
  }
  return src.slice(start, i + 1);
}
function grabConst(src, name) {
  const line = src.split('\n').find((l) => l.includes(`const ${name} =`));
  assert.ok(line, `constante ${name} présente`);
  return line.trim().replace(/;$/, '');
}

const APP_FNS = ['normalizeBusinessName', 'normalizeDeviceUuid', 'licenceMessage', 'crockfordEncode',
  'crockfordDecode', 'groupLicenceKey', 'importLicencePublicKey', 'verifyLicenceSignature',
  'buildLicenceSms', 'smsLicenceHref'];
const APP_CONSTS = ['LICENCE_KEY_PREFIX', 'LICENCE_PUBLIC_JWK', 'CROCKFORD_ALPHABET', 'IAFAD_SMS_NUMBER', 'APP_VERSION'];

const coreStart = toolHtml.indexOf('/* LICENCE-CORE-START');
const coreEnd = toolHtml.indexOf('/* LICENCE-CORE-END');
assert.ok(coreStart >= 0 && coreEnd > coreStart, 'bloc LICENCE-CORE délimité dans l’outil');
const toolCore = toolHtml.slice(toolHtml.indexOf('\n', coreStart), coreEnd);

const harness = `
const window = { crypto: { subtle } };
${APP_CONSTS.map((c) => `${grabConst(appSrc, c)};`).join('\n')}
${APP_FNS.map((f) => grabFunction(appSrc, f)).join('\n')}
const tool = (() => {
${toolCore}
return { normalizeBusinessName, normalizeDeviceUuid, licenceMessage, crockfordEncode, crockfordDecode, groupLicenceKey, signLicenceKey, verifyLicenceSignature, fingerprintPublicJwk, parseLicenceSms, LICENCE_TOOL_VERSION };
})();
return (async () => {
  const report = [];
  const check = (label) => report.push(label);

  // ---------- A. normalisation canonique (app) ----------
  assert.strictEqual(normalizeBusinessName('  Café\\tMaquis   Le Délice '), 'CAFÉ MAQUIS LE DÉLICE');
  assert.strictEqual(normalizeBusinessName('ﬁnance'), 'FINANCE');
  assert.strictEqual(normalizeBusinessName('boutique\\u00A0centrale'), 'BOUTIQUE CENTRALE');
  assert.strictEqual(normalizeBusinessName(null), '');
  assert.strictEqual(normalizeDeviceUuid(' 550E8400-E29B-41D4-A716-446655440000 '), '550e8400-e29b-41d4-a716-446655440000');
  assert.strictEqual(licenceMessage('Maquis X', 'UUID-1'), 'NOVA-LICENCE/v1\\nnom=MAQUIS X\\nuuid=uuid-1\\n');
  check('A. normalisation: OK');

  // ---------- B. équivalence app <-> outil ----------
  const vectors = [
    ['  Café Maquis\\tLe Délice ', ' 550E8400-E29B-41D4-A716-446655440000 '],
    ['ﬁnance & co.', '9d2b1c9a9d2b1c9a9d2b1c9a9d2b1c9a'],
    ['Épicerie "Le Baobab" — N°1', 'MACHINE-GUID-1234'],
  ];
  vectors.forEach(([shop, uuid]) => {
    assert.strictEqual(tool.normalizeBusinessName(shop), normalizeBusinessName(shop));
    assert.strictEqual(tool.normalizeDeviceUuid(uuid), normalizeDeviceUuid(uuid));
    assert.strictEqual(tool.licenceMessage(shop, uuid), licenceMessage(shop, uuid));
  });
  const sample = new Uint8Array([0, 1, 2, 250, 255, 16, 32, 64, 128, 200, 7, 63, 100, 144, 211, 19]);
  assert.strictEqual(tool.crockfordEncode(sample), crockfordEncode(sample));
  assert.deepStrictEqual([...tool.crockfordDecode(crockfordEncode(sample))], [...sample]);
  assert.deepStrictEqual([...crockfordDecode(tool.crockfordEncode(sample))], [...sample]);
  assert.strictEqual(tool.groupLicenceKey('NOVA1' + 'A'.repeat(103)), groupLicenceKey('NOVA1' + 'A'.repeat(103)));
  check('B. équivalence app/outils: OK');

  // ---------- C. codec Crockford ----------
  const encoded = crockfordEncode(sample);
  assert.ok(/^[0-9A-HJKMNP-TV-Z]+$/.test(encoded), 'alphabet restreint (sans I,L,O,U)');
  assert.strictEqual(crockfordEncode(new Uint8Array(64)).length, 103, '64 octets -> 103 caractères');
  assert.deepStrictEqual([...crockfordDecode(encoded.toLowerCase().replace(/(.{4})/g, '$1-'))], [...sample]);
  assert.deepStrictEqual([...crockfordDecode('8I')], [...crockfordDecode('81')], 'alias I -> 1');
  assert.deepStrictEqual([...crockfordDecode('8L')], [...crockfordDecode('81')], 'alias L -> 1');
  assert.deepStrictEqual([...crockfordDecode('8O')], [...crockfordDecode('80')], 'alias O -> 0');
  assert.strictEqual(crockfordDecode('NOVA1-****'), null, 'caractère invalide rejeté');
  check('C. codec Crockford: OK');

  // ---------- D. groupement ----------
  assert.strictEqual(groupLicenceKey('NOVA1' + 'A'.repeat(103)), 'NOVA1-' + ('AAAA-'.repeat(25)) + 'AAA');
  assert.strictEqual(groupLicenceKey('ABCDEFGH'), 'ABCD-EFGH');
  check('D. groupement: OK');

  // ---------- E. signature outil -> vérification app ----------
  const shop = 'Maquis Le Délice';
  const uuid = '550e8400-e29b-41d4-a716-446655440000';
  const key = await tool.signLicenceKey(testKeys.priv, shop, uuid);
  assert.ok(key.startsWith('NOVA1') && key.length === 108, 'format NOVA1 + 103 caractères');
  assert.strictEqual(await verifyLicenceSignature(testKeys.pub, key, shop, uuid), true, 'clé valide');
  assert.strictEqual(await verifyLicenceSignature(testKeys.pub, groupLicenceKey(key).toLowerCase(), '  ' + shop + ' ', uuid.toUpperCase()), true, 'saisie tolérante');
  assert.strictEqual(await tool.verifyLicenceSignature(testKeys.pub, key, shop, uuid), true, 'outil auto-vérifie');
  assert.strictEqual(await verifyLicenceSignature(testKeys.pub, key, 'Autre boutique', uuid), false, 'nom modifié rejeté');
  assert.strictEqual(await verifyLicenceSignature(testKeys.pub, key, shop, '00000000-0000-0000-0000-000000000000'), false, 'UUID modifié rejeté');
  const flipped = key.slice(0, 50) + (key[50] === 'A' ? 'B' : 'A') + key.slice(51);
  assert.strictEqual(await verifyLicenceSignature(testKeys.pub, flipped, shop, uuid), false, 'signature altérée rejetée');
  assert.strictEqual(await verifyLicenceSignature(testKeys.pub, 'XOVA1' + key.slice(5), shop, uuid), false, 'préfixe rejeté');
  assert.strictEqual(await verifyLicenceSignature(testKeys.pub, key.slice(0, -1), shop, uuid), false, 'clé tronquée rejetée');
  check('E. ECDSA interopérable: OK');

  // ---------- F. paire réelle de production ----------
  const realKey = await tool.signLicenceKey(toolKeyFile.privateJwk, shop, uuid);
  assert.strictEqual(await verifyLicenceSignature(LICENCE_PUBLIC_JWK, realKey, shop, uuid), true, 'clé privée réelle -> clé publique embarquée');
  assert.strictEqual(await verifyLicenceSignature(LICENCE_PUBLIC_JWK, realKey, shop, 'autre-uuid'), false);
  check('F. paire de production: OK');

  // ---------- G. SMS ----------
  const sms = buildLicenceSms('  Maquis X ', 'UUID-1');
  assert.ok(sms.includes('NOVA Commerce v' + APP_VERSION) && sms.includes('Boutique : Maquis X') && sms.includes('UUID : UUID-1'));
  const href = smsLicenceHref('Maquis X', 'UUID-1');
  assert.ok(href.startsWith('sms:+22676830482?body='), 'schéma sms: vers IAFAD');
  assert.strictEqual(decodeURIComponent(href.split('?body=')[1]), buildLicenceSms('Maquis X', 'UUID-1'));
  check('G. SMS: OK');

  // ---------- H. lecteur SMS (outil) ----------
  assert.strictEqual(tool.LICENCE_TOOL_VERSION, '1.0.0', 'version outil');
  const roundtrip = tool.parseLicenceSms(buildLicenceSms('  Maquis Le Délice ', '550E8400-E29B-41D4-A716-446655440000'));
  assert.deepStrictEqual(roundtrip, { shop: 'Maquis Le Délice', uuid: '550E8400-E29B-41D4-A716-446655440000' }, 'SMS app -> parseur');
  assert.deepStrictEqual(tool.parseLicenceSms(['BOUTIQUE: Café X', 'Uuid: 9d2b1c9a9d2b1c9a9d2b1c9a9d2b1c9a'].join(String.fromCharCode(10))), { shop: 'Café X', uuid: '9d2b1c9a9d2b1c9a9d2b1c9a9d2b1c9a' }, 'casse tolérée');
  assert.deepStrictEqual(tool.parseLicenceSms(['Boutique : —', 'UUID : —'].join(String.fromCharCode(10))), { shop: '', uuid: '' }, 'champs vides');
  assert.deepStrictEqual(tool.parseLicenceSms('rien à voir'), { shop: '', uuid: '' }, 'texte libre');
  assert.strictEqual(tool.parseLicenceSms('voici 550e8400-e29b-41d4-a716-446655440000 merci').uuid, '550e8400-e29b-41d4-a716-446655440000', 'UUID repêché');
  check('H. lecteur SMS: OK');

  return report;
})();
`;

async function main() {
  const pair = await subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const testKeys = {
    pub: await subtle.exportKey('jwk', pair.publicKey),
    priv: await subtle.exportKey('jwk', pair.privateKey),
  };
  const factory = new Function('assert', 'subtle', 'testKeys', 'toolKeyFile', harness); // eslint-disable-line no-new-func
  const report = await factory(assert, subtle, testKeys, toolKeyFile);
  console.log('NOVA Commerce — test licence d’appareil');
  report.forEach((line) => console.log(line));

  // ---------- câblage statique ----------
  [
    'renderLicenceRequestCard', 'showLicenceSmsModal', 'ensureDeviceUuid', 'enforceLicenceBinding',
    'verifyLicenceKey', 'LICENCE_PUBLIC_JWK', 'smsLicenceHref', 'buildLicenceSms',
    'request-licence-sms', 'copy-licence-uuid', 'copy-business-name', 'copy-sms-text',
    'licence-device-uuid', 'licence-sms-text', 'name="licenseKey"', 'Demander ma licence',
    '+226 76 83 04 82', 'getDeviceUuid', 'invalidatedReason', 'Boutique liée', 'Appareil lié (UUID)',
  ].forEach((anchor) => assert.ok(appSrc.includes(anchor), `câblage app ${anchor}`));
  ['LICENSE_CODE_DIGEST', 'normalizeLicenseCode', "get('licenseCode')", 'NOVA-LICENCE-2026',
    'README.md pour supprimer', 'type="password" name="licenseCode'].forEach((relic) => assert.ok(!appSrc.includes(relic), `relique app ${relic}`));
  ['nova-device-uuid', 'getMachineUuid', 'verifyLicenceKey', 'MachineGuid', 'machine-id',
    'IOPlatformUUID', 'payload?.key', 'payload?.deviceUuid', 'LICENCE_PUBLIC_JWK'].forEach((anchor) => assert.ok(mainSrc.includes(anchor), `câblage main ${anchor}`));
  ['LICENSE_CODE_DIGEST', 'licenseDigest', 'constantTimeHexEqual', 'normalizeLicenseCode', 'payload?.code'].forEach((relic) => assert.ok(!mainSrc.includes(relic), `relique main ${relic}`));
  assert.ok(preloadSrc.includes('getDeviceUuid'), 'câblage preload getDeviceUuid');
  assert.ok(preloadSrc.includes('licence?.key'), 'câblage preload activateLicense');
  assert.ok(!preloadSrc.includes("code: String(code"), 'relique preload');
  ['Demander ma licence', '+226 76 83 04 82', 'ECDSA', 'Nova-Licence-Generator', 'Nous contacter'].forEach((anchor) => assert.ok(readme.includes(anchor), `README ${anchor}`));
  assert.ok(!readme.includes('NOVA-LICENCE-2026'), 'README sans ancien code');
  ['LICENCE-CORE-START', 'LICENCE-CORE-END', 'signLicenceKey', 'parseLicenceSms', 'Nova-Licence-Generator', 'cle-privee.json', 'Générer la clé', 'Analyser le SMS'].forEach((anchor) => assert.ok(toolHtml.includes(anchor), `outil ${anchor}`));
  console.log('Câblage : OK');

  // ---------- synchronisation de la clé publique (3 endroits) ----------
  const jwkOf = (src) => {
    const found = src.match(/LICENCE_PUBLIC_JWK = \{ kty: 'EC', crv: 'P-256', x: '([^']+)', y: '([^']+)' \}/);
    assert.ok(found, 'JWK embarquée lisible');
    return { kty: 'EC', crv: 'P-256', x: found[1], y: found[2] };
  };
  assert.deepStrictEqual(jwkOf(appSrc), toolKeyFile.publicJwk, 'app.js = cle-privee.json');
  assert.deepStrictEqual(jwkOf(mainSrc), toolKeyFile.publicJwk, 'main.cjs = cle-privee.json');
  console.log('Clé publique synchronisée (app.js = main.cjs = cle-privee.json) : OK');

  console.log('\nTOUS LES TESTS LICENCE : OK');
}

main().catch((error) => { console.error(error); process.exit(1); });
