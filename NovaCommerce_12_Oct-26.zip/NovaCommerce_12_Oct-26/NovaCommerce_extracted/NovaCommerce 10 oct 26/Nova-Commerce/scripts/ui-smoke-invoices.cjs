// Test navigateur réel (hors dépôt) : facture → facturation → caisse → encaissement partiel → reçu → vente directe.
const puppeteer = require('puppeteer');
const crypto = require('crypto');
const KEY = 'nova-commerce-state-v1';
const SALT = 'nova-test-facturation';
const HASH = `pbkdf2-sha256$${SALT}$120000$${crypto.pbkdf2Sync('Test-1234!', SALT, 120000, 32, 'sha256').toString('hex')}`;
const log = (...a) => console.log(...a);
const BASE = process.env.BASE_URL || 'http://127.0.0.1:4190/index.html';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let page = null;
const clickSel = async (sel) => { try { await page.click(sel, { timeout: 4000 }); } catch (_) { await page.evaluate((x) => document.querySelector(x)?.click(), sel); } };
(async () => {
  const browser = global.__browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'] });
  page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 950 });
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('dialog', (d) => d.accept());
  await page.goto(BASE, { waitUntil: 'networkidle0' });
  await page.waitForSelector('[data-database-mode="demo"]', { timeout: 30000 });
  await sleep(1500);
  await page.evaluate(() => document.querySelector('[data-database-mode="demo"]').click());
  log('1. Données de démonstration chargées');
  await sleep(2500);
  await page.waitForFunction(() => { const i = document.querySelector('input[name="username"]'); return i && i.offsetParent !== null; }, { timeout: 30000 });
  await page.evaluate((key, hash) => {
    const s = JSON.parse(localStorage.getItem(key));
    const u = s.users.find((x) => x.username === 'mariam');
    u.passwordHash = hash; u.profile = 'Gérant';
    localStorage.setItem(key, JSON.stringify(s));
  }, KEY, HASH);
  await page.reload({ waitUntil: 'networkidle0' });
  await page.waitForFunction(() => { const i = document.querySelector('input[name="username"]'); return i && i.offsetParent !== null; }, { timeout: 30000 });
  await page.type('input[name="username"]', 'mariam');
  await page.type('input[name="password"]', 'Test-1234!');
  await page.keyboard.press('Enter');
  await page.waitForSelector('[data-view="sale"]', { timeout: 30000 });
  log('2. Connexion OK (profil Gérant de test)');
  const snapshot = () => page.evaluate((key) => JSON.parse(localStorage.getItem(key)), KEY);
  const nav = async (view) => { await clickSel(`[data-view="${view}"]`); await sleep(350); };
  const s0 = await snapshot();
  const client = s0.clients.find((c) => c.active !== false && c.id !== 'counter');
  const product = s0.products.find((p) => p.active && Object.values(p.stockByStore || {}).some((q) => Number(q) >= 3));
  const storeId = Object.keys(product.stockByStore).find((k) => Number(product.stockByStore[k]) >= 3);
  log(`   client=${client.name} produit=${product.name} stock=${product.stockByStore[storeId]} magasin=${storeId}`);

  // ---- Brouillon de facture ----
  await nav('sale');
  await page.waitForSelector('#sale-client', { timeout: 15000 });
  await page.select('#sale-client', client.id);
  await sleep(200);
  await page.click(`[data-product-card][data-product-id="${product.id}"]`, { clickCount: 2 });
  await sleep(400);
  await page.click('[data-action="set-sale-mode"][data-mode="invoice"]');
  await sleep(300);
  const stockBefore = (await snapshot()).products.find((p) => p.id === product.id).stockByStore[storeId];
  await page.$eval('#invoice-due', (el) => { el.value = '2026-12-31'; el.dispatchEvent(new Event('input', { bubbles: true })); });
  await page.click('[data-action="save-invoice-draft"]');
  await sleep(400);
  const s1 = await snapshot();
  const draft = s1.sales.find((x) => x.kind === 'invoice' && x.status === 'Brouillon');
  log(`3. Brouillon enregistré : ${draft ? draft.number : 'ABSENT'} ; stock inchangé=${s1.products.find((p) => p.id === product.id).stockByStore[storeId] === stockBefore}`);
  if (!draft) throw new Error('brouillon non créé');
  await nav('invoices');
  const rowsBefore = await page.$$eval('#invoices-table-body tr[data-invoice-row]', (rows) => rows.length);
  log(`   liste Facturation : ${rowsBefore} ligne(s)`);
  await nav('collect');
  const collectBrouillon = await page.$$eval('#collect-table-body tr[data-collect-row]', (rows) => rows.map((r) => r.textContent).join(' | '));
  log(`   caisse avant validation : ${collectBrouillon.includes(draft.number) ? 'BROUILLON VISIBLE (anomalie)' : 'brouillon absent (attendu)'}`);

  // ---- Validation de la facture ----
  await nav('sale');
  await page.click('[data-action="set-sale-mode"][data-mode="invoice"]');
  await sleep(200);
  const loadBtn = await page.$(`[data-action="load-invoice-draft"][data-id="${draft.id}"]`);
  if (loadBtn) { await nav('invoices'); await page.click(`[data-action="load-invoice-draft"][data-id="${draft.id}"]`); await sleep(400); }
  await page.click('[data-action="validate-invoice"]');
  await sleep(700);
  const s2 = await snapshot();
  const inv = s2.sales.find((x) => x.kind === 'invoice' && x.status === 'Validée');
  const stockAfter = s2.products.find((p) => p.id === product.id).stockByStore[storeId];
  const qty = inv ? inv.items.reduce((a, i) => a + Number(i.quantity), 0) : 0;
  log(`4. Facture validée : ${inv ? inv.number : 'ABSENTE'} ; stock ${stockBefore} → ${stockAfter} (sortie unique de ${qty}: ${stockBefore - stockAfter === qty})`);
  if (!inv) throw new Error('facture non validée');
  await page.click('[data-close-modal]').catch(() => {});
  await sleep(200);
  log(`   règlements créés à la validation : ${s2.customerPayments.length - s1.customerPayments.length} (attendu 0)`);

  // ---- Caisse ----
  await nav('collect');
  const collectRow = await page.$eval('#collect-table-body', (el) => el.textContent);
  log(`5. Caisse « Factures à encaisser » contient ${inv.number} : ${collectRow.includes(inv.number)}`);
  await page.click(`[data-action="open-invoice-payment"][data-id="${inv.id}"]`);
  await sleep(400);
  await page.$eval('#invoice-payment-form [name="amount"]', (el) => { el.value = '100'; });
  await page.click('[data-invoice-pay-submit]');
  await sleep(700);
  const modal2 = await page.$eval('#modal-root', (el) => el.textContent).catch(() => '');
  const s3 = await snapshot();
  const pays = s3.customerPayments.filter((p) => p.saleId === inv.id);
  log(`6. Encaissement partiel 100 : règlements liés=${pays.length} montant=${pays.map((p) => p.amount).join(',')} ; reçu affiché=${modal2.includes('Reçu')}`);
  log(`   stock après encaissement inchangé : ${s3.products.find((p) => p.id === product.id).stockByStore[storeId] === stockAfter}`);
  await page.click('[data-close-modal]').catch(() => {});
  await sleep(200);

  // Montant supérieur au solde : refusé
  await nav('collect');
  await page.click(`[data-action="open-invoice-payment"][data-id="${inv.id}"]`);
  await sleep(400);
  await page.$eval('#invoice-payment-form [name="amount"]', (el) => { el.value = '999999'; });
  await page.click('[data-invoice-pay-submit]');
  await sleep(500);
  const s4 = await snapshot();
  log(`7. Trop-perçu 999999 : refusé (règlements inchangés=${s4.customerPayments.filter((p) => p.saleId === inv.id).length === pays.length})`);
  await page.click('[data-close-modal]').catch(() => {});
  await sleep(200);

  // Solde restant : facture soldée
  const total = inv.items.reduce((a, i) => a + Number(i.quantity) * Number(i.unitPrice), 0);
  const solde = total - 100;
  await nav('collect');
  await page.click(`[data-action="open-invoice-payment"][data-id="${inv.id}"]`);
  await sleep(400);
  await page.$eval('#invoice-payment-form [name="amount"]', (el, v) => { el.value = v; }, String(solde));
  await page.click('[data-invoice-pay-submit]');
  await sleep(600);
  const s5 = await snapshot();
  const paidTotal = s5.customerPayments.filter((p) => p.saleId === inv.id).reduce((a, p) => a + p.amount, 0);
  log(`8. Solde ${solde} encaissé : total encaissé=${paidTotal} / facture=${total}`);
  await page.click('[data-close-modal]').catch(() => {});
  await sleep(200);
  await nav('invoices');
  const invText = await page.$eval('#invoices-table-body', (el) => el.textContent);
  log(`   liste Facturation : statut « Payée intégralement » = ${invText.includes('Payée intégralement')}`);
  await page.screenshot({ path: '/tmp/e2e/ui/invoices.png' });

  // ---- Vente directe : inchangée ----
  await nav('sale');
  await page.click('[data-action="set-sale-mode"][data-mode="direct"]');
  await sleep(250);
  const beforeDirect = (await snapshot()).sales.length;
  await page.click(`[data-product-card][data-product-id="${product.id}"]`, { clickCount: 2 });
  await sleep(400);
  await page.click('[data-action="validate-sale"]');
  await sleep(600);
  const s6 = await snapshot();
  const newSales = s6.sales.slice(0, s6.sales.length - beforeDirect); // ventes insérées en tête de liste
  const direct = newSales.find((x) => !x.kind || x.kind === 'direct');
  log(`9. Vente directe : ${s6.sales.length - beforeDirect} vente(s) créée(s) ; statut=${direct?.status || 'n/a'} ; mode=${direct?.payment || 'n/a'}`);

  log(`\nErreurs JavaScript pendant le parcours : ${errors.length}`);
  errors.slice(0, 10).forEach((e) => log('  - ' + e.slice(0, 300)));
  await browser.close();
})().catch(async (e) => { console.error('ECHEC:', e.message); process.exitCode = 1; }).finally(() => process.exit(process.exitCode || 0));
