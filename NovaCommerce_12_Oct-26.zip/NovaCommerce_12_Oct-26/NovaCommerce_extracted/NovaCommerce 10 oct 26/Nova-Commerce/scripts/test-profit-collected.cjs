/* Test de non-régression : bénéfice avec créances vs bénéfice encaissé.
 * Exécute le VRAI code de app.js (prorata FIFO par client + agrégation)
 * sur un jeu de données qui couvre : comptant, crédit impayé/partiel/soldé,
 * report initial, avoirs liés et non liés, client inconnu, brouillon.
 * Lancer avec : npm run test:profit */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

const blocks = [
  extract('  const num = '),
  ...['saleTotal', 'saleMargin', 'creditNoteTotal', 'creditNoteMargin', 'validSales',
    'validCreditNotes', 'creditPaymentsTotal', 'creditNoteSale', 'noteBelongsToCredit',
    'creditNoteAdjustmentsBySale', 'creditCollectionRatios', 'saleCollectedMargin',
    'collectedMarginOf'].map((name) => extract(`  function ${name}(`)),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let state = null;
const productById = () => null;
const mkSale = (id, payment, clientId, date, number, qty, unitPrice, costPrice, status = 'Validée') => (
  { id, payment, clientId, date, number, status, items: [{ productId: 'p1', quantity: qty, unitPrice, costPrice }] }
);
state = {
  clients: [
    { id: 'ca', name: 'Client A', openingReceivable: 0 },
    { id: 'cb', name: 'Client B', openingReceivable: 50000 },
    { id: 'cc', name: 'Client C', openingReceivable: 10000 }
  ],
  sales: [
    mkSale('s1', 'cash', 'counter', '2026-09-01', 'V-001', 10, 1000, 600),
    mkSale('s2', 'credit', 'ca', '2026-09-02', 'V-002', 10, 1000, 600),
    mkSale('s3', 'credit', 'ca', '2026-09-03', 'V-003', 5, 2000, 1200),
    mkSale('s4', 'credit', 'cb', '2026-09-04', 'V-004', 10, 2000, 1200),
    mkSale('s5', 'credit', 'ca', '2026-09-05', 'V-005', 10, 1000, 600),
    mkSale('s6', 'cash', 'counter', '2026-09-06', 'V-006', 10, 3000, 1800),
    mkSale('s7', 'credit', 'inconnu', '2026-09-07', 'V-007', 10, 1000, 600),
    mkSale('s8', 'credit', 'cc', '2026-09-08', 'V-008', 10, 1000, 600),
    mkSale('s9', 'credit', 'ca', '2026-09-09', 'V-009', 10, 1000, 600, 'Brouillon')
  ],
  creditNotes: [
    { id: 'n1', status: 'Validée', payment: 'cash', originalSaleId: 's6', lines: [{ productId: 'p1', quantity: 5, unitPrice: 1000, costPrice: 600 }] },
    { id: 'n2', status: 'Validée', payment: 'credit', clientId: 'ca', originalSaleId: 's5', lines: [{ productId: 'p1', quantity: 2, unitPrice: 1000, costPrice: 600 }] },
    { id: 'n3', status: 'Validée', payment: 'credit', clientId: 'ca', originalSaleId: '', lines: [{ productId: 'p1', quantity: 1, unitPrice: 1000, costPrice: 600 }] }
  ],
  customerPayments: [
    { status: 'Validé', clientId: 'ca', amount: 15000 },
    { status: 'En cours', clientId: 'ca', amount: 999999 },
    { status: 'Validé', clientId: 'cb', amount: 60000 },
    { status: 'Validé', clientId: 'cc', amount: 6000 }
  ]
};
// ---------- scénario ----------
const report = [];
const variation = creditCollectionRatios();
const { ratios, adjustments } = variation;
assert.strictEqual(ratios.s2, 1, 'A/V-002 soldée');
assert.strictEqual(ratios.s3, 0.5, 'A/V-003 moitié');
assert.strictEqual(ratios.s5, 0, 'A/V-005 impayée');
assert.strictEqual(ratios.s4, 0.5, 'B/V-004 moitié après report');
assert.strictEqual(ratios.s8, 0, 'C/V-008 report non couvert');
assert.strictEqual(ratios.s7, undefined, 'vente orpheline prudente');
assert.deepStrictEqual(adjustments.s5, { total: 2000, margin: 800 }, 'avoir lié déduit');
assert.strictEqual(adjustments[''], undefined, 'avoir non lié hors prorata');
report.push('Prorata: FIFO + report initial + avoir lié OK');
assert.strictEqual(noteBelongsToCredit(state.creditNotes[0]), false, 'avoir comptant');
assert.strictEqual(noteBelongsToCredit(state.creditNotes[1]), true, 'avoir crédit lié');
assert.strictEqual(noteBelongsToCredit(state.creditNotes[2]), true, 'avoir crédit repli');
assert.strictEqual(noteBelongsToCredit({ payment: 'cash' }), false, 'repli comptant');
const byId = (id) => state.sales.find((s) => s.id === id);
assert.strictEqual(saleCollectedMargin(byId('s1'), variation), 4000, 'comptant 100 %');
assert.strictEqual(saleCollectedMargin(byId('s2'), variation), 4000, 'crédit soldé');
assert.strictEqual(saleCollectedMargin(byId('s3'), variation), 2000, 'crédit moitié');
assert.strictEqual(saleCollectedMargin(byId('s5'), variation), 0, 'crédit impayé');
assert.strictEqual(saleCollectedMargin(byId('s4'), variation), 4000, 'crédit moitié B');
assert.strictEqual(saleCollectedMargin(byId('s7'), variation), 0, 'orpheline 0');
assert.strictEqual(saleCollectedMargin(byId('s9'), variation), 0, 'brouillon 0');
assert.strictEqual(saleCollectedMargin(null, variation), 0, 'nulle 0');
assert.strictEqual(saleCollectedMargin(byId('s1'), undefined), 4000, 'sans prorata');
report.push('Vente: comptant + paliers crédit + gardes OK');
const classic = validSales().reduce((t, s) => t + saleMargin(s), 0) - validCreditNotes().reduce((t, n) => t + creditNoteMargin(n), 0);
assert.strictEqual(classic, 40800, 'bénéfice avec créances');
assert.strictEqual(collectedMarginOf(validSales(), validCreditNotes(), variation), 23600, 'bénéfice encaissé');
assert.strictEqual(collectedMarginOf([], [], variation), 0, 'vide 0');
assert.strictEqual(collectedMarginOf([byId('s1')], [], undefined), 4000, 'comptant seul');
report.push('Agrégat: 40 800 avec créances vs 23 600 encaissé OK');
state.customerPayments.push({ status: 'Validé', clientId: 'ca', amount: 20000 });
const full = creditCollectionRatios();
assert.strictEqual(full.ratios.s3, 1, 'A/V-003 soldée');
assert.strictEqual(full.ratios.s5, 1, 'A/V-005 soldée');
assert.strictEqual(collectedMarginOf([byId('s2'), byId('s3'), byId('s5')], [], full), 11200, 'client soldé');
report.push('Règlement tardif: rejoint l’encaissé OK');
return { report };
`;

const result = new Function('assert', harness)(assert);
console.log('NOVA Commerce — test bénéfice encaissé');
result.report.forEach((line) => console.log(line));
console.log('Calcul : OK');

// ---------- affichage (vérifications statiques) ----------
const appSrc = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const cssSrc = fs.readFileSync(path.join(__dirname, '..', 'styles.css'), 'utf8');
[
  'Encaissé du jour', 'Bénéfice net encaissé', 'collectedMarginOf(daySales, dayNotes',
  'collectedMarginOf(monthSales, monthNotes', 'stat-strip five', 'Bénéfice encaissé',
  'encaissé ${money(saleCollectedMargin(sale, profitCollection))}', 'Marge encaissée',
  'Résultat net encaissé', 'netCollected', 'Marge brute encaissée',
  "duo: true, aLabel: 'Résultat net', bLabel: 'Résultat net encaissé'",
  "'Marge encaissée', 'Résultat encaissé'", 'encaissée ${money(per[2].collected)}',
  'encaissé (hors créances)',
  'Calcul des indicateurs financiers', 'Seules les opérations au statut Validée',
  'Quantité × (prix de vente − coût)', 'Marge encaissée divisée par marge brute',
  'Dépenses Validées de la période', 'Total brut des ventes à crédit validées',
  'soldent d’abord son report initial', 'Cas particulier',
].forEach((anchor) => assert.ok(appSrc.includes(anchor), `affichage ${anchor}`));
assert.strictEqual((appSrc.match(/\{ label: 'Marge brute encaissée', values: per\.map\(\(p\) => p\.collected\), fmt: 'money' \}/g) || []).length, 2, 'lignes ventes + bénéfices');
assert.strictEqual((appSrc.match(/collectedMarginOf\(/g) || []).length, 9, 'définition + 8 appels');
assert.strictEqual((appSrc.match(/creditCollectionRatios\(\)/g) || []).length, 9, 'définition + 8 appels (dont facturation : invoiceSettlement, liste factures, caisse)');
assert.ok(cssSrc.includes('.stat-strip.five'), 'style bandeau 5');
console.log('Affichage : OK (tableau de bord, bilan ventes, comptabilité, rapports, guide)');
console.log('\nTOUS LES TESTS BÉNÉFICE : OK');
