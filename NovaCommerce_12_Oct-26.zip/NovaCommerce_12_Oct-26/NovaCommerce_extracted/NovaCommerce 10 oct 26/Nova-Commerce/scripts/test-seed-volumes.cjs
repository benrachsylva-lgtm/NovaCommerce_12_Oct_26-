/* Test de non-régression : volumes et intégrité des données de démonstration (2 ans).
 * Exécute le VRAI seedState de app.js et contrôle les effectifs, les références,
 * les dates (sept 2024 → sept 2026), les numéros, les totaux et le déterminisme.
 * Lancer avec : npm run test:seed */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert');

const appLines = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8').split('\n');

function extract(marker) {
  const start = appLines.findIndex((line) => line.includes(marker));
  if (start < 0) throw new Error(`bloc introuvable: ${marker}`);
  const first = appLines[start];
  const opens = (first.match(/\{/g) || []).length;
  const closes = (first.match(/\}/g) || []).length;
  if (opens === closes && first.trimEnd().endsWith(';')) return first;
  let depth = 0;
  let begun = false;
  for (let i = start; i < appLines.length; i += 1) {
    for (const ch of appLines[i]) {
      if (ch === '{') { depth += 1; begun = true; }
      if (ch === '}') depth -= 1;
    }
    if (begun && depth === 0) return appLines.slice(start, i + 1).join('\n');
  }
  throw new Error(`bloc non terminé: ${marker}`);
}

const blocks = [
  ...['PROTECTED_ADMIN_USERNAME', 'SEED_PASSWORD_HASHES', 'num', 'isoDate', 'isoDateTime',
    'seedState'].map((name) => extract(`  const ${name} = `)),
  ...['dateCode', 'validSales', 'validCreditNotes', 'saleTotal', 'creditNoteTotal',
    'creditNotesTotalForClient', 'creditSalesTotal', 'creditPaymentsTotal',
    'validRefunds', 'clientRefundsTotal', 'clientPositionValues',
    'refreshClientReceivables', 'productById'].map((name) => extract(`  function ${name}(`)),
];

const harness = `
${blocks.join('\n')}
// ---------- environnement de test ----------
let state = null;
const perfStart = Date.now();
state = seedState();
const genMs = Date.now() - perfStart;
const report = [];
// ---------- volumes exigés ----------
const volumes = [
  ['stores', 2], ['categories', 20], ['products', 100], ['suppliers', 40],
  ['clients', 300], ['stockEntries', 300], ['stockExits', 20], ['orders', 500],
  ['sales', 4009], ['inventoryReports', 12], ['deliverers', 15], ['deliveries', 500],
  ['stockTransfers', 15]
];
volumes.forEach(([key, expected]) => assert.strictEqual(state[key].length, expected, key + ' = ' + expected));
assert.ok(state.customerPayments.length > 0, 'règlements générés');
assert.ok(state.inventory.length > 0, 'comptages générés');
assert.strictEqual(state.users.length, 3, 'utilisateurs conservés');
assert.strictEqual(state.roles.length, 5, 'profils conservés');
report.push('Volumes: ' + volumes.map(([k, v]) => k + '=' + v).join(', ')
  + ', règlements=' + state.customerPayments.length + ', comptages=' + state.inventory.length);
// ---------- identités historiques conservées ----------
const byId = (list, id) => list.find((x) => x.id === id);
assert.strictEqual(byId(state.deliverers, 'liv-01').firstName, 'Ibrahim');
assert.strictEqual(byId(state.deliverers, 'liv-02').firstName, 'Awa');
assert.strictEqual(byId(state.deliverers, 'liv-03').active, false);
assert.strictEqual(byId(state.products, 'prod-03').stock, 0, 'prod-03 en rupture');
assert.strictEqual(byId(state.sales, 'sale-02').clientId, 'client-01');
assert.strictEqual(state.deliveries.find((d) => d.saleId === 'sale-02').delivererId, 'liv-01');
assert.strictEqual(state.deliveries.filter((d) => d.saleId === 'sale-01').length, 0);
assert.strictEqual(state.deliveries.filter((d) => d.saleId === 'sale-04').length, 0);
report.push('Identités: liv-01/02/03, prod-03, sale-02→liv-01, sale-01/04 sans livraison : OK');
// ---------- créances : exactement 40 débiteurs ----------
refreshClientReceivables();
const debtors = state.clients.filter((c) => Number(c.receivable) > 0);
// 40 débiteurs générés + 4 clients avec factures de démo non soldées (A, B, C, D) : la facture annulée par avoir (G) ne crée aucune créance.
assert.strictEqual(debtors.length, 44, '44 créances, obtenu ' + debtors.length);
assert.ok(Number(byId(state.clients, 'client-01').receivable) > 0, 'client-01 débiteur');
assert.ok(Number(byId(state.clients, 'client-03').receivable) > 0, 'client-03 débiteur');
assert.strictEqual(Number(byId(state.clients, 'client-02').receivable), 0);
assert.strictEqual(Number(byId(state.clients, 'client-04').receivable), 0);
// Ventes générées uniquement : une facture de démo entièrement réglée ou annulée par avoir ne crée plus de créance (cf. test-demo-invoices).
const creditClientIds = new Set(state.sales.filter((s) => s.payment === 'credit' && s.kind !== 'invoice').map((s) => s.clientId));
creditClientIds.forEach((id) => assert.ok(debtors.some((c) => c.id === id), 'crédit sans débiteur: ' + id));
const totalReceivable = debtors.reduce((s, c) => s + Number(c.receivable), 0);
report.push('Créances: ' + debtors.length + ' débiteurs pour ' + totalReceivable + ' FCFA');
// ---------- intégrité référentielle ----------
const productIds = new Set(state.products.map((p) => p.id));
const clientIds = new Set(state.clients.map((c) => c.id));
const supplierIds = new Set(state.suppliers.map((s) => s.id));
const storeIds = new Set(state.stores.map((s) => s.id));
const delivererIds = new Set(state.deliverers.map((d) => d.id));
const saleIds = new Set(state.sales.map((s) => s.id));
const saleNumbers = {};
state.sales.forEach((s) => {
  assert.ok(s.id && !saleIds.has('x'), 'id vente');
  (s.items || []).forEach((it) => assert.ok(productIds.has(it.productId), 'vente ' + s.id + ' produit ' + it.productId));
  assert.ok(s.clientId === 'counter' || clientIds.has(s.clientId), 'vente ' + s.id + ' client');
  const expectedName = s.clientId === 'counter' ? 'Client comptoir' : byId(state.clients, s.clientId).name;
  assert.strictEqual(s.clientName, expectedName, 'nom client ' + s.id);
  assert.ok(['cash', 'mobile', 'card', 'credit'].includes(s.payment), 'paiement ' + s.id);
  assert.ok(s.status === 'Validée' || (s.kind === 'invoice' && s.status === 'Brouillon'), 'statut ' + s.id); // brouillons de facture autorisés
  const sum = (s.items || []).reduce((t, it) => t + Number(it.quantity) * Number(it.unitPrice), 0);
  assert.strictEqual(Number(s.total), sum, 'total ' + s.id);
  assert.ok(!saleNumbers[s.number], 'numéro dupliqué ' + s.number);
  saleNumbers[s.number] = 1;
});
const deliverySaleIds = new Set();
state.deliveries.forEach((d) => {
  assert.ok(saleIds.has(d.saleId), 'livraison ' + d.id + ' vente');
  assert.ok(delivererIds.has(d.delivererId), 'livraison ' + d.id + ' livreur');
  assert.ok(byId(state.deliverers, d.delivererId).active !== false, 'livreur actif ' + d.id);
  assert.strictEqual(d.saleNumber, byId(state.sales, d.saleId).number, 'référence ' + d.id);
  assert.ok(!deliverySaleIds.has(d.saleId), 'vente livrée 2 fois ' + d.saleId);
  deliverySaleIds.add(d.saleId);
  assert.ok(Number(d.fee) >= 0, 'frais ' + d.id);
});
const checkNumbered = (list, label, prefix) => {
  const seen = new Set();
  list.forEach((x) => {
    assert.ok(x.number && x.number.startsWith(prefix + '-'), label + ' ' + x.id + ' numéro');
    assert.ok(!seen.has(x.number), label + ' doublon ' + x.number);
    seen.add(x.number);
  });
};
checkNumbered(state.stockEntries, 'entrée', 'ENT');
checkNumbered(state.stockExits, 'sortie', 'SOR');
checkNumbered(state.orders, 'commande', 'CMD');
checkNumbered(state.customerPayments, 'règlement', 'REG');
checkNumbered(state.stockTransfers, 'transfert', 'TRF');
checkNumbered(state.inventoryReports, 'rapport', 'RIN');
state.stockEntries.forEach((e) => {
  assert.ok(supplierIds.has(e.supplierId), 'entrée ' + e.id + ' fournisseur');
  assert.ok(storeIds.has(e.storeId), 'entrée ' + e.id + ' magasin');
  assert.ok(productIds.has(e.productId), 'entrée ' + e.id + ' produit');
  assert.strictEqual(Number(e.total), Number(e.quantity) * Number(e.unitPrice), 'total ' + e.id);
  assert.ok(['Achat', 'Retour produit'].includes(e.type), 'type ' + e.id);
  assert.ok(['Validé', 'En cours'].includes(e.status), 'statut ' + e.id);
});
state.stockExits.forEach((e) => {
  assert.ok(storeIds.has(e.storeId), 'sortie ' + e.id + ' magasin');
  assert.ok(productIds.has(e.productId), 'sortie ' + e.id + ' produit');
  assert.strictEqual(Number(e.total), Number(e.quantity) * Number(e.unitPrice), 'total ' + e.id);
  assert.ok(['Vente', 'Don', 'Perte', 'Vol'].includes(e.type), 'type ' + e.id);
});
state.orders.forEach((o) => {
  assert.ok(supplierIds.has(o.supplierId), 'commande ' + o.id + ' fournisseur');
  assert.ok(storeIds.has(o.storeId), 'commande ' + o.id + ' magasin');
  assert.ok((o.lines || []).length > 0, 'commande ' + o.id + ' lignes');
  o.lines.forEach((l) => assert.ok(productIds.has(l.productId), 'commande ' + o.id + ' produit'));
  const sum = o.lines.reduce((t, l) => t + Number(l.quantity) * Number(l.unitPrice), 0);
  assert.strictEqual(Number(o.total), sum, 'total ' + o.id);
  assert.ok(['Brouillon', 'Envoyée', 'Réceptionnée'].includes(o.status), 'statut ' + o.id);
});
state.stockTransfers.forEach((t) => {
  assert.ok(storeIds.has(t.sourceStoreId) && storeIds.has(t.destinationStoreId), 'transfert ' + t.id);
  assert.ok(t.sourceStoreId !== t.destinationStoreId, 'transfert ' + t.id + ' sens');
  assert.ok((t.lines || []).length > 0, 'transfert ' + t.id + ' lignes');
  t.lines.forEach((l) => assert.ok(productIds.has(l.productId), 'transfert ' + t.id + ' produit'));
});
state.customerPayments.forEach((p) => {
  assert.ok(clientIds.has(p.clientId), 'règlement ' + p.id + ' client');
  assert.ok(Number(p.amount) > 0, 'montant ' + p.id);
  assert.strictEqual(p.status, 'Validé');
});
state.products.forEach((p) => {
  assert.ok(supplierIds.has(p.supplierId), 'produit ' + p.id + ' fournisseur');
  assert.ok(byId(state.suppliers, p.supplierId).active !== false, 'produit ' + p.id + ' fournisseur actif');
  assert.ok(Number(p.salePrice) > Number(p.purchasePrice), 'marge ' + p.id);
});
state.inventory.forEach((c) => assert.ok(productIds.has(c.productId), 'comptage ' + c.id));
report.push('Intégrité: références, numéros uniques, totaux : OK');
// ---------- rapports d inventaire ----------
const expectedDates = ['2024-10-31', '2024-12-31', '2025-02-28', '2025-04-30', '2025-06-30', '2025-08-31', '2025-10-31', '2025-12-31', '2026-02-28', '2026-04-30', '2026-06-30', '2026-08-31'];
assert.deepStrictEqual(state.inventoryReports.map((r) => r.date), expectedDates);
state.inventoryReports.forEach((r) => {
  assert.strictEqual(r.lines.length, 100, 'lignes ' + r.id);
  const counted = r.lines.filter((l) => l.counted || l.real != null);
  assert.strictEqual(r.countedProducts, counted.length, 'comptés ' + r.id);
  assert.strictEqual(r.gapProducts, counted.filter((l) => Number(l.gap) !== 0).length, 'écarts ' + r.id);
  assert.strictEqual(r.theoreticalTotal, r.lines.reduce((s, l) => s + Number(l.theoretical), 0), 'théorique ' + r.id);
  assert.strictEqual(r.realTotal, counted.reduce((s, l) => s + Number(l.real), 0), 'réel ' + r.id);
  assert.strictEqual(r.gapTotal, counted.reduce((s, l) => s + Number(l.gap), 0), 'écart total ' + r.id);
  r.lines.forEach((l) => assert.ok(productIds.has(l.productId), 'rapport ' + r.id + ' produit'));
});
report.push('Inventaires: 12 rapports bimestriels, résumés cohérents : OK');
// ---------- fenêtre de dates : sept 2024 → sept 2026 ----------
const inWindow = (ms) => ms >= Date.UTC(2024, 8, 1) && ms <= Date.UTC(2026, 8, 21, 23, 59, 59);
const fixedSales = new Set(['sale-01', 'sale-02', 'sale-03', 'sale-04', 'sale-05']);
const fixedEntries = new Set(['entry-01', 'entry-02', 'entry-03']);
const fixedExits = new Set(['exit-01', 'exit-02']);
const fixedOrders = new Set(['order-01', 'order-02']);
// Factures de démo : datées par rapport à aujourd'hui (récentes), hors fenêtre générée.
state.sales.forEach((s) => { if (s.kind === 'invoice') { const ms = new Date(s.date).getTime(); assert.ok(Date.now() - ms < 31 * 86400000 && ms <= Date.now() + 24 * 3600000, 'facture récente ' + s.id); } else if (!fixedSales.has(s.id)) assert.ok(inWindow(new Date(s.date).getTime()), 'date ' + s.id); });
state.stockEntries.forEach((e) => { if (!fixedEntries.has(e.id)) assert.ok(inWindow(new Date(e.date).getTime()), 'date ' + e.id); });
state.stockExits.forEach((e) => { if (!fixedExits.has(e.id)) assert.ok(inWindow(new Date(e.date).getTime()), 'date ' + e.id); });
state.orders.forEach((o) => { if (!fixedOrders.has(o.id)) assert.ok(inWindow(new Date(o.date + 'T12:00:00Z').getTime()), 'date ' + o.id); });
state.customerPayments.forEach((p) => { if (p.saleId) assert.ok(new Date(p.date + 'T12:00:00Z').getTime() <= Date.now() + 24 * 3600000, 'règlement facture non daté dans le futur ' + p.id); else assert.ok(inWindow(new Date(p.date + 'T12:00:00Z').getTime()), 'date ' + p.id); });
state.stockTransfers.forEach((t) => assert.ok(inWindow(new Date(t.date + 'T12:00:00Z').getTime()), 'date ' + t.id));
state.deliveries.forEach((d) => { if (d.id !== 'dlv-01') assert.ok(inWindow(new Date(d.assignedAt).getTime()), 'date ' + d.id); });
const nowMs = Date.now();
[...fixedSales].forEach((id) => { const ms = new Date(byId(state.sales, id).date).getTime(); assert.ok(nowMs - ms < 31 * 86400000 && ms <= nowMs + 24 * 3600000, 'fixe récent ' + id); }); // +24h : sale-01 = jour même 08:42 (flake pré-existant avant 07:42)
report.push('Dates: historique 09/2024→09/2026, 5 ventes fixes récentes : OK');
// ---------- déterminisme (hors horodatages système) ----------
const normalize = (s) => {
  const clone = JSON.parse(JSON.stringify(s));
  delete clone.license.trialStartedAt;
  (clone.supplierProducts || []).forEach((l) => delete l.createdAt);
  (clone.inventoryReports || []).forEach((r) => delete r.createdAt);
  (clone.stockTransfers || []).forEach((t) => delete t.createdAt);
  (clone.customerPayments || []).forEach((p) => delete p.createdAt);
  return JSON.stringify(clone);
};
const again = seedState();
const keepState = state;
state = again;
refreshClientReceivables();
state = keepState;
assert.strictEqual(normalize(again), normalize(state), 'seed déterministe');
report.push('Déterminisme: 2 générations identiques : OK');
// ---------- gabarit ----------
const jsonBytes = JSON.stringify(state).length;
report.push('Génération: ' + genMs + ' ms, ' + Math.round(jsonBytes / 1024) + ' Ko JSON');
assert.ok(genMs < 3000, 'génération < 3 s');
assert.ok(jsonBytes < 5000000, 'état < 5 Mo (quota localStorage)');
return { report };
`;

const result = new Function('assert', harness)(assert);
console.log('NOVA Commerce — test Données de démonstration (2 ans d’activité)');
result.report.forEach((line) => console.log(line));
console.log('\nTOUS LES TESTS DONNÉES DÉMO : OK');
