// Audit navigateur : visite de toutes les vues (données de démo), erreurs JS, textes parasites, captures.
const puppeteer = require('puppeteer');
const crypto = require('crypto');
const fs = require('fs');
const KEY = 'nova-commerce-state-v1';
const SALT = 'nova-test-facturation';
const HASH = `pbkdf2-sha256$${SALT}$120000$${crypto.pbkdf2Sync('Test-1234!', SALT, 120000, 32, 'sha256').toString('hex')}`;
const OUT = '/tmp/e2e/reports/sweep';
fs.mkdirSync(OUT, { recursive: true });
const BASE = process.env.BASE_URL || 'http://127.0.0.1:4190/index.html';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const BAD = /undefined|NaN|\[object Object\]|null FCFA/;

(async () => {
  const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 950 });
  const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  page.on('dialog', (d) => d.accept());
  await page.goto(BASE, { waitUntil: 'networkidle0' });
  await page.waitForSelector('[data-database-mode="demo"]', { timeout: 30000 });
  await sleep(1500);
  await page.evaluate(() => document.querySelector('[data-database-mode="demo"]').click());
  await sleep(2500);
  await page.waitForFunction(() => { const i = document.querySelector('input[name="username"]'); return i && i.offsetParent !== null; }, { timeout: 30000 });
  await page.evaluate((key, hash) => { const s = JSON.parse(localStorage.getItem(key)); const u = s.users.find((x) => x.username === 'mariam'); u.passwordHash = hash; u.profile = 'Gérant'; localStorage.setItem(key, JSON.stringify(s)); }, KEY, HASH);
  await page.reload({ waitUntil: 'networkidle0' });
  await page.waitForFunction(() => { const i = document.querySelector('input[name="username"]'); return i && i.offsetParent !== null; }, { timeout: 30000 });
  await page.type('input[name="username"]', 'mariam');
  await page.type('input[name="password"]', 'Test-1234!');
  await page.keyboard.press('Enter');
  await page.waitForSelector('[data-view="dashboard"], [data-view="sale"]', { timeout: 30000 });
  await sleep(800);

  const views = await page.$$eval('[data-view]', (els) => [...new Set(els.map((e) => e.dataset.view))]);
  console.log('vues:', views.length, views.join(', '));
  const report = [];
  for (const view of views) {
    const before = errs.length;
    const visible = await page.$(`[data-view="${view}"]`);
    if (!visible) { report.push({ view, skipped: true }); continue; }
    try { await page.click(`[data-view="${view}"]`); } catch (e) { report.push({ view, clickError: e.message.slice(0, 120) }); continue; }
    await sleep(500);
    const text = await page.evaluate(() => document.querySelector('#app, main, body').innerText);
    const bad = (text.match(new RegExp(BAD.source, 'g')) || []);
    const rows = await page.evaluate(() => document.querySelectorAll('table tbody tr').length);
    const newErrors = errs.slice(before);
    report.push({ view, rows, badTexts: [...new Set(bad)].slice(0, 5), jsErrors: newErrors.length, firstError: newErrors[0] || '' });
    await page.screenshot({ path: `${OUT}/${view}.png` });
  }
  console.log(JSON.stringify(report, null, 1));

  // Facturation et caisse : contenu détaillé
  for (const view of ['invoices', 'collect']) {
    await page.click(`[data-view="${view}"]`).catch(() => {});
    await sleep(600);
    const info = await page.evaluate(() => Array.from(document.querySelectorAll('table tbody tr')).map((tr) => tr.innerText.replace(/\s+/g, ' ').trim().slice(0, 220)));
    console.log(`\n== ${view} (${info.length} lignes)`);
    info.slice(0, 12).forEach((l) => console.log('  ' + l));
  }
  console.log('\nErreurs JS totales :', errs.length);
  errs.slice(0, 8).forEach((e) => console.log('  ' + e.slice(0, 200)));
  await browser.close();
  process.exit(0);
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
