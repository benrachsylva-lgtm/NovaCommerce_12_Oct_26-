@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  echo NOVA Commerce est disponible sur http://localhost:4173
  start "NOVA Commerce" http://localhost:4173
  py -m http.server 4173
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  echo NOVA Commerce est disponible sur http://localhost:4173
  start "NOVA Commerce" http://localhost:4173
  python -m http.server 4173
  goto :eof
)
echo Python 3 est necessaire pour lancer NOVA Commerce.
echo Installez Python depuis https://www.python.org/downloads/
pause
