# NOVA Commerce — Analyse critique (risques, correctifs, limites)

> Document de référence cité par le README et par l’application (Journal d’activité).
> Version : 1.0.0 — 21/09/2026.

## 1. Objet

Ce document consigne l’analyse critique de NOVA Commerce v1.0.0 : posture assumée,
risques identifiés lors de l’audit de production, correctifs appliqués et limites
résiduelles. Il sert de base à toute décision d’exploitation commerciale.

## 2. Posture assumée : locale-first, monoposte, sans backend

NOVA Commerce fonctionne **sans serveur** : les données vivent sur l’appareil
(PWA/Android : stockage web ; Desktop : SQLite + sessions locales). En conséquence,
**le propriétaire de l’appareil peut toujours lire, modifier ou détruire les
données locales et les fichiers de l’application**. Aucun mécanisme purement local
ne résiste à un attaquant qui possède la machine : les protections ci-dessous
visent les usages normaux, les erreurs et les attaques opportunistes, pas un
propriétaire hostile et compétent.

## 3. Risques identifiés et traitement (audit de production)

| # | Risque | Traitement (v1.0.0) |
|---|---|---|
| M1 | Stockage corrompu = perte silencieuse | ✅ Copies auto (3 emplacements rotatifs), bandeau d’alerte, restauration pré-connexion |
| M2 | Licence permanente contournable (code public, drapeau local) | ✅ Clés ECDSA liées (nom boutique, UUID), vérifiées hors-ligne + à chaque démarrage ; révocation distante impossible (limite §5) |
| M3 | Rupture mémoire à 4000+ écritures (DOM de 3,5 Mo) | ✅ Pagination virtuelle (10 lignes, ~11 Ko) sur les 21 tableaux |
| M4 | Pas de commit/tag de release | ✅ Commit + tag `v1.0.0` |
| M5 | Sauvegarde Android exposant les données | ✅ `android:allowBackup="false"` |
| M6 | Auth Desktop sans rate-limit + hash exposé | ✅ Rate-limit 5 essais/30 s, hash retiré de la réponse d’auth |
| m1 | Pas de verrouillage d’inactivité | ✅ Auto-verrouillage (défaut 15 min, 0–240, journalisé) |
| m2 | Pas de gestionnaire d’erreurs global | ✅ Handler global (toast + journal, anti-récursion) |
| m3 | Injection via exports CSV (`= + - @`) | ✅ Cellules à risque préfixées `'` |
| m4 | Uploads sans limite (quota ~5 Mo) | ✅ Limites 512 Ko / 2 Mo + préservation de l’existant |
| m5 | `ANALYSE-CRITIQUE.md` référencé mais absent | ✅ Présent document ; duplication README corrigée |
| m6 | Code concepteur en clair dans le client | ✅ Empreinte SHA-256 salée + comparaison quasi-constant-time (rotation §6) |
| m7 | Assets Capacitor périmés | ✅ Resynchronisation + livraison imposée via `mobile:apk:*` + test de non-régression |
| m8 | Sauvegardes sans version | ✅ `appVersion`/`schemaVersion`, schéma futur rejeté |
| m9 | Garde anti-recul réinitialisable (web) | ✅ Limite documentée et acceptable ; Desktop persisté en SQLite |
| m10 | Helpers HTML non échappants | ✅ Convention « HTML de confiance » documentée sur chaque helper, appelants audités |

Tests : 9/9 suites vertes (`test:express`, `test:deliverers`, `test:roles`,
`test:designer`, `test:profit`, `test:dashboard`, `test:seed`, `test:prod`,
`test:licence`).

## 4. Points forts confirmés par l’audit

Mots de passe PBKDF2-SHA-256 (120 000 itérations, sel 16 octets, comparaison
constant-time, rate-limit) ; discipline XSS (`esc()` systématique, CSP stricte,
aucun `eval`) ; Electron durci (`contextIsolation`, `sandbox`, DevTools sous
variable d’environnement) ; SQLite en transactions avec ventes validées
inaltérables ; RBAC complet (5 profils, 31 gates, 29 vues protégées) ; essai
3 mois avec données toujours consultables ; service worker + impressions ;
0 TODO/FIXME.

## 5. Limites résiduelles (acceptées en v1.0.0)

1. **Journal d’audit contournable par le propriétaire** : append-only côté
   Desktop, mais le fichier SQLite local reste modifiable hors application.
   Pour une preuve opposable : journal distant ou chaîné (hash-linké).
2. **Licence sans révocation ni renouvellement** : une clé émise reste valable
   tant que le couple (nom, UUID) est inchangé. Rotation = nouvelle paire de
   clés + nouvelle version + réémission (voir `Nova-Licence-Generator/README.md`).
3. **Garde anti-recul web réinitialisable** (m9) : vidage du stockage navigateur
   = contrôle reparti de zéro sur PWA/Android. Desktop non concerné (SQLite).
4. **Code concepteur = verrou d’interface** : l’empreinte salée protège contre
   la lecture du code dans les sources livrées, mais un utilisateur ouvrant les
   outils développeur peut contourner tout verrou purement client.
5. **Binaires Android de test** : APK debug signé par une clé debug, APK release
   volontairement non signé — à reconstruire avec les certificats officiels
   avant toute distribution commerciale (voir `GUIDE-COMPILATION-APK.md`).
6. **Pas de multi-utilisateur distant** : aucune synchronisation, aucun contrôle
   serveur, sauvegardes non chiffrées.

## 6. Codes et secrets

- **Code concepteur** (espace « Nous contacter ») : l’application embarque
  uniquement `DESIGNER_CODE_SALT` + `DESIGNER_CODE_DIGEST` (`app.js`). Pour
  définir un nouveau code, générer un sel puis l’empreinte :
  ```bash
  node -e "const c=require('node:crypto');const s='nova-designer-v1:'+c.randomBytes(12).toString('hex');console.log('sel :',s);console.log('empreinte :',c.createHash('sha256').update(s+'VOTRE-NOUVEAU-CODE','utf8').digest('hex'));"
  ```
  puis recopier les deux valeurs dans `app.js`, mettre à jour
  `scripts/test-designer-space.cjs` (empreinte attendue + code de test) et
  relancer `npm run test:designer`.
- **Clés de licence** : la clé privée ECDSA vit exclusivement dans
  `Nova-Licence-Generator/cle-privee.json` (**secret, hors dépôt**). Rotation : voir
  `Nova-Licence-Generator/README.md`.
- **Compte Administrateur protégé** : identifiant et hachage PBKDF2 dans le
  code (principal + secours) ; mot de passe transmis hors dépôt.
- **Dépôt privé requis** : le dépôt contient des hachages, une empreinte
  de code de test et la logique métier — il ne doit pas être public.

## 7. Recommandations pour une exploitation sensible

API HTTPS + authentification/autorisation serveur, sauvegardes chiffrées,
synchronisation avec résolution de conflits, journal d’audit distant/chaîné,
serveur de temps/licence signé avec révocation, gestion complète des retours
fournisseurs, clôture de caisse, supervision des clés de signature, `npm audit`
sur la machine de build, revue du code natif Java/Gradle et tests dynamiques
sur appareils.
