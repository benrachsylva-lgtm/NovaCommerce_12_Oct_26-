# Audit — données de démonstration et facturation

Date de l'audit : 10/10/2026. Périmètre : données de démonstration (`seedState` dans `app.js`), module Facturation / Factures à encaisser, suites de tests et parcours navigateur.

## 1. Modifications apportées

### 1.1 Données de démonstration (`www/app.js`, `seedState`)

Neuf factures de démonstration ajoutées, couvrant tous les statuts :

| Réf. | Statut facture | Règlement | Total (FCFA) | Remarque |
|---|---|---|---|---|
| A | Validée | Non payée | 14 450 | échéance dans 30 jours |
| B | Validée | Non payée | 11 400 | |
| C | Validée | Partiellement payée (1 règlement) | 2 425 | 900 encaissés |
| D | Validée | Partiellement payée (2 règlements) | 19 000 | 11 400 encaissés |
| E | Validée | Payée intégralement (1 règlement) | 8 375 | |
| F | Validée | Payée intégralement (2 règlements) | 5 875 | |
| G | Validée puis annulée par avoir | Annulée | 18 025 | avoir AVO « Annulation complète », retour en stock |
| H | Brouillon | — | 4 025 | hors caisse |
| I | Brouillon | — | 925 | hors caisse |

- Six règlements liés à une facture (`saleId`), chacun enregistré séparément, statut « Validé ».
- Stock : sortie unique pour les factures validées A à F ; la facture G est annulée par un avoir avec retour en stock (net zéro) ; les brouillons ne touchent pas au stock.
- Les factures utilisent six clients existants, non débiteurs à l'origine, avec une limite de crédit d'au moins 200 000 FCFA. Les clients 02 et 04 ne sont pas modifiés.
- Dates relatives à la date du jour (−1 à −25 jours), comme les ventes fixes existantes.
- La génération est déterministe : aucun tirage aléatoire ajouté, donc les données générées existantes ne changent pas.

### 1.2 Autres fichiers

- `app.js` (racine), `www/app.js` et `android/…/public/app.js` : identiques (vérifié par `cmp`).
- Cache du service worker : `nova-commerce-shell-v18` → `v19` (trois copies).
- `package.json` : script `test:demo-invoices`.
- Nouveau test `scripts/test-demo-invoices.cjs` (687 vérifications).
- Scripts navigateur : `scripts/ui-smoke-invoices.cjs` (parcours facturation, corrigé) et `scripts/ui-sweep-audit.cjs` (visite de toutes les vues).

### 1.3 Attentes de tests modifiées (changements voulus, documentés)

| Test | Avant | Après | Raison |
|---|---|---|---|
| `test-seed-volumes` : `sales` | 4000 | 4009 | 9 factures de démo (dont 2 brouillons) |
| `test-seed-volumes` : créances | 40 | 44 | 4 clients avec factures validées non soldées (A, B, C, D) |
| `test-seed-volumes` : statut | « Validée » uniquement | « Validée » ou brouillon de facture | brouillons de facture autorisés |
| `test-seed-volumes` : dates | fenêtre sept. 2024 → sept. 2026 | factures et règlements de démo récents | factures datées par rapport à aujourd'hui |
| `test-seed-volumes` : crédit ⇒ débiteur | toutes les ventes à crédit | ventes générées uniquement | une facture entièrement réglée n'est plus une créance |
| `test-deliverers` : lignes de l'historique | 4000 | 4007 | 7 factures validées affichées, brouillons exclus |

## 2. Résultats des tests

Commande : `scripts/*.cjs` exécutés un par un (`/tmp/e2e/run-all.sh`), avec serveur statique sur le port 4190.

| Suite | Résultat |
|---|---|
| test-barcodes | OK (58) |
| test-credit-advances | OK (38) |
| test-dashboard-indicators | OK |
| test-deliverers | OK |
| **test-demo-invoices (nouveau)** | **OK (687 vérifications)** |
| test-designer-space | OK |
| test-express-demo | OK |
| test-invoices | OK (18 tests) |
| test-prod-fixes | OK |
| test-profit-collected | OK |
| test-roles-matrix | OK |
| test-seed-volumes | OK |
| test-supplier-report | OK |
| test-write-recovery | OK |
| test-barcodes-browser | **ÉCHEC (non exécutable)** — voir constat C1 |
| test-supplier-credit | **ÉCHEC (non exécutable)** — voir constat C1 |
| test-licence | **ÉCHEC (non exécutable)** — voir constat C2 |

14 suites sur 17 passent. Les trois échecs existaient avant ces modifications et ne sont pas causés par elles.

### Parcours navigateur (Chrome 148 headless)

- `scripts/ui-smoke-invoices.cjs` : **OK**, 0 erreur JavaScript. Brouillon, validation avec sortie de stock unique (42 → 41), caisse, encaissement partiel avec reçu, refus du trop-perçu, solde final « Payée intégralement », vente directe.
- Audit de toutes les vues (`scripts/ui-sweep-audit.cjs`) : 30 vues sur 32 rendues, **0 erreur JavaScript**, **0 texte parasite** (`undefined`, `NaN`, `[object Object]`). Facturation : 9 lignes. Factures à encaisser : 4 lignes (A, B, C, D, celles qui ont un solde).
- Vues « Utilisateurs » et « Rôles » non cliquables avec le profil Gérant de test : limite du profil de test (C5).

## 3. Constats de l'audit

**C1 — Tests navigateur non exécutables sur le build livré (bloquant pour ces deux suites).** `test-barcodes-browser` et `test-supplier-credit` attendent `window.__novaDebug`, hook qui n'existe dans aucun fichier du projet. Décision requise : ajouter un hook de test (désactivé en production) ou réécrire ces scénarios sur l'interface, comme `ui-smoke-invoices`.

**C2 — `test-licence` non exécutable ici.** Le script lit `/home/user/Nova-Licence-Generator/Nova-Licence-Generator.html`, absent de ce poste (outil externe).

**C3 — Statut « Annulé » incohérent et non atteignable depuis l'interface.** `desktop/invoice-rules.cjs` définit `CANCELLED = 'Annulé'`. Ce statut sert à l'annulation d'un *règlement* (avec motif), mais aucun écran de `app.js` ne l'appelle (aucune occurrence de `cancelReason` dans l'interface). L'annulation d'une *facture* passe par un avoir « Annulation complète », et le statut « Annulée » est un statut de règlement dérivé. Le libellé « Annulé » et « Annulée » coexistent : à harmoniser ou à documenter. Décision requise : faut-il une annulation de règlement depuis l'interface ?

**C4 — Risque latent sur la lecture des ventes (non avéré).** Le mapping de lecture omet `kind` quand il vaut `'direct'`. Vérifié : une vente héritée relue puis renvoyée à l'identique ne demande aucune permission ; l'interface ne pose `kind` que pour les factures. Si quelqu'un ajoutait `kind: 'direct'` côté interface, les ventes existantes seraient traitées comme modifiées.

**C5 — Limite du profil de test.** Les vues « Utilisateurs » et « Rôles » n'ont pas été parcourues : elles exigent un profil administrateur, et le mot de passe administrateur n'est pas utilisé (conformément à la règle du projet). À couvrir avec un compte administrateur de test.

**C6 — Historique généré terminé au 10/09/2026.** Le générateur de deux ans s'arrête au 10 septembre 2026, alors que la date du jour est le 10 octobre 2026. Le mois en cours ne contient donc que les quelques ventes datées du jour et les factures de démo. Non corrigé : changer la fenêtre modifierait le volume de 4000 ventes et tous les compteurs qui en dépendent. Décision requise.

**C7 — Démos déjà installées.** Les données de démonstration ne sont chargées qu'au premier démarrage (ou par « Réinitialiser la démo », réservé à l'administrateur après activation). Une installation existante ne reçoit pas les nouvelles factures, ce qui est voulu : aucune donnée utilisateur n'est écrasée.

**C8 — Portée de la vérification « sortie de stock unique ».** `test-demo-invoices` vérifie la cohérence des données de démo (stock jamais négatif, stock = somme des dépôts, contrôle des règles de validation). La sortie unique réelle lors d'une validation est prouvée par `ui-smoke-invoices` (42 → 41) et par `test-invoices`.

**Aucun bug applicatif trouvé pendant le parcours.** Les deux anomalies rencontrées pendant l'audit étaient dans les scripts de test (sélection de la vente directe, identifiants du sweep), corrigées.

## 4. Commandes

```bash
# Tests unitaires et de données (Node.js, depuis la racine du projet)
npm run test:demo-invoices
npm run test:seed
npm run test:invoices
npm run test:roles
npm run test:deliverers

# Parcours navigateur : servir www/ puis lancer les scripts
cd www && python3 -m http.server 4190 --bind 0.0.0.0 &
cd .. && NODE_PATH=<dossier contenant puppeteer> node scripts/ui-smoke-invoices.cjs
cd .. && NODE_PATH=<dossier contenant puppeteer> node scripts/ui-sweep-audit.cjs
# Variable optionnelle : BASE_URL (défaut http://127.0.0.1:4190/index.html)
```

## 5. Limites de cet audit

- Environnement : Node.js 20, Chrome 148 headless, bibliothèques système extraites hors dépôt (non persistées).
- Les tests ont été exécutés sur la version de développement de `app.js` ; le build Android et Electron n'a pas été compilé.
- Pas de test de charge ni de revue de sécurité approfondie au-delà des règles de facturation et des permissions vérifiées par les suites existantes.
