'use strict';
// Règles des codes-barres côté persistance (module pur, sans Electron).
// Miroir des règles de app.js : scripts/test-barcodes.cjs vérifie que les deux implémentations restent identiques.
// Le but est que le refus d'un code invalide ou dupliqué ne dépende pas uniquement de l'interface.

const BARCODE_INTERNAL_RE = /^NC-\d{8}$/;
const GS1_LENGTH_TYPES = { 8: 'EAN-8', 12: 'UPC-A', 13: 'EAN-13', 14: 'GTIN-14' };
const BARCODE_MAX_LENGTH = 48;

// Nettoie la saisie : espaces retirés si la valeur est numérique, sinon trim seulement.
function normalizeBarcode(value) {
  const text = String(value ?? '').trim();
  return /^\d[\d\s]*$/.test(text) ? text.replace(/\s+/g, '') : text;
}

// Clé de chiffre de contrôle GS1 (modulo 10, poids 3 et 1 en partant de la droite).
function gs1CheckDigit(body) {
  let sum = 0;
  for (let i = body.length - 1, k = 0; i >= 0; i -= 1, k += 1) sum += Number(body[i]) * (k % 2 === 0 ? 3 : 1);
  return String((10 - (sum % 10)) % 10);
}

// Valide la structure d'un code. Retourne { valid, type, reason }. Une valeur vide signifie « pas de code-barres ».
function barcodeCheck(value) {
  const code = normalizeBarcode(value);
  if (!code) return { valid: true, type: '', reason: '' };
  if (code.length > BARCODE_MAX_LENGTH) return { valid: false, type: '', reason: `maximum ${BARCODE_MAX_LENGTH} caractères.` };
  if (BARCODE_INTERNAL_RE.test(code)) return { valid: true, type: 'Interne', reason: '' };
  if (/^\d+$/.test(code)) {
    const type = GS1_LENGTH_TYPES[code.length];
    if (!type) return { valid: true, type: 'Code 128', reason: '' };
    if (gs1CheckDigit(code.slice(0, -1)) !== code.slice(-1)) return { valid: false, type: '', reason: `clé de contrôle ${type} incorrecte.` };
    return { valid: true, type, reason: '' };
  }
  if (!/^[\x20-\x7E]+$/.test(code)) return { valid: false, type: '', reason: 'caractères non supportés (ASCII imprimable uniquement).' };
  return { valid: true, type: 'Code 128', reason: '' };
}

// Clé d'identité : un UPC-A (12 chiffres) est le même produit que l'EAN-13 précédé d'un zéro.
function barcodeKey(value) {
  const code = normalizeBarcode(value);
  return /^\d{12}$/.test(code) ? `0${code}` : code;
}

function articleLabel(product) {
  return String(product?.name || product?.code || 'sans nom');
}

// Contrôle d'écriture de la liste des articles. Retourne null si l'écriture peut passer,
// sinon { reason: 'code-barres', message } avec le motif lisible.
// Seuls les articles créés ou dont le code change sont contrôlés : les articles historiques ne sont pas bloqués.
function productBarcodeRefusal(previousProducts, nextProducts) {
  const list = Array.isArray(nextProducts) ? nextProducts : [];
  const previousKeys = new Map((Array.isArray(previousProducts) ? previousProducts : []).map((item) => [String(item?.id ?? ''), barcodeKey(item?.barcode)]));
  for (const product of list) {
    const code = normalizeBarcode(product?.barcode);
    if (!code) continue;
    const id = String(product?.id ?? '');
    const key = barcodeKey(code);
    const changed = !previousKeys.has(id) || previousKeys.get(id) !== key;
    if (!changed) continue;
    const check = barcodeCheck(code);
    if (!check.valid) {
      return { reason: 'code-barres', message: `Code-barres « ${code} » refusé pour l’article « ${articleLabel(product)} » : ${check.reason}` };
    }
    const holder = list.find((other) => String(other?.id ?? '') !== id && barcodeKey(other?.barcode) === key);
    if (holder) {
      return { reason: 'code-barres', message: `Code-barres « ${code} » déjà attribué à l’article « ${articleLabel(holder)} » (${String(holder.code || '—')}). Choisissez un autre code ou retirez-le de cet article.` };
    }
  }
  return null;
}

module.exports = { BARCODE_MAX_LENGTH, normalizeBarcode, gs1CheckDigit, barcodeCheck, barcodeKey, productBarcodeRefusal };
