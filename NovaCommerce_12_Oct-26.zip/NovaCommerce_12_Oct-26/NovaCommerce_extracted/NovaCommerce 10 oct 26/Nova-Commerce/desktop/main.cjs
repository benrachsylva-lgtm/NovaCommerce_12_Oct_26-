const { app, BrowserWindow, dialog, ipcMain, Menu, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const childProcess = require('node:child_process');
const nodeSubtle = require('node:crypto').webcrypto.subtle;
const Database = require('better-sqlite3');
const { normalizeBarcode, barcodeCheck, productBarcodeRefusal } = require('./barcode-rules.cjs');
const { invoiceWriteCheck, DRAFT: INVOICE_DRAFT } = require('./invoice-rules.cjs');

const STATE_KEY = 'nova-commerce-state-v1';
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const FALLBACK_ROLE_PERMISSIONS = {
  Administrateur: ['*'],
  Gérant: ['sales.validate', 'sales.reverse', 'invoices.view', 'invoices.create', 'invoices.validate', 'invoices.collect', 'invoices.payment.cancel', 'products.manage', 'clients.manage', 'credit.view', 'credit.record', 'catalog.manage', 'stores.manage', 'suppliers.manage', 'deliverers.manage', 'stock.create', 'stock.validate', 'stock.transfer', 'orders.manage', 'quotes.manage', 'expenses.manage', 'inventory.manage', 'reports.export', 'users.manage', 'roles.manage', 'settings.manage', 'license.activate'], 
  Vendeur: ['sales.create', 'sales.validate', 'invoices.view', 'invoices.create', 'invoices.validate', 'clients.manage', 'credit.view', 'quotes.manage', 'reports.export'],
  Magasinier: ['catalog.manage', 'stock.create', 'stock.validate', 'stock.transfer', 'orders.manage', 'inventory.manage', 'reports.export'],
  Comptable: ['invoices.view', 'invoices.collect', 'credit.view', 'credit.record', 'quotes.manage', 'expenses.manage', 'reports.export']
};

let database;
let databasePath = '';
let clockIntegrityFilePath = '';
let mainWindow;
const sessions = new Map();
const AUTH_MAX_ATTEMPTS = 5;
const AUTH_LOCK_MS = 30 * 1000;
const authAttempts = new Map();
const licenseTickets = new Map();
// Clé publique de vérification des licences d’appareil (la clé privée de signature
// reste dans l’outil générateur, Nova-Licence-Generator, jamais diffusée).
const LICENCE_KEY_PREFIX = 'NOVA1';
const LICENCE_PUBLIC_JWK = { kty: 'EC', crv: 'P-256', x: 'LddTuNHgWu1NOjg_q9KTZdePCvDC-yFyEX7X432BAuk', y: '5RTR0AJOsQ-oJwlRONs6QFIZkQF4ty5yFV-T5LNASoA' };
const TRIAL_MONTHS = 3;
const CLOCK_INTEGRITY_META_KEY = 'clock_integrity';
const CLOCK_ROLLBACK_TOLERANCE_MS = 5 * 60 * 1000;
const CLOCK_CHECKPOINT_INTERVAL_MS = 60 * 1000;
const PROTECTED_ADMIN_USERNAME = '%@PBGgS86D7@N';
const PROTECTED_ADMIN_PASSWORD_HASH = 'pbkdf2-sha256$8f1485ee6ee236ea2d0172e32e1f1e66$120000$2755850d67d932894bf87c66df2ed24af1c2dd4095427624eb938cdce926ffdd';

function nowIso() {
  return new Date().toISOString();
}

function json(value, fallback) {
  try { return JSON.parse(value); } catch (_) { return fallback; }
}

function text(value) {
  return String(value ?? '');
}

function number(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function bool(value) {
  return value ? 1 : 0;
}

function normalizeBusinessName(value) {
  return text(value).normalize('NFKC').replace(/\s+/g, ' ').trim().toUpperCase();
}
function normalizeDeviceUuid(value) {
  return text(value).trim().toLowerCase();
}
function licenceMessage(businessName, deviceUuid) {
  return `NOVA-LICENCE/v1\nnom=${normalizeBusinessName(businessName)}\nuuid=${normalizeDeviceUuid(deviceUuid)}\n`;
}
const CROCKFORD_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
function crockfordDecode(licenceText) {
  const clean = text(licenceText).toUpperCase().replace(/[\s-]+/g, '').replace(/I|L/g, '1').replace(/O/g, '0');
  const bytes = [];
  let bits = 0;
  let value = 0;
  for (const char of clean) {
    const index = CROCKFORD_ALPHABET.indexOf(char);
    if (index < 0) return null;
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) { bytes.push((value >>> (bits - 8)) & 255); bits -= 8; }
  }
  return new Uint8Array(bytes);
}
async function verifyLicenceKey(key, businessName, deviceUuid) {
  try {
    const clean = text(key).toUpperCase().replace(/[\s-]+/g, '');
    if (!clean.startsWith(LICENCE_KEY_PREFIX)) return false;
    const signature = crockfordDecode(clean.slice(LICENCE_KEY_PREFIX.length));
    if (!signature || signature.length !== 64) return false;
    const cryptoKey = await nodeSubtle.importKey('jwk', LICENCE_PUBLIC_JWK, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    return await nodeSubtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, cryptoKey, signature, Buffer.from(licenceMessage(businessName, deviceUuid), 'utf8'));
  } catch (_) { return false; }
}
let cachedMachineUuid = '';
function getMachineUuid() {
  if (cachedMachineUuid) return cachedMachineUuid;
  let id = '';
  try {
    if (process.platform === 'win32') {
      const out = childProcess.execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { stdio: ['ignore', 'pipe', 'ignore'] }).toString();
      const found = /MachineGuid\s+REG_SZ\s+(\S+)/i.exec(out);
      if (found) id = found[1];
    } else if (process.platform === 'linux') {
      id = fs.readFileSync('/etc/machine-id', 'utf8').trim();
    } else if (process.platform === 'darwin') {
      const out = childProcess.execSync('ioreg -rd1 -c IOPlatformExpertDevice', { stdio: ['ignore', 'pipe', 'ignore'] }).toString();
      const found = /"IOPlatformUUID"\s*=\s*"([^"]+)"/i.exec(out);
      if (found) id = found[1];
    }
  } catch (_) { id = ''; }
  if (!id) {
    try {
      const fallbackFile = path.join(app.getPath('userData'), 'nova-device-id');
      if (fs.existsSync(fallbackFile)) id = fs.readFileSync(fallbackFile, 'utf8').trim();
      if (!id) { id = crypto.randomUUID(); fs.writeFileSync(fallbackFile, id); }
    } catch (_) { id = ''; }
  }
  cachedMachineUuid = text(id).trim();
  return cachedMachineUuid;
}
function addMonths(value, months) {
  const date = new Date(value || nowIso());
  const day = date.getDate();
  date.setMonth(date.getMonth() + months);
  if (date.getDate() < day) date.setDate(0);
  return date;
}
function licenseReadOnly(license = {}) {
  if (license.clockIntegrity?.tampered) return true;
  if (license.activated) return false;
  const started = new Date(license.trialStartedAt || nowIso());
  return !Number.isFinite(started.getTime()) || Date.now() > addMonths(started, TRIAL_MONTHS).getTime();
}

function isTrustedSender(event) {
  return !!mainWindow && event.sender === mainWindow.webContents;
}

function hasRelationalState() {
  return !!database?.prepare('SELECT 1 FROM users LIMIT 1').get() || !!database?.prepare('SELECT 1 FROM products LIMIT 1').get();
}

function createSchema() {
  database.exec(`
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS app_storage (
      key TEXT PRIMARY KEY NOT NULL,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS app_meta (
      key TEXT PRIMARY KEY NOT NULL,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS app_state_meta (
      key TEXT PRIMARY KEY NOT NULL,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS roles (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL DEFAULT '',
      color TEXT NOT NULL DEFAULT 'neutral',
      permissions_json TEXT NOT NULL DEFAULT '[]',
      users_count INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      username TEXT NOT NULL UNIQUE,
      profile TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS stores (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      type TEXT NOT NULL DEFAULT '',
      manager TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT '',
      manager TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      secondary TEXT NOT NULL DEFAULT '',
      fiscal TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      email TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      credit_limit REAL NOT NULL DEFAULT 0,
      opening_receivable REAL NOT NULL DEFAULT 0,
      receivable REAL NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS deliverers (
      id TEXT PRIMARY KEY NOT NULL,
      last_name TEXT NOT NULL DEFAULT '',
      first_name TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      secondary TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      base_rate REAL NOT NULL DEFAULT 0,
      cin TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS deliveries (
      id TEXT PRIMARY KEY NOT NULL,
      sale_id TEXT NOT NULL,
      sale_number TEXT NOT NULL DEFAULT '',
      deliverer_id TEXT NOT NULL DEFAULT '',
      fee REAL NOT NULL DEFAULT 0,
      assigned_at TEXT NOT NULL DEFAULT '',
      assigned_by TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS customer_payments (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      client_id TEXT NOT NULL,
      date TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      method TEXT NOT NULL DEFAULT 'cash',
      reference TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Validé',
      user_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE RESTRICT
    );
    CREATE TABLE IF NOT EXISTS refunds (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      note_id TEXT NOT NULL DEFAULT '',
      note_number TEXT NOT NULL DEFAULT '',
      note_payment TEXT NOT NULL DEFAULT 'cash',
      client_id TEXT NOT NULL DEFAULT '',
      amount REAL NOT NULL DEFAULT 0,
      method TEXT NOT NULL DEFAULT 'cash',
      reference TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Validée',
      user_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY NOT NULL,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category_id TEXT NOT NULL DEFAULT '',
      brand TEXT NOT NULL DEFAULT '',
      model TEXT NOT NULL DEFAULT '',
      supplier_id TEXT NOT NULL DEFAULT '',
      default_store_id TEXT NOT NULL DEFAULT '',
      purchase_price REAL NOT NULL DEFAULT 0,
      sale_price REAL NOT NULL DEFAULT 0,
      wholesale_price REAL NOT NULL DEFAULT 0,
      promo_price REAL NOT NULL DEFAULT 0,
      min_stock REAL NOT NULL DEFAULT 0,
      max_stock REAL NOT NULL DEFAULT 0,
      presentation TEXT NOT NULL DEFAULT '',
      batch TEXT NOT NULL DEFAULT '',
      expiry TEXT NOT NULL DEFAULT '',
      image TEXT NOT NULL DEFAULT '',
      barcode TEXT NOT NULL DEFAULT '',
      barcode_type TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS product_stock (
      product_id TEXT NOT NULL,
      store_id TEXT NOT NULL,
      quantity REAL NOT NULL DEFAULT 0,
      PRIMARY KEY (product_id, store_id),
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
      FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE RESTRICT
    );
    CREATE TABLE IF NOT EXISTS supplier_products (
      supplier_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT '',
      user_id TEXT NOT NULL DEFAULT '',
      PRIMARY KEY (supplier_id, product_id),
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sales (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      client_id TEXT NOT NULL DEFAULT 'counter',
      client_name TEXT NOT NULL DEFAULT '',
      store_id TEXT NOT NULL DEFAULT '',
      total REAL NOT NULL DEFAULT 0,
      payment TEXT NOT NULL DEFAULT 'cash',
      price_type TEXT NOT NULL DEFAULT 'retail',
      price_label TEXT NOT NULL DEFAULT 'Prix de vente',
      status TEXT NOT NULL DEFAULT 'Validée',
      user_id TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS sale_lines (
      id TEXT PRIMARY KEY NOT NULL,
      sale_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      store_id TEXT NOT NULL DEFAULT '',
      quantity REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL DEFAULT 0,
      cost_price REAL NOT NULL DEFAULT 0,
      line_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS stock_movements (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      kind TEXT NOT NULL,
      date TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT '',
      supplier_id TEXT NOT NULL DEFAULT '',
      invoice TEXT NOT NULL DEFAULT '',
      beneficiary TEXT NOT NULL DEFAULT '',
      store_id TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'En cours',
      stock_applied INTEGER NOT NULL DEFAULT 0,
      reversed_of TEXT NOT NULL DEFAULT '',
      correction_reason TEXT NOT NULL DEFAULT '',
      user_id TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS stock_movement_lines (
      id TEXT PRIMARY KEY NOT NULL,
      movement_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      store_id TEXT NOT NULL DEFAULT '',
      quantity REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      line_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (movement_id) REFERENCES stock_movements(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS credit_notes (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'Avoir partiel',
      original_sale_id TEXT NOT NULL,
      original_sale_number TEXT NOT NULL DEFAULT '',
      client_id TEXT NOT NULL DEFAULT 'counter',
      client_name TEXT NOT NULL DEFAULT '',
      payment TEXT NOT NULL DEFAULT 'cash',
      total REAL NOT NULL DEFAULT 0,
      restock INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'En cours',
      stock_applied INTEGER NOT NULL DEFAULT 0,
      reason TEXT NOT NULL DEFAULT '',
      user_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS credit_note_lines (
      id TEXT PRIMARY KEY NOT NULL,
      credit_note_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      store_id TEXT NOT NULL DEFAULT '',
      quantity REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL DEFAULT 0,
      cost_price REAL NOT NULL DEFAULT 0,
      line_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (credit_note_id) REFERENCES credit_notes(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS stock_transfers (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      source_store_id TEXT NOT NULL,
      destination_store_id TEXT NOT NULL,
      note TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'En cours',
      stock_applied INTEGER NOT NULL DEFAULT 0,
      user_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS stock_transfer_lines (
      id TEXT PRIMARY KEY NOT NULL,
      transfer_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      quantity REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL DEFAULT 0,
      line_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (transfer_id) REFERENCES stock_transfers(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      label TEXT NOT NULL DEFAULT '',
      amount REAL NOT NULL DEFAULT 0,
      authorized_by TEXT NOT NULL DEFAULT '',
      executed_by TEXT NOT NULL DEFAULT '',
      receipt TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Validée'
    );
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT '',
      supplier_id TEXT NOT NULL DEFAULT '',
      store_id TEXT NOT NULL DEFAULT '',
      total REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Brouillon',
      express INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS order_lines (
      id TEXT PRIMARY KEY NOT NULL,
      order_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      quantity REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL DEFAULT 0,
      line_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS supplier_payments (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      order_id TEXT NOT NULL,
      supplier_id TEXT NOT NULL DEFAULT '',
      date TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      method TEXT NOT NULL DEFAULT 'cash',
      reference TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Validé',
      user_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE RESTRICT
    );
    CREATE TABLE IF NOT EXISTS quotes (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      client_name TEXT NOT NULL DEFAULT '',
      client_contact TEXT NOT NULL DEFAULT '',
      client_address TEXT NOT NULL DEFAULT '',
      subtotal REAL NOT NULL DEFAULT 0,
      vat REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Brouillon'
    );
    CREATE TABLE IF NOT EXISTS quote_lines (
      id TEXT PRIMARY KEY NOT NULL,
      quote_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      quantity REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL DEFAULT 0,
      line_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS inventory (
      id TEXT PRIMARY KEY NOT NULL,
      product_id TEXT NOT NULL,
      store_id TEXT NOT NULL DEFAULT '',
      real_quantity REAL NOT NULL DEFAULT 0,
      date TEXT NOT NULL,
      user_id TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS inventory_reports (
      id TEXT PRIMARY KEY NOT NULL,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      title TEXT NOT NULL DEFAULT '',
      store_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      user_id TEXT NOT NULL DEFAULT '',
      total_products INTEGER NOT NULL DEFAULT 0,
      counted_products INTEGER NOT NULL DEFAULT 0,
      gap_products INTEGER NOT NULL DEFAULT 0,
      theoretical_total REAL NOT NULL DEFAULT 0,
      real_total REAL NOT NULL DEFAULT 0,
      gap_total REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS inventory_report_lines (
      id TEXT PRIMARY KEY NOT NULL,
      report_id TEXT NOT NULL,
      product_id TEXT NOT NULL DEFAULT '',
      store_id TEXT NOT NULL DEFAULT '',
      code TEXT NOT NULL DEFAULT '',
      product_name TEXT NOT NULL DEFAULT '',
      category_name TEXT NOT NULL DEFAULT '',
      store_name TEXT NOT NULL DEFAULT '',
      theoretical REAL NOT NULL DEFAULT 0,
      real_quantity REAL,
      gap REAL,
      counted INTEGER NOT NULL DEFAULT 0,
      inventory_date TEXT NOT NULL DEFAULT '',
      line_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (report_id) REFERENCES inventory_reports(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS activities (
      id TEXT PRIMARY KEY NOT NULL,
      date TEXT NOT NULL,
      user_id TEXT NOT NULL DEFAULT '',
      module TEXT NOT NULL DEFAULT '',
      action TEXT NOT NULL DEFAULT '',
      element TEXT NOT NULL DEFAULT '',
      detail TEXT NOT NULL DEFAULT '',
      old_value TEXT NOT NULL DEFAULT '',
      new_value TEXT NOT NULL DEFAULT ''
    );
  `);
  const clientColumns = database.prepare('PRAGMA table_info(clients)').all().map((column) => column.name);
  if (!clientColumns.includes('opening_receivable')) database.exec("ALTER TABLE clients ADD COLUMN opening_receivable REAL NOT NULL DEFAULT 0");
  const movementColumns = database.prepare('PRAGMA table_info(stock_movements)').all().map((column) => column.name);
  if (!movementColumns.includes('reversed_of')) database.exec("ALTER TABLE stock_movements ADD COLUMN reversed_of TEXT NOT NULL DEFAULT ''");
  if (!movementColumns.includes('correction_reason')) database.exec("ALTER TABLE stock_movements ADD COLUMN correction_reason TEXT NOT NULL DEFAULT ''");
  const salesColumns = database.prepare('PRAGMA table_info(sales)').all().map((column) => column.name);
  if (!salesColumns.includes('price_type')) database.exec("ALTER TABLE sales ADD COLUMN price_type TEXT NOT NULL DEFAULT 'retail'");
  if (!salesColumns.includes('price_label')) database.exec("ALTER TABLE sales ADD COLUMN price_label TEXT NOT NULL DEFAULT 'Prix de vente'");
  const orderColumns = database.prepare('PRAGMA table_info(orders)').all().map((column) => column.name);
  if (!orderColumns.includes('express')) database.exec("ALTER TABLE orders ADD COLUMN express INTEGER NOT NULL DEFAULT 0");
  if (!orderColumns.includes('payment_mode')) database.exec("ALTER TABLE orders ADD COLUMN payment_mode TEXT NOT NULL DEFAULT 'cash'");
  if (!orderColumns.includes('due_date')) database.exec("ALTER TABLE orders ADD COLUMN due_date TEXT NOT NULL DEFAULT ''");
  const supplierColumns = database.prepare('PRAGMA table_info(suppliers)').all().map((column) => column.name);
  if (!supplierColumns.includes('credit_limit')) database.exec("ALTER TABLE suppliers ADD COLUMN credit_limit REAL NOT NULL DEFAULT 0");
  const productColumns = database.prepare('PRAGMA table_info(products)').all().map((column) => column.name);
  if (!productColumns.includes('barcode')) database.exec("ALTER TABLE products ADD COLUMN barcode TEXT NOT NULL DEFAULT ''");
  if (!productColumns.includes('barcode_type')) database.exec("ALTER TABLE products ADD COLUMN barcode_type TEXT NOT NULL DEFAULT ''");
  database.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode) WHERE barcode <> ''");
  // Schéma v12 : facturation séparée de l'encaissement (factures = ventes kind 'invoice', règlements ciblés par facture).
  const saleColumnsV12 = database.prepare('PRAGMA table_info(sales)').all().map((column) => column.name);
  if (!saleColumnsV12.includes('kind')) database.exec("ALTER TABLE sales ADD COLUMN kind TEXT NOT NULL DEFAULT 'direct'");
  if (!saleColumnsV12.includes('validated_by')) database.exec("ALTER TABLE sales ADD COLUMN validated_by TEXT NOT NULL DEFAULT ''");
  if (!saleColumnsV12.includes('validated_at')) database.exec("ALTER TABLE sales ADD COLUMN validated_at TEXT NOT NULL DEFAULT ''");
  if (!saleColumnsV12.includes('due_date')) database.exec("ALTER TABLE sales ADD COLUMN due_date TEXT NOT NULL DEFAULT ''");
  if (!saleColumnsV12.includes('observations')) database.exec("ALTER TABLE sales ADD COLUMN observations TEXT NOT NULL DEFAULT ''");
  const paymentColumnsV12 = database.prepare('PRAGMA table_info(customer_payments)').all().map((column) => column.name);
  if (!paymentColumnsV12.includes('sale_id')) database.exec("ALTER TABLE customer_payments ADD COLUMN sale_id TEXT NOT NULL DEFAULT ''");
  if (!paymentColumnsV12.includes('request_id')) database.exec("ALTER TABLE customer_payments ADD COLUMN request_id TEXT NOT NULL DEFAULT ''");
  if (!paymentColumnsV12.includes('cancel_reason')) database.exec("ALTER TABLE customer_payments ADD COLUMN cancel_reason TEXT NOT NULL DEFAULT ''");
  if (!paymentColumnsV12.includes('cancelled_by')) database.exec("ALTER TABLE customer_payments ADD COLUMN cancelled_by TEXT NOT NULL DEFAULT ''");
  if (!paymentColumnsV12.includes('cancelled_at')) database.exec("ALTER TABLE customer_payments ADD COLUMN cancelled_at TEXT NOT NULL DEFAULT ''");
  database.exec("CREATE INDEX IF NOT EXISTS idx_sales_kind_status ON sales(kind, status)");
  database.exec("CREATE INDEX IF NOT EXISTS idx_customer_payments_sale ON customer_payments(sale_id)");
  database.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_customer_payments_request ON customer_payments(request_id) WHERE request_id <> ''");
  database.prepare(`
    INSERT INTO app_meta (key, value) VALUES ('schema_version', '12')
    ON CONFLICT(key) DO UPDATE SET value = '12'
  `).run();
}

function parseLegacyState() {
  const row = database?.prepare('SELECT value FROM app_storage WHERE key = ?').get(STATE_KEY);
  return row ? json(row.value, null) : null;
}

function writeMeta(key, value) {
  database.prepare(`
    INSERT INTO app_state_meta (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(key, JSON.stringify(value ?? null));
}

function readMeta(key, fallback) {
  const row = database.prepare('SELECT value FROM app_state_meta WHERE key = ?').get(key);
  if (!row) return fallback;
  return json(row.value, fallback);
}

function defaultClockIntegrity() {
  return { version: 1, lastObservedAt: 0, maxObservedAt: 0, observations: 0, tampered: false, reason: '', detectedAt: '', source: '' };
}

function normalizeClockIntegrity(value = {}) {
  return {
    version: 1,
    lastObservedAt: Math.max(0, number(value.lastObservedAt)),
    maxObservedAt: Math.max(0, number(value.maxObservedAt)),
    observations: Math.max(0, Math.floor(number(value.observations))),
    tampered: value.tampered === true,
    reason: text(value.reason),
    detectedAt: text(value.detectedAt),
    source: text(value.source)
  };
}

function recordClockTamperAudit(clock) {
  try {
    database.prepare(`
      INSERT OR IGNORE INTO activities (id, date, user_id, module, action, element, detail, old_value, new_value)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(`clock-lock-${clock.maxObservedAt}`, nowIso(), 'system', 'Sécurité', 'Blocage de l’application', 'Intégrité de l’horloge', clock.reason || 'Modification suspecte de la date système.', '', 'Lecture seule pour tous les comptes');
  } catch (_) {}
}

function readExternalClockIntegrity() {
  if (!clockIntegrityFilePath) return defaultClockIntegrity();
  try { return normalizeClockIntegrity(JSON.parse(fs.readFileSync(clockIntegrityFilePath, 'utf8'))); } catch (_) { return defaultClockIntegrity(); }
}

function writeExternalClockIntegrity(clock) {
  if (!clockIntegrityFilePath) return;
  const temporary = `${clockIntegrityFilePath}.tmp`;
  try {
    fs.writeFileSync(temporary, JSON.stringify(clock), { encoding: 'utf8', mode: 0o600 });
    try { fs.renameSync(temporary, clockIntegrityFilePath); }
    catch (_) { fs.copyFileSync(temporary, clockIntegrityFilePath); fs.rmSync(temporary, { force: true }); }
  } catch (_) {
    try { fs.rmSync(temporary, { force: true }); } catch (_) {}
  }
}

function mergeClockIntegrity(...values) {
  const list = values.map(normalizeClockIntegrity);
  const maxItem = list.slice().sort((left, right) => right.maxObservedAt - left.maxObservedAt)[0] || defaultClockIntegrity();
  const tamperItem = list.find((item) => item.tampered) || maxItem;
  return {
    version: 1,
    lastObservedAt: Math.max(...list.map((item) => item.lastObservedAt), 0),
    maxObservedAt: Math.max(...list.map((item) => item.maxObservedAt), 0),
    observations: Math.max(...list.map((item) => item.observations), 0),
    tampered: list.some((item) => item.tampered),
    reason: tamperItem.reason || '',
    detectedAt: tamperItem.detectedAt || '',
    source: tamperItem.source || ''
  };
}

function observeSystemClock(source = 'main') {
  const nowMs = Date.now();
  const databaseCheckpoint = normalizeClockIntegrity(readMeta(CLOCK_INTEGRITY_META_KEY, defaultClockIntegrity()));
  const previous = mergeClockIntegrity(databaseCheckpoint, readExternalClockIntegrity());
  const rollback = previous.maxObservedAt > 0 && nowMs + CLOCK_ROLLBACK_TOLERANCE_MS < previous.maxObservedAt;
  const advance = nowMs - previous.maxObservedAt;
  const wasTampered = previous.tampered;
  const externalTamper = previous.tampered && !databaseCheckpoint.tampered;
  const shouldPersist = previous.maxObservedAt === 0 || advance >= CLOCK_CHECKPOINT_INTERVAL_MS || advance >= CLOCK_ROLLBACK_TOLERANCE_MS || (rollback && !wasTampered) || externalTamper;
  if (!shouldPersist) return previous;
  const next = {
    version: 1,
    lastObservedAt: nowMs,
    maxObservedAt: Math.max(previous.maxObservedAt, nowMs),
    observations: previous.observations + 1,
    tampered: wasTampered || rollback,
    reason: rollback ? 'Recul de l’horloge système détecté.' : previous.reason,
    detectedAt: rollback ? nowIso() : previous.detectedAt,
    source: rollback ? source : previous.source
  };
  writeMeta(CLOCK_INTEGRITY_META_KEY, next);
  writeExternalClockIntegrity(next);
  if ((rollback && !wasTampered) || externalTamper) recordClockTamperAudit(next);
  return next;
}

function clockIntegrityStatus() {
  return mergeClockIntegrity(readMeta(CLOCK_INTEGRITY_META_KEY, defaultClockIntegrity()), readExternalClockIntegrity());
}

function safeArray(value) {
  return Array.isArray(value) ? value : [];
}

function stockBalances(product) {
  const source = product?.stockByStore && typeof product.stockByStore === 'object' ? product.stockByStore : null;
  if (source && Object.keys(source).length) return source;
  const storeId = text(product?.storeId);
  return storeId ? { [storeId]: number(product?.stock) } : {};
}

function replaceRelationalState(state) {
  const tx = database.transaction(() => {
    const tables = [
      'sale_lines', 'sales', 'customer_payments', 'supplier_payments', 'refunds', 'credit_note_lines', 'credit_notes', 'stock_transfer_lines', 'stock_transfers', 'stock_movement_lines', 'stock_movements',
      'order_lines', 'orders', 'quote_lines', 'quotes', 'expenses', 'inventory_report_lines', 'inventory_reports', 'inventory',
      'supplier_products', 'product_stock', 'products', 'deliveries', 'deliverers', 'clients', 'suppliers', 'categories', 'stores', 'roles', 'users'
    ];
    tables.forEach((table) => database.prepare(`DELETE FROM ${table}`).run());

    const insertRole = database.prepare('INSERT INTO roles (id, name, description, color, permissions_json, users_count) VALUES (?, ?, ?, ?, ?, ?)');
    safeArray(state.roles).forEach((role) => insertRole.run(text(role.id), text(role.name), text(role.description), text(role.color || 'neutral'), JSON.stringify(safeArray(role.permissions)), number(role.users)));

    const insertUser = database.prepare('INSERT INTO users (id, name, username, profile, active, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.users).forEach((user) => {
      const timestamp = nowIso();
      insertUser.run(text(user.id), text(user.name), text(user.username), text(user.profile), bool(user.active !== false), text(user.passwordHash), timestamp, timestamp);
    });

    const insertCategory = database.prepare('INSERT INTO categories (id, name, code, description, active) VALUES (?, ?, ?, ?, ?)');
    safeArray(state.categories).forEach((item) => insertCategory.run(text(item.id), text(item.name), text(item.code), text(item.description), bool(item.active !== false)));

    const insertStore = database.prepare('INSERT INTO stores (id, name, code, type, manager, active) VALUES (?, ?, ?, ?, ?, ?)');
    safeArray(state.stores).forEach((item) => insertStore.run(text(item.id), text(item.name), text(item.code), text(item.type), text(item.manager), bool(item.active !== false)));

    const insertSupplier = database.prepare('INSERT INTO suppliers (id, name, type, manager, phone, secondary, fiscal, address, credit_limit, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.suppliers).forEach((item) => insertSupplier.run(text(item.id), text(item.name), text(item.type), text(item.manager), text(item.phone), text(item.secondary), text(item.fiscal), text(item.address), number(item.creditLimit), bool(item.active !== false)));

    const insertClient = database.prepare('INSERT INTO clients (id, name, phone, email, address, credit_limit, opening_receivable, receivable, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.clients).forEach((item) => insertClient.run(text(item.id), text(item.name), text(item.phone), text(item.email), text(item.address), number(item.creditLimit), number(item.openingReceivable), number(item.receivable), bool(item.active !== false)));

    const insertDeliverer = database.prepare('INSERT INTO deliverers (id, last_name, first_name, phone, secondary, address, base_rate, cin, notes, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.deliverers).forEach((item) => insertDeliverer.run(text(item.id), text(item.lastName), text(item.firstName), text(item.phone), text(item.secondary), text(item.address), number(item.baseRate), text(item.cin), text(item.notes), bool(item.active !== false)));

    const insertDelivery = database.prepare('INSERT INTO deliveries (id, sale_id, sale_number, deliverer_id, fee, assigned_at, assigned_by) VALUES (?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.deliveries).forEach((item) => insertDelivery.run(text(item.id), text(item.saleId), text(item.saleNumber), text(item.delivererId), number(item.fee), text(item.assignedAt), text(item.assignedBy)));

    const insertProduct = database.prepare(`INSERT INTO products
      (id, code, name, category_id, brand, model, supplier_id, default_store_id, purchase_price, sale_price, wholesale_price, promo_price, min_stock, max_stock, presentation, batch, expiry, image, barcode, barcode_type, active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    const insertBalance = database.prepare('INSERT INTO product_stock (product_id, store_id, quantity) VALUES (?, ?, ?)');
    const storeIds = new Set(safeArray(state.stores).map((store) => text(store.id)));
    safeArray(state.products).forEach((item) => { 
      insertProduct.run(text(item.id), text(item.code), text(item.name), text(item.categoryId), text(item.brand), text(item.model), text(item.supplierId), text(item.storeId), number(item.purchasePrice), number(item.salePrice), number(item.wholesalePrice), number(item.promoPrice), number(item.minStock), number(item.maxStock), text(item.presentation), text(item.batch), text(item.expiry), text(item.image), text(normalizeBarcode(item.barcode)), text(barcodeCheck(item.barcode).type), bool(item.active !== false));
      Object.entries(stockBalances(item)).forEach(([storeId, quantity]) => {
        if (storeId && storeIds.has(text(storeId))) insertBalance.run(text(item.id), text(storeId), number(quantity));
      });
    });

    const insertSupplierProduct = database.prepare('INSERT OR IGNORE INTO supplier_products (supplier_id, product_id, created_at, user_id) VALUES (?, ?, ?, ?)');
    const supplierProductLinks = Array.isArray(state.supplierProducts) ? state.supplierProducts : safeArray(state.products).filter((product) => product.supplierId).map((product) => ({ supplierId: product.supplierId, productId: product.id, createdAt: nowIso(), userId: 'system' }));
    supplierProductLinks.forEach((link) => insertSupplierProduct.run(text(link.supplierId), text(link.productId), text(link.createdAt || nowIso()), text(link.userId || 'system')));

    const insertSale = database.prepare('INSERT INTO sales (id, number, date, client_id, client_name, store_id, total, payment, price_type, price_label, status, user_id, kind, validated_by, validated_at, due_date, observations) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const insertSaleLine = database.prepare('INSERT INTO sale_lines (id, sale_id, product_id, store_id, quantity, unit_price, cost_price, line_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.sales).forEach((sale) => {
      insertSale.run(text(sale.id), text(sale.number), text(sale.date), text(sale.clientId || 'counter'), text(sale.clientName), text(sale.storeId), number(sale.total), text(sale.payment), text(sale.priceType || 'retail'), text(sale.priceLabel || 'Prix de vente'), text(sale.status), text(sale.userId), text(sale.kind || 'direct'), text(sale.validatedBy), text(sale.validatedAt), text(sale.dueDate), text(sale.observations));
      safeArray(sale.items).forEach((line, index) => insertSaleLine.run(`${text(sale.id)}-line-${index}`, text(sale.id), text(line.productId), text(line.storeId || sale.storeId), number(line.quantity), number(line.unitPrice), number(line.costPrice), index));
    });

    const insertCustomerPayment = database.prepare('INSERT INTO customer_payments (id, number, client_id, date, amount, method, reference, note, status, user_id, created_at, sale_id, request_id, cancel_reason, cancelled_by, cancelled_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.customerPayments).forEach((item) => insertCustomerPayment.run(text(item.id), text(item.number), text(item.clientId), text(item.date), number(item.amount), text(item.method || 'cash'), text(item.reference), text(item.note), text(item.status || 'Validé'), text(item.userId), text(item.createdAt || nowIso()), text(item.saleId), text(item.requestId), text(item.cancelReason), text(item.cancelledBy), text(item.cancelledAt)));
    const insertRefund = database.prepare('INSERT INTO refunds (id, number, date, note_id, note_number, note_payment, client_id, amount, method, reference, note, status, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.refunds).forEach((item) => insertRefund.run(text(item.id), text(item.number), text(item.date), text(item.noteId), text(item.noteNumber), text(item.notePayment || 'cash'), text(item.clientId), number(item.amount), text(item.method || 'cash'), text(item.reference), text(item.note), text(item.status || 'Validée'), text(item.userId), text(item.createdAt || nowIso())));

    const insertCreditNote = database.prepare('INSERT INTO credit_notes (id, number, date, type, original_sale_id, original_sale_number, client_id, client_name, payment, total, restock, status, stock_applied, reason, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const insertCreditNoteLine = database.prepare('INSERT INTO credit_note_lines (id, credit_note_id, product_id, store_id, quantity, unit_price, cost_price, line_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.creditNotes).forEach((item) => {
      insertCreditNote.run(text(item.id), text(item.number), text(item.date), text(item.type || 'Avoir partiel'), text(item.originalSaleId), text(item.originalSaleNumber), text(item.clientId || 'counter'), text(item.clientName), text(item.payment || 'cash'), number(item.total), bool(item.restock), text(item.status || 'En cours'), bool(item.stockApplied), text(item.reason), text(item.userId), text(item.createdAt || nowIso()));
      safeArray(item.lines).forEach((line, index) => insertCreditNoteLine.run(`${text(item.id)}-line-${index}`, text(item.id), text(line.productId), text(line.storeId), number(line.quantity), number(line.unitPrice), number(line.costPrice), index));
    });

    const insertTransfer = database.prepare('INSERT INTO stock_transfers (id, number, date, source_store_id, destination_store_id, note, status, stock_applied, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const insertTransferLine = database.prepare('INSERT INTO stock_transfer_lines (id, transfer_id, product_id, quantity, unit_price, line_order) VALUES (?, ?, ?, ?, ?, ?)');
    safeArray(state.stockTransfers).forEach((item) => {
      insertTransfer.run(text(item.id), text(item.number), text(item.date), text(item.sourceStoreId), text(item.destinationStoreId), text(item.note), text(item.status || 'En cours'), bool(item.stockApplied), text(item.userId), text(item.createdAt || nowIso()));
      safeArray(item.lines).forEach((line, index) => insertTransferLine.run(`${text(item.id)}-line-${index}`, text(item.id), text(line.productId), number(line.quantity), number(line.unitPrice), index));
    });

    const insertMovement = database.prepare('INSERT INTO stock_movements (id, number, kind, date, type, supplier_id, invoice, beneficiary, store_id, status, stock_applied, reversed_of, correction_reason, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const insertMovementLine = database.prepare('INSERT INTO stock_movement_lines (id, movement_id, product_id, store_id, quantity, unit_price, total, line_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    const movements = [
      ...safeArray(state.stockEntries).map((item) => ({ ...item, kind: 'entry' })),
      ...safeArray(state.stockExits).map((item) => ({ ...item, kind: 'exit' }))
    ];
    movements.forEach((movement) => {
      insertMovement.run(text(movement.id), text(movement.number), movement.kind, text(movement.date), text(movement.type), text(movement.supplierId), text(movement.invoice), text(movement.beneficiary), text(movement.storeId), text(movement.status), bool(movement.stockApplied), text(movement.reversalOf), text(movement.correctionReason), text(movement.userId));
      insertMovementLine.run(`${text(movement.id)}-line-0`, text(movement.id), text(movement.productId), text(movement.storeId), number(movement.quantity), number(movement.unitPrice), number(movement.total), 0);
    });

    const insertExpense = database.prepare('INSERT INTO expenses (id, number, date, label, amount, authorized_by, executed_by, receipt, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.expenses).forEach((item) => insertExpense.run(text(item.id), text(item.number), text(item.date), text(item.label), number(item.amount), text(item.authorizedBy), text(item.executedBy), text(item.receipt), text(item.status)));

    const insertOrder = database.prepare('INSERT INTO orders (id, number, date, type, supplier_id, store_id, total, status, express, payment_mode, due_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const insertOrderLine = database.prepare('INSERT INTO order_lines (id, order_id, product_id, quantity, unit_price, line_order) VALUES (?, ?, ?, ?, ?, ?)');
    safeArray(state.orders).forEach((order) => {
      insertOrder.run(text(order.id), text(order.number), text(order.date), text(order.type), text(order.supplierId), text(order.storeId), number(order.total), text(order.status), bool(order.express), text(order.paymentMode === 'credit' ? 'credit' : 'cash'), text(order.dueDate));
      safeArray(order.lines).forEach((line, index) => insertOrderLine.run(`${text(order.id)}-line-${index}`, text(order.id), text(line.productId), number(line.quantity), number(line.unitPrice), index));
    });

    const insertSupplierPayment = database.prepare('INSERT INTO supplier_payments (id, number, order_id, supplier_id, date, amount, method, reference, note, status, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.supplierPayments).forEach((item) => insertSupplierPayment.run(text(item.id), text(item.number), text(item.orderId), text(item.supplierId), text(item.date), number(item.amount), text(item.method || 'cash'), text(item.reference), text(item.note), text(item.status || 'Validé'), text(item.userId), text(item.createdAt || nowIso())));

    const insertQuote = database.prepare('INSERT INTO quotes (id, number, date, client_name, client_contact, client_address, subtotal, vat, discount, total, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const insertQuoteLine = database.prepare('INSERT INTO quote_lines (id, quote_id, product_id, quantity, unit_price, line_order) VALUES (?, ?, ?, ?, ?, ?)');
    safeArray(state.quotes).forEach((quote) => {
      insertQuote.run(text(quote.id), text(quote.number), text(quote.date), text(quote.clientName), text(quote.clientContact), text(quote.clientAddress), number(quote.subtotal), number(quote.vat), number(quote.discount), number(quote.total), text(quote.status));
      safeArray(quote.lines).forEach((line, index) => insertQuoteLine.run(`${text(quote.id)}-line-${index}`, text(quote.id), text(line.productId), number(line.quantity), number(line.unitPrice), index));
    });

    const insertInventory = database.prepare('INSERT INTO inventory (id, product_id, store_id, real_quantity, date, user_id) VALUES (?, ?, ?, ?, ?, ?)');
    safeArray(state.inventory).forEach((item) => insertInventory.run(text(item.id), text(item.productId), text(item.storeId), number(item.real), text(item.date), text(item.userId)));

    const insertInventoryReport = database.prepare('INSERT INTO inventory_reports (id, number, date, title, store_id, created_at, user_id, total_products, counted_products, gap_products, theoretical_total, real_total, gap_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const insertInventoryReportLine = database.prepare('INSERT INTO inventory_report_lines (id, report_id, product_id, store_id, code, product_name, category_name, store_name, theoretical, real_quantity, gap, counted, inventory_date, line_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.inventoryReports).forEach((report) => {
      insertInventoryReport.run(text(report.id), text(report.number), text(report.date), text(report.title), text(report.storeId), text(report.createdAt || nowIso()), text(report.userId), number(report.totalProducts), number(report.countedProducts), number(report.gapProducts), number(report.theoreticalTotal), number(report.realTotal), number(report.gapTotal));
      safeArray(report.lines).forEach((line, index) => insertInventoryReportLine.run(text(line.id || `${text(report.id)}-line-${index}`), text(report.id), text(line.productId), text(line.storeId), text(line.code), text(line.productName), text(line.categoryName), text(line.storeName), number(line.theoretical), line.real == null ? null : number(line.real), line.gap == null ? null : number(line.gap), bool(line.counted || line.real != null), text(line.inventoryDate), index));
    });

    // Le journal est append-only : un renderer ne peut pas effacer les événements déjà persistés.
    const insertActivity = database.prepare('INSERT OR IGNORE INTO activities (id, date, user_id, module, action, element, detail, old_value, new_value) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    safeArray(state.activities).forEach((item) => insertActivity.run(text(item.id), text(item.date), text(item.userId), text(item.module), text(item.action), text(item.element), text(item.detail), text(item.oldValue), text(item.newValue)));

    writeMeta('version', number(state.version) || 2);
    writeMeta('blank_database', state.blankDatabase === true);
    writeMeta('initial_setup_completed', state.initialSetupCompleted !== false);
    writeMeta('settings', state.settings || {});
    writeMeta('license', state.license || {});
    writeMeta('supplier_products_initialized', true);
  });
  tx();
}

function rowsById(rows) {
  const map = new Map();
  rows.forEach((row) => map.set(row.id, row));
  return map;
}

// Mouvement net de l'encours d'un client (hors ouverture) : miroir de www/app.js.
// ventes à crédit validées - avoirs à crédit validés - règlements validés + remboursements à crédit validés.
function clientNetMovement(clientId, data) {
  const amountOf = (item, lineKey) => number(item.total) || safeArray(item[lineKey]).reduce((sum, line) => sum + number(line.quantity) * number(line.unitPrice), 0);
  const creditSales = safeArray(data.sales).filter((sale) => sale.status === 'Validée' && sale.payment === 'credit' && sale.clientId === clientId).reduce((sum, sale) => sum + amountOf(sale, 'items'), 0);
  const creditNotes = safeArray(data.creditNotes).filter((note) => note.status === 'Validée' && note.payment === 'credit' && note.clientId === clientId).reduce((sum, note) => sum + amountOf(note, 'lines'), 0);
  const payments = safeArray(data.customerPayments).filter((payment) => payment.status === 'Validé' && payment.clientId === clientId).reduce((sum, payment) => sum + number(payment.amount), 0);
  const refunds = safeArray(data.refunds).filter((refund) => refund.status === 'Validée' && refund.notePayment === 'credit' && refund.clientId === clientId).reduce((sum, refund) => sum + number(refund.amount), 0);
  return creditSales - creditNotes - payments + refunds;
}

function buildRelationalState() {
  if (!hasRelationalState()) return null;
  const settings = readMeta('settings', {});
  const blankDatabase = readMeta('blank_database', false) === true;
  const initialSetupCompleted = readMeta('initial_setup_completed', true) !== false;
  const license = { ...readMeta('license', {}), clockIntegrity: clockIntegrityStatus() };
  const stores = database.prepare('SELECT * FROM stores ORDER BY rowid').all().map((row) => ({ id: row.id, name: row.name, code: row.code, type: row.type, manager: row.manager, active: !!row.active }));
  const stockRows = database.prepare('SELECT product_id, store_id, quantity FROM product_stock').all();
  const stockMap = new Map();
  stockRows.forEach((row) => {
    if (!stockMap.has(row.product_id)) stockMap.set(row.product_id, {});
    stockMap.get(row.product_id)[row.store_id] = number(row.quantity);
  });
  const products = database.prepare('SELECT * FROM products ORDER BY rowid').all().map((row) => {
    const stockByStore = stockMap.get(row.id) || {};
    const stock = Object.values(stockByStore).reduce((sum, value) => sum + number(value), 0);
    return { id: row.id, code: row.code, name: row.name, categoryId: row.category_id, brand: row.brand, model: row.model, supplierId: row.supplier_id, storeId: row.default_store_id, purchasePrice: number(row.purchase_price), salePrice: number(row.sale_price), wholesalePrice: number(row.wholesale_price), promoPrice: number(row.promo_price), stock, stockByStore, minStock: number(row.min_stock), maxStock: number(row.max_stock), presentation: row.presentation, batch: row.batch, expiry: row.expiry, image: row.image || '', barcode: row.barcode || '', barcodeType: row.barcode_type || '', active: !!row.active };
  });
  const lineRows = database.prepare('SELECT * FROM sale_lines ORDER BY sale_id, line_order').all();
  const saleLines = new Map();
  lineRows.forEach((row) => {
    if (!saleLines.has(row.sale_id)) saleLines.set(row.sale_id, []);
    saleLines.get(row.sale_id).push({ productId: row.product_id, storeId: row.store_id, quantity: number(row.quantity), unitPrice: number(row.unit_price), costPrice: number(row.cost_price) });
  });
  const sales = database.prepare('SELECT * FROM sales ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, date: row.date, clientId: row.client_id, clientName: row.client_name, storeId: row.store_id, items: saleLines.get(row.id) || [], total: number(row.total), payment: row.payment, priceType: row.price_type || 'retail', priceLabel: row.price_label || 'Prix de vente', status: row.status, userId: row.user_id, ...(row.kind && row.kind !== 'direct' ? { kind: row.kind } : {}), ...(row.validated_by ? { validatedBy: row.validated_by } : {}), ...(row.validated_at ? { validatedAt: row.validated_at } : {}), ...(row.due_date ? { dueDate: row.due_date } : {}), ...(row.observations ? { observations: row.observations } : {}) }));
  const creditNoteLineRows = database.prepare('SELECT * FROM credit_note_lines ORDER BY credit_note_id, line_order').all();
  const creditNoteLines = new Map();
  creditNoteLineRows.forEach((row) => { if (!creditNoteLines.has(row.credit_note_id)) creditNoteLines.set(row.credit_note_id, []); creditNoteLines.get(row.credit_note_id).push({ productId: row.product_id, storeId: row.store_id, quantity: number(row.quantity), unitPrice: number(row.unit_price), costPrice: number(row.cost_price) }); });
  const creditNotes = database.prepare('SELECT * FROM credit_notes ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, date: row.date, type: row.type, originalSaleId: row.original_sale_id, originalSaleNumber: row.original_sale_number, clientId: row.client_id, clientName: row.client_name, payment: row.payment, lines: creditNoteLines.get(row.id) || [], total: number(row.total), restock: !!row.restock, status: row.status, stockApplied: !!row.stock_applied, reason: row.reason, userId: row.user_id, createdAt: row.created_at }));
  const transferLineRows = database.prepare('SELECT * FROM stock_transfer_lines ORDER BY transfer_id, line_order').all();
  const transferLines = new Map();
  transferLineRows.forEach((row) => { if (!transferLines.has(row.transfer_id)) transferLines.set(row.transfer_id, []); transferLines.get(row.transfer_id).push({ productId: row.product_id, quantity: number(row.quantity), unitPrice: number(row.unit_price) }); });
  const stockTransfers = database.prepare('SELECT * FROM stock_transfers ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, date: row.date, sourceStoreId: row.source_store_id, destinationStoreId: row.destination_store_id, lines: transferLines.get(row.id) || [], note: row.note, status: row.status, stockApplied: !!row.stock_applied, userId: row.user_id, createdAt: row.created_at }));
  const movementLines = database.prepare('SELECT * FROM stock_movement_lines ORDER BY movement_id, line_order').all();
  const movementLineMap = new Map();
  movementLines.forEach((row) => movementLineMap.set(row.movement_id, row));
  const movementRows = database.prepare('SELECT * FROM stock_movements ORDER BY date DESC, rowid DESC').all();
  const stockEntries = [];
  const stockExits = [];
  movementRows.forEach((row) => {
    const line = movementLineMap.get(row.id) || {};
    const item = { id: row.id, number: row.number, date: row.date, type: row.type, supplierId: row.supplier_id, invoice: row.invoice, beneficiary: row.beneficiary, storeId: row.store_id, productId: line.product_id || '', quantity: number(line.quantity), unitPrice: number(line.unit_price), total: number(line.total), status: row.status, stockApplied: !!row.stock_applied, reversalOf: row.reversed_of || '', correctionReason: row.correction_reason || '', userId: row.user_id };
    (row.kind === 'entry' ? stockEntries : stockExits).push(item);
  });
  const orderLineRows = database.prepare('SELECT * FROM order_lines ORDER BY order_id, line_order').all();
  const orderLines = new Map();
  orderLineRows.forEach((row) => { if (!orderLines.has(row.order_id)) orderLines.set(row.order_id, []); orderLines.get(row.order_id).push({ productId: row.product_id, quantity: number(row.quantity), unitPrice: number(row.unit_price) }); });
  const orders = database.prepare('SELECT * FROM orders ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, date: row.date, type: row.type, supplierId: row.supplier_id, storeId: row.store_id, lines: orderLines.get(row.id) || [], total: number(row.total), status: row.status, express: !!row.express, paymentMode: row.payment_mode === 'credit' ? 'credit' : 'cash', dueDate: row.due_date || '' }));
  const quoteLineRows = database.prepare('SELECT * FROM quote_lines ORDER BY quote_id, line_order').all();
  const quoteLines = new Map();
  quoteLineRows.forEach((row) => { if (!quoteLines.has(row.quote_id)) quoteLines.set(row.quote_id, []); quoteLines.get(row.quote_id).push({ productId: row.product_id, quantity: number(row.quantity), unitPrice: number(row.unit_price) }); });
  const quotes = database.prepare('SELECT * FROM quotes ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, date: row.date, clientName: row.client_name, clientContact: row.client_contact, clientAddress: row.client_address, lines: quoteLines.get(row.id) || [], subtotal: number(row.subtotal), vat: number(row.vat), discount: number(row.discount), total: number(row.total), status: row.status }));
  const roles = database.prepare('SELECT * FROM roles ORDER BY rowid').all().map((row) => { const permissions = json(row.permissions_json, []); return { id: row.id, name: row.name, description: row.description, color: row.color, permissions: permissions.length ? permissions : (FALLBACK_ROLE_PERMISSIONS[row.name] || []), users: number(row.users_count) }; });
  const users = database.prepare('SELECT * FROM users ORDER BY rowid').all().map((row) => ({ id: row.id, name: row.name, username: row.username, profile: row.profile, active: !!row.active, passwordHash: row.password_hash }));
  const categories = database.prepare('SELECT * FROM categories ORDER BY rowid').all().map((row) => ({ id: row.id, name: row.name, code: row.code, description: row.description, active: !!row.active }));
  const suppliers = database.prepare('SELECT * FROM suppliers ORDER BY rowid').all().map((row) => ({ id: row.id, name: row.name, type: row.type, manager: row.manager, phone: row.phone, secondary: row.secondary, fiscal: row.fiscal, address: row.address, creditLimit: number(row.credit_limit), active: !!row.active }));
  const supplierProducts = database.prepare('SELECT supplier_id, product_id, created_at, user_id FROM supplier_products ORDER BY supplier_id, product_id').all().map((row) => ({ supplierId: row.supplier_id, productId: row.product_id, createdAt: row.created_at, userId: row.user_id }));
  const deliverers = database.prepare('SELECT * FROM deliverers ORDER BY rowid').all().map((row) => ({ id: row.id, lastName: row.last_name, firstName: row.first_name, phone: row.phone, secondary: row.secondary, address: row.address, baseRate: number(row.base_rate), cin: row.cin, notes: row.notes, active: !!row.active }));
  const deliveries = database.prepare('SELECT * FROM deliveries ORDER BY assigned_at DESC, rowid DESC').all().map((row) => ({ id: row.id, saleId: row.sale_id, saleNumber: row.sale_number, delivererId: row.deliverer_id, fee: number(row.fee), assignedAt: row.assigned_at, assignedBy: row.assigned_by }));
  const clientRows = database.prepare('SELECT * FROM clients ORDER BY rowid').all();
  const supplierPayments = database.prepare('SELECT * FROM supplier_payments ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, orderId: row.order_id, supplierId: row.supplier_id, date: row.date, amount: number(row.amount), method: row.method, reference: row.reference, note: row.note, status: row.status, userId: row.user_id, createdAt: row.created_at }));
  const customerPayments = database.prepare('SELECT * FROM customer_payments ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, clientId: row.client_id, date: row.date, amount: number(row.amount), method: row.method, reference: row.reference, note: row.note, status: row.status, userId: row.user_id, createdAt: row.created_at, ...(row.sale_id ? { saleId: row.sale_id } : {}), ...(row.request_id ? { requestId: row.request_id } : {}), ...(row.cancel_reason ? { cancelReason: row.cancel_reason } : {}), ...(row.cancelled_by ? { cancelledBy: row.cancelled_by } : {}), ...(row.cancelled_at ? { cancelledAt: row.cancelled_at } : {}) }));
  const refunds = database.prepare('SELECT * FROM refunds ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, date: row.date, noteId: row.note_id, noteNumber: row.note_number, notePayment: row.note_payment, clientId: row.client_id, amount: number(row.amount), method: row.method, reference: row.reference, note: row.note, status: row.status, userId: row.user_id, createdAt: row.created_at }));
  // Encours client : même règle que l'interface (www/app.js : creditSalesTotal, creditPaymentsTotal,
  // clientRefundsTotal, clientPositionValues). L'ouverture stockée prime. Si elle vaut 0 (dossier antérieur
  // à la colonne, ou ouverture réellement nulle), elle est reconstituée pour que le recalcul de l'interface
  // retrouve le solde stocké : solde > 0 → max(0, solde - mouvement) ; sinon 0 (l'avance reste dérivée du net).
  // Sans cela, le garde-fou d'écriture refuse la sauvegarde. L'ouverture reste >= 0 (imputation des règlements).
  const clients = clientRows.map((row) => {
    const movement = clientNetMovement(row.id, { sales, creditNotes, customerPayments, refunds });
    const receivable = number(row.receivable);
    const openingReceivable = number(row.opening_receivable) || (receivable > 0 ? Math.max(0, receivable - movement) : 0);
    const net = openingReceivable + movement;
    return { id: row.id, name: row.name, phone: row.phone, email: row.email, address: row.address, creditLimit: number(row.credit_limit), openingReceivable, receivable, advance: Math.max(0, -net), active: !!row.active };
  });
  const expenses = database.prepare('SELECT * FROM expenses ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, date: row.date, label: row.label, amount: number(row.amount), authorizedBy: row.authorized_by, executedBy: row.executed_by, receipt: row.receipt, status: row.status }));
  const inventory = database.prepare('SELECT * FROM inventory ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, productId: row.product_id, storeId: row.store_id, real: number(row.real_quantity), date: row.date, userId: row.user_id }));
  const inventoryReportLineRows = database.prepare('SELECT * FROM inventory_report_lines ORDER BY report_id, line_order').all();
  const inventoryReportLines = new Map();
  inventoryReportLineRows.forEach((row) => { if (!inventoryReportLines.has(row.report_id)) inventoryReportLines.set(row.report_id, []); inventoryReportLines.get(row.report_id).push({ id: row.id, productId: row.product_id, storeId: row.store_id, code: row.code, productName: row.product_name, categoryName: row.category_name, storeName: row.store_name, theoretical: number(row.theoretical), real: row.real_quantity == null ? null : number(row.real_quantity), gap: row.gap == null ? null : number(row.gap), counted: !!row.counted, inventoryDate: row.inventory_date }); });
  const inventoryReports = database.prepare('SELECT * FROM inventory_reports ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, number: row.number, date: row.date, title: row.title, storeId: row.store_id, createdAt: row.created_at, userId: row.user_id, lines: inventoryReportLines.get(row.id) || [], totalProducts: number(row.total_products), countedProducts: number(row.counted_products), gapProducts: number(row.gap_products), theoreticalTotal: number(row.theoretical_total), realTotal: number(row.real_total), gapTotal: number(row.gap_total) }));
  const activities = database.prepare('SELECT * FROM activities ORDER BY date DESC, rowid DESC').all().map((row) => ({ id: row.id, date: row.date, userId: row.user_id, module: row.module, action: row.action, element: row.element, detail: row.detail, oldValue: row.old_value, newValue: row.new_value }));
  return { version: number(readMeta('version', 6)) || 6, blankDatabase, initialSetupCompleted, settings, license, categories, stores, suppliers, supplierProducts, deliverers, deliveries, products, clients, customerPayments, supplierPayments, refunds, sales, creditNotes, stockEntries, stockExits, stockTransfers, expenses, orders, quotes, users, roles, inventory, inventoryReports, activities };
}

function migrateLegacyState() {
  if (hasRelationalState()) return;
  const legacy = parseLegacyState();
  if (!legacy || typeof legacy !== 'object') return;
  replaceRelationalState(legacy);
  database.prepare('DELETE FROM app_storage WHERE key = ?').run(STATE_KEY);
}

function migrateSupplierProductLinks() {
  if (!database || readMeta('supplier_products_initialized', false) === true) return;
  const hasLinks = database.prepare('SELECT 1 FROM supplier_products LIMIT 1').get();
  if (!hasLinks) database.prepare("INSERT OR IGNORE INTO supplier_products (supplier_id, product_id, created_at, user_id) SELECT supplier_id, id, ?, 'system' FROM products WHERE supplier_id <> ''").run(nowIso());
  writeMeta('supplier_products_initialized', true);
}

function migrateProtectedAdministrator() {
  if (!database) return;
  const migrate = database.transaction(() => {
    const legacy = database.prepare("SELECT * FROM users WHERE lower(username) = 'admin' ORDER BY rowid LIMIT 1").get();
    const protectedUser = database.prepare('SELECT * FROM users WHERE username = ?').get(PROTECTED_ADMIN_USERNAME);
    if (legacy && (!protectedUser || protectedUser.id === legacy.id)) {
      database.prepare('UPDATE users SET name = ?, username = ?, profile = ?, active = 1, password_hash = ?, updated_at = ? WHERE id = ?').run('Administrateur', PROTECTED_ADMIN_USERNAME, 'Administrateur', PROTECTED_ADMIN_PASSWORD_HASH, nowIso(), legacy.id);
    } else if (legacy && protectedUser && legacy.id !== protectedUser.id) {
      database.prepare('DELETE FROM users WHERE id = ?').run(legacy.id);
    } else if (protectedUser) {
      database.prepare('UPDATE users SET name = ?, profile = ?, active = 1, updated_at = ? WHERE id = ?').run('Administrateur', 'Administrateur', nowIso(), protectedUser.id);
    }
    const role = database.prepare("SELECT * FROM roles WHERE name = 'Administrateur' LIMIT 1").get();
    if (role) database.prepare('UPDATE roles SET permissions_json = ?, users_count = MAX(users_count, 1) WHERE id = ?').run(JSON.stringify(['*']), role.id);
    else database.prepare('INSERT OR IGNORE INTO roles (id, name, description, color, permissions_json, users_count) VALUES (?, ?, ?, ?, ?, ?)').run('role-admin', 'Administrateur', 'Accès complet à tous les modules', 'purple', JSON.stringify(['*']), 1);
  });
  migrate();
}

function openDatabase() {
  databasePath = path.join(app.getPath('userData'), 'nova-commerce.sqlite');
  clockIntegrityFilePath = path.join(app.getPath('userData'), 'nova-clock-integrity.json');
  database = new Database(databasePath);
  database.pragma('journal_mode = WAL');
  database.pragma('synchronous = FULL');
  createSchema();
  migrateLegacyState();
  migrateSupplierProductLinks();
  migrateProtectedAdministrator();
  observeSystemClock('startup');
}

function databaseDirectory() {
  return path.dirname(databasePath);
}

async function backupDatabase() {
  if (!database) return;
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Sauvegarder la base de données NOVA',
    defaultPath: path.join(app.getPath('documents'), 'nova-commerce-sauvegarde.sqlite'),
    filters: [{ name: 'Base SQLite', extensions: ['sqlite', 'db'] }]
  });
  if (result.canceled || !result.filePath) return;
  try {
    database.pragma('wal_checkpoint(TRUNCATE)');
    fs.copyFileSync(databasePath, result.filePath);
    await dialog.showMessageBox(mainWindow, { type: 'info', title: 'Sauvegarde terminée', message: 'La base relationnelle SQLite a été sauvegardée.', detail: result.filePath });
  } catch (error) {
    await dialog.showErrorBox('Sauvegarde impossible', error.message || 'La base SQLite n’a pas pu être copiée.');
  }
}

function createApplicationMenu() {
  const submenu = [
    { label: 'Actualiser', role: 'reload' },
    { role: 'togglefullscreen', label: 'Plein écran' }
  ];
  if (process.env.NOVA_DEVTOOLS === '1') submenu.push({ role: 'toggleDevTools', label: 'Outils de développement' });
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Fichier', submenu: [
      { label: 'Sauvegarder la base SQLite…', click: () => backupDatabase() },
      { label: 'Ouvrir le dossier des données', click: () => shell.openPath(databaseDirectory()) },
      { type: 'separator' },
      { role: 'quit', label: 'Quitter NOVA Commerce' }
    ] },
    { label: 'Affichage', submenu },
    { label: 'Aide', submenu: [{ label: 'À propos de NOVA Commerce', click: () => dialog.showMessageBox(mainWindow, { type: 'info', title: 'NOVA Commerce', message: 'NOVA Commerce', detail: 'Gestion commerciale et de stock\nVersion 1.0.0 · Application Desktop\nBase relationnelle SQLite.' }) }] }
  ]));
}

function sessionUser(token) {
  const item = sessions.get(text(token));
  if (!item) return null;
  if (item.expiresAt < Date.now()) { sessions.delete(text(token)); return null; }
  return item.userId;
}

// Session glissante : tant que l'application travaille, la session reste ouverte.
// Sans ce renouvellement, une journée de travail continue (> 8 h) se terminait par
// des écritures refusées alors que l'utilisateur était toujours connecté.
function touchSession(token) {
  const item = sessions.get(text(token));
  if (!item) return false;
  if (item.expiresAt < Date.now()) { sessions.delete(text(token)); return false; }
  item.expiresAt = Date.now() + SESSION_TTL_MS;
  return true;
}

function requireSession(event, token, allowBootstrap = false) {
  if (!isTrustedSender(event)) return false;
  if (sessionUser(token)) { touchSession(token); return true; }
  return allowBootstrap && !hasRelationalState();
}

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical).sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)));
  if (value && typeof value === 'object') return Object.keys(value).sort().reduce((result, key) => { result[key] = canonical(value[key]); return result; }, {});
  return value;
}

function collectionChanged(left, right, key, ignored = []) {
  const strip = (value) => {
    if (!value || typeof value !== 'object') return value;
    if (Array.isArray(value)) return value.map(strip);
    return Object.keys(value).reduce((result, name) => { if (!ignored.includes(name)) result[name] = strip(value[name]); return result; }, {});
  };
  return JSON.stringify(canonical(strip(left?.[key] || []))) !== JSON.stringify(canonical(strip(right?.[key] || [])));
}

function effectivePermissions(userId) {
  const user = database.prepare('SELECT profile FROM users WHERE id = ?').get(userId);
  if (!user) return [];
  const role = database.prepare('SELECT name, permissions_json FROM roles WHERE name = ?').get(user.profile);
  const parsed = json(role?.permissions_json, []);
  return parsed.length ? parsed : (FALLBACK_ROLE_PERMISSIONS[user.profile] || []);
}

function hasPermission(userId, permission) {
  const permissions = effectivePermissions(userId);
  return permissions.includes('*') || permissions.includes(permission);
}

function movementChange(previous, next, key) {
  const before = new Map((previous?.[key] || []).map((item) => [item.id, item]));
  const after = new Map((next?.[key] || []).map((item) => [item.id, item]));
  let needsValidation = false;
  for (const [id, item] of after) {
    const old = before.get(id);
    if (old?.status === 'Validé' && JSON.stringify(canonical(old)) !== JSON.stringify(canonical(item))) return { blocked: true, needsValidation: false };
    if (!old || old.status !== item.status || JSON.stringify(canonical(old)) !== JSON.stringify(canonical(item))) {
      if (item.status === 'Validé') needsValidation = true;
    }
  }
  for (const id of before.keys()) if (!after.has(id)) return { blocked: true, needsValidation: false };
  return { blocked: false, needsValidation };
}

function immutableCollectionChange(previous, next, key, allowDrafts = false) {
  const before = new Map((previous?.[key] || []).map((item) => [item.id, item]));
  const after = new Map((next?.[key] || []).map((item) => [item.id, item]));
  let needsValidation = false;
  for (const [id, item] of after) {
    const old = before.get(id);
    if (allowDrafts && old?.status === INVOICE_DRAFT) {
      if (item.status === 'Validée' && old.status !== 'Validée') needsValidation = true;
      continue;
    }
    if (old?.status === 'Validée' || old?.status === 'Validé') {
      if (JSON.stringify(canonical(old)) !== JSON.stringify(canonical(item))) return { blocked: true, needsValidation: false };
    } else if (!old || JSON.stringify(canonical(old)) !== JSON.stringify(canonical(item))) {
      if (item.status === 'Validée' || item.status === 'Validé') needsValidation = true;
    }
  }
  for (const id of before.keys()) {
    if (after.has(id)) continue;
    if (allowDrafts && before.get(id)?.status === INVOICE_DRAFT) continue;
    return { blocked: true, needsValidation: false };
  }
  return { blocked: false, needsValidation };
}

function consumeLicenseTicket(userId, ticket) {
  const value = licenseTickets.get(text(ticket));
  if (!value || value.userId !== userId || value.expiresAt < Date.now()) return false;
  licenseTickets.delete(text(ticket));
  return true;
}

function isInitialBlankDatabaseState(nextState) {
  if (nextState?.initialSetupCompleted !== true || nextState?.blankDatabase !== true) return false;
  for (const key of ['categories', 'stores', 'suppliers', 'supplierProducts', 'products', 'clients', 'customerPayments', 'supplierPayments', 'refunds', 'sales', 'creditNotes', 'stockEntries', 'stockExits', 'stockTransfers', 'expenses', 'orders', 'quotes', 'inventory', 'inventoryReports', 'deliverers', 'deliveries']) {
    if (safeArray(nextState[key]).length) return false;
  }
  const protectedUser = safeArray(nextState.users).find((user) => text(user.username) === PROTECTED_ADMIN_USERNAME && user.active !== false && text(user.name) === 'Administrateur' && text(user.profile) === 'Administrateur' && text(user.passwordHash) === PROTECTED_ADMIN_PASSWORD_HASH);
  const adminRole = safeArray(nextState.roles).find((role) => text(role.name) === 'Administrateur' && safeArray(role.permissions).includes('*'));
  return safeArray(nextState.users).length === 1 && !!protectedUser && safeArray(nextState.roles).length === 1 && !!adminRole;
}

// Premier démarrage sur une base vide, sans session : la démonstration doit être une base
// initiale complète (administrateur protégé, rôle Administrateur, produits et clients présents).
// Le cas « base neuve » est couvert par isInitialBlankDatabaseState.
function isInitialDemoDatabaseState(nextState) {
  if (nextState?.initialSetupCompleted !== true || nextState?.blankDatabase === true) return false;
  const protectedUser = safeArray(nextState.users).find((user) => text(user.username) === PROTECTED_ADMIN_USERNAME && user.active !== false && text(user.name) === 'Administrateur' && text(user.profile) === 'Administrateur' && text(user.passwordHash) === PROTECTED_ADMIN_PASSWORD_HASH);
  const adminRole = safeArray(nextState.roles).find((role) => text(role.name) === 'Administrateur' && safeArray(role.permissions).includes('*'));
  return !!protectedUser && !!adminRole && safeArray(nextState.products).length > 0 && safeArray(nextState.clients).length > 0;
}

// Écriture d'état sans session : n'est acceptée que pour créer la base initiale d'une base vide.
// Une base déjà remplie ne peut jamais être écrite sans session ouverte.
function evaluateBootstrapWrite(nextState) {
  if (hasRelationalState()) return { allowed: false, reason: 'session' };
  if (isInitialBlankDatabaseState(nextState) || isInitialDemoDatabaseState(nextState)) return { allowed: true, reason: '' };
  return { allowed: false, reason: 'base-absente' };
}

// Évalue une écriture d'état et renvoie la décision AVEC son motif, afin que
// l'interface puisse expliquer un refus autrement que par un message générique.
function evaluateStateWrite(userId, nextState) {
  const clockIntegrity = observeSystemClock('state-write');
  if (clockIntegrity.tampered) return { allowed: false, reason: 'clock' };
  const previous = buildRelationalState();
  if (!previous) {
    const blankAllowed = nextState?.blankDatabase === true && isInitialBlankDatabaseState(nextState);
    return blankAllowed ? { allowed: true, reason: '' } : { allowed: false, reason: 'base-absente' };
  }
  const previousLicense = previous.license || {};
  const nextLicense = nextState?.license || {};
  if (previousLicense.trialStartedAt && nextLicense.trialStartedAt && text(previousLicense.trialStartedAt) !== text(nextLicense.trialStartedAt)) {
    return { allowed: false, reason: 'licence-essai-modifie' };
  }
  if (previousLicense.activated && !nextLicense.activated) return { allowed: false, reason: 'licence-desactivee' };
  if (licenseReadOnly(previousLicense) && !nextLicense.activated) return { allowed: false, reason: 'licence-lecture-seule' };
  if (!previousLicense.activated && nextLicense.activated && !consumeLicenseTicket(userId, nextLicense.activationTicket)) {
    return { allowed: false, reason: 'licence-activation-invalide' };
  }
  const resetDemoRequest = nextState?.__resetDemo === true;
  if (resetDemoRequest) {
    if (!nextLicense.activated) return { allowed: false, reason: 'licence-requise' };
    if (!hasPermission(userId, 'demo.reset')) return { allowed: false, reason: 'droits', permission: 'demo.reset' };
    if (!safeArray(nextState.activities).some((item) => text(item.action) === 'Réinitialisation de la démo')) return { allowed: false, reason: 'audit-manquant' };
    for (const key of ['activated', 'licenseKey', 'licenseKeyDigest', 'activatedAt', 'trialStartedAt']) {
      if (JSON.stringify(previousLicense[key] ?? null) !== JSON.stringify(nextLicense[key] ?? null)) return { allowed: false, reason: 'licence-modifiee' };
    }
    return { allowed: true, reason: '' };
  }
  const freshRequest = nextState?.blankDatabase === true && previous?.blankDatabase !== true;
  if (freshRequest) {
    if (!nextLicense.activated) return { allowed: false, reason: 'licence-requise' };
    if (!hasPermission(userId, 'license.activate')) return { allowed: false, reason: 'droits', permission: 'license.activate' };
    for (const key of ['categories', 'stores', 'suppliers', 'supplierProducts', 'products', 'clients', 'customerPayments', 'supplierPayments', 'refunds', 'sales', 'creditNotes', 'stockEntries', 'stockExits', 'stockTransfers', 'expenses', 'orders', 'quotes', 'inventory', 'inventoryReports', 'deliverers', 'deliveries']) {
      if (safeArray(nextState[key]).length) return { allowed: false, reason: 'base-non-vide' };
    }
    const protectedUser = safeArray(nextState.users).find((user) => text(user.username) === PROTECTED_ADMIN_USERNAME && user.active !== false && text(user.profile) === 'Administrateur' && text(user.passwordHash) === PROTECTED_ADMIN_PASSWORD_HASH);
    const adminRole = safeArray(nextState.roles).find((role) => text(role.name) === 'Administrateur' && safeArray(role.permissions).includes('*'));
    const freshAudit = safeArray(nextState.activities).some((item) => text(item.action) === 'Mise à neuf de la base');
    if (safeArray(nextState.users).length !== 1 || !protectedUser || safeArray(nextState.roles).length !== 1 || !adminRole || !freshAudit) return { allowed: false, reason: 'base-neuve-invalide' };
    for (const key of ['activated', 'licenseKey', 'licenseKeyDigest', 'activatedAt', 'trialStartedAt']) {
      if (JSON.stringify(previousLicense[key] ?? null) !== JSON.stringify(nextLicense[key] ?? null)) return { allowed: false, reason: 'licence-modifiee' };
    }
    return { allowed: true, reason: '' };
  }
  // Codes-barres : format, clé de contrôle et unicité vérifiés ici, avant toute écriture (pas seulement dans l'interface).
  const barcodeRefusal = productBarcodeRefusal(previous.products, nextState?.products);
  if (barcodeRefusal) return { allowed: false, reason: barcodeRefusal.reason, detail: barcodeRefusal.message };
  const checks = [];
  const productMasterChanged = collectionChanged(previous, nextState, 'products', ['stock', 'stockByStore']);
  if (productMasterChanged) checks.push('products.manage');
  const clientMasterChanged = collectionChanged(previous, nextState, 'clients', ['receivable']);
  const clientBalanceChanged = collectionChanged(previous, nextState, 'clients', ['id', 'name', 'phone', 'email', 'address', 'creditLimit', 'active']);
  if (clientMasterChanged) checks.push('clients.manage');
  if (collectionChanged(previous, nextState, 'suppliers')) checks.push('suppliers.manage');
  if (collectionChanged(previous, nextState, 'supplierProducts')) checks.push('suppliers.manage');
  if (collectionChanged(previous, nextState, 'deliverers')) checks.push('deliverers.manage');
  if (collectionChanged(previous, nextState, 'deliveries')) checks.push('sales.validate');
  if (collectionChanged(previous, nextState, 'inventoryReports')) checks.push('inventory.manage');
  if (collectionChanged(previous, nextState, 'categories')) checks.push('catalog.manage');
  if (collectionChanged(previous, nextState, 'stores')) checks.push('stores.manage');
  if (collectionChanged(previous, nextState, 'users')) checks.push('users.manage');
  if (collectionChanged(previous, nextState, 'roles')) checks.push('roles.manage');
  if (collectionChanged(previous, nextState, 'settings', ['theme'])) checks.push('settings.manage');
  if (collectionChanged(previous, nextState, 'license', ['licenseKey', 'licenseKeyDigest', 'activationTicket', 'clockIntegrity'])) checks.push('license.activate');
  if (collectionChanged(previous, nextState, 'expenses')) checks.push('expenses.manage');
  if (collectionChanged(previous, nextState, 'orders')) checks.push('orders.manage');
  if (collectionChanged(previous, nextState, 'quotes')) checks.push('quotes.manage');
  const salesChanged = collectionChanged(previous, nextState, 'sales');
  const salesImmutable = immutableCollectionChange(previous, nextState, 'sales', true);
  if (salesImmutable.blocked) return { allowed: false, reason: 'integrite-vente' };
  const paymentsChanged = collectionChanged(previous, nextState, 'customerPayments');
  // Les règlements de facture (saleId) relèvent de invoices.collect / invoices.payment.cancel, contrôlés par invoiceWriteCheck.
  const standalonePaymentsChanged = collectionChanged({ customerPayments: safeArray(previous.customerPayments).filter((item) => !text(item.saleId)) }, { customerPayments: safeArray(nextState.customerPayments).filter((item) => !text(item.saleId)) }, 'customerPayments');
  if (standalonePaymentsChanged) checks.push('credit.record');
  if (collectionChanged(previous, nextState, 'supplierPayments')) checks.push('credit.record');
  const creditNotesChanged = collectionChanged(previous, nextState, 'creditNotes');
  const creditNoteChange = immutableCollectionChange(previous, nextState, 'creditNotes');
  if (creditNoteChange.blocked) return { allowed: false, reason: 'integrite-avoir' };
  if (creditNotesChanged) checks.push('sales.reverse');
  const refundsChanged = collectionChanged(previous, nextState, 'refunds');
  if (refundsChanged) checks.push('sales.reverse');
  if (creditNoteChange.needsValidation) checks.push('sales.validate');
  const entryChange = movementChange(previous, nextState, 'stockEntries');
  const exitChange = movementChange(previous, nextState, 'stockExits');
  if (entryChange.blocked || exitChange.blocked) return { allowed: false, reason: 'integrite-mouvement-stock' };
  const entriesChanged = collectionChanged(previous, nextState, 'stockEntries');
  const exitsChanged = collectionChanged(previous, nextState, 'stockExits');
  const transfersChanged = collectionChanged(previous, nextState, 'stockTransfers');
  const transferChange = immutableCollectionChange(previous, nextState, 'stockTransfers');
  if (transferChange.blocked) return { allowed: false, reason: 'integrite-transfert' };
  if (transfersChanged) checks.push('stock.transfer');
  if (transferChange.needsValidation) checks.push('stock.validate');
  const stockChanged = collectionChanged(previous, nextState, 'products', ['id', 'code', 'name', 'categoryId', 'brand', 'model', 'supplierId', 'storeId', 'purchasePrice', 'salePrice', 'wholesalePrice', 'minStock', 'maxStock', 'presentation', 'batch', 'expiry', 'image', 'active']);
  if (clientBalanceChanged && !salesChanged && !paymentsChanged && !creditNotesChanged) return { allowed: false, reason: 'encours-client-modifie' };
  if (entryChange.needsValidation || exitChange.needsValidation) checks.push('stock.validate');
  else if (entriesChanged || exitsChanged) checks.push('stock.create');
  if (stockChanged && !productMasterChanged && !salesChanged && !entriesChanged && !exitsChanged && !transfersChanged && !creditNotesChanged) checks.push('inventory.manage');
  // Factures et règlements : contrôle de contenu puis droits déduits des changements (sales.validate pour les ventes directes).
  const invoiceCheck = invoiceWriteCheck(previous, nextState, { stockFor: (product, storeId) => number(stockBalances(product)[storeId]) });
  if (invoiceCheck.refusal) return { allowed: false, reason: invoiceCheck.refusal.reason, detail: invoiceCheck.refusal.detail };
  invoiceCheck.permissions.forEach((permission) => checks.push(permission));
  const missing = checks.find((permission) => !hasPermission(userId, permission));
  if (missing) return { allowed: false, reason: 'droits', permission: missing };
  const volumeIssue = validateWriteVolumes(nextState);
  if (volumeIssue) return { allowed: false, reason: 'volume', detail: volumeIssue };
  return { allowed: true, reason: '' };
}

// Garde-fous de volume : une écriture ne doit jamais tronquer silencieusement une table.
function validateWriteVolumes(nextState) {
  const previous = buildRelationalState();
  if (!previous) return '';
  for (const key of ['sales', 'orders', 'clients', 'activities']) {
    const before = safeArray(previous[key]).length;
    const after = safeArray(nextState[key]).length;
    if (before > 0 && after < before * 0.5) return key + ': ' + before + ' → ' + after;
  }
  return '';
}

function stateWriteAuthorized(userId, nextState) {
  return evaluateStateWrite(userId, nextState).allowed;
}

function verifyPassword(password, storedHash) {
  const hash = text(storedHash);
  const parts = hash.match(/^pbkdf2-sha256\$([^$]+)\$(\d+)\$([a-f0-9]{64})$/i);
  if (parts) {
    const derived = crypto.pbkdf2Sync(text(password), parts[1], Number(parts[2]), 32, 'sha256').toString('hex');
    return crypto.timingSafeEqual(Buffer.from(derived, 'utf8'), Buffer.from(parts[3].toLowerCase(), 'utf8'));
  }
  if (/^[a-f0-9]{64}$/i.test(hash)) {
    const derived = crypto.createHash('sha256').update(text(password)).digest('hex');
    return crypto.timingSafeEqual(Buffer.from(derived, 'utf8'), Buffer.from(hash.toLowerCase(), 'utf8'));
  }
  return false;
}

ipcMain.handle('nova-authenticate', (event, payload) => {
  if (!isTrustedSender(event)) return { ok: false, reason: 'sender' };
  const clockIntegrity = observeSystemClock('authentication');
  const username = text(payload?.username).trim().toLowerCase();
  const attempt = authAttempts.get(username) || { count: 0, lockedUntil: 0 };
  if (Date.now() < attempt.lockedUntil) return { ok: false, reason: 'locked', clockIntegrity };
  const password = text(payload?.password);
  const row = database?.prepare('SELECT * FROM users WHERE lower(username) = ? AND active = 1').get(username);
  if (!row || !verifyPassword(password, row.password_hash)) {
    attempt.count += 1;
    if (attempt.count >= AUTH_MAX_ATTEMPTS) { attempt.lockedUntil = Date.now() + AUTH_LOCK_MS; attempt.count = 0; }
    authAttempts.set(username, attempt);
    return { ok: false };
  }
  authAttempts.delete(username);
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { userId: row.id, expiresAt: Date.now() + SESSION_TTL_MS });
  return { ok: true, sessionToken: token, clockIntegrity, user: { id: row.id, name: row.name, username: row.username, profile: row.profile, active: !!row.active } };
});

ipcMain.handle('nova-license-activate', async (event, payload) => {
  if (!isTrustedSender(event)) return { ok: false, reason: 'sender' };
  const clockIntegrity = observeSystemClock('license-activation');
  if (clockIntegrity.tampered) return { ok: false, reason: 'clock-tamper', clockIntegrity };
  const token = text(payload?.sessionToken);
  const userId = sessionUser(token);
  if (!userId || !hasPermission(userId, 'license.activate')) return { ok: false, reason: 'permission' };
  const key = text(payload?.key);
  const businessName = text(payload?.businessName);
  const deviceUuid = text(payload?.deviceUuid) || getMachineUuid();
  if (!key || !businessName || !deviceUuid) return { ok: false, reason: 'missing' };
  if (!await verifyLicenceKey(key, businessName, deviceUuid)) return { ok: false, reason: 'invalid' };
  const activationTicket = crypto.randomBytes(32).toString('hex');
  licenseTickets.set(activationTicket, { userId, expiresAt: Date.now() + 60_000 });
  return { ok: true, activationTicket };
});

ipcMain.handle('nova-device-uuid', (event) => {
  if (!isTrustedSender(event)) return '';
  return getMachineUuid();
});

ipcMain.handle('nova-logout', (event, token) => {
  if (!isTrustedSender(event)) return false;
  sessions.delete(text(token));
  return true;
});

ipcMain.handle('nova-session', (event, token) => {
  if (!isTrustedSender(event)) return { ok: false, reason: 'origine', clockIntegrity: null };
  const clockIntegrity = observeSystemClock('session');
  const valid = !!sessionUser(token);
  if (valid) touchSession(token);
  return { ok: valid, reason: valid ? '' : 'session', clockIntegrity };
});

ipcMain.handle('nova-clock-status', (event) => isTrustedSender(event) ? observeSystemClock('clock-status') : null);

ipcMain.on('nova-storage-get', (event, key) => {
  try {
    if (!isTrustedSender(event)) { event.returnValue = null; return; }
    observeSystemClock('state-read');
    const normalizedKey = text(key);
    if (normalizedKey === STATE_KEY) {
      const relational = buildRelationalState();
      if (relational) { event.returnValue = JSON.stringify(relational); return; }
    }
    const row = database?.prepare('SELECT value FROM app_storage WHERE key = ?').get(normalizedKey);
    event.returnValue = row?.value ?? null;
  } catch (_) {
    event.returnValue = null;
  }
});

ipcMain.on('nova-storage-set', (event, payload) => {
  try {
    const key = text(payload?.key);
    const value = text(payload?.value);
    const token = text(payload?.sessionToken);
    const clockIntegrity = observeSystemClock('state-write');
    if (clockIntegrity.tampered) { event.returnValue = { ok: false, reason: 'horloge' }; return; }
    if (!key) { event.returnValue = { ok: false, reason: 'cle-absente' }; return; }
    if (!requireSession(event, token, key === STATE_KEY)) { event.returnValue = { ok: false, reason: 'session' }; return; }
    if (key === STATE_KEY) {
      const parsed = JSON.parse(value);
      const userId = sessionUser(token);
      // Sans session, seul le premier démarrage (base vide) peut écrire une base initiale reconnue.
      const decision = userId ? evaluateStateWrite(userId, parsed) : evaluateBootstrapWrite(parsed);
      if (!decision.allowed) {
        console.info('NOVA: écriture refusée (' + decision.reason + (decision.permission ? ' · ' + decision.permission : '') + ')');
        event.returnValue = { ok: false, reason: decision.reason, permission: decision.permission || '', detail: decision.detail || '' };
        return;
      }
      replaceRelationalState(parsed);
      database.prepare('DELETE FROM app_storage WHERE key = ?').run(STATE_KEY);
    } else {
      database.prepare(`
        INSERT INTO app_storage (key, value, updated_at) VALUES (?, ?, datetime('now'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(key, value);
    }
    event.returnValue = { ok: true, reason: '' };
  } catch (error) {
    console.error('NOVA: échec d’écriture du stockage', error);
    event.returnValue = { ok: false, reason: 'erreur' };
  }
});

ipcMain.on('nova-storage-remove', (event, payload) => {
  try {
    const key = text(payload?.key);
    if (observeSystemClock('storage-remove').tampered) { event.returnValue = false; return; }
    if (!requireSession(event, text(payload?.sessionToken))) { event.returnValue = false; return; }
    if (key === STATE_KEY) { event.returnValue = false; return; }
    database?.prepare('DELETE FROM app_storage WHERE key = ?').run(key);
    event.returnValue = true;
  } catch (_) {
    event.returnValue = false;
  }
});

ipcMain.on('nova-storage-clear', (event, token) => {
  try {
    if (observeSystemClock('storage-clear').tampered) { event.returnValue = false; return; }
    if (!requireSession(event, text(token))) { event.returnValue = false; return; }
    database?.prepare('DELETE FROM app_storage').run();
    event.returnValue = true;
  } catch (_) {
    event.returnValue = false;
  }
});

ipcMain.handle('nova-database-info', (event) => {
  if (!isTrustedSender(event)) return null;
  return { engine: 'SQLite relationnel', schemaVersion: 11, clockIntegrity: observeSystemClock('database-info'), path: databasePath, fileName: path.basename(databasePath), tables: ['users', 'roles', 'products', 'product_stock', 'suppliers', 'supplier_products', 'supplier_payments', 'inventory', 'inventory_reports', 'inventory_report_lines', 'sales', 'sale_lines', 'credit_notes', 'credit_note_lines', 'stock_movements', 'stock_movement_lines', 'stock_transfers', 'stock_transfer_lines', 'customer_payments', 'activities'] };
});
ipcMain.handle('nova-backup-database', (event) => isTrustedSender(event) ? backupDatabase() : false);

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 940,
    minWidth: 1120,
    minHeight: 720,
    show: false,
    backgroundColor: '#0d1726',
    icon: path.join(__dirname, '..', 'assets', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false
    }
  });
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.loadFile(path.join(__dirname, '..', 'index.html'));
  if (process.env.NOVA_DEVTOOLS === '1') mainWindow.webContents.openDevTools();
}

app.whenReady().then(() => {
  openDatabase();
  createApplicationMenu();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  try { database?.close(); } catch (_) {}
});
