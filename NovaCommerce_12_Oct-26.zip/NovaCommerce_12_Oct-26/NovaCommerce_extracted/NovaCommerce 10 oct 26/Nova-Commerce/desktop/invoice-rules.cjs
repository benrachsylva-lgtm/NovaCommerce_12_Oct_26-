'use strict';
// Règles de facturation et d'encaissement côté persistance (module pur, sans Electron).
// - Une facture est une vente (sales) avec kind = 'invoice' : brouillon (status 'Brouillon') puis validée (status 'Validée').
// - Un règlement de facture est un paiement client (customer_payments) rattaché à la facture par saleId.
// - L'imputation des paiements suit le même principe que app.js (creditCollectionAllocation) : les paiements ciblés
//   soldent d'abord leur facture, le reste suit le FIFO existant. Sans paiement ciblé, le résultat est identique à l'existant.
// Scripts/test-invoices.cjs vérifie la parité avec app.js.

const INVOICE_KIND = 'invoice';
const DRAFT = 'Brouillon';
const VALID = 'Validée';
const CANCELLED = 'Annulé';
const TOLERANCE = 0.5;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

const num = (value) => Number(value) || 0;
const text = (value) => String(value ?? '').trim();
const round2 = (value) => Math.round(num(value) * 100) / 100;

function saleTotal(sale) {
  return num(sale?.total) || (sale?.items || []).reduce((sum, item) => sum + num(item.quantity) * num(item.unitPrice), 0);
}

function noteTotal(note) {
  return num(note?.total) || (note?.lines || []).reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0);
}

function isInvoice(sale) {
  return sale?.kind === INVOICE_KIND;
}

// Montants des avoirs validés rattachés à une vente à crédit (déduits de l'encours).
function creditAdjustments(state) {
  const sales = new Map((state.sales || []).map((sale) => [sale.id, sale]));
  const adjustments = {};
  (state.creditNotes || []).filter((note) => note.status === VALID && note.originalSaleId).forEach((note) => {
    const sale = sales.get(note.originalSaleId);
    const credit = sale ? sale.payment === 'credit' : note.payment === 'credit';
    if (!credit) return;
    adjustments[note.originalSaleId] = (adjustments[note.originalSaleId] || 0) + noteTotal(note);
  });
  return adjustments;
}

// Imputation des règlements : { ratios, paid, net } indexés par id de vente à crédit validée.
function collectionAllocation(state) {
  const ratios = {};
  const paid = {};
  const net = {};
  const adjustments = creditAdjustments(state);
  const payments = (state.customerPayments || []).filter((payment) => payment.status === 'Validé');
  const targeted = {};
  payments.filter((payment) => text(payment.saleId)).forEach((payment) => {
    targeted[payment.saleId] = (targeted[payment.saleId] || 0) + num(payment.amount);
  });
  (state.clients || []).forEach((client) => {
    const pool = payments.filter((payment) => !text(payment.saleId) && payment.clientId === client.id).reduce((sum, payment) => sum + num(payment.amount), 0);
    let remaining = pool - num(client.openingReceivable);
    const creditSales = (state.sales || [])
      .filter((sale) => sale.status === VALID && sale.payment === 'credit' && sale.clientId === client.id)
      .sort((a, b) => String(a.date).localeCompare(String(b.date)) || String(a.number || '').localeCompare(String(b.number || '')));
    creditSales.forEach((sale) => {
      const amount = saleTotal(sale) - (adjustments[sale.id] || 0);
      net[sale.id] = amount;
      if (amount <= 0) { ratios[sale.id] = 0; paid[sale.id] = 0; return; }
      const fromTarget = Math.min(amount, targeted[sale.id] || 0);
      const take = remaining > 0 ? Math.min(amount - fromTarget, remaining) : 0;
      remaining -= take;
      paid[sale.id] = fromTarget + take;
      ratios[sale.id] = Math.min(1, paid[sale.id] / amount);
    });
  });
  return { ratios, paid, net };
}

// Situation d'une facture validée : total net, payé, solde et statut de paiement.
function invoiceSettlement(state, sale, allocation = collectionAllocation(state)) {
  const credited = creditAdjustments(state)[sale.id] || 0;
  const net = round2(saleTotal(sale) - credited);
  const paid = round2(Math.min(Math.max(net, 0), allocation.paid[sale.id] || 0));
  const balance = round2(Math.max(0, net - paid));
  let status = 'Payée intégralement';
  if (net <= 0 && credited > 0) status = 'Annulée';
  else if (paid <= 0) status = 'Non payée';
  else if (balance > 0) status = 'Partiellement payée';
  return { total: round2(saleTotal(sale)), credited: round2(credited), net, paid, balance, status };
}

function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
  return JSON.stringify(value ?? null);
}

function indexById(list) {
  return new Map((Array.isArray(list) ? list : []).map((item) => [String(item?.id ?? ''), item]));
}

// Contrôle complet d'une écriture concernant factures et règlements.
// Retourne { refusal: null | { reason, detail }, permissions: [...] }.
function invoiceWriteCheck(previous, next, options = {}) {
  const permissions = new Set();
  const refuse = (reason, detail = '') => ({ refusal: { reason, detail }, permissions: [...permissions] });
  const stockFor = options.stockFor || (() => Infinity);
  const prevSales = indexById(previous.sales);
  const nextSales = indexById(next.sales);
  const prevClients = indexById(previous.clients);
  const nextClients = indexById(next.clients);
  const allNumbers = new Map();
  nextSales.forEach((sale) => { if (text(sale.number)) allNumbers.set(text(sale.number), (allNumbers.get(text(sale.number)) || 0) + 1); });

  // ----- Ventes et factures -----
  for (const [id, old] of prevSales) {
    if (nextSales.has(id)) continue;
    if (isInvoice(old) && old.status === DRAFT) { permissions.add('invoices.create'); continue; }
    return refuse('integrite-vente', 'Une vente validée ne peut pas être supprimée.');
  }
  for (const [id, sale] of nextSales) {
    const old = prevSales.get(id);
    if (old && stableStringify(old) === stableStringify(sale)) continue;
    if (!isInvoice(sale)) { permissions.add('sales.validate'); continue; }
    if (sale.status === DRAFT) { permissions.add('invoices.create'); continue; }
    if (sale.status !== VALID) return refuse('facture-statut', `Statut de facture inconnu : ${text(sale.status)}.`);
    if (old && old.status === VALID) continue; // déjà validée : l'immuabilité est contrôlée ailleurs
    permissions.add('invoices.validate');
    if (!text(sale.number)) return refuse('facture-numero', 'Une facture validée doit avoir un numéro.');
    if ((allNumbers.get(text(sale.number)) || 0) > 1) return refuse('facture-numero', `Le numéro ${text(sale.number)} est déjà utilisé.`);
    if (sale.payment !== 'credit') return refuse('facture-paiement', 'Une facture est réglée par un encaissement séparé : son mode doit être « à crédit ».');
    if (!text(sale.clientId) || sale.clientId === 'counter' || !nextClients.has(sale.clientId)) return refuse('facture-client', 'Une facture doit être rattachée à un client enregistré.');
    const items = Array.isArray(sale.items) ? sale.items : [];
    if (!items.length) return refuse('facture-lignes', 'Une facture doit comporter au moins un article.');
    if (items.some((item) => !(num(item.quantity) > 0) || !(num(item.unitPrice) >= 0))) return refuse('facture-lignes', 'Quantité ou prix de ligne invalide.');
    const computed = items.reduce((sum, item) => sum + num(item.quantity) * num(item.unitPrice), 0);
    if (Math.abs(computed - num(sale.total)) > TOLERANCE) return refuse('facture-montant', `Montant recalculé ${computed} différent du montant enregistré ${num(sale.total)}.`);
    if (sale.dueDate && !DATE_RE.test(text(sale.dueDate))) return refuse('facture-echeance', 'Date d’échéance invalide.');
    const client = prevClients.get(sale.clientId) || nextClients.get(sale.clientId);
    const limit = num(client.creditLimit);
    if (limit > 0 && (num(client.receivable) - num(client.advance)) + computed > limit) {
      return refuse('limite-credit', `${client.name || 'Ce client'} ne peut pas dépasser ${limit} d’encours net (avance déduite).`);
    }
    // Disponibilité du stock au moment de la validation (état précédent : avant la sortie).
    if (!next.settings?.allowNegative) {
      const requested = new Map();
      items.forEach((item) => { const key = `${item.productId}|${item.storeId || sale.storeId}`; requested.set(key, (requested.get(key) || 0) + num(item.quantity)); });
      const products = indexById(previous.products);
      for (const [key, quantity] of requested) {
        const [productId, storeId] = key.split('|');
        const product = products.get(productId);
        if (!product) return refuse('facture-article', `Article introuvable : ${productId}.`);
        if (quantity > stockFor(product, storeId)) return refuse('stock-insuffisant', `Stock insuffisant pour ${product.name || productId} : ${stockFor(product, storeId)} disponible(s).`);
      }
    }
  }

  // ----- Règlements -----
  const prevPayments = indexById(previous.customerPayments);
  const nextPayments = indexById(next.customerPayments);
  const SYSTEM_FIELDS = ['status', 'cancelReason', 'cancelledBy', 'cancelledAt'];
  const withoutFields = (item, fields) => Object.fromEntries(Object.entries(item).filter(([key]) => !fields.includes(key)));
  for (const [id, old] of prevPayments) {
    const current = nextPayments.get(id);
    if (!current) return refuse('integrite-paiement', 'Un règlement enregistré ne peut pas être supprimé : annulez-le avec son motif.');
    if (old.status === 'Validé') {
      if (stableStringify(withoutFields(old, SYSTEM_FIELDS)) !== stableStringify(withoutFields(current, SYSTEM_FIELDS))) {
        return refuse('integrite-paiement', 'Un règlement validé ne peut pas être modifié.');
      }
      if (current.status !== old.status) {
        if (current.status !== CANCELLED) return refuse('integrite-paiement', 'Statut de règlement non autorisé.');
        if (!text(current.cancelReason)) return refuse('motif-annulation', 'L’annulation d’un règlement exige un motif.');
        if (text(old.saleId)) permissions.add('invoices.payment.cancel');
      }
    } else if (stableStringify(old) !== stableStringify(current)) {
      return refuse('integrite-paiement', 'Un règlement annulé ne peut pas être modifié.');
    }
  }
  const requestIds = new Set();
  for (const payment of nextPayments.values()) {
    const key = text(payment.requestId);
    if (!key) continue;
    if (requestIds.has(key)) return refuse('paiement-doublon', 'Ce règlement a déjà été enregistré (double saisie détectée).');
    requestIds.add(key);
  }
  const pendingBySale = new Map();
  for (const [id, payment] of nextPayments) {
    if (prevPayments.has(id)) continue;
    if (payment.status !== 'Validé') return refuse('integrite-paiement', 'Un nouveau règlement doit être validé.');
    const amount = num(payment.amount);
    if (!(amount > 0)) return refuse('montant-invalide', 'Le montant du règlement doit être supérieur à 0.');
    if (!text(payment.saleId)) continue;
    permissions.add('invoices.collect');
    const sale = prevSales.get(payment.saleId);
    if (!sale || !isInvoice(sale)) return refuse('facture-introuvable', 'Le règlement doit viser une facture existante.');
    if (sale.status !== VALID) return refuse('facture-non-validee', 'Seule une facture validée peut être encaissée.');
    if (payment.clientId !== sale.clientId) return refuse('facture-client', 'Le règlement ne correspond pas au client de la facture.');
    pendingBySale.set(sale.id, (pendingBySale.get(sale.id) || 0) + amount);
  }
  if (pendingBySale.size) {
    const allocation = collectionAllocation(previous);
    for (const [saleId, pending] of pendingBySale) {
      const sale = prevSales.get(saleId);
      const settlement = invoiceSettlement(previous, sale, allocation);
      if (settlement.balance <= 0) return refuse('facture-soldee', `La facture ${sale.number} n’a plus de solde à régler.`);
      if (pending > settlement.balance + TOLERANCE) {
        return refuse('trop-percu', `Montant supérieur au solde de ${sale.number} (${settlement.balance} restant).`);
      }
    }
  }
  return { refusal: null, permissions: [...permissions] };
}

module.exports = { INVOICE_KIND, DRAFT, VALID, CANCELLED, saleTotal, creditAdjustments, collectionAllocation, invoiceSettlement, invoiceWriteCheck, stableStringify };
