# 🔐 Clé de signature NOVA Commerce — À CONSERVER PRÉCIEUSEMENT

Ce dossier contient la **clé privée de signature** de l'application Android
NOVA Commerce (`bf.iafad.nova`). Elle a été créée le **26/09/2026** et sert à
signer toutes les versions publiées.

---

## 1. Contenu du dossier

| Fichier | Rôle |
|---|---|
| `nova-commerce-release.p12` | **la clé** (format PKCS#12) — à sauvegarder |
| `compiler-release-signee.sh` | compile un APK release signé et vérifie la signature |
| `LISEZ-MOI-SIGNATURE.md` | ce document |

## 2. Informations de signature

```text
Fichier de clé (keystore) : nova-commerce-release.p12
Type                      : PKCS#12
Alias                     : nova-commerce
Mot de passe (magasin et clé, identiques) : bg9hL9GXmEufmMRjFJsKUWxy
Algorithme                : RSA 4096 bits · SHA384withRSA
Valide jusqu'au           : 20 septembre 2051
Titulaire                 : CN=NOVA Commerce, O=IAFAD, L=Ouagadougou, C=BF
Empreinte SHA-256 cert.   : 35:6F:FD:1C:2A:4F:A8:CE:D4:D2:4B:CC:D5:A0:96:72:62:28:AA:55:79:B8:9E:A5:8C:A3:7C:C3:23:6A:9E:37
Empreinte SHA-1 cert.     : 64:2D:76:96:87:7E:D7:DA:D5:E7:84:9C:9A:88:83:7D:DD:C0:18:2A
```

> En PKCS#12, le mot de passe du magasin et celui de la clé sont identiques
> (c'est une contrainte du format, pas un choix).

---

## 3. ⚠️ Règles à ne jamais oublier

1. **Ne perdez pas cette clé.** Sans elle, il est **impossible** de publier une
   mise à jour qui s'installe par-dessus une version déjà installée : Android
   refuse tout APK signé avec une autre clé. La seule issue serait de
   désinstaller/réinstaller l'application (perte des données locales de
   l'utilisateur).
2. **Ne la diffusez jamais** : pas d'e-mail, pas de dépôt Git, pas de cloud
   public. Conservez **2 sauvegardes** sur des supports distincts (par ex. une
   clé USB au bureau + une copie dans un coffre).
3. **Ne changez pas le mot de passe** sans renoter l'information ici : les
   futures compilations en ont besoin.
4. L'empreinte SHA-256 du certificat est **publique** (elle peut être partagée) ;
   elle sert à vérifier qu'un APK a bien été signé par vous.

---

## 4. Compiler une nouvelle version signée

```bash
bash compiler-release-signee.sh          # demande le mot de passe
# → produit Nova-Commerce/NOVA-Commerce-release.apk (signé + vérifié)
```

Équivalent manuel (PowerShell sous Windows, ou n'importe quel terminal) :

```bash
# 1) indiquer la clé et le canal de production
NOVA_BUILD_CHANNEL=production
NOVA_ANDROID_KEYSTORE_PATH=C:\secrets\nova-commerce-release.p12
NOVA_ANDROID_KEYSTORE_PASSWORD=bg9hL9GXmEufmMRjFJsKUWxy
NOVA_ANDROID_KEY_ALIAS=nova-commerce
NOVA_ANDROID_KEY_PASSWORD=bg9hL9GXmEufmMRjFJsKUWxy

# 2) compiler puis vérifier
npm run mobile:apk:release
node scripts/verify-apk.mjs NOVA-Commerce-release.apk --cert-sha256 35:6F:FD:1C:2A:4F:A8:CE:D4:D2:4B:CC:D5:A0:96:72:62:28:AA:55:79:B8:9E:A5:8C:A3:7C:C3:23:6A:9E:37
```

Le script `scripts/build-apk.mjs` **refuse** de produire un build `production`
sans ces quatre variables, et le contrôle final affiche l'empreinte du
certificat : elle doit toujours correspondre à celle ci-dessus.

---

## 5. Vérifier un APK reçu (sans le compiler)

```bash
# empreinte du certificat signataire
apksigner verify --print-certs NOVA-Commerce-release.apk

# ou avec le contrôle complet du dépôt (conformité + certificat attendu)
cd Nova-Commerce
node scripts/verify-apk.mjs NOVA-Commerce-release.apk --cert-sha256 35:6F:FD:1C:2A:4F:A8:CE:D4:D2:4B:CC:D5:A0:96:72:62:28:AA:55:79:B8:9E:A5:8C:A3:7C:C3:23:6A:9E:37
```

---

## 6. Changer la date d'expiration ou le mot de passe (si besoin)

```bash
export PATH=/chemin/vers/jdk17/bin:$PATH   # keytool fourni avec le JDK

# changer le mot de passe (JKS et PKCS#12) :
keytool -storepasswd -keystore nova-commerce-release.p12

# prolonger la validité (re-écrit le certificat auto-signé) :
keytool -selfcert -alias nova-commerce -keystore nova-commerce-release.p12 -validity 18250
```

Toute modification de la clé change… rien tant que **le même couple
clé/certificat** reste utilisé : c'est la clé privée, et non sa date, qui doit
rester identique.

---

## 7. Version déjà publiée avec cette clé

| Version | Fichier | SHA-256 de l'APK |
|---|---|---|
| 1.1 (versionCode 3) — 26/09/2026 | `NOVA-Commerce-release.apk` | `70d12869f3da006ff03dda4c702c89780345f18c94cc1b9bf3b1d990ef2a7d36` |

Application `bf.iafad.nova`, minSdk 22 (Android 5.0+), targetSdk 34, icône
« Rayira ». Détail : `../RELEASE-SIGNEE-26-09-2026.md`.
