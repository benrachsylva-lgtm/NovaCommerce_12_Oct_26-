/* Repro fidèle : exécute app.js dans jsdom avec un quota localStorage de type Android WebView. */
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM, VirtualConsole } = require('jsdom');

const APP = '/home/user/Nova-Commerce';
const html = fs.readFileSync(path.join(APP, 'index.html'), 'utf8');
const script = fs.readFileSync('/home/user/test-harness/app-instrumented.js', 'utf8');

// Quota paramétrable : Chromium/Android WebView comptabilise 2 octets par caractère UTF-16.
const LIMIT_BYTES = Number(process.env.NOVA_QUOTA_BYTES || 5 * 1024 * 1024);
const log = [];
const vc = new VirtualConsole();
vc.on('error', (...a) => log.push(['console.error', a.map(String).join(' ')]));
vc.on('jsdomError', (e) => log.push(['jsdomError', e.message]));

const dom = new JSDOM(html, { url: 'https://localhost/', runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole: vc });
const { window } = dom;

// --- localStorage instrumenté avec quota réel + comptabilité fidèle (UTF-16) ---
const store = new Map();
let usedBytes = 0;
const bytesOf = (k, v) => (String(k).length + String(v).length) * 2;
const storage = {
  getItem: (k) => (store.has(String(k)) ? store.get(String(k)) : null),
  setItem: (k, v) => {
    const key = String(k); v = String(v);
    const before = store.has(key) ? bytesOf(key, store.get(key)) : 0;
    const after = bytesOf(key, v);
    if (usedBytes - before + after > LIMIT_BYTES) {
      const err = new window.DOMException(
        `Failed to execute 'setItem' on 'Storage': Setting the value of '${key}' exceeded the quota.`, 'QuotaExceededError');
      const e = new Error('QuotaExceededError'); e.name = 'QuotaExceededError';
      log.push(['QUOTA', `setItem('${key}') refusé : ${after.toLocaleString('fr')} octets pour cette clé, ${(usedBytes - before + after).toLocaleString('fr')} / ${LIMIT_BYTES.toLocaleString('fr')} octets utilisés`]);
      throw e;
    }
    store.set(key, v); usedBytes += after - before;
  },
  removeItem: (k) => { const key = String(k); if (store.has(key)) { usedBytes -= bytesOf(key, store.get(key)); store.delete(key); } },
  clear: () => { store.clear(); usedBytes = 0; },
  key: (i) => [...store.keys()][i] ?? null,
  get length() { return store.size; }
};
Object.defineProperty(window, 'localStorage', { value: storage, configurable: true });

// Environnement navigateur : ce que jsdom n'implémente pas.
window.confirm = () => true;
window.alert = () => {};
window.print = () => log.push(['window.print', 'appelé (ouverture de l’impression)']);
window.matchMedia = window.matchMedia || (() => ({ matches: false, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} }));
window.URL.createObjectURL = (blob) => { log.push(['createObjectURL', `type=${blob.type} taille≈${blob.size} octets`]); return 'blob:https://localhost/' + Math.random().toString(16).slice(2); };
window.URL.revokeObjectURL = () => {};
if (!window.crypto || !window.crypto.subtle) Object.defineProperty(window, 'crypto', { value: require('node:crypto').webcrypto, configurable: true });

// URL.createObjectURL / revokeObjectURL utilisés via URL (global du window)
window.eval(script);

const nova = window.__novaDebug;
const toastSeen = [];
window.eval(`(() => { const orig = window.__novaDebug; })()`);

console.log('=== 1. ÉTAT INITIAL (seed de démonstration) ===');
const size = nova.saveSize();
console.log('Taille du JSON d’état :', size.toLocaleString('fr'), 'caractères →', (size * 2 / 1048576).toFixed(2), 'Mo (comptabilité UTF-16)');
console.log('Quota simulé :', (LIMIT_BYTES / 1048576).toFixed(0), 'Mo');
console.log('Occupation après écriture initiale :', (usedBytes / 1048576).toFixed(2), 'Mo =', ((usedBytes / LIMIT_BYTES) * 100).toFixed(1), '% du quota');

console.log('\n=== 2. SIMULATION DU COMPTE ADMINISTRATEUR (tous droits) ===');
const admin = nova.state.users.find((u) => u.profile === 'Administrateur') || nova.state.users[0];
nova.user = admin;
console.log('Utilisateur :', admin?.name, '/ profil :', admin?.profile);
const role = nova.state.roles.find((r) => r.name === admin?.profile);
console.log('Permissions orders.manage :', role?.permissions?.includes('orders.manage') ?? '(profil intégral)', '· total permissions :', role?.permissions?.length ?? 'toutes');

console.log('\n=== 3. MODULE COMMANDES → ANALYSE EXPRESS ===');
const lines = nova.compute();
console.log('Propositions de réassort :', lines.length, 'produit(s), dont', lines.filter((l) => l.supplierId).length, 'avec fournisseur');
nova.draft = { analysisDays: 30, coverageDays: 21, storeId: '', generatedAt: new Date().toISOString(), lines };
const before = nova.saveSize();

console.log('\n=== 4. GÉNÉRATION DES BONS DE COMMANDE (statut Brouillon) ===');
let ok = null, err = null;
try { nova.generate(); ok = true; } catch (e) { err = e; }
console.log('Appel generateExpressOrders() →', err ? 'EXCEPTION: ' + err.message : 'exécuté');
console.log('Commandes créées :', nova.state.orders.filter((o) => o.express).length, 'express ·', nova.state.orders.length, 'au total');
console.log('Taille après génération :', nova.saveSize().toLocaleString('fr'), 'caractères (+' + (nova.saveSize() - before) + ')');
console.log('Occupation stockage :', (usedBytes / 1048576).toFixed(2), 'Mo =', ((usedBytes / LIMIT_BYTES) * 100).toFixed(1), '% du quota');

console.log('\n=== 5. TEST DIRECT DE saveState() (l’appel qui échoue chez l’utilisateur) ===');
const saved = nova.save();
console.log('saveState() a retourné :', saved, saved ? '→ écriture réussie' : '→ ÉCHEC (le message d’erreur s’affiche)');

console.log('\n=== JOURNAL TECHNIQUE ===');
log.filter(([k]) => k !== 'createObjectURL').forEach(([k, m]) => console.log('  [' + k + ']', m));

// Fermeture propre : l'app installe des timers (checkpoint d'horloge, animation).
try { dom.window.close(); } catch (_) {}
process.exit(0);
