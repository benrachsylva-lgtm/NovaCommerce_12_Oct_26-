const puppeteer = require('puppeteer');
(async () => {
  const b = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const p = await b.newPage();
  await p.goto('http://127.0.0.1:4173/__qa-probe.html', { waitUntil: 'domcontentloaded' });
  const r = await p.evaluate(() => {
    const out = {};
    // Plafond d'UNE SEULE clé (c'est notre cas : tout l'état dans une clé 'nova-commerce-state-v1')
    let lo = 0, hi = 20000000;
    while (lo < hi) { const mid = Math.floor((lo + hi + 1) / 2); try { localStorage.setItem('x', 'a'.repeat(mid)); lo = mid; } catch (e) { hi = mid - 1; } }
    out.singleKeyChars = lo;
    // Plafond total multi-clés
    localStorage.clear();
    let total = 0;
    try { const chunk = 'a'.repeat(50000); for (let i = 0; i < 400; i++) { localStorage.setItem('k' + i, chunk); total += chunk.length; } } catch (e) {}
    out.totalChars = total;
    localStorage.clear();
    // Comportement en dépassement
    try { localStorage.setItem('big', 'a'.repeat(out.singleKeyChars + 1)); out.err = 'aucune erreur !'; }
    catch (e) { out.err = e.name + ' : ' + String(e.message).slice(0, 120); }
    localStorage.clear();
    return out;
  });
  console.log('=== QUOTA localStorage — CHROMIUM RÉEL (moteur d’Android WebView) ===');
  console.log('Taille max d’UNE SEULE clé   :', r.singleKeyChars.toLocaleString('fr'), 'caractères  =  ' + (r.singleKeyChars * 2 / 1048576).toFixed(2), 'Mo (UTF-16)');
  console.log('Total multi-clés             :', r.totalChars.toLocaleString('fr'), 'caractères =  ' + (r.totalChars * 2 / 1048576).toFixed(2), 'Mo');
  console.log('Erreur en dépassement        :', r.err);
  console.log();
  console.log('État NOVA seedé              : 2 288 161 caractères');
  console.log('→ Occupation du plafond      :', (2288161 / r.singleKeyChars * 100).toFixed(1) + ' %');
  console.log('→ Marge restante             :', (r.singleKeyChars - 2288161).toLocaleString('fr'), 'caractères');
  await b.close();
})();
