const puppeteer = require('puppeteer');
(async () => {
  const b = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const p = await b.newPage();
  p.on('pageerror', (e) => console.log('PAGEERROR:', e.message.slice(0, 300)));
  p.on('console', (m) => console.log('CONSOLE[' + m.type() + ']:', m.text().slice(0, 220)));
  p.on('requestfailed', (r) => console.log('REQ FAILED:', r.url().slice(0, 90), r.failure()?.errorText));
  await p.goto('http://127.0.0.1:4173/__qa-index.html', { waitUntil: 'domcontentloaded' });
  await new Promise((r) => setTimeout(r, 6000));
  console.log('--- état après 6s ---');
  console.log('__novaDebug:', await p.evaluate(() => typeof window.__novaDebug));
  console.log('longueur app.js chargé:', await p.evaluate(() => Array.from(document.scripts).map((s) => s.src)));
  console.log('storage:', await p.evaluate(() => (window.localStorage.getItem('nova-commerce-state-v1') || '').length));
  console.log('screens:', await p.evaluate(() => ({ setup: !!document.querySelector('#first-run-screen'), login: !!document.querySelector('#login-screen'), shell: !!document.querySelector('#app-shell'), loading: !!document.querySelector('#loading-screen') })));
  await b.close();
})();
