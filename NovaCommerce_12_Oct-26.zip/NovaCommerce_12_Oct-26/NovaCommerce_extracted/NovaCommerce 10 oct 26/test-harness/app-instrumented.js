(() => {
  'use strict';

  const STORAGE_KEY = 'nova-commerce-state-v1';
  // Licence d’appareil : la clé privée de signature reste dans l’outil générateur
  // (Nova-Licence-Generator, jamais diffusée) ; le logiciel embarque uniquement
  // la clé publique de vérification. Chaque clé est liée à un couple
  // (nom de boutique, UUID d’appareil) et se vérifie hors-ligne.
  const LICENCE_KEY_PREFIX = 'NOVA1';
  const LICENCE_PUBLIC_JWK = { kty: 'EC', crv: 'P-256', x: 'LddTuNHgWu1NOjg_q9KTZdePCvDC-yFyEX7X432BAuk', y: '5RTR0AJOsQ-oJwlRONs6QFIZkQF4ty5yFV-T5LNASoA' };
  const DEVICE_UUID_KEY = 'nova-device-uuid-v1';
  const IAFAD_SMS_NUMBER = '+22676830482';
  const TRIAL_MONTHS = 3;
  const PASSWORD_ITERATIONS = 120000;
  const LOGIN_MAX_ATTEMPTS = 5;
  const LOGIN_LOCK_MS = 30_000;
  // Garde anti-recul d’horloge (PWA/Android) : conservée dans le stockage web local, elle est
  // réinitialisable si l’utilisateur vide les données du navigateur — limite documentée et
  // acceptable (côté Desktop, la garde est persistée dans SQLite). Voir README § Contrôle d’intégrité.
  const CLOCK_GUARD_KEY = 'nova-clock-integrity-v1';
  const CLOCK_ROLLBACK_TOLERANCE_MS = 5 * 60 * 1000;
  const CLOCK_CHECKPOINT_INTERVAL_MS = 60 * 1000;
  const APP_VERSION = '1.0.0';
  const BACKUP_SCHEMA_VERSION = 1;
  const CORRUPT_BACKUP_SLOTS = ['nova-corrupt-backup-1', 'nova-corrupt-backup-2', 'nova-corrupt-backup-3'];
  const PAGED_TABLE_SIZE = 10;
  const MAX_IMAGE_BYTES = 512 * 1024;
  const MAX_RECEIPT_BYTES = 2 * 1024 * 1024;
  const PROTECTED_ADMIN_USERNAME = '%@PBGgS86D7@N';
  // Le code concepteur n’est jamais livré en clair : seule cette empreinte salée est embarquée
  // (comparaison à temps quasi-constant via verifyDesignerCode). Rotation : ANALYSE-CRITIQUE.md § Codes et secrets.
  const DESIGNER_CODE_SALT = 'nova-designer-v1:617faa21753ef844c8b64423';
  const DESIGNER_CODE_DIGEST = '1b8c98db9ec18607f22c3e38ab9e71b18fe8f713713404e8da907af586d9c0e6';
  // Les mots de passe initiaux ne sont jamais conservés en clair : seuls ces hachages PBKDF2 sont livrés.
  const SEED_PASSWORD_HASHES = {
    'user-admin': 'pbkdf2-sha256$8f1485ee6ee236ea2d0172e32e1f1e66$120000$2755850d67d932894bf87c66df2ed24af1c2dd4095427624eb938cdce926ffdd',
    'user-vendeur': 'pbkdf2-sha256$nova-mariam-2026$120000$6f46eb6ab0f4adb92a86dc27aaf6a94b84221c93a92063c5ee6c6ba966f7c8f7',
    'user-stock': 'pbkdf2-sha256$nova-issouf-2026$120000$5d5cb56a5f718aba9d85964b045fe2d338765008409e67963d65dc539bae21eb'
  };
  const TODAY = () => new Date();
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const clamp = (value, min, max) => Math.min(Math.max(value, min), max);
  const esc = (value = '') => String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
  const num = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
  // Le Desktop Electron remplace le stockage navigateur par une table SQLite via preload.
  let appStorage = window.localStorage;
  let storageCorruptInfo = null;
  let pagedRowStore = {};
  let inactivityTimer = null;
  let cachedDeviceUuid = '';
  try { if (window.novaDesktop?.storage) appStorage = window.novaDesktop.storage; } catch (_) {}

  // ---------------------------------------------------------------------------
  // Passerelle Android / iOS / Desktop : impression et enregistrement de fichiers.
  // La PWA et le navigateur utilisent l'enregistrement natif du navigateur ; dans
  // l'APK Capacitor, Android WebView n'exécute ni « a[download] » sur une URL
  // blob: ni window.print() : on passe alors par le plugin natif NovaExport.
  // ---------------------------------------------------------------------------
  const NATIVE_PLUGIN_NAME = 'NovaExport';
  const MAX_ACTIVITY_ENTRIES = 3000;
  const STORAGE_WARN_RATIO = 0.8;
  // Estimation de quota : Chromium (WebView Android) autorise ~5 242 880 caractères
  // (10 Mo en UTF-16) par origine pour localStorage. Sert uniquement aux alertes.
  const LOCAL_STORAGE_CHAR_BUDGET = 5240000;

  function nativeBridge() {
    try {
      const plugins = window.Capacitor?.Plugins;
      const plugin = plugins?.[NATIVE_PLUGIN_NAME];
      return plugin && typeof plugin === 'object' ? plugin : null;
    } catch (_) { return null; }
  }
  function isNativeApp() {
    const bridge = nativeBridge();
    if (!bridge) return false;
    try {
      if (typeof window.Capacitor?.isNativePlatform === 'function') return !!window.Capacitor.isNativePlatform();
      if (typeof window.Capacitor?.getPlatform === 'function') return window.Capacitor.getPlatform() !== 'web';
    } catch (_) { /* on suppose natif si un plugin est présent */ }
    return true;
  }
  function nativeBridgeAvailable() { return isNativeApp(); }
  function bytesToBase64(bytes) {
    let binary = '';
    const chunk = 0x8000;
    for (let index = 0; index < bytes.length; index += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(index, index + chunk));
    }
    return btoa(binary);
  }
  function textToBase64(value) {
    const text = String(value ?? '');
    if (typeof TextEncoder === 'function') return bytesToBase64(new TextEncoder().encode(text));
    return btoa(unescape(encodeURIComponent(text)));
  }
  // Enregistre un contenu texte (CSV, JSON, …) : plugin natif sur mobile, sinon
  // téléchargement classique du navigateur (inchangé pour la PWA et le Desktop).
  function saveTextFile(filename, content, mimeType = 'text/plain;charset=utf-8') {
    const bridge = nativeBridge();
    if (isNativeApp() && bridge?.saveToDevice) {
      return Promise.resolve(bridge.saveToDevice({ fileName: filename, mimeType, base64: textToBase64(content) }))
        .then((result) => {
          toast('Fichier enregistré', `${filename}${result?.path ? ` · ${result.path}` : ''}`, 'success');
          if (result?.uri && bridge.shareFile) offerFileActions(filename, result, mimeType);
          return result;
        })
        .catch((error) => {
          toast('Enregistrement impossible', String(error?.message || 'Le système a refusé l’enregistrement du fichier.'), 'error');
          return null;
        });
    }
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = filename; link.click();
    URL.revokeObjectURL(url);
    return Promise.resolve({ fileName: filename, browser: true });
  }
  function offerFileActions(filename, result, mimeType) {
    const bridge = nativeBridge();
    const body = `<div class="notice success" style="margin-top:0"><span>✓</span><div><strong>${esc(filename)}</strong><span>Enregistré dans ${esc(result.path || 'le stockage de l’appareil')}. Vous pouvez l’ouvrir depuis l’application Fichiers, ou le partager maintenant.</span></div></div>`;
    const footer = `<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button><button class="btn btn-primary" type="button" id="export-share-action">⇪ Partager / Ouvrir</button>`;
    openModal('Export terminé', 'Votre fichier est prêt.', body, 'sm', footer);
    $('#export-share-action')?.addEventListener('click', () => {
      try { bridge.shareFile({ uri: result.uri, path: result.path, mimeType }); } catch (_) {}
      closeModal();
    });
  }
  // Impression : plugin natif sur mobile (ouvre « Enregistrer en PDF »), sinon
  // window.print(). `cleanup` retire le document imprimable du DOM une fois l'envoi
  // terminé (immédiat sur mobile, 500 ms après le dialogue sur navigateur/Desktop).
  function printCurrentPage(cleanup) {
    const bridge = nativeBridge();
    if (isNativeApp() && bridge?.printPage) {
      // Filet de sécurité : le document quitte le DOM même si le dialogue système
      // ne rend jamais la main (impression annulée par le gestionnaire de tâches…).
      const safety = setTimeout(() => { try { cleanup?.(); } catch (_) {} }, 10 * 60 * 1000);
      Promise.resolve(bridge.printPage({ jobName: `${state.settings?.businessName || 'NOVA Commerce'} · ${new Date().toLocaleDateString('fr-FR')}` }))
        .catch(() => { try { window.print(); } catch (_) {} })
        .then(() => { clearTimeout(safety); try { cleanup?.(); } catch (_) {} });
      return true;
    }
    window.print();
    if (cleanup) setTimeout(() => { try { cleanup(); } catch (_) {} }, 500);
    return true;
  }
  function isPdfLink(target) {
    const anchor = target?.closest?.('a[href]');
    if (!anchor) return null;
    const href = String(anchor.getAttribute('href') || '');
    return /\.pdf$/i.test(href) && !/^https?:/i.test(href) ? anchor : null;
  }
  function openEmbeddedDocument(anchor) {
    const bridge = nativeBridge();
    const href = String(anchor.getAttribute('href') || '');
    if (!(isNativeApp() && bridge?.openAsset) || !href) return false;
    const fileName = String(anchor.getAttribute('download') || href.split('/').pop() || 'document.pdf');
    if (anchor.hasAttribute('download')) {
      bridge.saveAsset({ assetPath: href, fileName, mimeType: 'application/pdf' })
        .then((result) => { toast('Document enregistré', `${fileName}${result?.path ? ` · ${result.path}` : ''}`, 'success'); if (result?.uri) offerFileActions(fileName, result, 'application/pdf'); })
        .catch((error) => toast('Enregistrement impossible', String(error?.message || ''), 'error'));
    } else {
      bridge.openAsset({ assetPath: href })
        .catch((error) => toast('Ouverture impossible', String(error?.message || 'Aucune application ne peut lire ce PDF.'), 'error'));
    }
    return true;
  }
  // Suivi de l'occupation du stockage local (alerte avant saturation du quota).
  function localStateSize() {
    try { return JSON.stringify(state).length; } catch (_) { return 0; }
  }
  function storageUsage() {
    let used = localStateSize();
    try {
      const guard = appStorage.getItem(CLOCK_GUARD_KEY) || '';
      const device = appStorage.getItem(DEVICE_UUID_KEY) || '';
      used += guard.length + device.length;
    } catch (_) { }
    return { used, budget: LOCAL_STORAGE_CHAR_BUDGET, ratio: Math.min(1, used / LOCAL_STORAGE_CHAR_BUDGET) };
  }
  // Le journal d'activité grossit sans limite : on conserve les entrées récentes.
  function trimActivityLog(limit = MAX_ACTIVITY_ENTRIES) {
    if (!Array.isArray(state.activities) || state.activities.length <= limit) return 0;
    const removed = state.activities.length - limit;
    state.activities = state.activities.slice(0, limit);
    return removed;
  }

  // Icônes SVG locales inspirées de Lucide Icons : aucun CDN ni police externe requis.
  const ICON_PATHS = {
    'sparkles': '<path d="m12 3-1.5 4.5L6 9l4.5 1.5L12 15l1.5-4.5L18 9l-4.5-1.5L12 3Z"/><path d="m19 14-.75 2.25L16 17l2.25.75L19 20l.75-2.25L22 17l-2.25-.75L19 14Z"/><path d="m5 3-.5 1.5L3 5l1.5.5L5 7l.5-1.5L7 5l-1.5-.5L5 3Z"/>',
    'panel-left-close': '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m16 15-3-3 3-3"/>',
    'panel-left-open': '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m13 9 3 3-3 3"/>',
    'chevron-down': '<path d="m6 9 6 6 6-6"/>',
    'layout-dashboard': '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
    'plus-circle': '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
    'chart-line': '<path d="M3 3v18h18"/><path d="m7 16 4-5 3 3 5-7"/>',
    'trending-up': '<path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/>',
    'trending-down': '<path d="m22 17-8.5-8.5-5 5L2 7"/><path d="M16 17h6v-6"/>',
    'users': '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    'user-round': '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    'package': '<path d="m16.5 9.4-9-5.19M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="M3.27 6.96 12 12.01l8.73-5.05M12 22.08V12"/>',
    'tags': '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.83 8.83a2 2 0 0 0 2.828 0l7.172-7.172a2 2 0 0 0 0-2.828Z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
    'store': '<path d="m2 10 2-6h16l2 6"/><path d="M4 10v10h16V10M2 10a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 2 0"/><path d="M8 20v-6h8v6"/>',
    'truck': '<path d="M10 17h4V5H2v12h3"/><path d="M14 8h4l4 4v5h-3"/><circle cx="7.5" cy="17.5" r="2.5"/><circle cx="16.5" cy="17.5" r="2.5"/>',
    'arrow-down-to-line': '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>',
    'arrow-up-from-line': '<path d="M12 21V9"/><path d="m17 14-5-5-5 5"/><path d="M5 3h14"/>',
    'arrow-left-right': '<path d="M3 8h18M3 8l4-4M3 8l4 4M21 16H3M21 16l-4-4M21 16l-4 4"/>',
    'rotate-ccw': '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/>',
    'clipboard-list': '<rect width="16" height="18" x="4" y="3" rx="2"/><path d="M9 3h6v2H9zM8 10h8M8 14h6M8 18h4"/><path d="M6.5 10h.01M6.5 14h.01M6.5 18h.01"/>',
    'scan-line': '<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M7 12h10"/>',
    'file-text': '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h6"/>',
    'shopping-cart': '<circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/><path d="M3 4h2l2.5 11.5a2 2 0 0 0 2 1.5h7.75a2 2 0 0 0 1.94-1.52L21 8H6"/>',
    'chart-pie': '<path d="M21 12a9 9 0 1 1-9-9v9Z"/><path d="M12 3a9 9 0 0 1 9 9h-9Z"/>',
    'receipt': '<path d="M4 2v20l2.5-2 2.5 2 3-2 3 2 2.5-2 2.5 2V2l-2.5 2-2.5-2-3 2-3-2-2.5 2Z"/><path d="M8 9h8M8 13h6"/>',
    'calculator': '<rect width="16" height="20" x="4" y="2" rx="2"/><path d="M8 6h8M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01"/>',
    'files': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v5h6M8 13h8M8 17h6"/><path d="M8 2v-1h8l3 3v3"/>',
    'shield-check': '<path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3Z"/><path d="m9 12 2 2 4-4"/>',
    'history': '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
    'key-round': '<path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777Zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L17 9"/>',
    'phone-call': '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.78.62 2.63a2 2 0 0 1-.45 2.11L8 9.73a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.85.29 1.73.5 2.63.62A2 2 0 0 1 22 16.92Z"/>',
    'settings': '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2Z"/><circle cx="12" cy="12" r="3"/>',
    'bell': '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/>',
    'search': '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    'circle-dollar-sign': '<circle cx="12" cy="12" r="9"/><path d="M16 8h-5.5a2.5 2.5 0 0 0 0 5H14a2.5 2.5 0 0 1 0 5H8M12 6v2m0 8v2"/>',
    'badge-dollar-sign': '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.77 4 4 0 0 1 0 6.76 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.76 0 4 4 0 0 1-4.77-4.78 4 4 0 0 1 0-6.76Z"/><path d="M16 8h-4.5a2.5 2.5 0 0 0 0 5H14a2.5 2.5 0 0 1 0 5H8M12 6v2m0 8v2"/>',
    'coins': '<circle cx="8" cy="8" r="6"/><path d="M18.09 10.37A6 6 0 1 1 10.37 18.1"/><path d="M8 6v4l2 1M16 16v.01M19 13v.01"/>',
    'triangle-alert': '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4M12 17h.01"/>',
    'contrast': '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 0 0 18Z"/>',
    'sun': '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
    'moon': '<path d="M12 3a6.5 6.5 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    'circle-help': '<circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 1 1 5.83 1c-.65 1.42-2.93 1.5-2.93 3M12 17h.01"/>',
    'eye': '<path d="M2.06 12.35a1 1 0 0 1 0-.7C3.66 7.88 7.42 5 12 5s8.34 2.88 9.94 6.65a1 1 0 0 1 0 .7C20.34 16.12 16.58 19 12 19s-8.34-2.88-9.94-6.65Z"/><circle cx="12" cy="12" r="3"/>',
    'log-in': '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5M15 12H3"/>',
    'log-out': '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
    'lock-keyhole': '<circle cx="12" cy="16" r="1"/><rect width="14" height="12" x="5" y="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    'loader-circle': '<path d="M21 12a9 9 0 1 1-6.22-8.56"/><path d="M21 3v6h-6"/>',
    'eye-off': '<path d="m3 3 18 18M10.58 10.58a2 2 0 0 0 2.83 2.83M9.88 4.24A9.6 9.6 0 0 1 12 4c4.58 0 8.34 2.88 9.94 6.65a1 1 0 0 1 0 .7 14.8 14.8 0 0 1-3.01 4.18M6.61 6.61A14.8 14.8 0 0 0 2.06 11.65a1 1 0 0 0 0 .7C3.66 16.12 7.42 19 12 19a9.6 9.6 0 0 0 3.12-.52"/>'
  };
  function icon(name, size = 16, className = '') {
    return `<svg class="ui-icon ${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_PATHS[name] || ICON_PATHS['circle-help']}</svg>`;
  }
  function hydrateIcons(root = document) {
    root.querySelectorAll?.('[data-icon]').forEach((node) => { node.innerHTML = icon(node.dataset.icon, Number(node.dataset.iconSize) || 16); });
  }
  const uid = (prefix) => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  const isoDate = (offset = 0) => {
    const date = new Date();
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() + offset);
    return date.toISOString().slice(0, 10);
  };
  const isoDateTime = (offset = 0, hour = 10, minute = 15) => {
    const date = new Date();
    date.setHours(hour, minute, 0, 0);
    date.setDate(date.getDate() + offset);
    return date.toISOString();
  };
  const localDate = (value) => value ? new Date(value) : new Date();
  const shortDate = (value) => {
    if (!value) return '—';
    return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }).format(localDate(value)).replace('.', '');
  };
  const dateTime = (value) => {
    if (!value) return '—';
    return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }).format(localDate(value)).replace('.', '');
  };
  const dayLabel = (value, weekday = false) => {
    const opts = weekday ? { weekday: 'short', day: '2-digit' } : { day: '2-digit', month: 'short' };
    return new Intl.DateTimeFormat('fr-FR', opts).format(localDate(value)).replace('.', '');
  };
  const money = (value, compact = false) => {
    const n = num(value);
    if (compact && Math.abs(n) >= 1000000) return `${(n / 1000000).toFixed(1).replace('.', ',')} M FCFA`;
    if (compact && Math.abs(n) >= 1000) return `${Math.round(n / 1000)} k FCFA`;
    return `${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n)} FCFA`;
  };
  const number = (value) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(num(value));
  const monthKey = (value) => {
    const d = localDate(value);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  };
  const todayKey = () => isoDate(0);
  const currentMonthKey = () => monthKey(new Date());
  let activeDateFilter = { from: '', to: '' };
  function dateOnly(value) { if (!value) return ''; const date = localDate(value); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; }
  function inActivePeriod(value) { const key = dateOnly(value); return (!activeDateFilter.from || key >= activeDateFilter.from) && (!activeDateFilter.to || key <= activeDateFilter.to); }
  function periodItems(items, dateKey = 'date') { return (items || []).filter((item) => inActivePeriod(item?.[dateKey])); }
  function periodLabel() { return activeDateFilter.from || activeDateFilter.to ? `${activeDateFilter.from || '…'} → ${activeDateFilter.to || '…'}` : 'Toutes les périodes'; }
  const withinDays = (dateValue, days) => {
    if (!dateValue) return false;
    const today = new Date(`${todayKey()}T00:00:00`);
    const date = new Date(`${dateValue}T00:00:00`);
    const diff = Math.round((date - today) / 86400000);
    return diff >= 0 && diff <= days;
  };
  const daysUntil = (dateValue) => {
    if (!dateValue) return null;
    const today = new Date(`${todayKey()}T00:00:00`);
    const date = new Date(`${dateValue}T00:00:00`);
    return Math.round((date - today) / 86400000);
  };

  function addMonths(value, months) {
    const date = new Date(value || new Date());
    const originalDay = date.getDate();
    date.setMonth(date.getMonth() + months);
    if (date.getDate() < originalDay) date.setDate(0);
    return date;
  }
  function normalizeClockIntegrity(value = {}) {
    const maxObservedAt = Math.max(0, num(value.maxObservedAt ?? value.maxObservedMs));
    const lastObservedAt = Math.max(0, num(value.lastObservedAt ?? value.lastObservedMs));
    return {
      version: 1,
      lastObservedAt,
      maxObservedAt,
      observations: Math.max(0, Math.floor(num(value.observations))),
      tampered: value.tampered === true,
      reason: String(value.reason || ''),
      detectedAt: String(value.detectedAt || ''),
      source: String(value.source || '')
    };
  }
  function readStoredClockIntegrity() {
    try { return normalizeClockIntegrity(JSON.parse(appStorage.getItem(CLOCK_GUARD_KEY) || '{}')); } catch (_) { return normalizeClockIntegrity(); }
  }
  function observeClockIntegrity(remote = null, options = {}) {
    if (!state?.license) return normalizeClockIntegrity();
    const embedded = normalizeClockIntegrity(state.license.clockIntegrity || {});
    const stored = readStoredClockIntegrity();
    const external = normalizeClockIntegrity(remote || {});
    const candidates = [embedded, stored, external];
    const nowMs = Date.now();
    const previousMax = Math.max(...candidates.map((item) => num(item.maxObservedAt)), 0);
    const rollback = previousMax > 0 && nowMs + CLOCK_ROLLBACK_TOLERANCE_MS < previousMax;
    const previouslyTampered = candidates.some((item) => item.tampered);
    const tampered = previouslyTampered || rollback;
    const previous = candidates.find((item) => item.tampered) || candidates.find((item) => item.maxObservedAt === previousMax) || embedded;
    const advance = nowMs - previousMax;
    const shouldPersist = previousMax === 0 || advance >= CLOCK_CHECKPOINT_INTERVAL_MS || advance >= CLOCK_ROLLBACK_TOLERANCE_MS || (tampered && !previouslyTampered);
    const next = {
      version: 1,
      lastObservedAt: shouldPersist ? nowMs : Math.max(...candidates.map((item) => num(item.lastObservedAt)), 0),
      maxObservedAt: shouldPersist ? Math.max(previousMax, nowMs) : previousMax,
      observations: Math.max(...candidates.map((item) => num(item.observations)), 0) + (shouldPersist ? 1 : 0),
      tampered,
      reason: rollback ? 'Recul de l’horloge système détecté.' : (previous.reason || ''),
      detectedAt: rollback ? new Date(nowMs).toISOString() : (previous.detectedAt || ''),
      source: rollback ? 'PWA/Android' : (previous.source || '')
    };
    const changed = shouldPersist || JSON.stringify(embedded) !== JSON.stringify(next);
    state.license.clockIntegrity = next;
    if (shouldPersist || JSON.stringify(stored) !== JSON.stringify(next)) {
      try { appStorage.setItem(CLOCK_GUARD_KEY, JSON.stringify(next)); } catch (_) {}
    }
    if (tampered && !previouslyTampered) {
      state.activities = Array.isArray(state.activities) ? state.activities : [];
      state.activities.unshift({ id: uid('clock-lock'), date: new Date(nowMs).toISOString(), userId: 'system', module: 'Sécurité', action: 'Blocage de l’application', element: 'Intégrité de l’horloge', detail: next.reason || 'Modification suspecte de la date système.', oldValue: '', newValue: 'Lecture seule pour tous les comptes' });
    }
    // `deferPersist` est utilisé par saveState(), qui écrit immédiatement après :
    // évite d'écrire deux fois le même état (état volumineux) à chaque enregistrement.
    if (changed && !options.deferPersist && !window.novaDesktop?.isElectron) {
      try { appStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) {}
    }
    return next;
  }
  function clockIntegrityStatus(options = {}) { return observeClockIntegrity(null, options); }
  function isClockTampered(options = {}) { return clockIntegrityStatus(options).tampered; }
  function normalizeBusinessName(value) {
    return String(value ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim().toUpperCase();
  }
  function normalizeDeviceUuid(value) {
    return String(value ?? '').trim().toLowerCase();
  }
  function licenceMessage(businessName, deviceUuid) {
    return `NOVA-LICENCE/v1\nnom=${normalizeBusinessName(businessName)}\nuuid=${normalizeDeviceUuid(deviceUuid)}\n`;
  }
  const CROCKFORD_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
  function crockfordEncode(bytes) {
    const data = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    let bits = 0;
    let value = 0;
    let out = '';
    data.forEach((byte) => {
      value = (value << 8) | byte;
      bits += 8;
      while (bits >= 5) { out += CROCKFORD_ALPHABET[(value >>> (bits - 5)) & 31]; bits -= 5; }
    });
    if (bits > 0) out += CROCKFORD_ALPHABET[(value << (5 - bits)) & 31];
    return out;
  }
  function crockfordDecode(text) {
    const clean = String(text || '').toUpperCase().replace(/[\s-]+/g, '').replace(/I|L/g, '1').replace(/O/g, '0');
    const bytes = [];
    let bits = 0;
    let value = 0;
    for (const char of clean) {
      const index = CROCKFORD_ALPHABET.indexOf(char);
      if (index < 0) return null;
      value = (value << 5) | index;
      bits += 5;
      if (bits >= 8) { bytes.push((value >>> (bits - 8)) & 255); bits -= 8; }
    }
    return new Uint8Array(bytes);
  }
  function groupLicenceKey(key) {
    const clean = String(key || '');
    const head = clean.startsWith(LICENCE_KEY_PREFIX) ? `${LICENCE_KEY_PREFIX}-` : '';
    const body = head ? clean.slice(LICENCE_KEY_PREFIX.length) : clean;
    return head + body.replace(/(.{4})/g, '$1-').replace(/-+$/g, '');
  }
  async function importLicencePublicKey(publicJwk = LICENCE_PUBLIC_JWK) {
    if (!window.crypto?.subtle) throw new Error('Vérification cryptographique indisponible sur cet appareil.');
    return window.crypto.subtle.importKey('jwk', publicJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  }
  async function verifyLicenceSignature(publicJwk, key, businessName, deviceUuid) {
    try {
      const clean = String(key || '').toUpperCase().replace(/[\s-]+/g, '');
      if (!clean.startsWith(LICENCE_KEY_PREFIX)) return false;
      const signature = crockfordDecode(clean.slice(LICENCE_KEY_PREFIX.length));
      if (!signature || signature.length !== 64) return false;
      const cryptoKey = await importLicencePublicKey(publicJwk);
      const message = new TextEncoder().encode(licenceMessage(businessName, deviceUuid));
      return await window.crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, cryptoKey, signature, message);
    } catch (_) { return false; }
  }
  async function verifyLicenceKey(key, businessName, deviceUuid) {
    return verifyLicenceSignature(LICENCE_PUBLIC_JWK, key, businessName, deviceUuid);
  }
  function newDeviceUuid() {
    const bytes = new Uint8Array(16);
    if (window.crypto?.getRandomValues) window.crypto.getRandomValues(bytes);
    else bytes.forEach((_, index) => { bytes[index] = Math.floor(Math.random() * 256); });
    bytes[6] = (bytes[6] & 15) | 64;
    bytes[8] = (bytes[8] & 63) | 128;
    const hex = [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }
  async function ensureDeviceUuid() {
    if (cachedDeviceUuid) return cachedDeviceUuid;
    try {
      if (window.novaDesktop?.getDeviceUuid) {
        const machine = String(await window.novaDesktop.getDeviceUuid() || '').trim();
        if (machine) { cachedDeviceUuid = machine; return cachedDeviceUuid; }
      }
    } catch (_) { /* repli : UUID applicatif */ }
    try {
      let stored = '';
      try { stored = String(appStorage.getItem(DEVICE_UUID_KEY) || '').trim(); } catch (_) { stored = ''; }
      if (!stored) {
        stored = newDeviceUuid();
        try { appStorage.setItem(DEVICE_UUID_KEY, stored); } catch (_) { /* stockage indisponible */ }
      }
      cachedDeviceUuid = stored;
    } catch (_) { cachedDeviceUuid = ''; }
    return cachedDeviceUuid;
  }
  function buildLicenceSms(businessName, deviceUuid) {
    return `Demande de licence NOVA Commerce v${APP_VERSION}\nBoutique : ${String(businessName || '').trim() || '—'}\nUUID : ${String(deviceUuid || '').trim() || '—'}`;
  }
  function smsLicenceHref(businessName, deviceUuid) {
    return `sms:${IAFAD_SMS_NUMBER}?body=${encodeURIComponent(buildLicenceSms(businessName, deviceUuid))}`;
  }
  function copyTextToClipboard(text, okTitle, okMessage) {
    const value = String(text ?? '');
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(value).then(() => toast(okTitle, okMessage)).catch(() => toast(okTitle, value, 'success'));
    else toast(okTitle, value, 'success');
  }
  async function enforceLicenceBinding() {
    try {
      const license = state.license || {};
      if (!license.activated || !license.key) return;
      const uuid = await ensureDeviceUuid();
      const valid = await verifyLicenceKey(license.key, state.settings?.businessName || '', uuid);
      if (valid) return;
      state.license = { ...license, activated: false, invalidatedAt: new Date().toISOString(), invalidatedReason: 'Nom de boutique ou appareil modifié (clé liée à un autre couple nom/UUID).' };
      addActivity('Licence', 'Licence invalidée', state.settings?.businessName || '', 'La clé ne correspond plus au nom de boutique ou à l’appareil.');
      try { saveState(); } catch (_) { /* activation déjà persistée */ }
    } catch (_) { /* jamais bloquant au démarrage */ }
  }
  function licenseInfo() {
    const license = state.license || {};
    const clockIntegrity = observeClockIntegrity();
    if (clockIntegrity.tampered) return { state: 'clock-tampered', label: 'Lecture seule sécurité', title: 'Horloge système incohérente', description: 'Une modification suspecte de la date ou de l’heure a été détectée. L’application est en lecture seule pour tous les comptes.', trialStartedAt: license.trialStartedAt, endsAt: null, daysLeft: null, activatedAt: license.activatedAt, clockIntegrity };
    if (license.activated) return { state: 'licensed', label: 'Licence active', title: 'Fonctionnement illimité', description: 'Votre licence permanente est active sur cet appareil.', trialStartedAt: license.trialStartedAt, endsAt: null, daysLeft: null, activatedAt: license.activatedAt, clockIntegrity };
    const startedAt = license.trialStartedAt || new Date().toISOString();
    const endsAt = addMonths(startedAt, TRIAL_MONTHS);
    const remaining = Math.ceil((endsAt.getTime() - Date.now()) / 86400000);
    const active = remaining >= 0;
    return { state: active ? 'trial' : 'expired', label: active ? 'Période d’essai' : 'Lecture seule', title: active ? `Essai actif · ${Math.max(0, remaining)} jour${remaining > 1 ? 's' : ''} restant${remaining > 1 ? 's' : ''}` : 'Période d’essai expirée', description: active ? `Le logiciel est entièrement actif jusqu’au ${shortDate(endsAt.toISOString())}.` : `Le logiciel est passé en mode lecture seule depuis le ${shortDate(endsAt.toISOString())}.`, trialStartedAt: startedAt, endsAt: endsAt.toISOString(), daysLeft: Math.max(0, remaining), activatedAt: '', clockIntegrity };
  }
  function isReadOnly() { return ['expired', 'clock-tampered'].includes(licenseInfo().state); }
  function licenseStatusClass(info) { return info.state === 'licensed' ? 'ready' : info.state === 'trial' ? 'warning' : 'expired'; }
  const READ_ONLY_ACTIONS = new Set(['quick-add', 'select-product', 'cart-increase', 'cart-decrease', 'cart-remove', 'clear-cart', 'set-payment', 'validate-sale', 'create-credit-note', 'validate-credit-note', 'refund-credit-note', 'add-product', 'edit-product', 'toggle-product', 'add-client', 'edit-client', 'add-supplier', 'edit-supplier', 'add-deliverer', 'edit-deliverer', 'toggle-deliverer', 'assign-delivery', 'add-category', 'edit-category', 'add-store', 'edit-store', 'add-entry', 'validate-entry', 'reverse-entry', 'add-exit', 'validate-exit', 'reverse-exit', 'add-transfer', 'add-transfer-line', 'remove-transfer-line', 'edit-transfer', 'validate-transfer', 'add-order', 'receive-order', 'add-order-line', 'remove-order-line', 'express-generate', 'add-quote', 'add-quote-line', 'remove-quote-line', 'add-expense', 'edit-expense', 'count-product', 'start-inventory', 'create-inventory-report', 'add-user', 'edit-user', 'reset-password', 'add-role', 'edit-role', 'save-settings', 'reset-demo', 'fresh-database', 'designer-enable-all', 'designer-disable-all']);

  // Les droits sont des données métier, pas uniquement des éléments d’interface. Ils sont
  // vérifiés à l’ouverture des vues, sur les actions et sur les formulaires sensibles.
  const DEFAULT_ROLE_PERMISSIONS = {
    Administrateur: ['*'],
    Gérant: ['dashboard.view', 'sales.view', 'sales.create', 'sales.validate', 'sales.reverse', 'clients.view', 'clients.manage', 'credit.view', 'credit.record', 'products.view', 'products.manage', 'catalog.manage', 'stores.view', 'stores.manage', 'suppliers.view', 'suppliers.manage', 'deliverers.view', 'deliverers.manage', 'stock.view', 'stock.create', 'stock.validate', 'stock.transfer', 'orders.view', 'orders.manage', 'inventory.view', 'inventory.manage', 'quotes.view', 'quotes.manage', 'reports.view', 'reports.export', 'expenses.view', 'expenses.manage', 'accounting.view', 'audit.view', 'license.view', 'contact.view', 'settings.view', 'settings.manage'],
    Vendeur: ['dashboard.view', 'sales.view', 'sales.create', 'sales.validate', 'clients.view', 'clients.manage', 'credit.view', 'products.view', 'suppliers.view', 'deliverers.view', 'quotes.view', 'quotes.manage', 'reports.view', 'reports.export', 'license.view', 'contact.view'],
    Magasinier: ['dashboard.view', 'sales.view', 'products.view', 'catalog.manage', 'stores.view', 'suppliers.view', 'deliverers.view', 'stock.view', 'stock.create', 'stock.validate', 'stock.transfer', 'orders.view', 'orders.manage', 'inventory.view', 'inventory.manage', 'reports.view', 'reports.export', 'license.view', 'contact.view'],
    Comptable: ['dashboard.view', 'sales.view', 'clients.view', 'credit.view', 'credit.record', 'products.view', 'suppliers.view', 'deliverers.view', 'quotes.view', 'quotes.manage', 'reports.view', 'reports.export', 'expenses.view', 'expenses.manage', 'accounting.view', 'audit.view', 'license.view', 'contact.view']
  };
  const VIEW_PERMISSIONS = {
    dashboard: 'dashboard.view', sale: 'sales.create', sales: 'sales.view', clients: 'clients.view', products: 'products.view', categories: 'catalog.manage', stores: 'stores.view', suppliers: 'suppliers.view', deliverers: 'deliverers.view', entries: 'stock.view', exits: 'stock.view', transfers: 'stock.view', orders: 'orders.view', inventory: 'inventory.view', quotes: 'quotes.view', 'credit-notes': 'sales.view', 'purchase-report': 'reports.view', 'sales-report': 'reports.view', expenses: 'expenses.view', 'expense-report': 'reports.view', accounting: 'accounting.view', reports: 'reports.view', users: 'users.manage', roles: 'roles.manage', activity: 'audit.view', license: 'license.view', contact: 'contact.view', settings: 'settings.view'
  };
  const ROLE_MATRIX_MODULES = [
    ['Exploitation', [['dashboard', 'Tableau de bord'], ['sale', 'Nouvelle vente'], ['sales', 'Historique des ventes'], ['clients', 'Clients'], ['deliverers', 'Livreurs']]],
    ['Catalogue', [['products', 'Produits'], ['categories', 'Catégories'], ['stores', 'Magasins'], ['suppliers', 'Fournisseurs']]],
    ['Stocks', [['entries', 'Entrées de stock'], ['exits', 'Sorties de stock'], ['transfers', 'Transferts inter-magasins'], ['orders', 'Commandes'], ['inventory', 'Inventaire']]],
    ['Finance', [['quotes', 'Devis'], ['credit-notes', 'Avoirs & annulations'], ['purchase-report', 'Bilan des achats'], ['sales-report', 'Bilan des ventes'], ['expenses', 'Dépenses'], ['expense-report', 'Bilan des dépenses'], ['accounting', 'Comptabilité']]],
    ['Administration', [['reports', 'Rapports'], ['users', 'Utilisateurs'], ['roles', 'Profils & droits'], ['activity', 'Journal d’activité'], ['license', 'Licence'], ['settings', 'Paramètres']]]
  ];
  const MODULE_MANAGE_PERMISSIONS = {
    sale: ['sales.validate'], sales: ['sales.reverse'], clients: ['clients.manage'], deliverers: ['deliverers.manage'],
    products: ['products.manage'], stores: ['stores.manage'], suppliers: ['suppliers.manage'],
    entries: ['stock.create', 'stock.validate'], exits: ['stock.create', 'stock.validate'], transfers: ['stock.transfer', 'stock.validate'],
    orders: ['orders.manage'], inventory: ['inventory.manage'], quotes: ['quotes.manage'], 'credit-notes': ['sales.reverse', 'sales.validate'],
    'purchase-report': ['reports.export'], 'sales-report': ['reports.export'], expenses: ['expenses.manage'], 'expense-report': ['reports.export'],
    reports: ['reports.export'], license: ['license.activate'], settings: ['settings.manage']
  };
  const ACTION_PERMISSIONS = {
    'quick-add': 'sales.create', 'select-product': 'sales.create', 'cart-increase': 'sales.create', 'cart-decrease': 'sales.create', 'cart-remove': 'sales.create', 'clear-cart': 'sales.create', 'set-payment': 'sales.create', 'validate-sale': 'sales.validate',
    'add-product': 'products.manage', 'edit-product': 'products.manage', 'toggle-product': 'products.manage', 'add-client': 'clients.manage', 'edit-client': 'clients.manage', 'record-payment': 'credit.record', 'client-history': 'credit.view', 'add-supplier': 'suppliers.manage', 'edit-supplier': 'suppliers.manage', 'add-deliverer': 'deliverers.manage', 'edit-deliverer': 'deliverers.manage', 'toggle-deliverer': 'deliverers.manage', 'assign-delivery': 'sales.validate', 'add-category': 'catalog.manage', 'edit-category': 'catalog.manage', 'add-store': 'stores.manage', 'edit-store': 'stores.manage',
    'add-entry': 'stock.create', 'validate-entry': 'stock.validate', 'receive-order': 'stock.validate', 'reverse-entry': 'stock.create', 'add-exit': 'stock.create', 'validate-exit': 'stock.validate', 'reverse-exit': 'stock.create', 'add-transfer': 'stock.transfer', 'edit-transfer': 'stock.transfer', 'add-transfer-line': 'stock.transfer', 'remove-transfer-line': 'stock.transfer', 'validate-transfer': 'stock.validate', 'view-transfer': 'stock.view', 'create-credit-note': 'sales.reverse', 'validate-credit-note': 'sales.validate', 'refund-credit-note': 'sales.reverse', 'view-credit-note': 'sales.view', 'add-order': 'orders.manage', 'add-order-line': 'orders.manage', 'remove-order-line': 'orders.manage', 'express-analyze': 'orders.view', 'express-generate': 'orders.manage', 'express-reset': 'orders.view', 'add-quote': 'quotes.manage', 'add-quote-line': 'quotes.manage', 'remove-quote-line': 'quotes.manage', 'add-expense': 'expenses.manage', 'edit-expense': 'expenses.manage', 'count-product': 'inventory.manage', 'start-inventory': 'inventory.manage', 'create-inventory-report': 'inventory.manage', 'view-inventory-report': 'inventory.view', 'print-inventory-report': 'reports.view',
    'add-user': 'users.manage', 'edit-user': 'users.manage', 'reset-password': 'users.manage', 'add-role': 'roles.manage', 'edit-role': 'roles.manage', 'save-settings': 'settings.manage', 'reset-demo': 'demo.reset', 'fresh-database': 'license.activate', 'printer-connect': 'settings.manage', 'printer-disconnect': 'settings.manage', 'printer-test': 'reports.view', 'backup-download': 'settings.manage', 'designer-enable-all': 'settings.manage', 'designer-disable-all': 'settings.manage',
    'export-sales': 'reports.export', 'export-credit-notes': 'reports.export', 'export-transfers': 'reports.export', 'export-clients': 'reports.export', 'export-payments': 'reports.export', 'export-products': 'reports.export', 'export-entries': 'reports.export', 'export-exits': 'reports.export', 'export-expenses': 'reports.export', 'export-orders': 'reports.export', 'export-quotes': 'reports.export', 'export-categories': 'reports.export', 'export-stores': 'reports.export', 'export-suppliers': 'reports.export', 'export-activity': 'reports.export', 'export-inventory': 'reports.export', 'export-stock': 'reports.export', 'export-purchases': 'reports.export', 'export-sales-report': 'reports.export', 'export-accounting': 'reports.export', 'print-inventory': 'reports.view', 'print-report': 'reports.view', 'print-full-report': 'reports.view', 'print-sale': 'sales.view', 'print-receipt': 'sales.view', 'print-order': 'orders.view', 'print-quote': 'quotes.view', 'show-date-filter': 'reports.view', 'show-report-filters': 'reports.view'
  };
  const FORM_PERMISSIONS = {
    'quantity-form': 'sales.create', 'supplier-product-link-form': 'suppliers.manage', 'inventory-report-form': 'inventory.manage', 'credit-note-form': 'sales.reverse', 'transfer-form': 'stock.transfer', 'product-form': 'products.manage', 'client-form': 'clients.manage', 'customer-payment-form': 'credit.record', 'supplier-form': 'suppliers.manage', 'deliverer-form': 'deliverers.manage', 'delivery-form': 'sales.validate', 'category-form': 'catalog.manage', 'store-form': 'stores.manage', 'entry-form': 'stock.create', 'exit-form': 'stock.create', 'order-form': 'orders.manage', 'quote-form': 'quotes.manage', 'expense-form': 'expenses.manage', 'count-form': 'inventory.manage', 'user-form': 'users.manage', 'role-form': 'roles.manage', 'settings-form': 'settings.manage', 'license-form': 'license.activate', 'date-filter-form': 'reports.view'
  };

  const categoryPalette = ['#dff4f0', '#fff0df', '#e9e5ff', '#e6effd', '#ffe7ea'];
  const productTone = (product) => {
    const index = Math.abs((product?.name || '').split('').reduce((a, c) => a + c.charCodeAt(0), 0)) % categoryPalette.length;
    return categoryPalette[index];
  };
  const productImage = (product) => {
    if (product?.image) return product.image;
    const name = product?.name || 'Produit';
    const initials = name.split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
    const tone = productTone(product);
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="420" height="300" viewBox="0 0 420 300"><rect width="420" height="300" rx="26" fill="${tone}"/><circle cx="350" cy="52" r="74" fill="white" opacity=".35"/><circle cx="78" cy="246" r="96" fill="white" opacity=".27"/><rect x="145" y="58" width="130" height="165" rx="18" fill="#ffffff" opacity=".84"/><rect x="161" y="78" width="98" height="92" rx="12" fill="#152338" opacity=".92"/><text x="210" y="136" text-anchor="middle" fill="white" font-family="Arial, sans-serif" font-weight="700" font-size="30">${esc(initials)}</text><rect x="174" y="185" width="72" height="8" rx="4" fill="#152338" opacity=".25"/><text x="210" y="258" text-anchor="middle" fill="#152338" opacity=".62" font-family="Arial, sans-serif" font-size="18">NOVA</text></svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  };

  const seedState = () => {
    let seedCursor = 20260921;
    const seedNext = () => {
      seedCursor |= 0; seedCursor = (seedCursor + 0x6D2B79F5) | 0;
      let t = Math.imul(seedCursor ^ (seedCursor >>> 15), 1 | seedCursor);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    const seedPad = (value, size) => String(value).padStart(size || 2, '0');
    const seedInt = (min, max) => min + Math.floor(seedNext() * (max - min + 1));
    const seedPick = (list) => list[Math.floor(seedNext() * list.length)];
    const seedWeighted = (pairs) => {
      let total = 0;
      for (let i = 0; i < pairs.length; i += 1) total += pairs[i][1];
      let roll = seedNext() * total;
      for (let i = 0; i < pairs.length; i += 1) { roll -= pairs[i][1]; if (roll <= 0) return pairs[i][0]; }
      return pairs[pairs.length - 1][0];
    };
    const DAY_MS = 86400000;
    const SEED_FIRST_DAY = Date.UTC(2024, 8, 1);
    const SEED_LAST_DAY = Date.UTC(2026, 8, 10);
    const SEED_PAY_MAX = Date.UTC(2026, 8, 18);
    const seedDayCount = Math.round((SEED_LAST_DAY - SEED_FIRST_DAY) / DAY_MS) + 1;
    const seedDayLabel = (ms) => { const d = new Date(ms); return d.getUTCFullYear() + '-' + seedPad(d.getUTCMonth() + 1) + '-' + seedPad(d.getUTCDate()); };
    const seedCode = (ms) => { const d = new Date(ms); return String(d.getUTCFullYear()).slice(2) + seedPad(d.getUTCMonth() + 1) + seedPad(d.getUTCDate()); };
    const daySeq = {};
    const seedNumber = (prefix, ms) => {
      const code = seedCode(ms);
      const key = prefix + code;
      daySeq[key] = (daySeq[key] || 0) + 1;
      return prefix + '-' + code + '-' + seedPad(daySeq[key], 3);
    };
    const phonePrefixes = ['60', '64', '65', '66', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79'];
    const phoneGen = () => '+226 ' + seedPick(phonePrefixes) + ' ' + seedPad(seedInt(0, 99)) + ' ' + seedPad(seedInt(0, 99)) + ' ' + seedPad(seedInt(0, 99));
    const lastNames = ['Kaboré', 'Ouedraogo', 'Sawadogo', 'Zongo', 'Traoré', 'Nikiema', 'Sanou', 'Diarra', 'Compaoré', 'Kone', 'Barry', 'Simpore', 'Zoré', 'Nacanabo', 'Belem', 'Kientega', 'Yameogo', 'Bance', 'Tiemtore', 'Ramde', 'Sedogo', 'Ilboudo', 'Congo', 'Dipama', 'Nana', 'Toé', 'Lingani', 'Bationo', 'Somé', 'Hien', 'Dabiré', 'Kambou', 'Sanon', 'Soulama', 'Dao', 'Fofana', 'Cissé', 'Maïga', 'Konaté', 'Sidibé', 'Doumbia', 'Camara', 'Keita', 'Bah', 'Diallo', 'Sow', 'Ndiaye', 'Mensah', 'Adebayo'];
    const firstNamesM = ['Amadou', 'Ibrahim', 'Moussa', 'Issouf', 'Abdoulaye', 'Karim', 'Ousmane', 'Yacouba', 'Dramane', 'Seydou', 'Ali', 'Mamadou', 'Souleymane', 'Harouna', 'Mahamadi', 'Issa', 'Daouda', 'Boureima', 'Salif', 'Adama'];
    const firstNamesF = ['Mariam', 'Awa', 'Aminata', 'Fatoumata', 'Mariam', 'Rokia', 'Kadidiatou', 'Salimata', 'Aïcha', 'Ramata', 'Safiatou', 'Djénéba', 'Assetou', 'Kadiatou', 'Bintou', 'Aminata', 'Zalissa', 'Habibou'];
    const districts = ['Dassasgho', 'Cissin', 'Tampouy', 'Patte d’Oie', 'Karpala', 'Saaba', 'Kossodo', 'Ouaga 2000', 'Gounghin', 'Pissy', 'Nagrin', 'Balkuy', 'Wayalghin', 'Somgandé', 'Kamboinsin', 'Zagtouli', 'Yagma', 'Zogona', 'Samandin', 'Larlé', 'Koulouba', 'Bilbalogho', 'Cissin', 'Bobo-Dioulasso'];
    const personName = () => (seedNext() < 0.5 ? seedPick(firstNamesF) : seedPick(firstNamesM)) + ' ' + seedPick(lastNames);
    const addressGen = () => { const district = seedPick(districts); return district === 'Bobo-Dioulasso' ? district : district + ', Ouagadougou'; };
    const catalogRows = [
      ['cat-alim', 'Sucre en poudre 1 kg', 'Sosuco', 'Poudre', 600, 30, 'Paquet', 9, 1],
      ['cat-alim', 'Pâtes alimentaires 500 g', 'Naya', 'Spaghetti', 425, 30, 'Paquet', 8, 1],
      ['cat-alim', 'Concentré de tomate 400 g', 'Giana', 'Double', 550, 32, 'Boîte', 8, 1],
      ['cat-alim', 'Sel iodé 500 g', 'Sel Star', 'Fin', 200, 40, 'Sachet', 7, 0],
      ['cat-alim', 'Farine de blé 1 kg', 'Grands Moulins', 'T55', 650, 28, 'Paquet', 7, 1],
      ['cat-boissons', 'Jus d’orange 1 L', 'Dafani', 'Nectar', 700, 30, 'Brique', 8, 1],
      ['cat-boissons', 'Soda cola 1 L', 'Brakina', 'Cola', 600, 32, 'Bouteille', 9, 1],
      ['cat-boissons', 'Café moulu 250 g', 'Nescafé', 'Classic', 1400, 28, 'Paquet', 7, 1],
      ['cat-boissons', 'Thé vert 100 sachets', 'Lipton', 'Yellow', 950, 30, 'Boîte', 6, 1],
      ['cat-boissons', 'Sirop de menthe 1 L', 'Teisseire', 'Menthe', 1600, 30, 'Bidon', 5, 1],
      ['cat-entretien', 'Eau de Javel 1 L', 'Javel La Croix', '12°', 450, 35, 'Bidon', 8, 0],
      ['cat-entretien', 'Lessive en poudre 1 kg', 'Omo', 'Multi Active', 1100, 30, 'Paquet', 8, 0],
      ['cat-entretien', 'Liquide vaisselle 500 ml', 'Paic', 'Citron', 650, 32, 'Flacon', 7, 0],
      ['cat-entretien', 'Désodorisant 300 ml', 'Air Wick', 'Vanille', 1300, 35, 'Bombe', 5, 0],
      ['cat-entretien', 'Serpillière coton', 'Propre Maison', 'Double', 800, 40, 'Pièce', 4, 0],
      ['cat-hygiene', 'Savon parfumé 200 g', 'Palmida', 'Karité', 350, 40, 'Pièce', 8, 0],
      ['cat-hygiene', 'Dentifrice 140 g', 'Colgate', 'Max Fresh', 850, 30, 'Tube', 8, 0],
      ['cat-hygiene', 'Shampooing 400 ml', 'Nouria', 'Karité', 1500, 32, 'Flacon', 6, 0],
      ['cat-hygiene', 'Lait corporel karité 500 ml', 'Nouria', 'Hydra', 1900, 32, 'Flacon', 6, 0],
      ['cat-hygiene', 'Déodorant bille 50 ml', 'Narta', 'Invisible', 1200, 35, 'Flacon', 5, 0],
      ['cat-papeterie', 'Stylo bille bleu x10', 'Bic', 'Cristal', 900, 35, 'Boîte', 7, 0],
      ['cat-papeterie', 'Crayon HB x12', 'Maped', 'HB', 700, 35, 'Boîte', 6, 0],
      ['cat-papeterie', 'Ramette A4 500 feuilles', 'Double A', '80 g', 3200, 25, 'Ramette', 5, 0],
      ['cat-papeterie', 'Cahier 100 pages', 'Elite', '17 x 22', 350, 40, 'Unité', 7, 0],
      ['cat-conserves', 'Sardines à l’huile 425 g', 'Sardina', 'Entières', 650, 30, 'Boîte', 8, 1],
      ['cat-conserves', 'Maïs doux 340 g', 'Géant Vert', 'Extra', 550, 32, 'Boîte', 6, 1],
      ['cat-conserves', 'Petits pois 400 g', 'D’Aucy', 'Fins', 500, 32, 'Boîte', 6, 1],
      ['cat-conserves', 'Ananas au sirop 565 g', 'Del Monte', 'Tranches', 800, 30, 'Boîte', 5, 1],
      ['cat-conserves', 'Champignons émincés 400 g', 'Bonduelle', 'Paris', 750, 30, 'Boîte', 4, 1],
      ['cat-condiments', 'Huile d’arachide 1 L', 'Savor', 'Pure', 1400, 28, 'Bouteille', 8, 1],
      ['cat-condiments', 'Vinaigre d’alcool 1 L', 'Amora', 'Blanc', 500, 35, 'Bouteille', 6, 0],
      ['cat-condiments', 'Mayonnaise 500 g', 'Lesieur', 'Fine', 950, 30, 'Pot', 6, 1],
      ['cat-condiments', 'Moutarde 500 g', 'Amora', 'Forte', 700, 32, 'Pot', 5, 1],
      ['cat-condiments', 'Cube bouillon x48', 'Maggi', 'Poulet', 850, 30, 'Boîte', 9, 1],
      ['cat-cereales', 'Riz brisure 5 kg', 'Soleil', 'Brisure', 3400, 25, 'Sac', 9, 1],
      ['cat-cereales', 'Mil décortiqué 5 kg', 'Bama', 'Décortiqué', 2800, 28, 'Sac', 7, 1],
      ['cat-cereales', 'Maïs concassé 5 kg', 'Bama', 'Gros', 2500, 28, 'Sac', 7, 1],
      ['cat-cereales', 'Couscous moyen 1 kg', 'Dari', 'Moyen', 900, 30, 'Paquet', 6, 1],
      ['cat-cereales', 'Flocons d’avoine 500 g', 'Quaker', 'Nature', 1100, 30, 'Boîte', 4, 1],
      ['cat-laitiers', 'Lait en poudre 500 g', 'Nido', 'Entier', 2400, 25, 'Boîte', 8, 1],
      ['cat-laitiers', 'Yaourt nature x4', 'Yoplait', 'Nature', 800, 30, 'Pack', 7, 1],
      ['cat-laitiers', 'Fromage fondu x8', 'Faso Lait', 'Portions', 900, 30, 'Boîte', 6, 1],
      ['cat-laitiers', 'Beurre doux 250 g', 'Président', 'Doux', 1500, 28, 'Plaquette', 5, 1],
      ['cat-laitiers', 'Lait concentré sucré 397 g', 'Nestlé', 'Sucré', 850, 30, 'Boîte', 7, 1],
      ['cat-surgeles', 'Poulet entier surgelé 1,5 kg', 'Faso Poulet', 'Entier', 2800, 25, 'Sachet', 7, 1],
      ['cat-surgeles', 'Poisson capitaine 1 kg', 'Pêche du Jour', 'Entier', 2200, 28, 'Sachet', 6, 1],
      ['cat-surgeles', 'Légumes mélangés 1 kg', 'Bonduelle', 'Mélange', 1400, 30, 'Sachet', 4, 1],
      ['cat-bebe', 'Couches taille M x40', 'Pampers', 'Baby Dry', 4500, 25, 'Paquet', 7, 0],
      ['cat-bebe', 'Lait infantile 800 g', 'Nursie', '1er âge', 5200, 22, 'Boîte', 6, 1],
      ['cat-bebe', 'Lingettes x72', 'Pampers', 'Sensitive', 1200, 30, 'Paquet', 6, 1],
      ['cat-bebe', 'Savon bébé 200 g', 'Mustela', 'Doux', 1100, 32, 'Pièce', 5, 0],
      ['cat-bebe', 'Poudre bébé 200 g', 'Johnson’s', 'Classic', 900, 32, 'Flacon', 4, 0],
      ['cat-beaute', 'Beurre de karité pur 500 g', 'Nouria', 'Bio', 2200, 35, 'Pot', 7, 0],
      ['cat-beaute', 'Huile de coco 250 ml', 'Nouria', 'Vierge', 1800, 35, 'Flacon', 5, 0],
      ['cat-beaute', 'Pommade capillaire 250 g', 'Soulmate', 'Karité', 1300, 35, 'Pot', 6, 0],
      ['cat-beaute', 'Vernis lot de 3', 'Miss Europe', 'Assortis', 1500, 40, 'Coffret', 4, 0],
      ['cat-beaute', 'Eau de parfum 100 ml', 'Brise du Faso', 'Agrumes', 6500, 40, 'Flacon', 3, 0],
      ['cat-textile', 'Pagne wax 6 yards', 'Vlisco', 'Prestige', 12000, 30, 'Pièce', 6, 0],
      ['cat-textile', 'T-shirt coton', 'Basique', 'Unisexe', 1500, 40, 'Pièce', 7, 0],
      ['cat-textile', 'Jean homme', 'Denim Star', 'Slim', 5500, 35, 'Pièce', 5, 0],
      ['cat-textile', 'Robe bazin', 'Faso Mode', 'Brodée', 9500, 35, 'Pièce', 5, 0],
      ['cat-textile', 'Chaussettes x6', 'Confort', 'Coton', 1200, 40, 'Lot', 6, 0],
      ['cat-chaussures', 'Sandales cuir homme', 'Marocain', 'Cousues', 4500, 35, 'Paire', 6, 0],
      ['cat-chaussures', 'Baskets running', 'Sport Plus', 'Air', 8500, 35, 'Paire', 6, 0],
      ['cat-chaussures', 'Babouches brodées', 'Sahélien', 'Broderie', 3500, 40, 'Paire', 5, 0],
      ['cat-chaussures', 'Chaussures école', 'Rentrée', 'Noires', 4000, 35, 'Paire', 6, 0],
      ['cat-chaussures', 'Tongs plage', 'Plage Fun', 'Légères', 800, 45, 'Paire', 5, 0],
      ['cat-quincaillerie', 'Marteau 500 g', 'Stanley', 'Menuisier', 3200, 30, 'Pièce', 4, 0],
      ['cat-quincaillerie', 'Tournevis x6', 'Ingco', 'Assortis', 2800, 32, 'Coffret', 4, 0],
      ['cat-quincaillerie', 'Cadenas 50 mm', 'Viro', 'Acier', 2500, 35, 'Pièce', 5, 0],
      ['cat-quincaillerie', 'Ampoules LED x4', 'Philips', '9 W', 2200, 32, 'Boîte', 6, 0],
      ['cat-quincaillerie', 'Rouleau adhésif', 'Tesa', '48 mm', 600, 40, 'Rouleau', 5, 0],
      ['cat-electromenager', 'Ventilateur sur pied', 'Binatone', '16 pouces', 14000, 25, 'Carton', 5, 0],
      ['cat-electromenager', 'Bouilloire 1,7 L', 'Moulinex', 'Inox', 9500, 28, 'Carton', 4, 0],
      ['cat-electromenager', 'Fer à repasser', 'Philips', 'Vapeur', 11000, 28, 'Carton', 4, 0],
      ['cat-telephonie', 'Smartphone 64 Go', 'Itel', 'A60', 35000, 20, 'Coffret', 4, 0],
      ['cat-telephonie', 'Chargeur rapide USB-C', 'Oraimo', '20 W', 3500, 40, 'Boîte', 6, 0],
      ['cat-telephonie', 'Écouteurs filaires', 'Oraimo', 'Bass', 2500, 40, 'Boîte', 6, 0],
      ['cat-telephonie', 'Coque + verre trempé', 'Protect Plus', 'Universel', 1500, 45, 'Lot', 5, 0],
      ['cat-telephonie', 'Batterie externe 10000 mAh', 'Anker', 'PowerCore', 8000, 30, 'Boîte', 5, 0],
      ['cat-jouets', 'Ballon football T5', 'Sport Plus', 'Cuir', 4500, 35, 'Pièce', 6, 0],
      ['cat-jouets', 'Poupée parlante', 'Merveilles', '40 cm', 6500, 35, 'Coffret', 4, 0],
      ['cat-jouets', 'Jeu de société Ludo', 'Family Games', 'Classic', 2500, 40, 'Boîte', 4, 0],
      ['cat-jouets', 'Coloriage + crayons x12', 'Maped', 'Color Peps', 1800, 38, 'Coffret', 5, 0],
      ['cat-animalerie', 'Croquettes chien 3 kg', 'Royal Canin', 'Adulte', 4200, 28, 'Sac', 4, 1],
      ['cat-animalerie', 'Pâtée chat x12', 'Whiskas', 'Poulet', 3600, 28, 'Lot', 4, 1],
      ['cat-animalerie', 'Litière végétale 5 L', 'Catsan', 'Agglomérante', 2800, 30, 'Sac', 3, 0],
      ['cat-deco', 'Set casseroles 3 pièces', 'Tefal', 'Inox', 16000, 28, 'Carton', 4, 0],
      ['cat-deco', 'Théière émaillée 1 L', 'Sahélienne', 'Décorée', 3500, 35, 'Pièce', 5, 0],
      ['cat-deco', 'Nappe damassée', 'Maison Belle', '2 x 1,5 m', 4500, 35, 'Pièce', 3, 0],
      ['cat-deco', 'Panier tressé', 'Artisanat Faso', 'Rond', 2000, 40, 'Pièce', 4, 0],
      ['cat-deco', 'Bougies parfumées x3', 'Senteurs', 'Vanille', 1800, 40, 'Coffret', 4, 0]
    ];
    const categories = [
      { id: 'cat-alim', name: 'Alimentation', code: 'ALIM', description: 'Produits alimentaires et épicerie', active: true },
      { id: 'cat-boissons', name: 'Boissons', code: 'BOIS', description: 'Boissons fraîches et chaudes', active: true },
      { id: 'cat-entretien', name: 'Entretien', code: 'ENTR', description: 'Entretien de la maison', active: true },
      { id: 'cat-hygiene', name: 'Hygiène & soin', code: 'HYGI', description: 'Hygiène corporelle et soin', active: true },
      { id: 'cat-papeterie', name: 'Papeterie', code: 'PAPE', description: 'Fournitures scolaires et bureau', active: true },
      { id: 'cat-conserves', name: 'Conserves & bocaux', code: 'CONS', description: 'Conserves de légumes, fruits et poissons', active: true },
      { id: 'cat-condiments', name: 'Huiles & condiments', code: 'COND', description: 'Huiles, sauces et assaisonnements', active: true },
      { id: 'cat-cereales', name: 'Céréales & farines', code: 'CERE', description: 'Riz, mil, maïs et farines en sacs', active: true },
      { id: 'cat-laitiers', name: 'Produits laitiers', code: 'LAIT', description: 'Lait, yaourts, fromages et beurre', active: true },
      { id: 'cat-surgeles', name: 'Surgelés', code: 'SURG', description: 'Viandes, poissons et légumes surgelés', active: true },
      { id: 'cat-bebe', name: 'Bébé & puériculture', code: 'BEBE', description: 'Couches, lait infantile et soin bébé', active: true },
      { id: 'cat-beaute', name: 'Beauté & cosmétique', code: 'BEAU', description: 'Karité, capillaires et parfumerie', active: true },
      { id: 'cat-textile', name: 'Textile & habillement', code: 'TEXT', description: 'Pagnes, prêt-à-porter et mercerie', active: true },
      { id: 'cat-chaussures', name: 'Chaussures', code: 'CHAU', description: 'Chaussures homme, femme et enfant', active: true },
      { id: 'cat-quincaillerie', name: 'Quincaillerie', code: 'QUIN', description: 'Outillage et petit équipement', active: true },
      { id: 'cat-electromenager', name: 'Électroménager', code: 'ELEC', description: 'Ventilation, cuisine et repassage', active: true },
      { id: 'cat-telephonie', name: 'Téléphonie & accessoires', code: 'TEL', description: 'Téléphones et accessoires mobiles', active: true },
      { id: 'cat-jouets', name: 'Jouets & loisirs', code: 'JOUET', description: 'Jeux, sport et loisirs créatifs', active: true },
      { id: 'cat-animalerie', name: 'Animalerie', code: 'ANIM', description: 'Alimentation et soin des animaux', active: true },
      { id: 'cat-deco', name: 'Maison & déco', code: 'DECO', description: 'Cuisine, linge et décoration', active: true }
    ];
    const stores = [
      { id: 'store-main', name: 'Boutique centrale', code: 'MAG-01', type: 'Point de vente', manager: 'Amadou Kaboré', active: true },
      { id: 'store-reserve', name: 'Réserve arrière', code: 'MAG-02', type: 'Réserve', manager: 'Mariam Ouedraogo', active: true }
    ];
    const suppliers = [
      { id: 'sup-01', name: 'SODIS Burkina', type: 'Entreprise', manager: 'Issa Nikiema', phone: '+226 70 21 44 18', secondary: '+226 25 33 11 02', fiscal: 'IFU 0002458A', address: 'Zone du Bois, Ouagadougou', active: true },
      { id: 'sup-02', name: 'Distriboissons SA', type: 'Entreprise', manager: 'Aïcha Sanou', phone: '+226 76 89 04 12', secondary: '', fiscal: 'IFU 0029187B', address: 'Koulouba, Ouagadougou', active: true },
      { id: 'sup-03', name: 'Marché frais de Karpala', type: 'Particulier', manager: 'Moussa Ouédraogo', phone: '+226 66 04 23 51', secondary: '', fiscal: '', address: 'Karpala, Ouagadougou', active: true }
    ];
    const companyNames = ['Sahel Distribution', 'Faso Négoce', 'Wendkouni Import', 'Zongo Trading', 'Comptoir du Centre', 'Kaboré & Frères', 'Sawadogo Import Export', 'Burkina Market Supply', 'Nikiéma Négoce', 'Sana Distribution', 'Diarra Import', 'Compaoré Négoce', 'Kone Distribution', 'Barry Frères', 'Simpore Trading', 'Ouédraogo & Fils', 'Kone et Fils', 'Sanou Distribution', 'SOREXX Burkina', 'Yameogo Négoce', 'Bance Import', 'Ramde Trading', 'Ilboudo Distribution', 'Nana & Frères'];
    const institutionNames = ['Coopérative Riz du Sourou', 'Centrale d’Achat Scolaire', 'Union des Producteurs de Karité', 'Coopérative Laitière de Koubri'];
    const fiscalGen = () => 'IFU ' + seedPad(seedInt(0, 9999999), 7) + seedPick(['A', 'B', 'C', 'R', 'M']);
    for (let i = 0; i < 37; i += 1) {
      const rank = i + 4;
      const id = 'sup-' + seedPad(rank);
      const type = i < 24 ? 'Entreprise' : (i < 33 ? 'Particulier' : 'Institution');
      const name = type === 'Entreprise' ? companyNames[i] : (type === 'Institution' ? institutionNames[i - 33] : personName() + ' (grossiste)');
      suppliers.push({ id, name, type, manager: personName(), phone: phoneGen(), secondary: seedNext() < 0.5 ? phoneGen() : '', fiscal: type === 'Particulier' ? (seedNext() < 0.3 ? fiscalGen() : '') : fiscalGen(), address: addressGen(), active: rank !== 38 && rank !== 40 });
    }
    const deliverers = [
      { id: 'liv-01', lastName: 'Kaboré', firstName: 'Ibrahim', phone: '+226 70 55 21 34', secondary: '+226 76 55 21 34', address: 'Cissin, Ouagadougou', baseRate: 1_000, cin: 'B 4521 8890', notes: 'Moto personnelle · disponible 7j/7', active: true },
      { id: 'liv-02', lastName: 'Sawadogo', firstName: 'Awa', phone: '+226 66 12 78 45', secondary: '', address: 'Saaba, Ouagadougou', baseRate: 1_500, cin: 'B 7812 3345', notes: '', active: true },
      { id: 'liv-03', lastName: 'Zongo', firstName: 'Pascal', phone: '+226 78 90 34 12', secondary: '', address: 'Bobo-Dioulasso', baseRate: 2_000, cin: '', notes: 'Longues distances uniquement', active: false }
    ];
    const delivererNotes = ['', '', 'Moto personnelle', 'Disponible 7j/7', 'Zone Ouaga Est', 'Zone Ouaga Ouest', 'Vélo + moto', 'Longues distances', 'Disponible weekends'];
    for (let i = 4; i <= 15; i += 1) {
      deliverers.push({ id: 'liv-' + seedPad(i), lastName: seedPick(lastNames), firstName: seedPick(seedNext() < 0.5 ? firstNamesF : firstNamesM), phone: phoneGen(), secondary: seedNext() < 0.4 ? phoneGen() : '', address: addressGen(), baseRate: seedPick([750, 1_000, 1_000, 1_250, 1_500, 1_500, 1_750, 2_000, 2_500]), cin: seedNext() < 0.6 ? 'B ' + seedPad(seedInt(0, 9999), 4) + ' ' + seedPad(seedInt(0, 9999), 4) : '', notes: seedPick(delivererNotes), active: true });
    }
    const products = [
      { id: 'prod-01', code: 'P-001', name: 'Lait Vita UHT 1L', categoryId: 'cat-boissons', brand: 'Vita', model: 'UHT', supplierId: 'sup-02', storeId: 'store-main', purchasePrice: 650, salePrice: 900, wholesalePrice: 825, promoPrice: 850, stock: 42, minStock: 12, maxStock: 90, presentation: 'Brique', batch: 'VT-0626', expiry: isoDate(18), active: true },
      { id: 'prod-02', code: 'P-002', name: 'Riz parfumé 5 kg', categoryId: 'cat-alim', brand: 'Soleil', model: 'Parfumé', supplierId: 'sup-01', storeId: 'store-main', purchasePrice: 3_900, salePrice: 5_200, wholesalePrice: 4_850, promoPrice: 5_000, stock: 28, minStock: 10, maxStock: 55, presentation: 'Sac', batch: 'RZ-2608', expiry: isoDate(170), active: true },
      { id: 'prod-03', code: 'P-003', name: 'Semoule de maïs 1 kg', categoryId: 'cat-alim', brand: 'Bama', model: 'Fine', supplierId: 'sup-01', storeId: 'store-main', purchasePrice: 550, salePrice: 800, wholesalePrice: 730, promoPrice: 750, stock: 0, minStock: 8, maxStock: 65, presentation: 'Sachet', batch: 'SM-2508', expiry: isoDate(-4), active: true },
      { id: 'prod-04', code: 'P-004', name: 'Eau minérale 1,5 L', categoryId: 'cat-boissons', brand: 'Jirma', model: 'Naturelle', supplierId: 'sup-02', storeId: 'store-main', purchasePrice: 375, salePrice: 500, wholesalePrice: 450, promoPrice: 475, stock: 116, minStock: 24, maxStock: 100, presentation: 'Bouteille', batch: 'EA-0926', expiry: isoDate(58), active: true },
      { id: 'prod-05', code: 'P-005', name: 'Savon de ménage 400 g', categoryId: 'cat-entretien', brand: 'Koudougou', model: 'Original', supplierId: 'sup-01', storeId: 'store-main', purchasePrice: 450, salePrice: 650, wholesalePrice: 590, promoPrice: 600, stock: 6, minStock: 12, maxStock: 75, presentation: 'Pièce', batch: 'SV-2607', expiry: '', active: true },
      { id: 'prod-06', code: 'P-006', name: 'Huile végétale 1 L', categoryId: 'cat-alim', brand: 'J’adore', model: 'Tournesol', supplierId: 'sup-01', storeId: 'store-main', purchasePrice: 920, salePrice: 1_250, wholesalePrice: 1_150, promoPrice: 1_190, stock: 19, minStock: 8, maxStock: 50, presentation: 'Bouteille', batch: 'HV-0826', expiry: isoDate(40), active: true },
      { id: 'prod-07', code: 'P-007', name: 'Gel douche Karité 250 ml', categoryId: 'cat-hygiene', brand: 'Nouria', model: 'Karité', supplierId: 'sup-03', storeId: 'store-main', purchasePrice: 1_150, salePrice: 1_650, wholesalePrice: 1_520, promoPrice: 1_550, stock: 33, minStock: 7, maxStock: 45, presentation: 'Flacon', batch: 'GD-0626', expiry: isoDate(75), active: true },
      { id: 'prod-08', code: 'P-008', name: 'Cahier 200 pages', categoryId: 'cat-papeterie', brand: 'Elite', model: '21 x 29,7', supplierId: 'sup-01', storeId: 'store-reserve', purchasePrice: 575, salePrice: 800, wholesalePrice: 720, promoPrice: 750, stock: 64, minStock: 15, maxStock: 60, presentation: 'Unité', batch: 'CA-2609', expiry: '', active: true }
    ];
    const supplierSlots = [];
    for (let i = 0; i < 10; i += 1) supplierSlots.push('sup-01');
    for (let i = 0; i < 8; i += 1) supplierSlots.push('sup-02');
    for (let i = 0; i < 6; i += 1) supplierSlots.push('sup-03');
    for (let s = 4; s <= 37; s += 1) { supplierSlots.push('sup-' + seedPad(s)); supplierSlots.push('sup-' + seedPad(s)); }
    for (let i = supplierSlots.length - 1; i > 0; i -= 1) { const j = Math.floor(seedNext() * (i + 1)); const tmp = supplierSlots[i]; supplierSlots[i] = supplierSlots[j]; supplierSlots[j] = tmp; }
    const expiredPool = ['2025-03-14', '2025-06-02', '2025-08-19', '2025-11-20', '2026-02-11', '2026-05-30', '2026-07-22', '2026-08-15'];
    const soonPool = ['2026-09-28', '2026-10-05', '2026-10-12', '2026-10-20', '2026-10-30', '2026-11-04'];
    const pickExpiry = () => {
      const roll = seedNext();
      if (roll < 0.12) return seedPick(expiredPool);
      if (roll < 0.30) return seedPick(soonPool);
      const off = seedInt(0, 6);
      return (off === 0 ? 2026 : 2027) + '-' + seedPad(off === 0 ? 12 : off) + '-' + seedPad(seedInt(1, 28));
    };
    const ruptureRows = [10, 33, 55, 71, 86];
    const inactiveRows = [20, 50, 80];
    catalogRows.forEach((row, index) => {
      const rank = index + 9;
      const buy = row[4];
      const step = buy >= 20000 ? 100 : 25;
      const roundPrice = (value) => Math.max(25, Math.round(value / step) * step);
      const sale = roundPrice(buy * (1 + row[5] / 100));
      const pop = row[7];
      let minStock = 4;
      let maxStock = 40;
      let stock = 20;
      if (pop >= 8) { minStock = seedInt(12, 30); maxStock = minStock * seedInt(4, 6); stock = seedInt(minStock + 5, maxStock); }
      else if (pop >= 5) { minStock = seedInt(6, 14); maxStock = minStock * seedInt(4, 6); stock = seedInt(minStock + 2, maxStock); }
      else { minStock = seedInt(2, 6); maxStock = seedInt(24, 70); stock = seedInt(3, maxStock); }
      if (ruptureRows.includes(index)) stock = 0;
      else if (index % 11 === 5) stock = Math.max(1, minStock - 1);
      let reserve = 0;
      if (stock > 10 && seedNext() < 0.45) reserve = Math.round(stock * (0.2 + seedNext() * 0.3));
      const main = stock - reserve;
      products.push({ id: 'prod-' + seedPad(rank), code: 'P-' + seedPad(rank, 3), name: row[1], categoryId: row[0], brand: row[2], model: row[3], supplierId: supplierSlots[index], storeId: reserve > main ? 'store-reserve' : 'store-main', stockByStore: { 'store-main': main, 'store-reserve': reserve }, purchasePrice: buy, salePrice: sale, wholesalePrice: roundPrice(sale * 0.93), promoPrice: roundPrice(sale * 0.95), stock, minStock, maxStock, presentation: row[6], popularity: pop, batch: 'LT-' + seedPad(rank, 3) + '-' + seedPad(seedInt(10, 99)), expiry: row[8] ? pickExpiry() : '', active: !inactiveRows.includes(index) });
    });
    const productByIdSeed = {};
    products.forEach((p) => { productByIdSeed[p.id] = p; });
    const fixedPopularity = { 'prod-01': 9, 'prod-02': 10, 'prod-03': 6, 'prod-04': 10, 'prod-05': 8, 'prod-06': 9, 'prod-07': 6, 'prod-08': 5 };
    const productWeight = (p) => p.popularity || fixedPopularity[p.id] || 5;
    const popList = products.filter((p) => p.active !== false);
    let popTotal = 0;
    popList.forEach((p) => { popTotal += productWeight(p); });
    const popularProduct = (exclude) => {
      for (let tries = 0; tries < 12; tries += 1) {
        let roll = seedNext() * popTotal;
        for (let i = 0; i < popList.length; i += 1) {
          roll -= productWeight(popList[i]);
          if (roll <= 0) { if (!exclude || !exclude[popList[i].id]) return popList[i]; break; }
        }
      }
      return popList[seedInt(0, popList.length - 1)];
    };
    const productsBySupplier = {};
    products.forEach((p) => { if (p.active === false) return; if (!productsBySupplier[p.supplierId]) productsBySupplier[p.supplierId] = []; productsBySupplier[p.supplierId].push(p); });
    const clients = [
      { id: 'client-01', name: 'Sira Traoré', phone: '+226 70 44 02 88', email: 'sira.t@example.com', address: 'Dassasgho, Ouagadougou', creditLimit: 300_000, receivable: 86_000, active: true },
      { id: 'client-02', name: 'Boubacar & Fils', phone: '+226 76 18 31 09', email: '', address: 'Patte d’Oie, Ouagadougou', creditLimit: 500_000, receivable: 0, active: true },
      { id: 'client-03', name: 'Café Wend-Panga', phone: '+226 65 90 12 17', email: 'contact@wendpanga.bf', address: 'Ouaga 2000', creditLimit: 250_000, receivable: 135_500, active: true },
      { id: 'client-04', name: 'Clinique La Grâce', phone: '+226 25 37 10 90', email: '', address: 'Tampouy, Ouagadougou', creditLimit: 750_000, receivable: 0, active: true }
    ];
    const bizKinds = ['Boutique', 'Kiosque', 'Restaurant', 'Maquis', 'Pharmacie', 'Quincaillerie', 'Salon de coiffure', 'Atelier', 'Pressing', 'Boulangerie', 'Cafétéria', 'Librairie', 'Garage', 'Menuiserie', 'Studio photo', 'Pâtisserie'];
    const bizNames = ['Wend-Panga', 'La Grâce', 'Le Palmier', 'Espoir', 'Amitié', 'Le Progrès', 'Victoire', 'Lumière', 'La Paix', 'Solidarité', 'Nong Taaba', 'Le Baobab', 'Émeraude', 'Le Phare', 'Concorde', 'Béni'];
    const usedClientNames = { 'Sira Traoré': 1, 'Boubacar & Fils': 1, 'Café Wend-Panga': 1, 'Clinique La Grâce': 1 };
    for (let i = 5; i <= 300; i += 1) {
      const id = 'client-' + (i < 10 ? '0' + i : i);
      let name = '';
      let creditLimit = 0;
      if (seedNext() < 0.7) {
        name = personName();
        creditLimit = seedNext() < 0.4 ? 0 : 50_000 * seedInt(1, 6);
      } else {
        name = seedPick(bizKinds) + ' ' + seedPick(bizNames);
        creditLimit = 200_000 + 50_000 * seedInt(0, 16);
      }
      if (usedClientNames[name]) name = name + ' ' + (usedClientNames[name] + 1);
      usedClientNames[name] = (usedClientNames[name] || 0) + 1;
      clients.push({ id, name, phone: phoneGen(), email: seedNext() < 0.4 ? 'client' + i + '@example.com' : '', address: addressGen(), creditLimit, receivable: 0, active: (i - 5) % 50 !== 25 });
    }
    const clientByIdSeed = {};
    clients.forEach((c) => { clientByIdSeed[c.id] = c; });
    const debtorCandidates = clients.filter((c) => c.active !== false && c.creditLimit >= 100_000 && !['client-01', 'client-02', 'client-03', 'client-04'].includes(c.id));
    const debtors = [];
    for (let k = 0; k < 38; k += 1) debtors.push(debtorCandidates[Math.floor(k * debtorCandidates.length / 38)].id);
    const debtorSet = {};
    debtors.forEach((id) => { debtorSet[id] = true; });
    const namedPool = [];
    let namedTotal = 0;
    clients.forEach((c) => {
      if (c.active === false) return;
      const w = debtorSet[c.id] ? 4 : 1;
      namedPool.push([c.id, w]);
      namedTotal += w;
    });
    const saleClient = () => {
      if (seedNext() < 0.62) return 'counter';
      let roll = seedNext() * namedTotal;
      for (let i = 0; i < namedPool.length; i += 1) { roll -= namedPool[i][1]; if (roll <= 0) return namedPool[i][0]; }
      return namedPool[namedPool.length - 1][0];
    };
    const makeSale = (id, ms, forceClientId, forcePayment) => {
      const lineCount = seedWeighted([[1, 35], [2, 30], [3, 20], [4, 10], [5, 5]]);
      const used = {};
      const items = [];
      for (let l = 0; l < lineCount; l += 1) {
        const product = popularProduct(used);
        used[product.id] = true;
        let qty = seedWeighted([[1, 50], [2, 22], [3, 13], [4, 6], [5, 4], [6, 2]]);
        if (product.salePrice < 2000 && seedNext() < 0.03) qty = seedInt(7, 24);
        const unitPrice = qty >= 10 ? product.wholesalePrice : (seedNext() < 0.08 ? product.promoPrice : product.salePrice);
        items.push({ productId: product.id, quantity: qty, unitPrice, costPrice: product.purchasePrice });
      }
      const total = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
      const clientId = forceClientId || saleClient();
      let payment = forcePayment;
      if (!payment) {
        if (clientId === 'counter') payment = seedWeighted([['cash', 60], ['mobile', 30], ['card', 10]]);
        else if (debtorSet[clientId]) payment = seedWeighted([['credit', 70], ['cash', 14], ['mobile', 11], ['card', 5]]);
        else payment = seedWeighted([['cash', 50], ['mobile', 30], ['card', 20]]);
      }
      return { id, number: seedNumber('VTE', ms), date: new Date(ms).toISOString(), clientId, clientName: clientId === 'counter' ? 'Client comptoir' : clientByIdSeed[clientId].name, items, total, payment, status: 'Validée', userId: seedNext() < 0.65 ? 'user-admin' : 'user-vendeur' };
    };
    const sales = [
      { id: 'sale-01', number: `VTE-${dateCode(0)}-001`, date: isoDateTime(0, 8, 42), clientId: 'counter', clientName: 'Client comptoir', items: [{ productId: 'prod-01', quantity: 2, unitPrice: 900, costPrice: 650 }, { productId: 'prod-04', quantity: 3, unitPrice: 500, costPrice: 375 }], total: 3_300, payment: 'cash', status: 'Validée', userId: 'user-admin' },
      { id: 'sale-02', number: `VTE-${dateCode(-1)}-014`, date: isoDateTime(-1, 17, 26), clientId: 'client-01', clientName: 'Sira Traoré', items: [{ productId: 'prod-02', quantity: 2, unitPrice: 5_200, costPrice: 3_900 }, { productId: 'prod-06', quantity: 1, unitPrice: 1_250, costPrice: 920 }], total: 11_650, payment: 'credit', status: 'Validée', userId: 'user-admin' },
      { id: 'sale-03', number: `VTE-${dateCode(-2)}-009`, date: isoDateTime(-2, 12, 10), clientId: 'counter', clientName: 'Client comptoir', items: [{ productId: 'prod-07', quantity: 2, unitPrice: 1_650, costPrice: 1_150 }, { productId: 'prod-05', quantity: 2, unitPrice: 650, costPrice: 450 }], total: 4_600, payment: 'mobile', status: 'Validée', userId: 'user-admin' },
      { id: 'sale-04', number: `VTE-${dateCode(-4)}-018`, date: isoDateTime(-4, 14, 5), clientId: 'client-03', clientName: 'Café Wend-Panga', items: [{ productId: 'prod-01', quantity: 12, unitPrice: 900, costPrice: 650 }, { productId: 'prod-04', quantity: 24, unitPrice: 500, costPrice: 375 }], total: 22_800, payment: 'credit', status: 'Validée', userId: 'user-vendeur' },
      { id: 'sale-05', number: `VTE-${dateCode(-8)}-003`, date: isoDateTime(-8, 9, 12), clientId: 'counter', clientName: 'Client comptoir', items: [{ productId: 'prod-06', quantity: 4, unitPrice: 1_250, costPrice: 920 }, { productId: 'prod-08', quantity: 5, unitPrice: 800, costPrice: 575 }], total: 9_000, payment: 'card', status: 'Validée', userId: 'user-admin' }
    ];
    const generatedSales = [];
    let saleSeq = 6;
    const dedicatedCounts = debtors.map((debtorId, di) => 2 + (di % 4));
    dedicatedCounts.forEach((count, di) => {
      for (let k = 0; k < count; k += 1) {
        const ms = SEED_FIRST_DAY + Math.floor(seedNext() * (SEED_LAST_DAY - SEED_FIRST_DAY + DAY_MS));
        generatedSales.push(makeSale('sale-' + seedPad(saleSeq, 4), ms, debtors[di], 'credit'));
        saleSeq += 1;
      }
    });
    const dedicatedTotal = dedicatedCounts.reduce((a, b) => a + b, 0);
    const generalTotal = 3995 - dedicatedTotal;
    const dayPlan = [];
    let weightSum = 0;
    for (let i = 0; i < seedDayCount; i += 1) {
      const ms = SEED_FIRST_DAY + i * DAY_MS;
      const d = new Date(ms);
      const dow = d.getUTCDay();
      const month = d.getUTCMonth();
      let w = 0.45 + 0.55 * (i / (seedDayCount - 1));
      if (dow === 0) w *= 0.35; else if (dow === 6) w *= 1.5; else if (dow === 5) w *= 1.2;
      if (month === 11) w *= 1.6; else if (month === 10) w *= 1.15; else if (month === 7) w *= 0.8; else if (month === 3) w *= 0.9;
      weightSum += w;
      dayPlan.push({ ms, w, idx: i });
    }
    let assigned = 0;
    dayPlan.forEach((d) => { const raw = generalTotal * d.w / weightSum; d.count = Math.floor(raw); d.frac = raw - d.count; assigned += d.count; });
    const byFrac = dayPlan.slice().sort((a, b) => (b.frac - a.frac) || (a.idx - b.idx));
    for (let i = 0; i < generalTotal - assigned; i += 1) byFrac[i].count += 1;
    const saleHour = () => seedWeighted([[8, 4], [9, 8], [10, 10], [11, 9], [12, 6], [13, 3], [14, 5], [15, 7], [16, 9], [17, 10], [18, 8], [19, 5], [20, 2]]);
    dayPlan.forEach((d) => {
      for (let k = 0; k < d.count; k += 1) {
        const ms = d.ms + saleHour() * 3600000 + seedInt(0, 59) * 60000 + seedInt(0, 59) * 1000;
        generatedSales.push(makeSale('sale-' + seedPad(saleSeq, 4), ms));
        saleSeq += 1;
      }
    });
    generatedSales.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    generatedSales.forEach((s) => sales.push(s));
    const customerPayments = [];
    let paySeq = 1;
    debtors.forEach((debtorId, di) => {
      const credits = sales.filter((s) => s.payment === 'credit' && s.clientId === debtorId && s.status === 'Validée');
      const creditTotal = credits.reduce((sum, s) => sum + s.total, 0);
      if (!creditTotal) return;
      const firstMs = Math.min(...credits.map((s) => new Date(s.date).getTime()));
      const lastMs = Math.max(...credits.map((s) => new Date(s.date).getTime()));
      const coverage = 0.40 + seedNext() * 0.52;
      const due = Math.round(creditTotal * coverage / 100) * 100;
      const nPay = creditTotal > 200_000 ? 3 + (di % 4) : 1 + (di % 3);
      const totalH = Math.max(nPay, Math.round(due / 100));
      const cuts = [0];
      for (let c = 1; c < nPay; c += 1) cuts.push(seedInt(1, totalH - 1));
      cuts.push(totalH);
      cuts.sort((a, b) => a - b);
      const parts = [];
      for (let c = 1; c < cuts.length; c += 1) { const amt = (cuts[c] - cuts[c - 1]) * 100; if (amt > 0) parts.push(amt); }
      const windowEnd = Math.min(SEED_PAY_MAX, lastMs + 45 * DAY_MS);
      parts.forEach((amount) => {
        const span = Math.max(DAY_MS, windowEnd - firstMs - 2 * DAY_MS);
        const ms = firstMs + 2 * DAY_MS + Math.floor(seedNext() * span);
        const method = seedWeighted([['cash', 40], ['mobile', 35], ['card', 10], ['cheque', 15]]);
        customerPayments.push({ id: 'pay-' + seedPad(paySeq, 3), number: seedNumber('REG', ms), clientId: debtorId, date: seedDayLabel(ms), amount, method, reference: method === 'mobile' ? 'TXN' + seedPad(seedInt(0, 99999999), 8) : (method === 'cheque' ? 'CHQ' + seedPad(seedInt(0, 999999), 6) : ''), note: seedNext() < 0.25 ? 'Acompte' : '', status: 'Validé', userId: seedNext() < 0.6 ? 'user-admin' : 'user-vendeur', createdAt: new Date(ms).toISOString() });
        paySeq += 1;
      });
    });
    customerPayments.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    const deliveries = [
      { id: 'dlv-01', saleId: 'sale-02', saleNumber: `VTE-${dateCode(-1)}-014`, delivererId: 'liv-01', fee: 1_000, assignedAt: isoDateTime(-1, 18, 5), assignedBy: 'user-admin' }
    ];
    const activeDeliverers = deliverers.filter((d) => d.active !== false);
    const deliveryWeights = activeDeliverers.map((d) => [d.id, d.id === 'liv-01' ? 5 : (d.id === 'liv-02' ? 4 : 2)]);
    let deliveryWeightTotal = 0;
    deliveryWeights.forEach((w) => { deliveryWeightTotal += w[1]; });
    const pickDeliverer = () => {
      let roll = seedNext() * deliveryWeightTotal;
      for (let i = 0; i < deliveryWeights.length; i += 1) { roll -= deliveryWeights[i][1]; if (roll <= 0) return deliveryWeights[i][0]; }
      return deliveryWeights[0][0];
    };
    const delivererById = {};
    deliverers.forEach((d) => { delivererById[d.id] = d; });
    const deliveryCandidates = generatedSales.filter((s) => s.clientId !== 'counter' || s.total >= 5000);
    for (let i = deliveryCandidates.length - 1; i > 0; i -= 1) { const j = Math.floor(seedNext() * (i + 1)); const tmp = deliveryCandidates[i]; deliveryCandidates[i] = deliveryCandidates[j]; deliveryCandidates[j] = tmp; }
    const chosenDeliveries = deliveryCandidates.slice(0, 499);
    if (chosenDeliveries.length < 499) {
      const chosenIds = {};
      chosenDeliveries.forEach((s) => { chosenIds[s.id] = true; });
      for (let i = 0; i < generatedSales.length && chosenDeliveries.length < 499; i += 1) { if (!chosenIds[generatedSales[i].id]) { chosenDeliveries.push(generatedSales[i]); chosenIds[generatedSales[i].id] = true; } }
    }
    chosenDeliveries.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    chosenDeliveries.forEach((sale, index) => {
      const delivererId = pickDeliverer();
      const saleMs = new Date(sale.date).getTime();
      const ms = saleMs + seedInt(20, 200) * 60000;
      deliveries.push({ id: 'dlv-' + seedPad(index + 2, 4), saleId: sale.id, saleNumber: sale.number, delivererId, fee: delivererById[delivererId].baseRate + seedPick([0, 250, 500, 750, 1000]), assignedAt: new Date(ms).toISOString(), assignedBy: seedNext() < 0.6 ? 'user-admin' : 'user-vendeur' });
    });
    const stockEntries = [
      { id: 'entry-01', number: `ENT-${dateCode(-1)}-004`, date: isoDateTime(-1, 9, 20), type: 'Achat', supplierId: 'sup-01', invoice: 'FAC-2026-091', storeId: 'store-main', productId: 'prod-02', quantity: 40, unitPrice: 3_900, total: 156_000, status: 'Validé', stockApplied: true, userId: 'user-admin' },
      { id: 'entry-02', number: `ENT-${dateCode(0)}-005`, date: isoDateTime(0, 7, 55), type: 'Achat', supplierId: 'sup-02', invoice: 'FAC-2026-104', storeId: 'store-main', productId: 'prod-04', quantity: 60, unitPrice: 375, total: 22_500, status: 'En cours', stockApplied: false, userId: 'user-admin' },
      { id: 'entry-03', number: `ENT-${dateCode(-6)}-002`, date: isoDateTime(-6, 10, 10), type: 'Retour produit', supplierId: 'sup-03', invoice: 'RET-14', storeId: 'store-main', productId: 'prod-07', quantity: 12, unitPrice: 1_150, total: 13_800, status: 'Validé', stockApplied: true, userId: 'user-admin' }
    ];
    const entrySuppliers = suppliers.filter((s) => s.active !== false);
    const pickEntrySupplier = () => {
      const roll = seedNext();
      if (roll < 0.22) return 'sup-01';
      if (roll < 0.38) return 'sup-02';
      if (roll < 0.48) return 'sup-03';
      return seedPick(entrySuppliers).id;
    };
    const entryQty = (buy) => buy < 1000 ? seedInt(30, 200) : (buy > 10000 ? seedInt(2, 20) : seedInt(10, 80));
    const generatedEntries = [];
    for (let i = 0; i < 297; i += 1) {
      const recent = seedNext() < 0.3;
      const from = recent ? SEED_LAST_DAY - 120 * DAY_MS : SEED_FIRST_DAY;
      const ms = from + Math.floor(seedNext() * (SEED_LAST_DAY - from + DAY_MS));
      const supplierId = pickEntrySupplier();
      const choices = productsBySupplier[supplierId] && productsBySupplier[supplierId].length ? productsBySupplier[supplierId] : popList;
      const product = seedPick(choices);
      const quantity = entryQty(product.purchasePrice);
      const unitPrice = Math.max(5, Math.round(product.purchasePrice * (0.95 + seedNext() * 0.1) / 5) * 5);
      const type = seedNext() < 0.88 ? 'Achat' : 'Retour produit';
      generatedEntries.push({ id: 'entry-' + seedPad(i + 4, 4), number: seedNumber('ENT', ms), date: new Date(ms).toISOString(), type, supplierId, invoice: (type === 'Achat' ? 'FAC-' : 'RET-') + new Date(ms).getUTCFullYear() + '-' + seedPad(seedInt(1, 999), 3), storeId: seedNext() < 0.7 ? 'store-main' : 'store-reserve', productId: product.id, quantity, unitPrice, total: quantity * unitPrice, status: 'Validé', stockApplied: true, userId: seedNext() < 0.7 ? 'user-stock' : 'user-admin' });
    }
    generatedEntries.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    generatedEntries.slice(-8).forEach((e) => { e.status = 'En cours'; e.stockApplied = false; });
    generatedEntries.forEach((e) => stockEntries.push(e));
    const stockExits = [
      { id: 'exit-01', number: `SOR-${dateCode(-2)}-003`, date: isoDateTime(-2, 16, 30), type: 'Don', beneficiary: 'Association Wend Laafi', storeId: 'store-main', productId: 'prod-05', quantity: 8, unitPrice: 650, total: 5_200, status: 'Validé', stockApplied: true, userId: 'user-admin' },
      { id: 'exit-02', number: `SOR-${dateCode(0)}-004`, date: isoDateTime(0, 8, 5), type: 'Perte', beneficiary: 'Casse en réserve', storeId: 'store-main', productId: 'prod-03', quantity: 3, unitPrice: 800, total: 2_400, status: 'En cours', stockApplied: false, userId: 'user-admin' }
    ];
    const donBeneficiaries = ['Association Wend Laafi', 'Orphelinat Sainte Famille', 'Croix-Rouge BF', 'Association Sid Nooma', 'Centre d’accueil Suka'];
    const perteMotifs = ['Périmé en rayon', 'Casse en réserve', 'Avarié pendant le transport', 'Produit défectueux'];
    const generatedExits = [];
    for (let i = 0; i < 18; i += 1) {
      const ms = SEED_FIRST_DAY + Math.floor(seedNext() * (SEED_LAST_DAY - SEED_FIRST_DAY + DAY_MS));
      const type = seedWeighted([['Don', 30], ['Perte', 35], ['Vol', 10], ['Vente', 25]]);
      const product = seedPick(popList);
      const quantity = seedInt(1, 15);
      const beneficiary = type === 'Don' ? seedPick(donBeneficiaries) : (type === 'Perte' ? seedPick(perteMotifs) : (type === 'Vol' ? 'Vol constaté — plainte n° ' + seedInt(100, 999) + '/2026' : 'Vente directe marché'));
      generatedExits.push({ id: 'exit-' + seedPad(i + 3), number: seedNumber('SOR', ms), date: new Date(ms).toISOString(), type, beneficiary, storeId: seedNext() < 0.75 ? 'store-main' : 'store-reserve', productId: product.id, quantity, unitPrice: product.salePrice, total: quantity * product.salePrice, status: 'Validé', stockApplied: true, userId: seedNext() < 0.6 ? 'user-stock' : 'user-admin' });
    }
    generatedExits.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    generatedExits.slice(-2).forEach((e) => { e.status = 'En cours'; e.stockApplied = false; });
    generatedExits.forEach((e) => stockExits.push(e));
    const expenses = [
      { id: 'expense-01', number: `DEP-${dateCode(0)}-002`, date: isoDate(0), label: 'Transport et livraison', amount: 18_500, authorizedBy: 'Amadou Kaboré', executedBy: 'Mariam Ouedraogo', receipt: '', status: 'Validée' },
      { id: 'expense-02', number: `DEP-${dateCode(-3)}-001`, date: isoDate(-3), label: 'Électricité boutique', amount: 42_000, authorizedBy: 'Amadou Kaboré', executedBy: 'Amadou Kaboré', receipt: '', status: 'Validée' },
      { id: 'expense-03', number: `DEP-${dateCode(-8)}-001`, date: isoDate(-8), label: 'Petites fournitures', amount: 9_750, authorizedBy: 'Amadou Kaboré', executedBy: 'Mariam Ouedraogo', receipt: '', status: 'Validée' },
      { id: 'expense-04', number: `DEP-${dateCode(-12)}-001`, date: isoDate(-12), label: 'Communication digitale', amount: 25_000, authorizedBy: 'Amadou Kaboré', executedBy: 'Amadou Kaboré', receipt: '', status: 'Validée' }
    ];
    const orders = [
      { id: 'order-01', number: `CMD-${dateCode(-5)}-002`, date: isoDate(-5), type: 'Prévisionnelle', supplierId: 'sup-02', storeId: 'store-main', lines: [{ productId: 'prod-04', quantity: 120, unitPrice: 375 }], total: 45_000, status: 'Envoyée' },
      { id: 'order-02', number: `CMD-${dateCode(-1)}-003`, date: isoDate(-1), type: 'Urgente', supplierId: 'sup-01', storeId: 'store-main', lines: [{ productId: 'prod-03', quantity: 60, unitPrice: 550 }], total: 33_000, status: 'Brouillon' }
    ];
    const generatedOrders = [];
    for (let i = 0; i < 498; i += 1) {
      const ms = SEED_FIRST_DAY + Math.floor(seedNext() * (SEED_LAST_DAY - SEED_FIRST_DAY + DAY_MS));
      const supplierId = pickEntrySupplier();
      const choices = productsBySupplier[supplierId] && productsBySupplier[supplierId].length ? productsBySupplier[supplierId] : popList;
      const lineCount = Math.min(choices.length, seedWeighted([[1, 40], [2, 30], [3, 20], [4, 10]]));
      const usedLines = {};
      const lines = [];
      for (let l = 0; l < lineCount; l += 1) {
        let product = seedPick(choices);
        let guard = 0;
        while (usedLines[product.id] && guard < 10) { product = seedPick(choices); guard += 1; }
        if (usedLines[product.id]) continue;
        usedLines[product.id] = true;
        const quantity = entryQty(product.purchasePrice);
        lines.push({ productId: product.id, quantity, unitPrice: product.purchasePrice });
      }
      if (!lines.length) { const fallback = seedPick(choices); lines.push({ productId: fallback.id, quantity: entryQty(fallback.purchasePrice), unitPrice: fallback.purchasePrice }); }
      const total = lines.reduce((sum, line) => sum + line.quantity * line.unitPrice, 0);
      const type = seedWeighted([['Prévisionnelle', 50], ['Complémentaire', 25], ['Urgente', 15], ['Autre', 10]]);
      const cutoffOld = Date.UTC(2026, 6, 1);
      const cutoffMid = Date.UTC(2026, 7, 15);
      const status = ms < cutoffOld ? seedWeighted([['Réceptionnée', 90], ['Envoyée', 10]]) : (ms < cutoffMid ? seedWeighted([['Réceptionnée', 60], ['Envoyée', 25], ['Brouillon', 15]]) : seedWeighted([['Réceptionnée', 20], ['Envoyée', 45], ['Brouillon', 35]]));
      generatedOrders.push({ id: 'order-' + seedPad(i + 3, 4), number: seedNumber('CMD', ms), date: seedDayLabel(ms), type, supplierId, storeId: seedNext() < 0.7 ? 'store-main' : 'store-reserve', lines, total, status });
    }
    generatedOrders.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    generatedOrders.forEach((o) => orders.push(o));
    const transferNotes = ['Réassort boutique depuis la réserve', 'Équilibrage des stocks', 'Retour excédent vers la réserve', 'Préparation inventaire', 'Mise en rayon nouveautés'];
    const stockTransfers = [];
    for (let i = 0; i < 15; i += 1) {
      const recentBias = 1 - Math.pow(1 - seedNext(), 2);
      const ms = SEED_FIRST_DAY + Math.floor(recentBias * (SEED_LAST_DAY - SEED_FIRST_DAY + DAY_MS));
      const toMain = seedNext() < 0.67;
      const lineCount = seedWeighted([[1, 40], [2, 40], [3, 20]]);
      const usedLines = {};
      const lines = [];
      for (let l = 0; l < lineCount; l += 1) {
        const product = popularProduct(usedLines);
        usedLines[product.id] = true;
        lines.push({ productId: product.id, quantity: seedInt(5, 60) });
      }
      stockTransfers.push({ id: 'transfer-' + seedPad(i + 1), number: seedNumber('TRF', ms), date: seedDayLabel(ms), sourceStoreId: toMain ? 'store-reserve' : 'store-main', destinationStoreId: toMain ? 'store-main' : 'store-reserve', lines, note: seedPick(transferNotes), status: 'Validé', stockApplied: true, userId: seedNext() < 0.6 ? 'user-stock' : 'user-admin', createdAt: new Date(ms).toISOString() });
    }
    stockTransfers.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    stockTransfers.slice(-3).forEach((t) => { t.status = 'En cours'; t.stockApplied = false; });
    const monthLabels = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
    const reportDates = ['2024-10-31', '2024-12-31', '2025-02-28', '2025-04-30', '2025-06-30', '2025-08-31', '2025-10-31', '2025-12-31', '2026-02-28', '2026-04-30', '2026-06-30', '2026-08-31'];
    const inventoryReports = [];
    reportDates.forEach((reportDate, index) => {
      const parts = reportDate.split('-');
      const ms = Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]), 18, 0, 0);
      const lines = products.map((product, pIndex) => {
        let theoretical = Math.max(0, Math.round(product.stock * (0.75 + seedNext() * 0.5)));
        if (product.stock === 0 && seedNext() < 0.5) theoretical = seedInt(2, 12);
        const counted = seedNext() < 0.85;
        let real = null;
        let gap = null;
        if (counted) {
          const drift = seedNext() < 0.82 ? 0 : seedPick([-4, -3, -2, -1, 1, 2, 3, 4]);
          real = Math.max(0, theoretical + drift);
          gap = real - theoretical;
        }
        return { id: 'rin-' + seedPad(index + 1) + '-L' + seedPad(pIndex + 1, 3), productId: product.id, storeId: product.storeId || 'store-main', code: product.code, productName: product.name, categoryName: (categories.find((c) => c.id === product.categoryId) || {}).name || '', storeName: product.storeId === 'store-reserve' ? 'Réserve arrière' : 'Boutique centrale', theoretical, real, gap, counted, inventoryDate: reportDate };
      });
      const countedLines = lines.filter((line) => line.counted || line.real != null);
      const summary = {
        totalProducts: lines.length,
        countedProducts: countedLines.length,
        gapProducts: countedLines.filter((line) => Number(line.gap) !== 0).length,
        theoreticalTotal: lines.reduce((sum, line) => sum + Number(line.theoretical), 0),
        realTotal: countedLines.reduce((sum, line) => sum + Number(line.real), 0),
        gapTotal: countedLines.reduce((sum, line) => sum + Number(line.gap), 0)
      };
      inventoryReports.push({ id: 'invrep-' + seedPad(index + 1), number: seedNumber('RIN', ms), date: reportDate, title: 'Inventaire bimestriel — ' + monthLabels[Number(parts[1]) - 1] + ' ' + parts[0], storeId: '', lines, totalProducts: summary.totalProducts, countedProducts: summary.countedProducts, gapProducts: summary.gapProducts, theoreticalTotal: summary.theoreticalTotal, realTotal: summary.realTotal, gapTotal: summary.gapTotal, createdAt: new Date(ms).toISOString(), userId: 'user-stock' });
    });
    const inventory = [];
    for (let k = 0; k < 40; k += 1) {
      const product = products[(k * 2 + (k % 3)) % products.length];
      const real = Math.max(0, product.stock + seedPick([0, 0, 0, 1, -1, 2, -2]));
      inventory.push({ id: 'inv-' + seedPad(k + 1), productId: product.id, storeId: product.storeId || 'store-main', real, date: '2026-09-' + seedPad(15 + (k % 6)), userId: 'user-stock' });
    }
    const supplierProducts = products.filter((product) => product.supplierId).map((product) => ({ supplierId: product.supplierId, productId: product.id, createdAt: new Date().toISOString(), userId: 'system' }));
    return {
      version: 1,
      blankDatabase: false,
      initialSetupCompleted: false,
      settings: {
        businessName: 'NOVA Boutique', manager: 'Amadou Kaboré', managerPhone: '+226 70 12 45 87', commercialPhone: '+226 25 33 11 02', address: 'Avenue de la Nation, Ouagadougou', gps: '12.3714, -1.5197', email: 'contact@novaboutique.bf', rccm: 'BF OUA 2024 B 1245', fiscal: 'IFU 0008547R', currency: 'FCFA', vat: 18, stockAlert: 30, defaultStoreId: 'store-main', logo: '', theme: 'standard', disabledModules: [], inactivityLockMinutes: 15, ticketPrinter: { mode: 'browser', paperWidth: '80mm', baudRate: 9600, autoPrint: false, status: 'ready', deviceName: '' }
      },
      license: { trialStartedAt: new Date().toISOString(), activated: false, licenseKey: '', activatedAt: '' },
      categories, stores, suppliers, supplierProducts, products, clients, customerPayments, sales, deliverers, deliveries, creditNotes: [], refunds: [], stockEntries, stockExits, stockTransfers, expenses,
      orders,
      quotes: [
        { id: 'quote-01', number: `DEV-${dateCode(-3)}-001`, date: isoDate(-3), clientName: 'Clinique La Grâce', clientContact: '+226 25 37 10 90', clientAddress: 'Tampouy, Ouagadougou', lines: [{ productId: 'prod-07', quantity: 10, unitPrice: 1_650 }, { productId: 'prod-08', quantity: 20, unitPrice: 800 }], subtotal: 32_500, vat: 5_850, discount: 0, total: 38_350, status: 'Envoyé' }
      ],
      users: [
        { id: 'user-admin', name: 'Administrateur', username: PROTECTED_ADMIN_USERNAME, profile: 'Administrateur', active: true, passwordHash: SEED_PASSWORD_HASHES['user-admin'] },
        { id: 'user-vendeur', name: 'Mariam Ouedraogo', username: 'mariam', profile: 'Vendeur', active: true, passwordHash: SEED_PASSWORD_HASHES['user-vendeur'] },
        { id: 'user-stock', name: 'Issouf Zongo', username: 'issouf', profile: 'Magasinier', active: true, passwordHash: SEED_PASSWORD_HASHES['user-stock'] }
      ],
      roles: [
        { id: 'role-admin', name: 'Administrateur', description: 'Accès complet à tous les modules', users: 1, color: 'purple' },
        { id: 'role-manager', name: 'Gérant', description: 'Pilotage, ventes, stocks et rapports', users: 0, color: 'teal' },
        { id: 'role-seller', name: 'Vendeur', description: 'Ventes, clients et consultation produits', users: 1, color: 'blue' },
        { id: 'role-stock', name: 'Magasinier', description: 'Saisie d’un comptage', users: 1, color: 'orange' },
        { id: 'role-accounting', name: 'Comptable', description: 'Dépenses, bilans et comptabilité', users: 0, color: 'red' }
      ],
      inventory,
      inventoryReports,
      activities: [
        { id: 'act-01', date: isoDateTime(0, 9, 10), userId: 'user-admin', module: 'Ventes', action: 'Validation d’une vente', element: 'VTE-001', detail: '3 300 FCFA', oldValue: '', newValue: 'Validée' },
        { id: 'act-02', date: isoDateTime(0, 8, 5), userId: 'user-admin', module: 'Stocks', action: 'Création d’une sortie', element: 'SOR-004', detail: 'Perte · 3 unités', oldValue: '', newValue: 'En cours' },
        { id: 'act-03', date: isoDateTime(-1, 17, 31), userId: 'user-vendeur', module: 'Ventes', action: 'Validation d’une vente', element: 'VTE-014', detail: '11 650 FCFA', oldValue: '', newValue: 'Validée' },
        { id: 'act-04', date: isoDateTime(-2, 10, 25), userId: 'user-admin', module: 'Produits', action: 'Modification d’un prix', element: 'P-006', detail: 'Huile végétale 1 L', oldValue: '1 200', newValue: '1 250' },
        { id: 'act-05', date: isoDateTime(-3, 16, 44), userId: 'user-stock', module: 'Stocks', action: 'Validation d’une entrée', element: 'ENT-002', detail: '12 unités', oldValue: 'En cours', newValue: 'Validé' }
      ]
    };
  };

  function dateCode(offset = 0) {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    return `${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  }

  function isPasswordHash(value) {
    const hash = String(value || '');
    return /^pbkdf2-sha256\$[^$]+\$\d+\$[a-f0-9]{64}$/i.test(hash) || /^[a-f0-9]{64}$/i.test(hash);
  }
  function normalizeUsers(users, fallback) {
    const source = Array.isArray(users) && users.length ? users : fallback;
    return source.map((user) => {
      const base = fallback.find((item) => item.id === user.id || item.username === user.username) || {};
      return { ...base, ...user, passwordHash: isPasswordHash(user.passwordHash) ? user.passwordHash : base.passwordHash };
    });
  }
  function normalizeRoles(roles, fallback) {
    const source = Array.isArray(roles) && roles.length ? roles : fallback;
    return source.map((role) => {
      const base = fallback.find((item) => item.id === role.id || item.name === role.name) || {};
      const permissions = Array.isArray(role.permissions) && (role.permissions.length || !DEFAULT_ROLE_PERMISSIONS[role.name]) ? role.permissions : (DEFAULT_ROLE_PERMISSIONS[role.name] || []);
      return { ...base, ...role, permissions, users: num(role.users ?? base.users) };
    });
  }
  function enforceProtectedAdministrator() {
    state.users = Array.isArray(state.users) ? state.users : [];
    state.roles = Array.isArray(state.roles) ? state.roles : [];
    const existingProtected = state.users.find((user) => String(user.username || '') === PROTECTED_ADMIN_USERNAME);
    const legacyAdmin = state.users.find((user) => String(user.username || '').trim().toLowerCase() === 'admin');
    if (existingProtected && legacyAdmin && existingProtected !== legacyAdmin) state.users = state.users.filter((user) => user !== legacyAdmin);
    const admin = existingProtected || legacyAdmin || state.users.find((user) => user.id === 'user-admin') || state.users.find((user) => user.profile === 'Administrateur');
    const protectedAdmin = admin || { id: 'user-admin' };
    const passwordHash = admin && String(admin.username || '') === PROTECTED_ADMIN_USERNAME && isPasswordHash(admin.passwordHash) ? admin.passwordHash : SEED_PASSWORD_HASHES['user-admin'];
    Object.assign(protectedAdmin, { id: 'user-admin', name: 'Administrateur', username: PROTECTED_ADMIN_USERNAME, profile: 'Administrateur', active: true, passwordHash });
    if (!admin) state.users.unshift(protectedAdmin);
    const adminRole = state.roles.find((role) => role.name === 'Administrateur') || { id: 'role-admin', name: 'Administrateur', description: 'Accès complet à tous les modules', color: 'purple', users: 1 };
    adminRole.id = adminRole.id || 'role-admin';
    adminRole.permissions = ['*'];
    adminRole.users = Math.max(1, num(adminRole.users));
    if (!state.roles.some((role) => role.id === adminRole.id)) state.roles.unshift(adminRole);
  }
  function normalizeProductStock(product, stores = state?.stores || []) {
    const raw = product?.stockByStore && typeof product.stockByStore === 'object' ? product.stockByStore : null;
    const balances = {};
    if (raw && Object.keys(raw).length) Object.entries(raw).forEach(([storeId, quantity]) => { if (storeId) balances[storeId] = Math.max(0, num(quantity)); });
    else if (product?.storeId) balances[product.storeId] = Math.max(0, num(product.stock));
    stores.forEach((store) => { if (store?.id && balances[store.id] == null) balances[store.id] = 0; });
    product.stockByStore = balances;
    product.stock = Object.values(balances).reduce((sum, quantity) => sum + num(quantity), 0);
    if (!product.storeId) product.storeId = Object.keys(balances)[0] || stores[0]?.id || '';
    return product;
  }
  function normalizeAllProductStocks() {
    if (!state?.products) return;
    state.products.forEach((product) => normalizeProductStock(product, state.stores));
  }
  function normalizeSupplierProducts(links, products = state?.products || [], suppliers = state?.suppliers || [], deriveLegacy = !Array.isArray(links)) {
    const knownSuppliers = new Set((suppliers || []).map((supplier) => supplier.id));
    const knownProducts = new Set((products || []).map((product) => product.id));
    const source = Array.isArray(links) ? links : [];
    const normalized = [];
    const seen = new Set();
    source.forEach((link) => {
      const supplierId = String(link?.supplierId || '').trim();
      const productId = String(link?.productId || '').trim();
      const key = `${supplierId}::${productId}`;
      if (!supplierId || !productId || !knownSuppliers.has(supplierId) || !knownProducts.has(productId) || seen.has(key)) return;
      seen.add(key);
      normalized.push({ supplierId, productId, createdAt: link.createdAt || new Date().toISOString(), userId: link.userId || 'system' });
    });
    if (deriveLegacy) (products || []).forEach((product) => {
      const supplierId = String(product.supplierId || '').trim();
      const key = `${supplierId}::${product.id}`;
      if (!supplierId || !knownSuppliers.has(supplierId) || seen.has(key)) return;
      seen.add(key);
      normalized.push({ supplierId, productId: product.id, createdAt: new Date().toISOString(), userId: 'system' });
    });
    return normalized;
  }
  function supplierProductsFor(supplierId) {
    return (state.supplierProducts || []).filter((link) => link.supplierId === supplierId);
  }
  function supplierProductIds(supplierId) {
    return new Set(supplierProductsFor(supplierId).map((link) => link.productId));
  }
  function productSuppliers(productId) {
    const ids = new Set((state.supplierProducts || []).filter((link) => link.productId === productId).map((link) => link.supplierId));
    return state.suppliers.filter((supplier) => ids.has(supplier.id));
  }
  function stockFor(productOrId, storeId = '') {
    const product = typeof productOrId === 'string' ? productById(productOrId) : productOrId;
    if (!product) return 0;
    normalizeProductStock(product, state.stores);
    const target = storeId || product.storeId || state.stores[0]?.id;
    return num(product.stockByStore?.[target]);
  }
  function totalStock(productOrId) {
    const product = typeof productOrId === 'string' ? productById(productOrId) : productOrId;
    if (!product) return 0;
    normalizeProductStock(product, state.stores);
    return num(product.stock);
  }
  function setStockFor(productOrId, storeId, quantity) {
    const product = typeof productOrId === 'string' ? productById(productOrId) : productOrId;
    if (!product || !storeId) return false;
    normalizeProductStock(product, state.stores);
    if (!state.stores.some((store) => store.id === storeId)) return false;
    product.stockByStore[storeId] = num(quantity);
    product.stock = Object.values(product.stockByStore).reduce((sum, value) => sum + num(value), 0);
    return true;
  }
  function changeStock(productOrId, storeId, delta) {
    const product = typeof productOrId === 'string' ? productById(productOrId) : productOrId;
    if (!product || !storeId) return false;
    return setStockFor(product, storeId, stockFor(product, storeId) + num(delta));
  }
  function productSaleStore(product) {
    normalizeProductStock(product, state.stores);
    if (product.storeId && (stockFor(product, product.storeId) > 0 || state.settings.allowNegative)) return product.storeId;
    return Object.keys(product.stockByStore).find((storeId) => stockFor(product, storeId) > 0) || product.storeId || state.stores[0]?.id || '';
  }
  function stockSummary(product) {
    normalizeProductStock(product, state.stores);
    return Object.entries(product.stockByStore).filter(([, quantity]) => num(quantity) !== 0).map(([storeId, quantity]) => `${storeName(storeId)} : ${number(quantity)}`).join(' · ') || 'Aucun stock';
  }
  function creditNoteTotal(note) {
    return num(note?.total) || (note?.lines || []).reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0);
  }
  function creditNoteMargin(note) {
    return (note?.lines || []).reduce((sum, line) => sum + num(line.quantity) * (num(line.unitPrice) - num(line.costPrice ?? productById(line.productId)?.purchasePrice)), 0);
  }
  function validCreditNotes() { return (state.creditNotes || []).filter((note) => note.status === 'Validée'); }
  function creditNotesForSale(saleId) { return (state.creditNotes || []).filter((note) => note.originalSaleId === saleId && note.status !== 'Annulée'); }
  function creditNotesTotalForClient(clientId) {
    return validCreditNotes().filter((note) => note.clientId === clientId && note.payment === 'credit').reduce((sum, note) => sum + creditNoteTotal(note), 0);
  }
  function creditSalesTotal(clientId) {
    const sales = (state.sales || []).filter((sale) => sale.status === 'Validée' && sale.payment === 'credit' && sale.clientId === clientId);
    return sales.reduce((sum, sale) => sum + saleTotal(sale), 0) - creditNotesTotalForClient(clientId);
  }
  function creditPaymentsTotal(clientId) {
    return (state.customerPayments || []).filter((payment) => payment.status === 'Validé' && payment.clientId === clientId).reduce((sum, payment) => sum + num(payment.amount), 0);
  }
  function validRefunds() { return (state.refunds || []).filter((refund) => refund.status === 'Validée'); }
  function clientRefundsTotal(clientId) {
    return validRefunds().filter((refund) => refund.clientId === clientId && refund.notePayment === 'credit').reduce((sum, refund) => sum + num(refund.amount), 0);
  }
  function clientPositionValues(client) {
    const net = num(client?.openingReceivable) + creditSalesTotal(client?.id) - creditPaymentsTotal(client?.id) + clientRefundsTotal(client?.id);
    return { net, receivable: Math.max(0, net), advance: Math.max(0, -net) };
  }
  function creditNoteRefunded(noteId) {
    return validRefunds().filter((refund) => refund.noteId === noteId).reduce((sum, refund) => sum + num(refund.amount), 0);
  }
  function noteRefundableMax(note) {
    if (!note || note.status !== 'Validée') return 0;
    const remaining = Math.max(0, creditNoteTotal(note) - creditNoteRefunded(note.id));
    if (!noteBelongsToCredit(note)) return remaining;
    const client = (state.clients || []).find((item) => item.id === note.clientId);
    if (!client) return 0;
    return Math.min(remaining, num(client.advance));
  }
  function refundValidation(note, amount) {
    if (!note || note.status !== 'Validée') return { ok: false, error: 'Seul un avoir validé peut être remboursé.' };
    const value = Math.max(0, num(amount));
    if (!value) return { ok: false, error: 'Indiquez un montant d’au moins 1 FCFA.' };
    const remaining = Math.max(0, creditNoteTotal(note) - creditNoteRefunded(note.id));
    if (value > remaining) return { ok: false, error: 'Le remboursement ne peut pas dépasser le restant de l’avoir (' + money(remaining) + ').' };
    if (noteBelongsToCredit(note)) {
      const client = (state.clients || []).find((item) => item.id === note.clientId);
      if (!client) return { ok: false, error: 'Client introuvable : remboursement impossible.' };
      if (value > num(client.advance)) return { ok: false, error: 'Avance disponible insuffisante (' + money(num(client.advance)) + ').' };
    }
    return { ok: true, error: '' };
  }
  function noteOverpayment(note, previousAdvance) {
    if (!noteBelongsToCredit(note)) return 0;
    const client = (state.clients || []).find((item) => item.id === note.clientId);
    if (!client) return 0;
    return Math.max(0, num(client.advance) - num(previousAdvance));
  }
  function availableSaleQuantity(sale, line) {
    const used = creditNotesForSale(sale.id).reduce((sum, note) => sum + (note.lines || []).filter((item) => item.productId === line.productId).reduce((subtotal, item) => subtotal + num(item.quantity), 0), 0);
    return Math.max(0, num(line.quantity) - used);
  }
  function refreshClientReceivables() {
    state.customerPayments = Array.isArray(state.customerPayments) ? state.customerPayments : [];
    state.creditNotes = Array.isArray(state.creditNotes) ? state.creditNotes : [];
    state.refunds = Array.isArray(state.refunds) ? state.refunds : [];
    state.clients = Array.isArray(state.clients) ? state.clients : [];
    state.clients.forEach((client) => {
      if (client.openingReceivable == null) {
        client.openingReceivable = Math.max(0, num(client.receivable) - creditSalesTotal(client.id));
      }
      const position = clientPositionValues(client);
    client.receivable = position.receivable;
    client.advance = position.advance;
    });
  }
  function clientLedger(clientId) {
    const client = state.clients.find((item) => item.id === clientId);
    if (!client) return [];
    const sales = (state.sales || []).filter((sale) => sale.status === 'Validée' && sale.payment === 'credit' && sale.clientId === clientId).map((sale) => ({ date: sale.date, sortDate: sale.date, order: 1, type: 'Vente à crédit', reference: sale.number, debit: saleTotal(sale), credit: 0, method: 'Crédit', user: userName(sale.userId), detail: 'Vente validée' }));
    const notes = validCreditNotes().filter((note) => note.clientId === clientId && note.payment === 'credit').map((note) => ({ date: note.date, sortDate: `${note.date}T23:59:58`, order: 2, type: note.type === 'Annulation complète' ? 'Annulation de vente' : 'Avoir client', reference: note.number, debit: 0, credit: creditNoteTotal(note), method: 'Avoir', user: userName(note.userId), detail: `${note.originalSaleNumber} · ${note.reason}` }));
    const payments = (state.customerPayments || []).filter((payment) => payment.status === 'Validé' && payment.clientId === clientId).map((payment) => ({ date: payment.date, sortDate: `${payment.date}T23:59:59`, order: 3, type: 'Règlement', reference: payment.number, debit: 0, credit: num(payment.amount), method: paymentLabel(payment.method), user: userName(payment.userId), detail: payment.reference || payment.note || 'Paiement client' }));
    const refunds = (state.refunds || []).filter((refund) => refund.status === 'Validée' && refund.clientId === clientId && refund.notePayment === 'credit').map((refund) => ({ date: refund.date, sortDate: `${refund.date}T23:59:59`, order: 4, type: 'Remboursement', reference: refund.number, debit: num(refund.amount), credit: 0, method: paymentLabel(refund.method), user: userName(refund.userId), detail: `${refund.noteNumber || ''} · ${refund.reference || refund.note || 'Remboursement client'}` }));
    const opening = num(client.openingReceivable);
    return [{ date: '', sortDate: '', order: 0, type: 'Solde initial', reference: 'OUVERTURE', debit: opening, credit: 0, method: 'Report', user: '—', detail: 'Encours initial' }, ...sales, ...notes, ...payments, ...refunds].sort((left, right) => (left.sortDate || '').localeCompare(right.sortDate || '') || num(left.order) - num(right.order));
  }
  function roleForUser(user = currentUser) {
    if (!user) return null;
    return state.roles.find((role) => role.id === user.roleId || role.name === user.profile) || null;
  }
  function can(permission, user = currentUser) {
    if (!user) return false;
    const role = roleForUser(user);
    const permissions = Array.isArray(role?.permissions) ? role.permissions : (DEFAULT_ROLE_PERMISSIONS[user.profile] || []);
    return permissions.includes('*') || permissions.includes(permission);
  }
  function requirePermission(permission, message = 'Votre profil ne permet pas cette opération.') {
    if (!permission || can(permission)) return true;
    toast('Accès refusé', message, 'error');
    return false;
  }
  function bytesToHex(bytes) { return [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join(''); }
  function constantTimeEqual(left, right) {
    const a = String(left || '');
    const b = String(right || '');
    if (a.length !== b.length) return false;
    let result = 0;
    for (let index = 0; index < a.length; index += 1) result |= a.charCodeAt(index) ^ b.charCodeAt(index);
    return result === 0;
  }
  function randomPasswordSalt() {
    const bytes = new Uint8Array(16);
    if (window.crypto?.getRandomValues) window.crypto.getRandomValues(bytes); else bytes.fill(Math.floor(Math.random() * 255));
    return bytesToHex(bytes);
  }
  async function sha256Hex(value) {
    if (!window.crypto?.subtle) throw new Error('Le navigateur ne prend pas en charge le hachage sécurisé.');
    const buffer = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(value)));
    return bytesToHex(new Uint8Array(buffer));
  }
  async function derivePasswordDigest(password, salt, iterations = PASSWORD_ITERATIONS) {
    if (!window.crypto?.subtle) throw new Error('Le navigateur ne prend pas en charge le hachage sécurisé.');
    const key = await window.crypto.subtle.importKey('raw', new TextEncoder().encode(String(password)), 'PBKDF2', false, ['deriveBits']);
    const bits = await window.crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(String(salt)), iterations: Number(iterations), hash: 'SHA-256' }, key, 256);
    return bytesToHex(new Uint8Array(bits));
  }
  async function hashPassword(password) {
    const salt = randomPasswordSalt();
    const digest = await derivePasswordDigest(password, salt, PASSWORD_ITERATIONS);
    return `pbkdf2-sha256$${salt}$${PASSWORD_ITERATIONS}$${digest}`;
  }
  async function verifyPassword(password, storedHash) {
    const hash = String(storedHash || '');
    const parts = hash.match(/^pbkdf2-sha256\$([^$]+)\$(\d+)\$([a-f0-9]{64})$/i);
    if (parts) return constantTimeEqual(await derivePasswordDigest(password, parts[1], Number(parts[2])), parts[3]);
    if (/^[a-f0-9]{64}$/i.test(hash)) return constantTimeEqual(await sha256Hex(password), hash);
    return false;
  }

  function preserveCorruptStorage(raw) {
    const info = { detectedAt: new Date().toISOString(), backupKey: '', bytes: String(raw || '').length };
    try {
      let slot = CORRUPT_BACKUP_SLOTS.find((key) => !appStorage.getItem(key));
      if (!slot) {
        let oldest = CORRUPT_BACKUP_SLOTS[0];
        let oldestAt = null;
        CORRUPT_BACKUP_SLOTS.forEach((key) => {
          let at = null;
          try { at = JSON.parse(appStorage.getItem(key) || 'null')?.savedAt || null; } catch (_) { at = null; }
          if (oldestAt === null || (at !== null && at < oldestAt)) { oldestAt = at; oldest = key; }
        });
        slot = oldest;
      }
      appStorage.setItem(slot, JSON.stringify({ savedAt: info.detectedAt, raw: String(raw || '') }));
      info.backupKey = slot;
    } catch (_) { info.backupKey = ''; }
    return info;
  }
  function loadState() {
    const fresh = seedState();
    let raw = '';
    try { raw = appStorage.getItem(STORAGE_KEY) || ''; } catch (_) { raw = ''; }
    if (!raw) return fresh;
    let saved = null;
    try { saved = JSON.parse(raw); } catch (_) { saved = null; }
    if (!saved || typeof saved !== 'object') {
      storageCorruptInfo = preserveCorruptStorage(raw);
      return fresh;
    }
    try {
      const merged = { ...fresh, ...saved, settings: { ...fresh.settings, ...(saved.settings || {}), ticketPrinter: { ...fresh.settings.ticketPrinter, ...(saved.settings?.ticketPrinter || {}) } }, license: { ...fresh.license, ...(saved.license || {}) } };
      // Une ancienne installation possède déjà une base choisie : on ne lui affiche pas l’assistant.
      merged.initialSetupCompleted = saved.initialSetupCompleted !== false;
      merged.users = normalizeUsers(saved.users, fresh.users);
      merged.roles = normalizeRoles(saved.roles, fresh.roles);
      merged.customerPayments = Array.isArray(saved.customerPayments) ? saved.customerPayments : (fresh.customerPayments || []);
      merged.creditNotes = Array.isArray(saved.creditNotes) ? saved.creditNotes : (fresh.creditNotes || []);
      merged.refunds = Array.isArray(saved.refunds) ? saved.refunds : [];
      merged.stockTransfers = Array.isArray(saved.stockTransfers) ? saved.stockTransfers : (fresh.stockTransfers || []);
      merged.inventoryReports = Array.isArray(saved.inventoryReports) ? saved.inventoryReports : (fresh.inventoryReports || []);
      merged.deliverers = Array.isArray(saved.deliverers) ? saved.deliverers : [];
      merged.deliveries = Array.isArray(saved.deliveries) ? saved.deliveries : [];
      merged.supplierProducts = normalizeSupplierProducts(saved.supplierProducts, merged.products, merged.suppliers, !Array.isArray(saved.supplierProducts));
      merged.blankDatabase = saved.blankDatabase === true;
      if (merged.blankDatabase) {
        const savedUsers = Array.isArray(saved.users) ? saved.users : [];
        const savedRoles = Array.isArray(saved.roles) ? saved.roles : [];
        const adminUser = savedUsers.find((user) => user.id === 'user-admin' || String(user.username || '') === PROTECTED_ADMIN_USERNAME || user.profile === 'Administrateur');
        const adminRole = savedRoles.find((role) => role.name === 'Administrateur');
        merged.users = adminUser ? [adminUser] : [];
        merged.roles = adminRole ? [adminRole] : [];
        ['categories', 'stores', 'suppliers', 'supplierProducts', 'products', 'clients', 'customerPayments', 'sales', 'creditNotes', 'stockEntries', 'stockExits', 'stockTransfers', 'expenses', 'orders', 'quotes', 'inventory', 'inventoryReports', 'deliverers', 'deliveries'].forEach((key) => { merged[key] = []; });
      } else merged.products = Array.isArray(saved.products) && saved.products.length ? saved.products : fresh.products;
      merged.products.forEach((product) => normalizeProductStock(product, merged.stores));
      return merged;
    } catch (error) {
      if (raw && !storageCorruptInfo) storageCorruptInfo = preserveCorruptStorage(raw);
      return fresh;
    }
  }
  let state = loadState();
  state.roles = normalizeRoles(state.roles, seedState().roles);
  enforceProtectedAdministrator();
  normalizeAllProductStocks();
  state.supplierProducts = normalizeSupplierProducts(state.supplierProducts, state.products, state.suppliers, !Array.isArray(state.supplierProducts));
  state.inventoryReports = Array.isArray(state.inventoryReports) ? state.inventoryReports : [];
  state.license = { trialStartedAt: new Date().toISOString(), activated: false, licenseKey: '', licenseKeyDigest: '', activationTicket: '', activatedAt: '', ...(state.license || {}) };
  if (state.license.activated) { state.license.licenseKey = ''; }
  let initialSetupPending = state.initialSetupCompleted !== true;
  observeClockIntegrity();
  state.settings.theme = ['standard', 'clair', 'sombre'].includes(state.settings.theme) ? state.settings.theme : 'standard';
  state.settings.defaultStoreId = state.stores.some((store) => store.id === state.settings.defaultStoreId) ? state.settings.defaultStoreId : (state.stores[0]?.id || '');
  refreshClientReceivables();
  state.settings.ticketPrinter = { mode: 'browser', paperWidth: '80mm', baudRate: 9600, autoPrint: false, status: 'ready', deviceName: '', ...(state.settings.ticketPrinter || {}) };
  if (state.settings.ticketPrinter.mode !== 'browser' && state.settings.ticketPrinter.status === 'connected') state.settings.ticketPrinter.status = 'disconnected';
  let storedLicenseExists = false;
  try { storedLicenseExists = !!JSON.parse(appStorage.getItem(STORAGE_KEY) || 'null')?.license?.trialStartedAt; } catch (_) {}
  if (!storedLicenseExists && !initialSetupPending) saveState();
  let currentUser = null;
  let loginAttempts = 0;
  let loginLockedUntil = 0;
  let printerSession = { serialPort: null, usbDevice: null, usbInterface: null, usbEndpoint: null, bluetoothDevice: null, bluetoothCharacteristic: null };
  let activeView = appStorage.getItem('nova-active-view') || 'dashboard';
  let supplierLinkSupplierId = '';
  let designerUnlocked = false;
  let sidebarCollapsed = appStorage.getItem('nova-sidebar-collapsed') === '1';
  let saleCart = [];
  let saleDraft = { clientId: 'counter', payment: 'cash', storeId: '', priceType: 'retail' };
  let orderDraftLines = [];
  let expressOrderDraft = null;
  let quoteDraftLines = [];
  let creditNoteDraftLines = [];
  let transferDraftLines = [];
  let tablePages = {};
  let clickTimer = null;
  window.__novaDebug = {
    get state() { return state; },
    set user(u) { currentUser = u; },
    set draft(d) { expressOrderDraft = d; },
    save() { return saveState(); },
    seed() { return seedState(); },
    compute() { return computeExpressLines(activeProducts(), state.sales, 30, 21, ''); },
    generate() { return generateExpressOrders(); },
    render() { return render(); },
    saveSize() { return JSON.stringify(state).length; },
    exports: { csvExport, downloadBackup, printFullReport, printCurrentPage, saveTextFile, describeWriteFailure, storageUsage },
  };
  let sessionRecoveryPending = false;
  let sessionMonitorTimer = null;

  function saveState(options = {}) {
    if (isClockTampered(true)) {
      if (currentUser) toast('Blocage de sécurité', 'Les modifications sont désactivées pour tous les comptes après un recul de l’horloge.', 'warning');
      return false;
    }
    try {
      trimActivityLog();
      const snapshot = { ...state };
      if (!window.novaDesktop?.isElectron) delete snapshot.__resetDemo;
      appStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
      sessionRecoveryPending = false;
      return true;
    } catch (error) {
      console.error('NOVA: échec de persistance', error);
      const diagnostic = describeWriteFailure(error);
      if (!options.silent && diagnostic.kind === 'session') {
        sessionRecoveryPending = true;
        requestSessionRecovery(diagnostic);
        return false;
      }
      if (currentUser && !options.silent) toast(diagnostic.title, diagnostic.message, 'error');
      return false;
    }
  }
  // Qualifie l'échec d'écriture pour afficher un message exploitable au lieu d'un
  // message générique : session expirée (Desktop), quota saturé (PWA / APK), etc.
  function describeWriteFailure(error) {
    const code = String(error?.code || '');
    const name = String(error?.name || '');
    const message = String(error?.message || '');
    const usage = storageUsage();
    const percent = Math.round(usage.ratio * 100);
    if (code === 'NOVA_SESSION_EXPIRED' || /session/i.test(message)) {
      return {
        kind: 'session',
        title: 'Session expirée',
        message: 'Votre session a été fermée par la base locale (8 heures maximum). Reconnectez-vous : votre saisie est conservée et sera enregistrée immédiatement après.'
      };
    }
    if (code === 'NOVA_LICENSE_READONLY') {
      return {
        kind: 'license',
        title: 'Mode lecture seule',
        message: `${message || 'La période d’essai est terminée.'} Ouvrez le module Licence → Activation pour saisir votre code d’activation.`
      };
    }
    if (code === 'NOVA_INTEGRITY') {
      return { kind: 'integrity', title: 'Opération refusée', message: message || 'Une donnée déjà validée ne peut plus être modifiée. Créez une opération de correction.' };
    }
    if (code === 'NOVA_CLOCK_TAMPER') {
      return { kind: 'clock', title: 'Blocage de sécurité', message: 'L’horloge de cet appareil a reculé : les écritures sont bloquées pour tous les comptes.' };
    }
    if (code === 'NOVA_DB_MISSING') {
      return { kind: 'database', title: 'Base locale introuvable', message: 'Fermez puis relancez NOVA Commerce. Si le problème persiste, restaurez une sauvegarde.' };
    }
    if (code === 'NOVA_WRITE_DENIED' || /droits|permission|refus/i.test(message)) {
      return {
        kind: 'permission',
        title: 'Écriture refusée',
        message: `${message || 'La base locale a refusé cette opération pour ce profil.'} Vérifiez les droits dans Utilisateurs → Profils et droits.`
      };
    }
    if (name === 'QuotaExceededError' || name === 'NS_ERROR_DOM_QUOTA_REACHED' || /quota/i.test(message) || code === '22') {
      return {
        kind: 'quota',
        title: 'Stockage local saturé',
        message: `Le stockage de l’appareil est plein (${percent} % utilisés). Téléchargez une sauvegarde puis supprimez les anciennes données (Journal d’activité → Exports) avant de recommencer.`
      };
    }
    if (name === 'SecurityError' || /security/i.test(message)) {
      return {
        kind: 'security',
        title: 'Stockage bloqué',
        message: 'Le navigateur ou l’appareil bloque le stockage local (navigation privée ou cookies désactivés). Autorisez le stockage du site puis réessayez.'
      };
    }
    return {
      kind: 'unknown',
      title: 'Enregistrement impossible',
      message: `La session ou la base locale ne permet pas cette écriture (occupation du stockage : ${percent} %). Détail technique : ${message || name || 'inconnu'}.`
    };
  }
  // Reprise de session sans perte de saisie : l'application demande le mot de passe,
  // réauthentifie auprès de la base locale puis rejoue automatiquement l'écriture.
  function requestSessionRecovery(diagnostic = null) {
    if (!window.novaDesktop?.authenticate) {
      if (currentUser) toast(diagnostic?.title || 'Enregistrement impossible', diagnostic?.message || '', 'error');
      return;
    }
    if ($('#session-recovery-form')) return;
    const username = currentUser?.username || '';
    const body = `<div class="notice warning" style="margin-top:0"><span>⌛</span><div><strong>Session expirée</strong><span>Pour des raisons de sécurité, la base locale ferme la session après 8 heures. Votre dernière saisie n’a pas été perdue : elle sera enregistrée dès la reconnexion.</span></div></div>
      <form id="session-recovery-form"><div class="form-grid"><div class="field"><label>Utilisateur</label><input class="input-control" name="username" value="${esc(username)}" readonly></div><div class="field"><label>Mot de passe <em>*</em></label><input class="input-control" type="password" name="password" autocomplete="current-password" required></div></div><div class="field-hint">Seul le compte en cours doit confirmer son mot de passe.</div></form>`;
    const footer = `<button class="btn btn-secondary" type="button" data-close-modal>Plus tard</button><button class="btn btn-primary" type="submit" form="session-recovery-form">Se reconnecter et enregistrer</button>`;
    openModal('Session expirée', 'Reconnexion nécessaire pour enregistrer vos données.', body, 'sm', footer);
    $('#session-recovery-form')?.addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const data = Object.fromEntries(new FormData(form).entries());
      const button = footer.includes('submit') ? $('#modal-root button[type="submit"]') : null;
      if (button) button.disabled = true;
      let recovered = false;
      try {
        const remote = await window.novaDesktop.authenticate(String(data.username || username), String(data.password || ''));
        recovered = !!remote?.ok;
        if (recovered && remote.user && currentUser) currentUser = { ...currentUser, ...remote.user };
      } catch (_) { recovered = false; }
      if (button) button.disabled = false;
      if (!recovered) {
        setFormFeedback(form, 'Mot de passe incorrect.', 'error');
        return;
      }
      closeModal();
      const replayed = sessionRecoveryPending ? saveState() : true;
      render();
      toast('Session rétablie', replayed ? 'Votre saisie a été enregistrée.' : 'Connecté, mais l’écriture a été refusée à nouveau.', replayed ? 'success' : 'warning');
    });
  }
  function setFormFeedback(form, message, type = 'error') {
    let feedback = form.querySelector('.form-feedback');
    if (!feedback) {
      feedback = document.createElement('div');
      feedback.className = 'form-feedback';
      form.appendChild(feedback);
    }
    feedback.textContent = message;
    feedback.className = `form-feedback ${type}`;
  }
  function currentUserId() { return currentUser?.id || 'user-admin'; }
  function userInitials(user) {
    const value = user?.name || 'NOVA';
    return value.split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
  }
  function setLoginFeedback(message = '', type = '') {
    const feedback = $('#login-feedback');
    if (!feedback) return;
    feedback.textContent = message;
    feedback.className = `login-feedback ${type}`.trim();
  }
  function updateCurrentUserChrome() {
    const user = currentUser || { name: 'Administrateur', profile: 'Administrateur' };
    const initials = userInitials(user);
    const fields = [
      ['#sidebar-user-avatar', initials], ['#sidebar-user-name', user.name || user.username], ['#sidebar-user-profile', user.profile || 'Utilisateur'],
      ['#topbar-user-avatar', initials], ['#topbar-user-name', user.name || user.username], ['#topbar-user-profile', user.profile || 'Utilisateur']
    ];
    fields.forEach(([selector, value]) => { const node = $(selector); if (node) node.textContent = value; });
  }
  function showLogin(message = '', type = '') {
    const setup = $('#first-run-screen');
    const screen = $('#login-screen');
    const shell = $('#app-shell');
    if (setup) setup.hidden = true;
    if (shell) shell.hidden = true;
    if (screen) screen.hidden = false;
    document.body.classList.add('login-active');
    document.body.dataset.theme = state.settings.theme || 'standard';
    hydrateIcons(screen || document);
    if (message) setLoginFeedback(message, type);
    setTimeout(() => $('#login-username')?.focus(), 40);
  }
  function showInitialSetup() {
    const setup = $('#first-run-screen');
    const screen = $('#login-screen');
    const shell = $('#app-shell');
    if (screen) screen.hidden = true;
    if (shell) shell.hidden = true;
    if (setup) setup.hidden = false;
    document.body.classList.add('login-active');
    document.body.dataset.theme = state.settings.theme || 'standard';
    hydrateIcons(setup || document);
    renderCorruptStorageWarning();
    setTimeout(() => $('#first-run-screen [data-database-mode="demo"]')?.focus(), 40);
  }
  function renderCorruptStorageWarning() {
    if (!storageCorruptInfo) return;
    const card = document.querySelector('#first-run-screen .setup-card');
    if (!card || document.getElementById('corrupt-storage-warning')) return;
    const banner = document.createElement('div');
    banner.className = 'notice warning';
    banner.id = 'corrupt-storage-warning';
    const kept = storageCorruptInfo.backupKey
      ? `Une copie de sécurité automatique a été conservée sur cet appareil (${esc(storageCorruptInfo.backupKey)}).`
      : `Aucune copie automatique n'a pu être conservée (stockage inaccessible ou plein).`;
    banner.innerHTML = `<span>!</span><div><strong>Vos données précédentes sont illisibles</strong><span>Le stockage local semble endommagé. ${kept} Restaurez une sauvegarde JSON avant de choisir une base, sinon vos anciennes données seront remplacées.</span><div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap"><label class="btn btn-secondary btn-sm" style="cursor:pointer">Restaurer depuis un fichier<input type="file" id="corrupt-restore-file" accept="application/json,.json" hidden></label></div></div>`;
    card.prepend(banner);
    hydrateIcons(banner);
    document.getElementById('corrupt-restore-file')?.addEventListener('change', (event) => { restoreBackupAtBoot(event.target.files[0]); event.target.value = ''; });
  }
  function restoreBackupAtBoot(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      let data = null;
      try { data = JSON.parse(String(reader.result || '')); } catch (_) { data = null; }
      const error = validateBackupData(data);
      if (error) { toast('Restauration impossible', error, 'error'); return; }
      const payload = data.state && typeof data.state === 'object' ? data.state : data;
      const products = Array.isArray(payload.products) ? payload.products.length : 0;
      const sales = Array.isArray(payload.sales) ? payload.sales.length : 0;
      if (!window.confirm(`Restaurer cette sauvegarde (${number(products)} produits, ${number(sales)} ventes) ? Elle remplacera la base actuelle.`)) return;
      const currentLicense = state.license;
      state = { ...payload, license: currentLicense, initialSetupCompleted: true };
      if (!Array.isArray(state.deliverers)) state.deliverers = [];
      if (!Array.isArray(state.deliveries)) state.deliveries = [];
      enforceProtectedAdministrator();
      normalizeAllProductStocks();
      refreshClientReceivables();
      storageCorruptInfo = null;
      initialSetupPending = false;
      saveState();
      showLogin('Base restaurée. Identifiez-vous pour continuer.', 'success');
      toast('Base restaurée', 'Vos données ont été récupérées depuis la sauvegarde.');
    };
    reader.readAsText(file);
  }
  function showApplication() {
    const setup = $('#first-run-screen');
    const screen = $('#login-screen');
    const shell = $('#app-shell');
    if (setup) setup.hidden = true;
    if (screen) screen.hidden = true;
    if (shell) shell.hidden = false;
    document.body.classList.remove('login-active');
    updateCurrentUserChrome();
    startDesktopSessionMonitor();
    render();
  }
  // Desktop Electron : la session de la base locale expire au bout de 8 heures.
  // Ce battement maintient la session active (renouvellement glissant côté main.cjs)
  // et prévient l'utilisateur avant toute perte de saisie si elle est déjà fermée.
  function startDesktopSessionMonitor() {
    if (!window.novaDesktop?.session || sessionMonitorTimer) return;
    sessionMonitorTimer = window.setInterval(async () => {
      if (!currentUser) return;
      try {
        const status = await window.novaDesktop.session();
        if (status && status.ok === false) requestSessionRecovery({
          title: 'Session expirée',
          message: 'La base locale a fermé la session. Reconnectez-vous pour continuer à enregistrer.'
        });
      } catch (_) { /* la base locale reste la référence : l'écriture signalera l'erreur */ }
    }, 5 * 60 * 1000);
  }
  async function submitLogin(event) {
    event.preventDefault();
    const form = event.currentTarget;
    if (currentUser) return;
    if (Date.now() < loginLockedUntil) {
      const seconds = Math.ceil((loginLockedUntil - Date.now()) / 1000);
      setLoginFeedback(`Trop de tentatives. Réessayez dans ${seconds} seconde(s).`, 'error');
      return;
    }
    const data = Object.fromEntries(new FormData(form).entries());
    const username = String(data.username || '').trim().toLowerCase();
    const password = String(data.password || '');
    if (!username || !password) { setLoginFeedback('Saisissez votre nom d’utilisateur et votre mot de passe.', 'error'); return; }
    const button = form.querySelector('button[type="submit"]');
    if (button) { button.disabled = true; button.innerHTML = `${icon('loader-circle', 16)} Vérification…`; }
    let user = state.users.find((item) => item.active !== false && String(item.username || '').trim().toLowerCase() === username);
    let valid = false;
    try {
      if (window.novaDesktop?.authenticate) {
        const remote = await window.novaDesktop.authenticate(username, password);
        valid = !!remote?.ok;
        if (remote?.clockIntegrity) observeClockIntegrity(remote.clockIntegrity);
        if (remote?.user) user = { ...user, ...remote.user };
      } else {
        valid = !!user && await verifyPassword(password, user.passwordHash);
      }
    } catch (_) { valid = false; }
    if (button) { button.disabled = false; button.innerHTML = `${icon('log-in', 17)} Se connecter`; }
    if (!valid || !user) {
      loginAttempts += 1;
      const remaining = LOGIN_MAX_ATTEMPTS - loginAttempts;
      if (remaining <= 0) { loginLockedUntil = Date.now() + LOGIN_LOCK_MS; loginAttempts = 0; setLoginFeedback('Trop de tentatives incorrectes. Accès temporairement suspendu pendant 30 secondes.', 'error'); }
      else setLoginFeedback(`Identifiants incorrects. Il reste ${remaining} tentative(s).`, 'error');
      return;
    }
    currentUser = { ...user };
    loginAttempts = 0;
    loginLockedUntil = 0;
    if (!isClockTampered()) {
      addActivity('Sécurité', 'Connexion', user.username, 'Connexion réussie');
      saveState();
    }
    form.reset();
    showApplication();
    resetInactivityTimer();
  }
  function bindAuthentication() {
    const form = $('#login-form');
    if (form) form.addEventListener('submit', submitLogin);
    const toggle = $('#login-toggle-password');
    const password = $('#login-password');
    if (toggle && password) toggle.addEventListener('click', () => {
      const visible = password.type === 'text';
      password.type = visible ? 'password' : 'text';
      toggle.innerHTML = icon(visible ? 'eye' : 'eye-off', 16);
      toggle.setAttribute('aria-label', visible ? 'Afficher le mot de passe' : 'Masquer le mot de passe');
    });
  }
  async function synchronizeDesktopClockIntegrity() {
    if (!window.novaDesktop?.getClockStatus) return;
    try {
      const remote = await window.novaDesktop.getClockStatus();
      if (!remote) return;
      const status = observeClockIntegrity(remote);
      if (status.tampered && !currentUser) setLoginFeedback('Modification suspecte de la date système détectée. L’application sera disponible en lecture seule pour tous les comptes.', 'error');
      if (currentUser) render();
    } catch (_) {}
  }
  function startClockIntegrityMonitor() {
    let knownTampered = isClockTampered();
    window.setInterval(() => {
      const status = observeClockIntegrity();
      if (status.tampered && !knownTampered) {
        if (currentUser) render();
        else setLoginFeedback('Modification suspecte de la date système détectée. L’application sera disponible en lecture seule pour tous les comptes.', 'error');
      }
      knownTampered = status.tampered;
    }, 60_000);
  }
  function resetInactivityTimer() {
    if (inactivityTimer) { clearTimeout(inactivityTimer); inactivityTimer = null; }
    if (!currentUser) return;
    const minutes = num(state.settings?.inactivityLockMinutes ?? 15);
    if (!minutes || minutes <= 0) return;
    inactivityTimer = setTimeout(lockForInactivity, Math.min(minutes, 240) * 60 * 1000);
  }
  function lockForInactivity() {
    inactivityTimer = null;
    if (!currentUser) return;
    addActivity('Sécurité', 'Verrouillage automatique', currentUser.username, 'Session verrouillée après inactivité.');
    try { saveState(); } catch (_) {}
    currentUser = null;
    designerUnlocked = false;
    saleCart = [];
    try { window.novaDesktop?.logout?.(); } catch (_) {}
    closeModal();
    showLogin('Session verrouillée pour cause d’inactivité. Identifiez-vous pour continuer.', 'warning');
    toast('Session verrouillée', 'Reconnectez-vous pour continuer.', 'warning');
  }
  function bindInactivityMonitor() {
    ['click', 'keydown', 'touchstart'].forEach((evt) => document.addEventListener(evt, () => resetInactivityTimer(), { passive: true }));
  }
  function logout() {
    if (inactivityTimer) { clearTimeout(inactivityTimer); inactivityTimer = null; }
    if (currentUser && !isClockTampered()) { addActivity('Sécurité', 'Déconnexion', currentUser.username, 'Session fermée'); saveState(); }
    try { window.novaDesktop?.logout?.(); } catch (_) {}
    currentUser = null;
    designerUnlocked = false;
    saleCart = [];
    saleDraft = { clientId: 'counter', payment: 'cash', storeId: '', priceType: 'retail' };
    closeModal();
    showLogin('Session fermée. Identifiez-vous pour continuer.', 'success');
  }
  function chooseInitialDatabase(mode) {
    if (!initialSetupPending || !['demo', 'fresh'].includes(mode)) return;
    if (mode === 'fresh' && !window.confirm('Commencer avec une base neuve ? Les données de démonstration ne seront pas chargées sur cet appareil.')) return;
    const license = { ...(state.license || {}) };
    if (mode === 'demo') {
      state.initialSetupCompleted = true;
      state.blankDatabase = false;
      state.license = license;
    } else {
      const fresh = seedState();
      state = {
        ...fresh,
        initialSetupCompleted: true,
        blankDatabase: true,
        license,
        categories: [], stores: [], suppliers: [], supplierProducts: [], products: [], clients: [], customerPayments: [], sales: [], creditNotes: [], refunds: [], stockEntries: [], stockExits: [], stockTransfers: [], expenses: [], orders: [], quotes: [], inventory: [], inventoryReports: [], deliverers: [], deliveries: [],
        activities: [{ id: uid('act'), date: new Date().toISOString(), userId: 'system', module: 'Administration', action: 'Initialisation de la base', element: 'Base locale', detail: 'Base neuve choisie au premier démarrage.', oldValue: '', newValue: 'Base vide' }],
        users: [],
        roles: []
      };
      enforceProtectedAdministrator();
      state.settings.defaultStoreId = '';
      normalizeAllProductStocks();
      refreshClientReceivables();
    }
    if (!saveState()) return;
    initialSetupPending = false;
    showLogin(mode === 'demo' ? 'Données de démonstration chargées. Connectez-vous pour continuer.' : 'Base neuve créée. Connectez-vous avec le compte Administrateur.', 'success');
  }
  function categoryName(id) { return state.categories.find((item) => item.id === id)?.name || 'Sans catégorie'; }
  function storeName(id) { return state.stores.find((item) => item.id === id)?.name || '—'; }
  function supplierName(id) { return state.suppliers.find((item) => item.id === id)?.name || '—'; }
  function clientName(id) { return id === 'counter' ? 'Client comptoir' : (state.clients.find((item) => item.id === id)?.name || 'Client inconnu'); }
  function delivererName(id) { const deliverer = (state.deliverers || []).find((item) => item.id === id); return deliverer ? `${deliverer.firstName || ''} ${deliverer.lastName || ''}`.trim() : '—'; }
  function deliveryForSale(saleId) { return (state.deliveries || []).find((item) => item.saleId === saleId) || null; }
  function userName(id) { return state.users.find((item) => item.id === id)?.name || 'Administrateur'; }
  function productById(id) { return state.products.find((item) => item.id === id); }
  function productName(id) { return productById(id)?.name || 'Produit supprimé'; }
  function activeProducts() { return state.products.filter((product) => product.active !== false); }
  const SALE_PRICE_TYPES = [
    { key: 'retail', label: 'Prix de vente', field: 'salePrice' },
    { key: 'wholesale', label: 'Prix de gros', field: 'wholesalePrice' },
    { key: 'promo', label: 'Prix promotionnel', field: 'promoPrice' }
  ];
  function salePriceTypeLabel(key) { return SALE_PRICE_TYPES.find((item) => item.key === key)?.label || 'Prix de vente'; }
  function productPriceForSale(product, priceType) {
    if (!product) return 0;
    const field = SALE_PRICE_TYPES.find((item) => item.key === (priceType || saleDraft.priceType))?.field || 'salePrice';
    const specific = num(product[field]);
    return specific > 0 ? specific : num(product.salePrice);
  }
  function setSalePriceType(priceType) {
    if (!SALE_PRICE_TYPES.some((item) => item.key === priceType)) return;
    if (!requirePermission('sales.create', 'Votre profil ne peut pas préparer une vente.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour préparer une nouvelle vente.', 'warning'); render(); return; }
    saleDraft.priceType = priceType;
    saleCart.forEach((line) => { const product = productById(line.productId); if (product) line.unitPrice = productPriceForSale(product, priceType); });
    render();
    toast('Prix de vente sélectionné', `${salePriceTypeLabel(priceType)} appliqué au panier.`);
  }
  function validSales() { return (state.sales || []).filter((sale) => sale.status === 'Validée'); }
  function saleTotal(sale) { return num(sale.total) || (sale.items || []).reduce((sum, item) => sum + num(item.quantity) * num(item.unitPrice), 0); }
  function saleMargin(sale) { return (sale.items || []).reduce((sum, item) => sum + num(item.quantity) * (num(item.unitPrice) - num(item.costPrice ?? productById(item.productId)?.purchasePrice)), 0); }
  function creditNoteSale(note) { return (state.sales || []).find((sale) => sale.id === note?.originalSaleId) || null; }
  function noteBelongsToCredit(note) {
    const sale = creditNoteSale(note);
    return sale ? sale.payment === 'credit' : note?.payment === 'credit';
  }
  function creditNoteAdjustmentsBySale() {
    const adjustments = {};
    validCreditNotes().filter((note) => noteBelongsToCredit(note)).forEach((note) => {
      const key = note.originalSaleId || '';
      if (!key) return;
      adjustments[key] = adjustments[key] || { total: 0, margin: 0 };
      adjustments[key].total += creditNoteTotal(note);
      adjustments[key].margin += creditNoteMargin(note);
    });
    return adjustments;
  }
  function creditCollectionRatios() {
    // Part encaissée (0..1) de chaque vente à crédit validée : les règlements
    // du client soldent d'abord son report initial (sans marge), puis ses
    // ventes à crédit les plus anciennes, avoirs déduits. Les ventes au
    // comptant (cash, mobile, carte) sont encaissées à 100 % par construction.
    const ratios = {};
    const adjustments = creditNoteAdjustmentsBySale();
    (state.clients || []).forEach((client) => {
      const creditSales = validSales()
        .filter((sale) => sale.payment === 'credit' && sale.clientId === client.id)
        .sort((a, b) => String(a.date).localeCompare(String(b.date)) || String(a.number || '').localeCompare(String(b.number || '')));
      let remaining = creditPaymentsTotal(client.id) - num(client.openingReceivable);
      creditSales.forEach((sale) => {
        const net = saleTotal(sale) - num(adjustments[sale.id]?.total);
        if (net > 0 && remaining > 0) {
          ratios[sale.id] = Math.min(1, remaining / net);
          remaining -= Math.min(net, remaining);
        } else {
          ratios[sale.id] = 0;
        }
      });
    });
    return { ratios, adjustments };
  }
  function saleCollectedMargin(sale, collection) {
    if (!sale || sale.status !== 'Validée') return 0;
    if (sale.payment !== 'credit') return saleMargin(sale);
    const ratios = collection?.ratios || {};
    const adjustments = collection?.adjustments || {};
    return (saleMargin(sale) - num(adjustments[sale.id]?.margin)) * (num(ratios[sale.id]) || 0);
  }
  function collectedMarginOf(sales, notes, collection) {
    // Marge encaissée : ventes au comptant à 100 % + ventes à crédit au
    // prorata des règlements reçus, avoirs au comptant déduits (les avoirs
    // sur crédit liés à une vente sont déjà déduits vente par vente dans le
    // prorata ; un avoir sur crédit sans vente d'origine est déduit globalement).
    const list = sales || [];
    const cashPart = list.filter((sale) => sale.payment !== 'credit').reduce((sum, sale) => sum + saleMargin(sale), 0);
    const creditPart = list.filter((sale) => sale.payment === 'credit').reduce((sum, sale) => sum + saleCollectedMargin(sale, collection), 0);
    const notesPart = (notes || []).filter((note) => !noteBelongsToCredit(note) || !note.originalSaleId).reduce((sum, note) => sum + creditNoteMargin(note), 0);
    return cashPart + creditPart - notesPart;
  }
  function netSalesRevenue(sales = validSales()) {
    const ids = new Set(sales.map((sale) => sale.id));
    return sales.reduce((sum, sale) => sum + saleTotal(sale), 0) - validCreditNotes().filter((note) => ids.has(note.originalSaleId)).reduce((sum, note) => sum + creditNoteTotal(note), 0);
  }
  function netSalesMargin(sales = validSales()) {
    const ids = new Set(sales.map((sale) => sale.id));
    return sales.reduce((sum, sale) => sum + saleMargin(sale), 0) - validCreditNotes().filter((note) => ids.has(note.originalSaleId)).reduce((sum, note) => sum + creditNoteMargin(note), 0);
  }
  function netSalesQuantity(sales = validSales()) {
    const ids = new Set(sales.map((sale) => sale.id));
    return sales.reduce((sum, sale) => sum + (sale.items || []).reduce((subtotal, item) => subtotal + num(item.quantity), 0), 0) - validCreditNotes().filter((note) => ids.has(note.originalSaleId)).reduce((sum, note) => sum + (note.lines || []).reduce((subtotal, item) => subtotal + num(item.quantity), 0), 0);
  }
  function productStockState(product) {
    if (!product) return { key: 'out', label: 'Rupture', className: 'danger' };
    const stock = totalStock(product);
    if (stock <= 0) return { key: 'out', label: 'Rupture', className: 'danger' };
    if (stock <= num(product.minStock)) return { key: 'low', label: 'Stock faible', className: 'warning' };
    if (num(product.maxStock) > 0 && stock >= num(product.maxStock)) return { key: 'high', label: 'Stock élevé', className: 'info' };
    return { key: 'normal', label: 'Stock normal', className: 'success' };
  }
  // Helper sûr par construction : le statut affiché passe par esc() et la table de
  // correspondance est interne (aucune donnée utilisateur dans les classes CSS).
  function statusBadge(status, map = {}) {
    const key = map[status] || ({ 'Validée': 'success', 'Validé': 'success', 'En cours': 'warning', 'Brouillon': 'neutral', 'Envoyée': 'info', 'Envoyé': 'info', 'Réceptionnée': 'success', 'Annulée': 'danger' }[status] || 'neutral');
    return `<span class="status-badge ${key}">${esc(status)}</span>`;
  }
  function actionButtons(editAction, id, extra = '') {
    return `<div class="table-actions"><button class="table-action" type="button" data-action="${editAction}" data-id="${esc(id)}" title="Consulter / modifier">✎</button>${extra}</div>`;
  }
  function options(items, selected, labelKey = 'name', blank = '') {
    const blankOption = blank !== null ? `<option value="">${blank || 'Sélectionner'}</option>` : '';
    return blankOption + items.map((item) => `<option value="${esc(item.id)}" ${item.id === selected ? 'selected' : ''}>${esc(typeof labelKey === 'function' ? labelKey(item) : item[labelKey])}</option>`).join('');
  }
  function paymentLabel(payment) { return ({ cash: 'Cash', mobile: 'Mobile Money', card: 'Carte', cheque: 'Chèque', credit: 'À crédit' }[payment] || payment); }
  function paymentBadge(payment) {
    const color = payment === 'credit' ? 'warning' : payment === 'cash' ? 'success' : payment === 'mobile' ? 'info' : 'neutral';
    return `<span class="status-badge ${color}">${esc(paymentLabel(payment))}</span>`;
  }
  function emptyState(title, message = 'Aucun élément à afficher pour le moment.') {
    return `<div class="empty-state"><div class="empty-icon">⌁</div><strong>${esc(title)}</strong><p>${esc(message)}</p></div>`;
  }
  function pageHeading(title, subtitle, actions = '') {
    return `<div class="page-heading"><div><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></div><div class="page-heading-actions">${actions}</div></div>`;
  }
  function toolbar(searchPlaceholder, target, actions = '', filters = '') {
    return `<div class="toolbar"><div class="toolbar-left"><label class="search-field"><span>⌕</span><input type="search" placeholder="${esc(searchPlaceholder)}" data-filter-input data-filter-target="${esc(target)}" autocomplete="off" /></label>${filters}</div><div class="toolbar-right">${actions}</div></div>`;
  }
  // Convention XSS « HTML DE CONFIANCE » : ce helper reçoit du HTML déjà composé par
  // l’appelant et ne l’échappe PAS. Toute donnée utilisateur/serveur doit passer dans
  // esc() AVANT l’appel (appelants vérifiés sûrs par audit le 21/09/2026).
  function panel(title, subtitle, body, link = '') {
    return `<section class="panel"><div class="panel-header"><div><div class="panel-title">${title}</div>${subtitle ? `<div class="panel-subtitle">${subtitle}</div>` : ''}</div>${link}</div><div class="panel-body">${body}</div></section>`;
  }
  // Convention XSS « HTML DE CONFIANCE » : ce helper reçoit du HTML déjà composé par
  // l’appelant et ne l’échappe PAS. Toute donnée utilisateur/serveur doit passer dans
  // esc() AVANT l’appel (appelants vérifiés sûrs par audit le 21/09/2026).
  function metricCard(iconName, label, value, trend, extra, tone = 'teal') {
    const iconMap = { '↗': 'trending-up', '◒': 'circle-dollar-sign', '▣': 'badge-dollar-sign', '◇': 'receipt', '✦': 'sparkles', '▤': 'package', '₣': 'coins', '!': 'triangle-alert' };
    return `<article class="metric-card ${tone}"><div class="metric-top"><div class="metric-icon">${icon(iconMap[iconName] || iconName, 16)}</div></div><div class="metric-label">${label}</div><div class="metric-value">${value}</div><div class="metric-footer"><span class="metric-trend ${trend?.className || 'neutral'}">${trend?.text || '—'}</span><span class="metric-extra">${extra || ''}</span></div></article>`;
  }

  const VIEW_META = {
    dashboard: ['Pilotage', 'Tableau de bord'], sale: ['Ventes', 'Nouvelle vente'], sales: ['Ventes', 'Historique des ventes'], clients: ['Relations', 'Clients'], deliverers: ['Exploitation', 'Livreurs'],
    products: ['Catalogue', 'Produits'], categories: ['Catalogue', 'Catégories'], stores: ['Catalogue', 'Magasins'], suppliers: ['Catalogue', 'Fournisseurs'],
    entries: ['Stocks', 'Entrées de stock'], exits: ['Stocks', 'Sorties de stock'], transfers: ['Stocks', 'Transferts inter-magasins'], orders: ['Stocks', 'Commandes fournisseurs'], inventory: ['Stocks', 'Inventaire'],
    quotes: ['Finance', 'Devis'], 'credit-notes': ['Finance', 'Avoirs & annulations'], 'purchase-report': ['Finance', 'Bilan des achats'], 'sales-report': ['Finance', 'Bilan des ventes'], expenses: ['Finance', 'Dépenses'], 'expense-report': ['Finance', 'Bilan des dépenses'], accounting: ['Finance', 'Comptabilité'],
    reports: ['Administration', 'Rapports'], users: ['Administration', 'Utilisateurs'], roles: ['Administration', 'Profils & droits'], activity: ['Administration', "Journal d'activité"], license: ['Administration', 'Licence'], guide: ['Assistance', 'Guide utilisateur'], contact: ['Assistance', 'Nous contacter'], settings: ['Administration', 'Paramètres']
  };

  function renderDashboard() {
    const sales = validSales();
    const today = todayKey();
    const month = currentMonthKey();
    const daySales = sales.filter((sale) => sale.date.slice(0, 10) === today);
    const monthSales = sales.filter((sale) => monthKey(sale.date) === month);
    const dayNotes = validCreditNotes().filter((note) => String(note.date).slice(0, 10) === today);
    const monthNotes = validCreditNotes().filter((note) => monthKey(note.date) === month);
    const dayRevenue = daySales.reduce((sum, sale) => sum + saleTotal(sale), 0) - dayNotes.reduce((sum, note) => sum + creditNoteTotal(note), 0);
    const monthRevenue = monthSales.reduce((sum, sale) => sum + saleTotal(sale), 0) - monthNotes.reduce((sum, note) => sum + creditNoteTotal(note), 0);
    const dayMargin = daySales.reduce((sum, sale) => sum + saleMargin(sale), 0) - dayNotes.reduce((sum, note) => sum + creditNoteMargin(note), 0);
    const monthMargin = monthSales.reduce((sum, sale) => sum + saleMargin(sale), 0) - monthNotes.reduce((sum, note) => sum + creditNoteMargin(note), 0);
    const monthExpenses = state.expenses.filter((expense) => expense.status !== 'Annulée' && monthKey(expense.date) === month).reduce((sum, expense) => sum + num(expense.amount), 0);
    const net = monthMargin - monthExpenses;
    const profitCollection = creditCollectionRatios();
    const dayCollected = collectedMarginOf(daySales, dayNotes, profitCollection);
    const monthCollected = collectedMarginOf(monthSales, monthNotes, profitCollection);
    const netCollected = monthCollected - monthExpenses;
    const deliveries = state.deliveries || [];
    const dayDeliveries = deliveries.filter((delivery) => String(delivery.assignedAt || '').slice(0, 10) === today);
    const monthDeliveries = deliveries.filter((delivery) => monthKey(delivery.assignedAt) === month);
    const dayDeliveryFees = dayDeliveries.reduce((sum, delivery) => sum + num(delivery.fee), 0);
    const monthDeliveryFees = monthDeliveries.reduce((sum, delivery) => sum + num(delivery.fee), 0);
    const monthPayments = (state.customerPayments || []).filter((payment) => payment.status === 'Validé' && monthKey(payment.date) === month);
    const monthPaymentsTotal = monthPayments.reduce((sum, payment) => sum + num(payment.amount), 0);
    const collectionRate = monthMargin > 0 ? Math.max(0, Math.min(100, Math.round((monthCollected / monthMargin) * 100))) : 0;
    const recentDeliveries = deliveries.slice().sort((a, b) => String(b.assignedAt || '').localeCompare(String(a.assignedAt || ''))).slice(0, 4);
    const recentPayments = (state.customerPayments || []).filter((payment) => payment.status === 'Validé').sort((a, b) => localDate(b.date) - localDate(a.date)).slice(0, 4);
    const stockValue = activeProducts().reduce((sum, product) => sum + totalStock(product) * num(product.purchasePrice), 0);
    const receivables = state.clients.reduce((sum, client) => sum + num(client.receivable), 0);
    const out = activeProducts().filter((p) => productStockState(p).key === 'out').length;
    const low = activeProducts().filter((p) => productStockState(p).key === 'low').length;
    const high = activeProducts().filter((p) => productStockState(p).key === 'high').length;
    const expired = activeProducts().filter((p) => p.expiry && daysUntil(p.expiry) < 0).length;
    const expiring = activeProducts().filter((p) => p.expiry && withinDays(p.expiry, 45) && daysUntil(p.expiry) >= 0).sort((a, b) => a.expiry.localeCompare(b.expiry));
    const lowProducts = activeProducts().filter((p) => ['low', 'out'].includes(productStockState(p).key)).sort((a, b) => totalStock(a) - totalStock(b));
    const topProducts = productSalesRanking().slice(0, 5);
    const categoryRevenue = state.categories.map((category) => ({ ...category, value: monthSales.reduce((sum, sale) => sum + (sale.items || []).filter((item) => productById(item.productId)?.categoryId === category.id).reduce((subtotal, item) => subtotal + num(item.quantity) * num(item.unitPrice), 0), 0) - monthNotes.reduce((sum, note) => sum + (note.lines || []).filter((item) => productById(item.productId)?.categoryId === category.id).reduce((subtotal, item) => subtotal + num(item.quantity) * num(item.unitPrice), 0), 0) })).filter((category) => category.value > 0).sort((a, b) => b.value - a.value);
    const categoryTotal = categoryRevenue.reduce((sum, category) => sum + category.value, 0) || 1;
    const chartDays = Array.from({ length: 14 }, (_, index) => {
      const offset = index - 13;
      const date = isoDate(offset);
      return { date, label: dayLabel(date).split(' ')[0], value: sales.filter((sale) => sale.date.slice(0, 10) === date).reduce((sum, sale) => sum + saleTotal(sale), 0) - validCreditNotes().filter((note) => String(note.date).slice(0, 10) === date).reduce((sum, note) => sum + creditNoteTotal(note), 0) };
    });
    const chartMax = Math.max(...chartDays.map((item) => item.value), 1);
    const recentStock = [...state.stockEntries.map((item) => ({ ...item, movement: 'Entrée' })), ...state.stockExits.map((item) => ({ ...item, movement: 'Sortie' })), ...(state.stockTransfers || []).map((item) => ({ ...item, movement: 'Transfert', productId: item.lines?.[0]?.productId || '', quantity: (item.lines || []).reduce((sum, line) => sum + num(line.quantity), 0) }))].sort((a, b) => localDate(b.date) - localDate(a.date)).slice(0, 4);
    const dateText = new Intl.DateTimeFormat('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date());
    const categoryColors = ['#0f9f91', '#f19a52', '#8270dc', '#4e87df', '#dce3ed'];
    const dashboardIdentity = state.users.find((user) => user.id === currentUser?.id)?.name || currentUser?.name || 'Administrateur';

    return `<div class="dashboard-welcome"><div><h1>Bonjour, ${esc(dashboardIdentity)} <span style="color:#f1a55d">✦</span></h1><p>Voici la synthèse de votre activité commerciale.</p></div><div class="date-chip"><span>◷</span><b>${esc(dateText.charAt(0).toUpperCase() + dateText.slice(1))}</b></div></div>
      <div class="metric-grid">
        ${metricCard('↗', 'Chiffre d’affaires du jour', money(dayRevenue), { text: daySales.length ? `${daySales.length} vente${daySales.length > 1 ? 's' : ''}` : 'Aucune vente', className: daySales.length ? 'up' : 'neutral' }, 'enregistrée(s)', 'teal')}
        ${metricCard('◒', 'Bénéfice du jour', money(dayMargin), { text: dayRevenue ? `${Math.round((dayMargin / dayRevenue) * 100)} %` : '0 %', className: 'up' }, 'marge brute · avec créances', 'orange')}
        ${metricCard('₣', 'Encaissé du jour', money(dayCollected), { text: dayMargin ? `${Math.round((dayCollected / dayMargin) * 100)} % du bénéfice` : 'aucune marge', className: 'up' }, 'hors créances', 'teal')}
        ${metricCard('▣', 'Chiffre d’affaires du mois', money(monthRevenue), { text: `${monthSales.length} vente${monthSales.length > 1 ? 's' : ''}`, className: 'up' }, 'validée(s)', 'blue')}
        ${metricCard('◇', 'Dépenses du mois', money(monthExpenses), { text: monthExpenses ? 'suivi en temps réel' : 'Aucune dépense', className: 'neutral' }, '', 'purple')}
        ${metricCard('✦', 'Bénéfice net du mois', money(net), { text: net >= 0 ? 'positif' : 'à surveiller', className: net >= 0 ? 'up' : 'down' }, 'marge - dépenses · avec créances', net >= 0 ? 'teal' : 'red')}
        ${metricCard('✦', 'Bénéfice net encaissé', money(netCollected), { text: netCollected >= 0 ? 'positif' : 'à surveiller', className: netCollected >= 0 ? 'up' : 'down' }, 'hors créances', netCollected >= 0 ? 'teal' : 'red')}
        ${metricCard('◒', 'Taux d’encaissement', collectionRate + ' %', { text: money(monthCollected) + ' encaissés', className: collectionRate >= 75 ? 'up' : collectionRate >= 50 ? 'neutral' : 'down' }, 'marge du mois', collectionRate >= 75 ? 'teal' : collectionRate >= 50 ? 'orange' : 'red')}
        ${metricCard('₣', 'Règlements reçus', money(monthPaymentsTotal), { text: monthPayments.length ? `${monthPayments.length} règlement${monthPayments.length > 1 ? 's' : ''}` : 'Aucun règlement', className: monthPayments.length ? 'up' : 'neutral' }, 'ce mois-ci', 'teal')}
        ${isModuleDisabled('deliverers') ? '' : metricCard('truck', 'Livraisons du jour', number(dayDeliveries.length), { text: dayDeliveries.length ? `${money(dayDeliveryFees)} de frais` : 'Aucune livraison', className: dayDeliveries.length ? 'up' : 'neutral' }, 'affectée(s)', 'blue')}
        ${isModuleDisabled('deliverers') ? '' : metricCard('truck', 'Livraisons du mois', number(monthDeliveries.length), { text: `${money(monthDeliveryFees)} de frais`, className: monthDeliveries.length ? 'up' : 'neutral' }, 'affectée(s)', 'purple')}
        ${metricCard('▤', 'Valeur totale du stock', money(stockValue), { text: `${activeProducts().length} références`, className: 'neutral' }, 'au prix d’achat', 'blue')}
        ${metricCard('₣', 'Créances clients', money(receivables), { text: state.clients.filter((c) => c.receivable > 0).length + ' client(s)', className: receivables ? 'down' : 'up' }, 'à recouvrer', 'orange')}
        ${metricCard('!', 'Alertes stock & péremption', number(out + low + expired), { text: `${out} rupture · ${low} faible`, className: out || low || expired ? 'down' : 'up' }, `${expired} périmé(s)`, 'red')}
      </div>
      <div class="dashboard-grid">
        ${panel('Évolution des ventes', 'Chiffre d’affaires journalier · 14 derniers jours', `<div class="chart-legend"><span><i></i>Ventes validées</span><span><i class="secondary"></i>Objectif indicatif</span></div><div class="bar-chart">${chartDays.map((item) => `<div class="bar-item"><div class="bar secondary" style="height:${Math.max(4, Math.round((Math.max(chartMax * .75, 1) / Math.max(chartMax, 1)) * 100))}%"></div><div class="bar" title="${esc(item.date)} · ${money(item.value)}" style="height:${Math.max(item.value ? 6 : 2, Math.round((item.value / chartMax) * 100))}%"></div></div>`).join('')}</div><div class="bar-labels">${chartDays.map((item) => `<span>${esc(item.label)}</span>`).join('')}</div>`, '<button class="panel-link" type="button" data-view="sales-report">Voir le bilan →</button>')}
        ${panel('Revenus par catégorie', 'Répartition du mois en cours', `<div class="donut-layout"><div class="donut" style="background:conic-gradient(${categoryRevenue.length ? categoryRevenue.map((item, index) => `${categoryColors[index % categoryColors.length]} 0 ${(categoryRevenue.slice(0, index + 1).reduce((s, x) => s + x.value, 0) / categoryTotal) * 100}%`).join(', ') : '#e5ebf1 0 100%'})"><div class="donut-center"><strong>${money(categoryTotal === 1 ? 0 : categoryTotal)}</strong><span>ce mois</span></div></div><div class="legend-list">${(categoryRevenue.length ? categoryRevenue.slice(0, 4) : [{ name: 'Pas encore de données', value: 0 }]).map((item, index) => `<div class="legend-line"><i class="legend-dot" style="background:${categoryColors[index % categoryColors.length]}"></i><span>${esc(item.name)}</span><strong>${categoryRevenue.length ? Math.round((item.value / categoryTotal) * 100) : 0}%</strong></div>`).join('')}</div></div>`, '<button class="panel-link" type="button" data-view="sales-report">Détails →</button>')}
      </div>
      <div class="dashboard-grid equal">
        ${panel('Produits les plus vendus', 'Quantités écoulées sur la période', `<div class="data-list">${topProducts.length ? topProducts.map((item, index) => `<div class="data-row"><span class="rank">0${index + 1}</span><img class="mini-thumb" src="${productImage(item.product)}" alt=""><div class="data-row-main"><strong>${esc(item.product.name)}</strong><span>${esc(categoryName(item.product.categoryId))}</span></div><div class="data-row-value">${number(item.quantity)} u.</div></div>`).join('') : emptyState('Pas encore de ventes')}</div>`, '<button class="panel-link" type="button" data-view="sales-report">Tout voir →</button>')}
        ${panel('Alertes à traiter', `${out + low + expired} élément(s) nécessitent votre attention`, `<div class="data-list">${[...lowProducts.slice(0, 3).map((product) => ({ product, type: productStockState(product).key })), ...expiring.slice(0, 3).map((product) => ({ product, type: 'expiry' }))].slice(0, 5).map(({ product, type }) => `<div class="data-row"><span class="status-dot ${type === 'expiry' ? 'orange' : type === 'out' ? 'red' : 'orange'}"></span><div class="data-row-main"><strong>${esc(product.name)}</strong><span>${type === 'expiry' ? `Expire ${shortDate(product.expiry)}` : type === 'out' ? 'Rupture de stock' : `${number(totalStock(product))} restant(s) · min. ${number(product.minStock)}`}</span></div><button class="text-button" type="button" data-action="edit-product" data-id="${esc(product.id)}">Gérer</button></div>`).join('') || emptyState('Aucune alerte', 'Votre stock est bien maîtrisé.')}</div>`, '<button class="panel-link" type="button" data-view="products">Catalogue →</button>')}
      </div>
      <div class="dashboard-grid equal">
        ${panel('Dernières ventes', 'Les opérations les plus récentes', `<div class="data-list">${sales.slice().sort((a, b) => localDate(b.date) - localDate(a.date)).slice(0, 4).map((sale) => `<div class="data-row"><div class="data-row-main"><strong>${esc(sale.number)}</strong><span>${esc(clientName(sale.clientId))} · ${dateTime(sale.date)}</span></div><div class="data-row-value">${money(saleTotal(sale))}<br>${paymentBadge(sale.payment)}</div></div>`).join('') || emptyState('Aucune vente')}</div>`, '<button class="panel-link" type="button" data-view="sales">Historique →</button>')}
        ${panel('Mouvements de stock', 'Entrées et sorties récentes', `<div class="data-list">${recentStock.map((item) => `<div class="data-row"><span class="status-dot ${item.movement === 'Entrée' ? 'teal' : 'orange'}"></span><div class="data-row-main"><strong>${esc(item.number)}</strong><span>${item.movement} · ${esc(productName(item.productId))}</span></div><div class="data-row-value">${number(item.quantity)} u.<br>${statusBadge(item.status)}</div></div>`).join('') || emptyState('Aucun mouvement')}</div>`, '<button class="panel-link" type="button" data-view="entries">Journal →</button>')}
      </div>
      <div class="dashboard-grid equal">
        ${isModuleDisabled('deliverers') ? '' : panel('Dernières livraisons', 'Affectations les plus récentes', `<div class="data-list">${recentDeliveries.map((delivery) => `<div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>${esc(delivery.saleNumber || '—')} → ${esc(delivererName(delivery.delivererId))}</strong><span>${dateTime(delivery.assignedAt)} · ${money(num(delivery.fee))} de frais</span></div></div>`).join('') || emptyState('Aucune livraison', 'Affectez un livreur depuis l’historique des ventes.')}</div>`, '<button class="panel-link" type="button" data-view="deliverers">Livreurs →</button>')}
        ${panel('Derniers règlements', 'Encaissements clients récents', `<div class="data-list">${recentPayments.map((payment) => `<div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>${esc(clientName(payment.clientId))}</strong><span>${shortDate(payment.date)} · ${esc(paymentLabel(payment.method))}${payment.reference ? ` · ${esc(payment.reference)}` : ''}</span></div><div class="data-row-value">${money(payment.amount)}</div></div>`).join('') || emptyState('Aucun règlement', 'Les règlements clients apparaîtront ici.')}</div>`, '<button class="panel-link" type="button" data-view="clients">Clients →</button>')}
      </div>`;
  }

  function productSalesRanking(source = validSales()) {
    const map = new Map();
    const ids = new Set(source.map((sale) => sale.id));
    source.forEach((sale) => (sale.items || []).forEach((item) => {
      if (!map.has(item.productId)) map.set(item.productId, 0);
      map.set(item.productId, map.get(item.productId) + num(item.quantity));
    }));
    validCreditNotes().filter((note) => ids.has(note.originalSaleId)).forEach((note) => (note.lines || []).forEach((item) => map.set(item.productId, Math.max(0, num(map.get(item.productId)) - num(item.quantity)))));
    return [...map.entries()].map(([id, quantity]) => ({ product: productById(id), quantity })).filter((item) => item.product && item.quantity > 0).sort((a, b) => b.quantity - a.quantity);
  }

  function renderSale() {
    const query = '';
    const activePriceType = saleDraft.priceType || 'retail';
    const cartTotal = saleCart.reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0);
    const cartCount = saleCart.reduce((sum, line) => sum + num(line.quantity), 0);
    const currentClient = state.clients.find((client) => client.id === saleDraft.clientId);
    return `${pageHeading('Nouvelle vente', 'Encaissez rapidement et gardez une trace fiable de chaque opération.', `<button class="btn btn-secondary" type="button" data-action="show-shortcuts">⌨ Raccourcis</button><button class="btn btn-secondary" type="button" data-action="show-receipt-help">▣ Ticket exemple</button>`)}
      <div class="sale-layout">
        <section class="sale-catalog">
          <div class="sale-headline"><h2>Sélectionner le prix de vente</h2><p>Ce prix sera appliqué aux produits ajoutés au panier du client</p></div><div class="price-type-grid">${SALE_PRICE_TYPES.map((type) => `<label class="price-type-option ${activePriceType === type.key ? 'active' : ''}"><input type="checkbox" data-price-type-checkbox="${type.key}" ${activePriceType === type.key ? 'checked' : ''}><span>${type.label}</span></label>`).join('')}</div><div class="sale-headline"><h2>Sélectionner un produit</h2><p>Cliquez pour choisir la quantité · double-cliquez pour un ajout rapide</p></div>
          <div class="toolbar" style="border-top:0"><div class="toolbar-left"><label class="search-field" style="min-width:260px;flex:1"><span>⌕</span><input id="sale-product-search" type="search" placeholder="Nom, code, marque ou catégorie..." data-filter-input data-filter-target="#sale-products-grid" value="${esc(query)}" autocomplete="off"></label><select class="select-control" id="sale-category-filter" data-filter-select="category" data-filter-target="#sale-products-grid"><option value="">Toutes les catégories</option>${state.categories.filter((c) => c.active !== false).map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')}</select></div><div class="toolbar-right"><span style="color:#9aa5b4;font-size:10px">${activeProducts().length} références</span></div></div>
          <div class="products-grid" id="sale-products-grid">${activeProducts().map((product) => { const status = productStockState(product); return `<article class="product-card" data-product-card data-product-id="${esc(product.id)}" data-category="${esc(product.categoryId)}" data-text="${esc(`${product.name} ${product.code} ${product.brand} ${categoryName(product.categoryId)}`.toLowerCase())}"><img class="product-card-image" src="${productImage(product)}" alt="${esc(product.name)}"><button class="quick-add" type="button" data-action="quick-add" data-id="${esc(product.id)}" title="Ajouter 1">＋</button><div class="product-card-meta"><strong>${esc(product.name)}</strong><span>${esc(product.code)} · ${esc(product.brand || 'Sans marque')}</span></div><div class="product-card-bottom"><span class="product-card-price">${money(productPriceForSale(product, activePriceType))}</span><span class="product-card-stock ${status.key === 'out' ? 'out' : status.key === 'low' ? 'low' : ''}">${status.key === 'out' ? 'Rupture' : `${number(totalStock(product))} en stock`}</span></div></article>`; }).join('')}</div>
        </section>
        <aside class="cart-panel">
          <div class="cart-header"><h2>Panier de vente</h2><span class="cart-count">${cartCount} u.</span></div><div class="cart-price-hint">Prix appliqué : <strong>${salePriceTypeLabel(activePriceType)}</strong></div>
          <div class="cart-lines">${saleCart.length ? saleCart.map((line) => { const product = productById(line.productId); return `<div class="cart-line"><img class="cart-line-image" src="${productImage(product)}" alt=""><div class="cart-line-copy"><strong>${esc(product?.name || 'Produit')}</strong><span>${money(line.unitPrice)} / unité</span><div class="cart-line-bottom"><div class="qty-control"><button type="button" data-action="cart-decrease" data-id="${esc(line.productId)}">−</button><input type="number" min="1" max="${stockFor(product, line.storeId || productSaleStore(product)) || 9999}" value="${num(line.quantity)}" data-cart-input data-id="${esc(line.productId)}"><button type="button" data-action="cart-increase" data-id="${esc(line.productId)}">＋</button></div><span class="cart-line-total">${money(num(line.quantity) * num(line.unitPrice))}</span></div></div><button class="table-action danger" type="button" data-action="cart-remove" data-id="${esc(line.productId)}" title="Retirer">×</button></div>`; }).join('') : emptyState('Votre panier est vide', 'Sélectionnez un produit à gauche pour commencer une vente.')}</div>
          <div class="sale-client-box"><label for="sale-client">Client</label><select class="select-control" id="sale-client"><option value="counter" ${saleDraft.clientId === 'counter' ? 'selected' : ''}>Client comptoir · sans fiche</option>${state.clients.filter((c) => c.active !== false).map((client) => `<option value="${esc(client.id)}" ${saleDraft.clientId === client.id ? 'selected' : ''}>${esc(client.name)}${client.receivable ? ` · dû ${money(client.receivable)}` : ''}</option>`).join('')}</select><div class="payment-grid">${[['cash', 'Cash'], ['mobile', 'Mobile Money'], ['card', 'Carte'], ['credit', 'À crédit']].map(([key, label]) => `<button class="payment-option ${saleDraft.payment === key ? 'active' : ''}" type="button" data-action="set-payment" data-payment="${key}">${label}</button>`).join('')}</div>${saleDraft.payment === 'credit' ? `<div class="field-hint" style="color:#b96c2e;margin:8px 0 0">ⓘ Une vente à crédit doit être liée à un client enregistré.${currentClient ? ` Encours actuel : ${money(currentClient.receivable)}` : ''}</div>` : ''}</div>
          <div class="cart-summary"><div class="summary-line"><span>Sous-total</span><strong>${money(cartTotal)}</strong></div><div class="summary-line"><span>Remise</span><strong>0 FCFA</strong></div><div class="summary-total"><span>Total à encaisser</span><strong>${money(cartTotal)}</strong></div></div>
          <div class="cart-validation"><button class="btn btn-primary" type="button" data-action="validate-sale" ${saleCart.length ? '' : 'disabled'}>Valider la vente <span>→</span></button><button class="text-button" type="button" data-action="clear-cart" style="display:block;margin:9px auto 0">Vider le panier</button></div>
        </aside>
      </div>`;
  }

  function renderSales() {
    const sales = periodItems(state.sales).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const rows = sales.map((sale) => { const delivery = deliveryForSale(sale.id); const deliveryName = delivery ? delivererName(delivery.delivererId) : ''; return `<tr data-filter-row data-text="${esc(`${sale.number} ${clientName(sale.clientId)} ${paymentLabel(sale.payment)} ${sale.status} ${deliveryName}`.toLowerCase())}"><td><strong>${esc(sale.number)}</strong><span class="table-secondary">${dateTime(sale.date)}</span></td><td>${esc(clientName(sale.clientId))}</td><td>${number((sale.items || []).reduce((sum, item) => sum + num(item.quantity), 0))} produit(s)</td><td><strong>${money(saleTotal(sale))}</strong></td><td>${paymentBadge(sale.payment)}</td><td>${esc(userName(sale.userId))}</td><td>${statusBadge(sale.status)}</td><td>${delivery ? `<strong>${esc(deliveryName)}</strong><span class="table-secondary">${money(delivery.fee)}</span>` : '<span class="table-secondary">Non affecté</span>'}</td><td>${actionButtons('view-sale', sale.id, `<button class="table-action" type="button" data-action="print-sale" data-id="${esc(sale.id)}" title="Réimprimer">▣</button><button class="table-action" type="button" data-action="assign-delivery" data-id="${esc(sale.id)}" title="Affecter un livreur (Livraison)">🚚</button>`)}</td></tr>`; }).join('');
    return `${pageHeading('Historique des ventes', 'Retrouvez, filtrez, réimprimez les ventes et affectez un livreur.', `<button class="btn btn-secondary" type="button" data-action="export-sales">⇩ Exporter</button><button class="btn btn-secondary" type="button" data-view="credit-notes">↩ Avoirs & annulations</button><button class="btn btn-primary" type="button" data-view="sale">＋ Nouvelle vente</button>`)}
      <div class="stat-strip"><div class="strip-item"><span>Ventes enregistrées</span><strong>${number(sales.length)}</strong></div><div class="strip-item"><span>CA net cumulé</span><strong>${money(netSalesRevenue(sales))}</strong></div><div class="strip-item"><span>Avoirs liés</span><strong>${money(periodItems(validCreditNotes()).filter((note) => sales.some((sale) => sale.id === note.originalSaleId)).reduce((sum, note) => sum + creditNoteTotal(note), 0))}</strong></div><div class="strip-item"><span>À crédit</span><strong>${number(sales.filter((s) => s.payment === 'credit').length)}</strong></div></div>
      <section class="panel">${toolbar('Rechercher une vente...', '#sales-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button><button class="btn btn-secondary btn-sm" type="button" data-action="show-filter-info">≡ Filtres</button>')}
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Vente</th><th>Client</th><th>Articles</th><th>Montant</th><th>Paiement</th><th>Utilisateur</th><th>Statut</th><th>Livreur</th><th></th></tr></thead><tbody id="sales-table-body">${rows ? pagedTbody('sales-table-body', rows) : `<tr><td colspan="9">${emptyTable('Aucune vente enregistrée')}</td></tr>`}</tbody></table></div><div class="table-footer"><span>Affichage de ${number(sales.length)} vente(s)</span><div class="pagination"><button class="page-btn active">1</button><button class="page-btn">2</button><button class="page-btn">›</button></div></div>
      </section>`;
  }
  function emptyTable(title, msg = 'Les éléments apparaîtront ici.') { return `<div class="empty-table"><strong>${esc(title)}</strong><span>${esc(msg)}</span></div>`; }

  function renderClients() {
    const clients = state.clients;
    const receivable = clients.reduce((sum, client) => sum + num(client.receivable), 0);
    const rows = clients.map((client) => `<tr data-filter-row data-text="${esc(`${client.name} ${client.phone} ${client.email} ${client.address}`.toLowerCase())}"><td><div class="table-product"><div class="avatar">${esc(client.name.split(' ').map((p) => p[0]).slice(0,2).join('').toUpperCase())}</div><div><strong>${esc(client.name)}</strong><span class="table-secondary">${esc(client.phone || 'Sans téléphone')}</span></div></div></td><td>${esc(client.email || '—')}</td><td>${esc(client.address || '—')}</td><td><strong>${money(client.receivable)}</strong><span class="table-secondary">limite ${money(client.creditLimit)}</span></td><td>${client.active === false ? statusBadge('Inactif', { Inactif: 'danger' }) : statusBadge('Actif', { Actif: 'success' })}</td><td>${actionButtons('edit-client', client.id, `<button class="table-action" type="button" data-action="client-history" data-id="${esc(client.id)}" title="Journal des créances">↗</button><button class="table-action" type="button" data-action="record-payment" data-id="${esc(client.id)}" title="Enregistrer un règlement">₣</button>`)}</td></tr>`).join('');
    return `${pageHeading('Clients', 'Gérez les fiches clients et suivez les créances en temps réel.', `<button class="btn btn-secondary" type="button" data-action="export-clients">⇩ Clients</button><button class="btn btn-secondary" type="button" data-action="export-payments">⇩ Règlements</button><button class="btn btn-primary" type="button" data-action="add-client">＋ Nouveau client</button>`)}
      <div class="stat-strip"><div class="strip-item"><span>Clients actifs</span><strong>${number(clients.filter((c) => c.active !== false).length)}</strong></div><div class="strip-item"><span>Créances à recouvrer</span><strong>${money(receivable)}</strong></div><div class="strip-item"><span>Clients débiteurs</span><strong>${number(clients.filter((c) => c.receivable > 0).length)}</strong></div><div class="strip-item"><span>Limites de crédit</span><strong>${money(clients.reduce((s, c) => s + num(c.creditLimit), 0))}</strong></div></div>
      <section class="panel">${toolbar('Nom, téléphone ou e-mail...', '#clients-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-filter-info">≡ Filtres</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Client</th><th>E-mail</th><th>Adresse</th><th>Encours</th><th>Statut</th><th></th></tr></thead><tbody id="clients-table-body">${pagedTbody('clients-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(clients.length)} fiche(s) client</span><div class="pagination"><button class="page-btn active">1</button><button class="page-btn">›</button></div></div></section>`;
  }

  function renderProducts() {
    const products = state.products;
    const out = products.filter((p) => productStockState(p).key === 'out').length;
    const low = products.filter((p) => productStockState(p).key === 'low').length;
    const expired = products.filter((p) => p.expiry && daysUntil(p.expiry) < 0).length;
    const rows = products.map((product) => { const stock = productStockState(product); const ratio = product.maxStock ? clamp((totalStock(product) / product.maxStock) * 100, 3, 100) : 50; return `<tr data-filter-row data-category="${esc(product.categoryId)}" data-text="${esc(`${product.name} ${product.code} ${product.brand} ${categoryName(product.categoryId)} ${supplierName(product.supplierId)}`.toLowerCase())}"><td><div class="table-product"><img class="mini-thumb" src="${productImage(product)}" alt=""><div><strong>${esc(product.name)}</strong><span class="table-secondary">${esc(product.code)} · ${esc(product.brand || 'Sans marque')}</span></div></div></td><td>${esc(categoryName(product.categoryId))}</td><td>${esc(storeName(product.storeId))}<span class="table-secondary">${esc(stockSummary(product))}</span></td><td><strong>${money(product.salePrice)}</strong><span class="table-secondary">achat ${money(product.purchasePrice)}</span></td><td><span class="stock-meter"><span class="${stock.key === 'out' ? 'out' : stock.key === 'low' ? 'low' : stock.key === 'high' ? 'high' : 'ok'}" style="width:${ratio}%"></span></span>${number(totalStock(product))} u.<span class="table-secondary">min ${number(product.minStock)} · max ${number(product.maxStock)}</span></td><td>${statusBadge(stock.label, { 'Rupture': 'danger', 'Stock faible': 'warning', 'Stock normal': 'success', 'Stock élevé': 'info' })}</td><td>${product.expiry ? `<span class="table-secondary" style="color:${daysUntil(product.expiry) < 0 ? '#c35159' : withinDays(product.expiry, 45) ? '#b96c2e' : ''}">${daysUntil(product.expiry) < 0 ? 'Périmé' : `Expire ${shortDate(product.expiry)}`}</span>` : '<span class="table-secondary">Sans expiration</span>'}</td><td>${actionButtons('edit-product', product.id, `<button class="table-action danger" type="button" data-action="toggle-product" data-id="${esc(product.id)}" title="${product.active === false ? 'Activer' : 'Désactiver'}">${product.active === false ? '↻' : '×'}</button>`)}</td></tr>`; }).join('');
    return `${pageHeading('Produits', 'Votre catalogue, vos prix et vos seuils de stock au même endroit.', `<button class="btn btn-secondary" type="button" data-action="export-products">⇩ Exporter</button><button class="btn btn-primary" type="button" data-action="add-product">＋ Nouveau produit</button>`)}
      <div class="stat-strip"><div class="strip-item"><span>Références actives</span><strong>${number(products.filter((p) => p.active !== false).length)}</strong></div><div class="strip-item"><span>En rupture</span><strong style="color:#c35159">${number(out)}</strong></div><div class="strip-item"><span>Stock faible</span><strong style="color:#b96c2e">${number(low)}</strong></div><div class="strip-item"><span>Produits périmés</span><strong style="color:#c35159">${number(expired)}</strong></div></div>
      <section class="panel">${toolbar('Nom, code, marque ou catégorie...', '#products-table-body', '<select class="select-control" style="min-width:140px" data-table-filter="category"><option value="">Toutes catégories</option>'+state.categories.map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')+'</select><button class="btn btn-secondary btn-sm" type="button" data-action="show-stock-filter">⚑ État du stock</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Produit</th><th>Catégorie</th><th>Magasin</th><th>Prix de vente</th><th>Quantité</th><th>État</th><th>Expiration</th><th></th></tr></thead><tbody id="products-table-body">${pagedTbody('products-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(products.length)} produit(s) au catalogue</span><div class="pagination"><button class="page-btn active">1</button><button class="page-btn">›</button></div></div></section>`;
  }

  function renderCategories() {
    const rows = state.categories.map((category) => { const count = state.products.filter((p) => p.categoryId === category.id).length; return `<tr data-filter-row data-text="${esc(`${category.name} ${category.code} ${category.description}`.toLowerCase())}"><td><strong>${esc(category.name)}</strong><span class="table-secondary">${esc(category.description || '—')}</span></td><td><span class="status-badge info">${esc(category.code)}</span></td><td>${number(count)} produit(s)</td><td>${category.active === false ? statusBadge('Inactif', { Inactif: 'danger' }) : statusBadge('Actif', { Actif: 'success' })}</td><td>${actionButtons('edit-category', category.id)}</td></tr>`; }).join('');
    return `${pageHeading('Catégories', 'Structurez le catalogue et facilitez les recherches et les statistiques.', `<button class="btn btn-primary" type="button" data-action="add-category">＋ Nouvelle catégorie</button>`)}<section class="panel">${toolbar('Nom, code ou description...', '#categories-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="export-categories">⇩ Exporter</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Catégorie</th><th>Code</th><th>Produits associés</th><th>Statut</th><th></th></tr></thead><tbody id="categories-table-body">${pagedTbody('categories-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(state.categories.length)} catégorie(s)</span></div></section>`;
  }

  function renderStores() {
    const rows = state.stores.map((store) => { const count = state.products.filter((p) => stockFor(p, store.id) > 0).length; const value = state.products.reduce((sum, p) => sum + stockFor(p, store.id) * p.purchasePrice, 0); return `<tr data-filter-row data-text="${esc(`${store.name} ${store.code} ${store.type} ${store.manager}`.toLowerCase())}"><td><div class="table-product"><div class="avatar">⌂</div><div><strong>${esc(store.name)}</strong><span class="table-secondary">${esc(store.code)}</span></div></div></td><td>${esc(store.type)}</td><td>${esc(store.manager || '—')}</td><td>${number(count)} référence(s)<span class="table-secondary">${money(value)} de stock</span></td><td>${store.active === false ? statusBadge('Inactif', { Inactif: 'danger' }) : statusBadge('Actif', { Actif: 'success' })}</td><td>${actionButtons('edit-store', store.id)}</td></tr>`; }).join('');
    return `${pageHeading('Magasins', 'Pilotez vos points de vente et zones de stockage.', `<button class="btn btn-primary" type="button" data-action="add-store">＋ Nouveau magasin</button>`)}<section class="panel">${toolbar('Nom, code ou responsable...', '#stores-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="export-stores">⇩ Exporter</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Magasin</th><th>Type</th><th>Responsable</th><th>Contenu</th><th>Statut</th><th></th></tr></thead><tbody id="stores-table-body">${pagedTbody('stores-table-body', rows)}</tbody></table></div><div class="table-footer"><span>Code magasin unique requis</span></div></section>`;
  }

  function updateSupplierLinkCount() {
    const container = $('#supplier-link-products');
    const count = $('#supplier-link-selected-count');
    if (container && count) count.textContent = `${number(container.querySelectorAll('[data-supplier-link-product]:checked').length)} produit(s) déjà sélectionné(s)`;
  }
  function filterSupplierLinkProducts() {
    const container = $('#supplier-link-products');
    if (!container) return;
    const query = String($('#supplier-link-search')?.value || '').toLowerCase().trim();
    container.querySelectorAll('.supplier-product-option').forEach((option) => { option.style.display = !query || option.textContent.toLowerCase().includes(query) ? '' : 'none'; });
  }
  function renderSupplierLinkProducts() {
    const container = $('#supplier-link-products');
    const supplierSelect = $('#supplier-link-supplier');
    if (!container || !supplierSelect) return;
    supplierLinkSupplierId = supplierSelect.value || '';
    if (!supplierLinkSupplierId) { container.innerHTML = emptyState('Sélectionnez un fournisseur', 'Choisissez d’abord le partenaire à associer aux produits.'); return; }
    const linked = supplierProductIds(supplierLinkSupplierId);
    const products = (state.products || []).slice().sort((left, right) => String(left.name || '').localeCompare(String(right.name || ''), 'fr'));
    container.innerHTML = products.length ? products.map((product) => `<label class="supplier-product-option"><input type="checkbox" data-supplier-link-product value="${esc(product.id)}" ${linked.has(product.id) ? 'checked' : ''}><span class="supplier-product-option-copy"><strong>${esc(product.name)}</strong><small>${esc(product.code)} · ${esc(categoryName(product.categoryId))}${product.active === false ? ' · Inactif' : ''}</small></span><span class="supplier-product-option-stock">${number(totalStock(product))} u.</span></label>`).join('') : emptyState('Aucun produit disponible', 'Créez d’abord une référence dans Produits.');
    filterSupplierLinkProducts();
    updateSupplierLinkCount();
  }
  function saveSupplierProductLinks() {
    if (!requirePermission('suppliers.manage', 'Votre profil ne peut pas gérer les produits des fournisseurs.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier les relations fournisseurs.', 'warning'); return; }
    const supplierId = $('#supplier-link-supplier')?.value || supplierLinkSupplierId;
    const supplier = state.suppliers.find((item) => item.id === supplierId);
    if (!supplier) { toast('Fournisseur requis', 'Sélectionnez un fournisseur avant de valider.', 'warning'); return; }
    const selectedProducts = $$('#supplier-link-products [data-supplier-link-product]:checked').map((input) => input.value);
    const previous = Array.isArray(state.supplierProducts) ? state.supplierProducts.slice() : [];
    const retained = previous.filter((link) => link.supplierId !== supplierId);
    const next = selectedProducts.map((productId) => ({ supplierId, productId, createdAt: new Date().toISOString(), userId: currentUserId() }));
    state.supplierProducts = [...retained, ...next];
    const activityId = uid('act');
    state.activities.unshift({ id: activityId, date: new Date().toISOString(), userId: currentUserId(), module: 'Fournisseurs', action: 'Mise à jour des produits fournis', element: supplier.name, detail: `${number(selectedProducts.length)} produit(s) associé(s)`, oldValue: `${number(previous.filter((link) => link.supplierId === supplierId).length)} produit(s)`, newValue: `${number(selectedProducts.length)} produit(s)` });
    if (!saveState()) {
      state.supplierProducts = previous;
      state.activities = state.activities.filter((activity) => activity.id !== activityId);
      renderSupplierLinkProducts();
      return;
    }
    supplierLinkSupplierId = supplierId;
    render();
    toast('Relations enregistrées', `${supplier.name} peut désormais fournir ${number(selectedProducts.length)} produit(s).`);
  }
  function renderSuppliers() {
    const rows = state.suppliers.map((supplier) => { const total = state.stockEntries.filter((e) => e.supplierId === supplier.id && e.status === 'Validé').reduce((s, e) => s + num(e.total), 0); const linkedCount = supplierProductsFor(supplier.id).length; return `<tr data-filter-row data-text="${esc(`${supplier.name} ${supplier.type} ${supplier.manager} ${supplier.phone} ${supplier.fiscal}`.toLowerCase())}"><td><strong>${esc(supplier.name)}</strong><span class="table-secondary">${esc(supplier.type)}</span></td><td>${esc(supplier.manager || '—')}</td><td>${esc(supplier.phone || '—')}<span class="table-secondary">${esc(supplier.secondary || '')}</span></td><td>${esc(supplier.fiscal || '—')}</td><td>${number(linkedCount)} produit(s)<span class="table-secondary">référencé(s)</span></td><td>${money(total)}<span class="table-secondary">achats validés</span></td><td>${supplier.active === false ? statusBadge('Inactif', { Inactif: 'danger' }) : statusBadge('Actif', { Actif: 'success' })}</td><td>${actionButtons('edit-supplier', supplier.id, `<button class="table-action" type="button" data-action="supplier-history" data-id="${esc(supplier.id)}" title="Historique">↗</button>`)}</td></tr>`; }).join('');
    const activeSuppliers = state.suppliers.filter((supplier) => supplier.active !== false);
    if (!activeSuppliers.some((supplier) => supplier.id === supplierLinkSupplierId)) supplierLinkSupplierId = activeSuppliers[0]?.id || '';
    const supplierOptions = options(activeSuppliers, supplierLinkSupplierId);
    return `${pageHeading('Fournisseurs', 'Centralisez vos partenaires, leurs produits fournis et l’historique de vos achats.', `<button class="btn btn-secondary" type="button" data-action="print-supplier-products">▣ Rapport PDF</button><button class="btn btn-primary" type="button" data-action="add-supplier">＋ Nouveau fournisseur</button>`)}<section class="panel">${toolbar('Nom, contact, IFU...', '#suppliers-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="export-suppliers">⇩ Exporter</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Fournisseur</th><th>Responsable</th><th>Contacts</th><th>N° fiscal</th><th>Produits liés</th><th>Achats</th><th>Statut</th><th></th></tr></thead><tbody id="suppliers-table-body">${pagedTbody('suppliers-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(state.suppliers.length)} fournisseur(s)</span></div></section><section class="panel supplier-links-panel"><div class="panel-header"><div><div class="panel-title">Produits fournis par fournisseur</div><div class="panel-subtitle">Sélectionnez un fournisseur puis cochez les produits qu’il est capable de fournir. Un même produit peut être associé à plusieurs fournisseurs.</div></div><span class="status-badge info">Relation plusieurs-à-plusieurs</span></div><form id="supplier-product-link-form"><div class="supplier-link-layout"><div class="supplier-link-settings"><div class="field"><label for="supplier-link-supplier">Fournisseur <em>*</em></label><select class="select-control" id="supplier-link-supplier" name="supplierId" required>${supplierOptions}</select><div class="field-hint">Le fournisseur principal renseigné dans une fiche produit reste conservé ; cette section gère les fournisseurs complémentaires.</div></div><label class="search-field supplier-link-search"><span>⌕</span><input id="supplier-link-search" type="search" placeholder="Rechercher un produit, code ou catégorie…" autocomplete="off"></label><div class="supplier-link-summary"><strong id="supplier-link-selected-count">0 produit(s) déjà sélectionné(s)</strong><span>Décochez un produit pour retirer le lien, puis validez.</span></div></div><div class="supplier-link-products-wrap"><div class="supplier-link-products-header"><strong>Produits de la base</strong><span>Les produits inactifs restent visibles pour préserver l’historique.</span></div><div id="supplier-link-products" class="supplier-product-grid"></div></div></div><div class="form-actions"><span class="required-note">La sélection remplace les produits liés à ce fournisseur.</span><button class="btn btn-primary" type="submit">✓ Valider la sélection</button></div></form></section>`;
  }

  function renderDeliverers() {
    const deliveries = state.deliveries || [];
    const rows = state.deliverers.map((deliverer) => { const assigned = deliveries.filter((item) => item.delivererId === deliverer.id); const total = assigned.reduce((sum, item) => sum + num(item.fee), 0); return `<tr data-filter-row data-text="${esc(`${deliverer.firstName} ${deliverer.lastName} ${deliverer.phone} ${deliverer.cin}`.toLowerCase())}"><td><strong>${esc(deliverer.firstName)} ${esc(deliverer.lastName)}</strong><span class="table-secondary">${esc(deliverer.cin ? `CIN ${deliverer.cin}` : 'Sans CIN')}</span></td><td>${esc(deliverer.phone || '—')}<span class="table-secondary">${esc(deliverer.secondary || '')}</span></td><td>${esc(deliverer.address || '—')}</td><td><strong>${money(deliverer.baseRate)}</strong><span class="table-secondary">tarif de base</span></td><td>${esc(deliverer.notes || '—')}</td><td>${number(assigned.length)} livraison(s)<span class="table-secondary">${money(total)} de frais</span></td><td>${deliverer.active === false ? statusBadge('Inactif', { Inactif: 'danger' }) : statusBadge('Actif', { Actif: 'success' })}</td><td>${actionButtons('edit-deliverer', deliverer.id, `<button class="table-action danger" type="button" data-action="toggle-deliverer" data-id="${esc(deliverer.id)}" title="${deliverer.active === false ? 'Activer' : 'Désactiver'}">${deliverer.active === false ? '↻' : '×'}</button>`)}</td></tr>`; }).join('');
    return `${pageHeading('Livreurs', 'Enregistrez les livreurs et affectez-les aux ventes depuis l’historique.', `<button class="btn btn-secondary" type="button" data-action="export-deliverers">⇩ Exporter</button><button class="btn btn-primary" type="button" data-action="add-deliverer">＋ Nouveau livreur</button>`)}
      <div class="stat-strip"><div class="strip-item"><span>Livreurs actifs</span><strong>${number(state.deliverers.filter((item) => item.active !== false).length)}</strong></div><div class="strip-item"><span>Livraisons affectées</span><strong>${number(deliveries.length)}</strong></div><div class="strip-item"><span>Frais cumulés</span><strong>${money(deliveries.reduce((sum, item) => sum + num(item.fee), 0))}</strong></div><div class="strip-item"><span>Ventes sans livreur</span><strong>${number(state.sales.filter((sale) => !deliveryForSale(sale.id)).length)}</strong></div></div>
      <section class="panel">${toolbar('Nom, contact, CIN...', '#deliverers-table-body')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Livreur</th><th>Contacts</th><th>Adresse</th><th>Tarif de base</th><th>Informations</th><th>Livraisons</th><th>Statut</th><th></th></tr></thead><tbody id="deliverers-table-body">${rows ? pagedTbody('deliverers-table-body', rows) : `<tr><td colspan="8">${emptyTable('Aucun livreur enregistré')}</td></tr>`}</tbody></table></div><div class="table-footer"><span>${number(state.deliverers.length)} livreur(s)</span></div></section>`;
  }
  function isOrderReceived(order) {
    if (!order) return false;
    return order.status === 'Réceptionnée' || (state.stockEntries || []).some((entry) => entry.type === 'Réception de commande' && String(entry.invoice || '') === String(order.number || ''));
  }
  function orderIsWithinLastMonth(order) {
    if (!order?.date) return false;
    const orderDate = new Date(`${dateOnly(order.date)}T12:00:00`);
    const today = new Date(`${todayKey()}T23:59:59`);
    const earliest = addMonths(new Date(`${todayKey()}T00:00:00`), -1);
    return Number.isFinite(orderDate.getTime()) && orderDate >= earliest && orderDate <= today;
  }
  function recentOrdersForReception() {
    return (state.orders || []).filter(orderIsWithinLastMonth).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
  }
  function orderReceptionButton(order) {
    const received = isOrderReceived(order);
    return `<button class="table-action order-reception-action" type="button" data-action="receive-order" data-id="${esc(order.id)}" title="${received ? 'Commande déjà réceptionnée' : 'Transformer la commande en entrée de stock'}" ${received ? 'disabled' : ''}>${received ? 'Reçue' : 'Réception'}</button>`;
  }
  function renderEntries() {
    const entries = periodItems(state.stockEntries).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const pending = entries.filter((e) => e.status === 'En cours').length;
    const recentOrders = recentOrdersForReception();
    const recentOrderRows = recentOrders.map((order) => {
      const received = isOrderReceived(order);
      const totalUnits = (order.lines || []).reduce((sum, line) => sum + num(line.quantity), 0);
      return `<tr data-filter-row data-text="${esc(`${order.number} ${order.type} ${supplierName(order.supplierId)} ${storeName(order.storeId)} ${order.status}`.toLowerCase())}"><td><strong>${esc(order.number)}</strong><span class="table-secondary">${shortDate(order.date)}</span></td><td>${esc(supplierName(order.supplierId))}</td><td>${esc(storeName(order.storeId))}</td><td><strong>${number((order.lines || []).length)} ligne(s)</strong><span class="table-secondary">${number(totalUnits)} unité(s)</span></td><td><strong>${money(order.total)}</strong></td><td>${statusBadge(received ? 'Réceptionnée' : order.status)}</td><td><div class="table-actions">${orderReceptionButton(order)}<button class="table-action" type="button" data-action="view-order" data-id="${esc(order.id)}" title="Détail de la commande">✎</button></div></td></tr>`;
    }).join('');
    const receptionPanel = `<section class="panel reception-orders-panel"><div class="panel-header"><div><div class="panel-title">Commandes récentes à réceptionner</div><div class="panel-subtitle">Commandes enregistrées au cours du dernier mois · la réception crée une entrée validée pour chaque produit.</div></div><span class="status-badge info">${number(recentOrders.length)} commande(s)</span></div>${toolbar('N° commande, fournisseur, magasin...', '#recent-reception-orders-table-body')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Commande</th><th>Fournisseur</th><th>Magasin</th><th>Lignes / quantité</th><th>Montant</th><th>État</th><th></th></tr></thead><tbody id="recent-reception-orders-table-body">${recentOrderRows ? pagedTbody('recent-reception-orders-table-body', recentOrderRows) : `<tr><td colspan="7">${emptyTable('Aucune commande récente', 'Les commandes de moins d’un mois apparaîtront ici.')}</td></tr>`}</tbody></table></div><div class="table-footer"><span>Fenêtre de réception : du dernier mois jusqu’à aujourd’hui</span></div></section>`;
    const rows = entries.map((entry) => `<tr data-filter-row data-text="${esc(`${entry.number} ${entry.type} ${supplierName(entry.supplierId)} ${productName(entry.productId)} ${entry.invoice}`.toLowerCase())}"><td><strong>${esc(entry.number)}</strong><span class="table-secondary">${dateTime(entry.date)}</span></td><td>${esc(entry.type)}</td><td>${esc(supplierName(entry.supplierId))}</td><td>${esc(productName(entry.productId))}<span class="table-secondary">${esc(storeName(entry.storeId))}</span></td><td>${number(entry.quantity)} u.</td><td><strong>${money(entry.total)}</strong></td><td>${statusBadge(entry.status)}</td><td><div class="table-actions">${entry.status === 'En cours' ? `<button class="table-action" type="button" data-action="validate-entry" data-id="${esc(entry.id)}" title="Valider">✓</button>` : ''}<button class="table-action" type="button" data-action="view-entry" data-id="${esc(entry.id)}" title="Détail">✎</button></div></td></tr>`).join('');
    return `${pageHeading('Entrées de stock', 'Enregistrez les achats et retours sans jamais doubler une incrémentation.', `<button class="btn btn-secondary" type="button" data-action="export-entries">⇩ Exporter</button><button class="btn btn-primary" type="button" data-action="add-entry">＋ Nouvelle entrée</button>`)}${receptionPanel}<div class="notice ${pending ? 'warning' : 'success'}"><span>ⓘ</span><div><strong>${pending ? `${pending} entrée(s) en attente de validation` : 'Stock à jour'}</strong><span>Une entrée « En cours » est enregistrée mais ne modifie pas les quantités disponibles. Une commande réceptionnée est marquée pour empêcher une seconde réception.</span></div></div><section class="panel">${toolbar('Référence, fournisseur, produit...', '#entries-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button><select class="select-control" data-table-filter="status"><option value="">Tous les statuts</option><option value="En cours">En cours</option><option value="Validé">Validé</option></select>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Référence</th><th>Type</th><th>Fournisseur</th><th>Produit / magasin</th><th>Quantité</th><th>Montant</th><th>Statut</th><th></th></tr></thead><tbody id="entries-table-body">${rows ? pagedTbody('entries-table-body', rows) : `<tr><td colspan="8">${emptyTable('Aucune entrée enregistrée')}</td></tr>`}</tbody></table></div><div class="table-footer"><span>${number(entries.length)} entrée(s) · ${number(pending)} en attente</span></div></section>`;
  }

  function renderExits() {
    const exits = periodItems(state.stockExits).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const pending = exits.filter((e) => e.status === 'En cours').length;
    const rows = exits.map((exit) => `<tr data-filter-row data-text="${esc(`${exit.number} ${exit.type} ${exit.beneficiary} ${productName(exit.productId)}`.toLowerCase())}"><td><strong>${esc(exit.number)}</strong><span class="table-secondary">${dateTime(exit.date)}</span></td><td>${esc(exit.type)}</td><td>${esc(exit.beneficiary || '—')}</td><td>${esc(productName(exit.productId))}<span class="table-secondary">${esc(storeName(exit.storeId))}</span></td><td>${number(exit.quantity)} u.</td><td><strong>${money(exit.total)}</strong></td><td>${statusBadge(exit.status)}</td><td><div class="table-actions">${exit.status === 'En cours' ? `<button class="table-action" type="button" data-action="validate-exit" data-id="${esc(exit.id)}" title="Valider">✓</button>` : ''}<button class="table-action" type="button" data-action="view-exit" data-id="${esc(exit.id)}" title="Détail">✎</button></div></td></tr>`).join('');
    return `${pageHeading('Sorties de stock', 'Traçabilité complète des ventes, dons, pertes et vols.', `<button class="btn btn-secondary" type="button" data-action="export-exits">⇩ Exporter</button><button class="btn btn-primary" type="button" data-action="add-exit">＋ Nouvelle sortie</button>`)}<div class="notice info"><span>ⓘ</span><div><strong>Règle de sécurité active</strong><span>Le stock ne peut pas devenir négatif. Les sorties sont déduites uniquement à la validation.</span></div></div><section class="panel">${toolbar('Référence, type, bénéficiaire...', '#exits-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button><select class="select-control" data-table-filter="status"><option value="">Tous les statuts</option><option value="En cours">En cours</option><option value="Validé">Validé</option></select>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Référence</th><th>Type</th><th>Bénéficiaire</th><th>Produit / magasin</th><th>Quantité</th><th>Montant</th><th>Statut</th><th></th></tr></thead><tbody id="exits-table-body">${pagedTbody('exits-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(exits.length)} sortie(s) · ${number(pending)} en attente</span></div></section>`;
  }

  function renderOrders() {
    const orders = periodItems(state.orders).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const rows = orders.map((order) => {
      const received = isOrderReceived(order);
      const receptionLabel = received ? 'Réceptionnée' : 'Réception';
      return `<tr data-filter-row data-text="${esc(`${order.number} ${order.type} ${supplierName(order.supplierId)} ${order.status}`.toLowerCase())}"><td><strong>${esc(order.number)}</strong><span class="table-secondary">${shortDate(order.date)}</span></td><td>${esc(order.type)}${order.express ? ' <span class="express-tag">Express</span>' : ''}</td><td>${esc(supplierName(order.supplierId))}</td><td>${esc(storeName(order.storeId))}</td><td><strong>${number((order.lines || []).length)} ligne(s)</strong><span class="table-secondary">${number((order.lines || []).reduce((s, l) => s + num(l.quantity), 0))} unité(s)</span></td><td><strong>${money(order.total)}</strong></td><td>${statusBadge(received ? 'Réceptionnée' : order.status)}</td><td><div class="table-actions"><button class="table-action order-reception-action" type="button" data-action="receive-order" data-id="${esc(order.id)}" title="${received ? 'Commande déjà réceptionnée' : 'Transformer en entrée de stock'}" ${received ? 'disabled' : ''}>${receptionLabel}</button><button class="table-action" type="button" data-action="view-order" data-id="${esc(order.id)}" title="Consulter">✎</button><button class="table-action" type="button" data-action="print-order" data-id="${esc(order.id)}" title="Imprimer">▣</button></div></td></tr>`;
    }).join('');
    return `${pageHeading('Commandes fournisseurs', 'Anticipez vos approvisionnements et partagez des commandes propres.', `<button class="btn btn-secondary" type="button" data-action="export-orders">⇩ Exporter</button><button class="btn btn-primary" type="button" data-action="add-order">＋ Nouvelle commande</button>`)}${renderExpressOrder()}<section class="panel">${toolbar('N° commande, fournisseur...', '#orders-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button><select class="select-control" data-table-filter="status"><option value="">Tous les statuts</option><option>Brouillon</option><option>Envoyée</option><option>Réceptionnée</option></select>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Commande</th><th>Type</th><th>Fournisseur</th><th>Magasin</th><th>Lignes / quantité</th><th>Montant</th><th>Statut</th><th>Actions</th></tr></thead><tbody id="orders-table-body">${rows ? pagedTbody('orders-table-body', rows) : `<tr><td colspan="8">${emptyTable('Aucune commande enregistrée')}</td></tr>`}</tbody></table></div><div class="table-footer"><span>${number(orders.length)} commande(s)</span></div></section>`;
  }

  function renderQuotes() {
    const quotes = periodItems(state.quotes).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const rows = quotes.map((quote) => `<tr data-filter-row data-text="${esc(`${quote.number} ${quote.clientName} ${quote.status}`.toLowerCase())}"><td><strong>${esc(quote.number)}</strong><span class="table-secondary">${shortDate(quote.date)}</span></td><td><strong>${esc(quote.clientName)}</strong><span class="table-secondary">${esc(quote.clientContact || 'Sans contact')}</span></td><td>${number((quote.lines || []).reduce((s, l) => s + num(l.quantity), 0))} u.</td><td>${money(quote.subtotal)}</td><td>${money(quote.vat)}</td><td><strong>${money(quote.total)}</strong></td><td>${statusBadge(quote.status)}</td><td>${actionButtons('view-quote', quote.id, `<button class="table-action" type="button" data-action="print-quote" data-id="${esc(quote.id)}" title="Imprimer">▣</button>`)}</td></tr>`).join('');
    return `${pageHeading('Devis', 'Préparez des propositions claires, chiffrées et imprimables.', `<button class="btn btn-secondary" type="button" data-action="export-quotes">⇩ Exporter</button><button class="btn btn-primary" type="button" data-action="add-quote">＋ Nouveau devis</button>`)}<section class="panel">${toolbar('N° devis ou nom du client...', '#quotes-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button><button class="btn btn-secondary btn-sm" type="button" data-action="show-vat-info">TVA ${num(state.settings.vat)}%</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Devis</th><th>Client</th><th>Articles</th><th>Sous-total</th><th>TVA</th><th>Total</th><th>Statut</th><th></th></tr></thead><tbody id="quotes-table-body">${pagedTbody('quotes-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(quotes.length)} devis</span></div></section>`;
  }

  function renderExpenses() {
    const expenses = periodItems(state.expenses).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const total = expenses.filter((e) => e.status === 'Validée').reduce((s, e) => s + num(e.amount), 0);
    const rows = expenses.map((expense) => `<tr data-filter-row data-text="${esc(`${expense.number} ${expense.label} ${expense.authorizedBy} ${expense.executedBy}`.toLowerCase())}"><td><strong>${esc(expense.number)}</strong><span class="table-secondary">${shortDate(expense.date)}</span></td><td><strong>${esc(expense.label)}</strong></td><td>${money(expense.amount)}</td><td>${esc(expense.authorizedBy || '—')}</td><td>${esc(expense.executedBy || '—')}</td><td>${expense.receipt ? '<span class="status-badge info">Justifié</span>' : '<span class="table-secondary">Non joint</span>'}</td><td>${statusBadge(expense.status, { Validée: 'success' })}</td><td>${actionButtons('edit-expense', expense.id)}</td></tr>`).join('');
    return `${pageHeading('Dépenses', 'Enregistrez chaque sortie financière et conservez les justificatifs.', `<button class="btn btn-secondary" type="button" data-action="export-expenses">⇩ Exporter</button><button class="btn btn-primary" type="button" data-action="add-expense">＋ Nouvelle dépense</button>`)}<div class="stat-strip"><div class="strip-item"><span>Total validé</span><strong>${money(total)}</strong></div><div class="strip-item"><span>Ce mois</span><strong>${money(expenses.filter((e) => monthKey(e.date) === currentMonthKey()).reduce((s, e) => s + num(e.amount), 0))}</strong></div><div class="strip-item"><span>Justificatifs</span><strong>${number(expenses.filter((e) => e.receipt).length)} / ${number(expenses.length)}</strong></div><div class="strip-item"><span>Opérations</span><strong>${number(expenses.length)}</strong></div></div><section class="panel">${toolbar('Désignation, personne, référence...', '#expenses-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button><button class="btn btn-secondary btn-sm" type="button" data-view="expense-report">Voir le bilan →</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Référence</th><th>Désignation</th><th>Montant</th><th>Autorisé par</th><th>Exécuté par</th><th>Justificatif</th><th>Statut</th><th></th></tr></thead><tbody id="expenses-table-body">${pagedTbody('expenses-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(expenses.length)} dépense(s)</span></div></section>`;
  }

  function renderPurchaseReport() {
    const entries = periodItems(state.stockEntries).filter((entry) => entry.status === 'Validé');
    const total = entries.reduce((s, e) => s + num(e.total), 0);
    const bySupplier = state.suppliers.map((supplier) => ({ ...supplier, total: entries.filter((e) => e.supplierId === supplier.id).reduce((s, e) => s + num(e.total), 0) })).filter((s) => s.total).sort((a, b) => b.total - a.total);
    const byCategory = state.categories.map((category) => ({ ...category, total: entries.filter((e) => productById(e.productId)?.categoryId === category.id).reduce((s, e) => s + num(e.total), 0) })).filter((c) => c.total).sort((a, b) => b.total - a.total);
    const max = Math.max(...bySupplier.map((s) => s.total), 1);
    return `${pageHeading('Bilan des achats', 'Analysez les achats validés par période, fournisseur, catégorie et produit.', `<button class="btn btn-secondary" type="button" data-action="show-date-filter">◷ Période</button><button class="btn btn-secondary" type="button" data-action="export-purchases">⇩ Exporter</button><button class="btn btn-dark" type="button" data-action="print-report" data-report="achats">▣ Imprimer</button>`)}<div class="stat-strip"><div class="strip-item"><span>Total des achats</span><strong>${money(total)}</strong></div><div class="strip-item"><span>Entrées validées</span><strong>${number(entries.length)}</strong></div><div class="strip-item"><span>Quantités achetées</span><strong>${number(entries.reduce((s, e) => s + num(e.quantity), 0))}</strong></div><div class="strip-item"><span>Fournisseurs actifs</span><strong>${number(bySupplier.length)}</strong></div></div><div class="two-column"><section class="panel">${panel('Achats par fournisseur', 'Montants engagés sur les entrées validées', `<div class="data-list">${bySupplier.map((supplier) => `<div class="data-row"><div class="data-row-main"><strong>${esc(supplier.name)}</strong><span>${number(entries.filter((e) => e.supplierId === supplier.id).reduce((s, e) => s + num(e.quantity), 0))} unités</span><div class="progress-wrap"><div class="progress-bar"><span style="width:${(supplier.total / max) * 100}%"></span></div></div></div><div class="data-row-value">${money(supplier.total)}</div></div>`).join('') || emptyState('Aucun achat validé')}</div>`, '')}</section><section class="panel">${panel('Répartition par catégorie', 'Valeur des marchandises entrées', `<div class="data-list">${byCategory.map((category, index) => `<div class="data-row"><span class="legend-dot" style="background:${categoryPalette[index % categoryPalette.length]}"></span><div class="data-row-main"><strong>${esc(category.name)}</strong><span>${number(entries.filter((e) => productById(e.productId)?.categoryId === category.id).reduce((s, e) => s + num(e.quantity), 0))} unités</span></div><div class="data-row-value">${money(category.total)}</div></div>`).join('') || emptyState('Aucune catégorie')}</div>`, '')}</section></div><section class="panel" style="margin-top:14px"><div class="panel-header"><div><div class="panel-title">Détail des achats</div><div class="panel-subtitle">Filtrez et contrôlez les opérations d’approvisionnement.</div></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Référence</th><th>Date</th><th>Fournisseur</th><th>Produit</th><th>Quantité</th><th>Montant</th></tr></thead><tbody>${entries.map((entry) => `<tr><td><strong>${esc(entry.number)}</strong></td><td>${shortDate(entry.date)}</td><td>${esc(supplierName(entry.supplierId))}</td><td>${esc(productName(entry.productId))}</td><td>${number(entry.quantity)}</td><td><strong>${money(entry.total)}</strong></td></tr>`).join('') || `<tr><td colspan="6">${emptyTable('Aucun achat')}</td></tr>`}</tbody></table></div></section>`;
  }

  function renderSalesReport() {
    const sales = periodItems(validSales());
    const notes = periodItems(validCreditNotes());
    const revenue = sales.reduce((s, sale) => s + saleTotal(sale), 0) - notes.reduce((sum, note) => sum + creditNoteTotal(note), 0);
    const margin = sales.reduce((s, sale) => s + saleMargin(sale), 0) - notes.reduce((sum, note) => sum + creditNoteMargin(note), 0);
    const qty = sales.reduce((s, sale) => s + (sale.items || []).reduce((a, item) => a + num(item.quantity), 0), 0) - notes.reduce((s, note) => s + (note.lines || []).reduce((a, item) => a + num(item.quantity), 0), 0);
    const byPayment = ['cash', 'mobile', 'card', 'credit'].map((payment) => ({ payment, total: sales.filter((s) => s.payment === payment).reduce((sum, s) => sum + saleTotal(s), 0) - notes.filter((note) => note.payment === payment).reduce((sum, note) => sum + creditNoteTotal(note), 0), count: sales.filter((s) => s.payment === payment).length }));
    const profitCollection = creditCollectionRatios();
    const collected = collectedMarginOf(sales, notes, profitCollection);
    const ranking = productSalesRanking(sales);
    return `${pageHeading('Bilan des ventes', 'Mesurez le chiffre d’affaires, la marge et les canaux d’encaissement.', `<button class="btn btn-secondary" type="button" data-action="export-sales-report">⇩ Exporter</button><button class="btn btn-secondary" type="button" data-view="credit-notes">↩ Voir les avoirs</button><button class="btn btn-dark" type="button" data-action="print-report" data-report="ventes">▣ Imprimer</button>`)}<div class="stat-strip five"><div class="strip-item"><span>Chiffre d’affaires</span><strong>${money(revenue)}</strong></div><div class="strip-item"><span>Bénéfice brut · avec créances</span><strong>${money(margin)}</strong></div><div class="strip-item"><span>Bénéfice encaissé</span><strong>${money(collected)}</strong></div><div class="strip-item"><span>Nombre de ventes</span><strong>${number(sales.length)}</strong></div><div class="strip-item"><span>Quantités vendues</span><strong>${number(qty)}</strong></div></div><div class="two-column"><section class="panel">${panel('Ventes par mode de paiement', 'Répartition du chiffre d’affaires', `<div class="data-list">${byPayment.map((item) => `<div class="data-row"><span class="status-dot ${item.payment === 'credit' ? 'orange' : item.payment === 'cash' ? 'teal' : 'blue'}"></span><div class="data-row-main"><strong>${paymentLabel(item.payment)}</strong><span>${number(item.count)} opération(s)</span></div><div class="data-row-value">${money(item.total)}</div></div>`).join('')}</div>`, '')}</section><section class="panel">${panel('Produits les plus vendus', 'Quantités écoulées', `<div class="data-list">${ranking.slice(0, 6).map((item, index) => `<div class="data-row"><span class="rank">${String(index + 1).padStart(2, '0')}</span><div class="data-row-main"><strong>${esc(item.product.name)}</strong><span>${esc(categoryName(item.product.categoryId))}</span></div><div class="data-row-value">${number(item.quantity)} u.</div></div>`).join('') || emptyState('Aucune vente')}</div>`, '')}</section></div><section class="panel" style="margin-top:14px">${toolbar('Numéro, client ou paiement...', '#sales-report-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Opération</th><th>Date</th><th>Client</th><th>Montant net</th><th>Marge nette</th><th>Paiement</th><th>Utilisateur</th></tr></thead><tbody id="sales-report-table-body">${pagedTbody('sales-report-table-body', [...sales.map((sale) => `<tr data-filter-row data-text="${esc(`${sale.number} ${clientName(sale.clientId)} ${paymentLabel(sale.payment)}`.toLowerCase())}"><td><strong>${esc(sale.number)}</strong></td><td>${dateTime(sale.date)}</td><td>${esc(clientName(sale.clientId))}</td><td><strong>${money(saleTotal(sale))}</strong></td><td>${money(saleMargin(sale))}${sale.payment === 'credit' ? `<span class="table-secondary">encaissé ${money(saleCollectedMargin(sale, profitCollection))}</span>` : ''}</td><td>${paymentBadge(sale.payment)}</td><td>${esc(userName(sale.userId))}</td></tr>`), ...notes.map((note) => `<tr data-filter-row data-text="${esc(`${note.number} ${note.originalSaleNumber} ${clientName(note.clientId)} avoir`.toLowerCase())}"><td><strong>${esc(note.number)}</strong><span class="table-secondary">${esc(note.originalSaleNumber)}</span></td><td>${dateTime(note.date)}</td><td>${esc(clientName(note.clientId))}</td><td><strong style="color:var(--red)">−${money(creditNoteTotal(note))}</strong></td><td style="color:var(--red)">−${money(creditNoteMargin(note))}</td><td><span class="status-badge danger">Avoir</span></td><td>${esc(userName(note.userId))}</td></tr>`)] )}</tbody></table></div></section>`;
  }

  function renderExpenseReport() {
    const expenses = periodItems(state.expenses).filter((e) => e.status === 'Validée');
    const total = expenses.reduce((s, e) => s + num(e.amount), 0);
    const max = Math.max(...expenses.map((e) => num(e.amount)), 1);
    return `${pageHeading('Bilan des dépenses', 'Suivez les dépenses, leurs tendances et les responsables.', `<button class="btn btn-secondary" type="button" data-action="export-expenses">⇩ Exporter</button><button class="btn btn-dark" type="button" data-action="print-report" data-report="depenses">▣ Imprimer</button>`)}<div class="stat-strip"><div class="strip-item"><span>Total validé</span><strong>${money(total)}</strong></div><div class="strip-item"><span>Dépense moyenne</span><strong>${money(expenses.length ? total / expenses.length : 0)}</strong></div><div class="strip-item"><span>Plus gros poste</span><strong>${money(Math.max(...expenses.map((e) => e.amount), 0))}</strong></div><div class="strip-item"><span>Justificatifs joints</span><strong>${number(expenses.filter((e) => e.receipt).length)}</strong></div></div><div class="two-column"><section class="panel">${panel('Évolution des dépenses', 'Les dernières opérations validées', `<div class="data-list">${expenses.slice().sort((a, b) => localDate(b.date) - localDate(a.date)).slice(0, 6).map((expense) => `<div class="data-row"><div class="data-row-main"><strong>${esc(expense.label)}</strong><span>${shortDate(expense.date)} · ${esc(expense.executedBy)}</span><div class="progress-wrap"><div class="progress-bar"><span style="width:${(expense.amount / max) * 100}%;background:#8270dc"></span></div></div></div><div class="data-row-value">${money(expense.amount)}</div></div>`).join('') || emptyState('Aucune dépense')}</div>`, '')}</section><section class="panel">${panel('Répartition', 'Par désignation', `<div class="data-list">${expenses.slice().sort((a, b) => b.amount - a.amount).slice(0, 6).map((expense, index) => `<div class="data-row"><span class="legend-dot" style="background:${['#8270dc','#f19a52','#0f9f91','#4e87df','#d9a5b1'][index % 5]}"></span><div class="data-row-main"><strong>${esc(expense.label)}</strong><span>${shortDate(expense.date)}</span></div><div class="data-row-value">${Math.round((expense.amount / (total || 1)) * 100)}%</div></div>`).join('') || emptyState('Aucune donnée')}</div>`, '')}</section></div><section class="panel" style="margin-top:14px">${toolbar('Désignation, autorisateur ou exécutant...', '#expense-report-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Désignation</th><th>Montant</th><th>Autorisé par</th><th>Exécuté par</th><th>Justificatif</th></tr></thead><tbody id="expense-report-table-body">${pagedTbody('expense-report-table-body', expenses.map((expense) => `<tr data-filter-row data-text="${esc(`${expense.label} ${expense.authorizedBy} ${expense.executedBy}`.toLowerCase())}"><td>${shortDate(expense.date)}</td><td><strong>${esc(expense.label)}</strong></td><td><strong>${money(expense.amount)}</strong></td><td>${esc(expense.authorizedBy)}</td><td>${esc(expense.executedBy)}</td><td>${expense.receipt ? statusBadge('Justifié', { Justifié: 'info' }) : '—'}</td></tr>`))}</tbody></table></div></section>`;
  }

  function renderAccounting() {
    const sales = periodItems(validSales());
    const notes = periodItems(validCreditNotes());
    const revenue = sales.reduce((s, sale) => s + saleTotal(sale), 0) - notes.reduce((sum, note) => sum + creditNoteTotal(note), 0);
    const margin = sales.reduce((s, sale) => s + saleMargin(sale), 0) - notes.reduce((sum, note) => sum + creditNoteMargin(note), 0);
    const profitCollection = creditCollectionRatios();
    const collected = collectedMarginOf(sales, notes, profitCollection);
    const purchases = periodItems(state.stockEntries).filter((e) => e.status === 'Validé').reduce((s, e) => s + num(e.total), 0);
    const expenses = periodItems(state.expenses).filter((e) => e.status === 'Validée').reduce((s, e) => s + num(e.amount), 0);
    const netCollected = collected - expenses;
    const stockValue = activeProducts().reduce((s, p) => s + totalStock(p) * p.purchasePrice, 0);
    const credits = state.clients.reduce((s, c) => s + num(c.receivable), 0);
    const advances = state.clients.reduce((s, c) => s + num(c.advance), 0);
    const cash = sales.filter((s) => s.payment === 'cash').reduce((sum, s) => sum + saleTotal(s), 0) - notes.filter((note) => note.payment === 'cash').reduce((sum, note) => sum + creditNoteTotal(note), 0);
    const mobile = sales.filter((s) => s.payment === 'mobile').reduce((sum, s) => sum + saleTotal(s), 0) - notes.filter((note) => note.payment === 'mobile').reduce((sum, note) => sum + creditNoteTotal(note), 0);
    const card = sales.filter((s) => s.payment === 'card').reduce((sum, s) => sum + saleTotal(s), 0) - notes.filter((note) => note.payment === 'card').reduce((sum, note) => sum + creditNoteTotal(note), 0);
    return `${pageHeading('Comptabilité', 'Une synthèse financière consolidée à partir des opérations validées.', `<button class="btn btn-secondary" type="button" data-action="show-date-filter">◷ Période</button><button class="btn btn-secondary" type="button" data-action="export-accounting">⇩ Exporter</button><button class="btn btn-dark" type="button" data-action="print-report" data-report="comptabilite">▣ Imprimer</button>`)}<div class="metric-grid">${metricCard('↗', 'Chiffre d’affaires', money(revenue), { text: `${number(sales.length)} ventes`, className: 'up' }, 'validées', 'teal')}${metricCard('◒', 'Marge brute', money(margin), { text: revenue ? `${Math.round(margin / revenue * 100)} %` : '0 %', className: 'up' }, 'sur le CA · avec créances', 'orange')}${metricCard('₣', 'Marge encaissée', money(collected), { text: margin ? `${Math.round(collected / margin * 100)} % de la marge` : '0 %', className: 'up' }, 'hors créances', 'teal')}${metricCard('◇', 'Dépenses', money(expenses), { text: `${number(state.expenses.length)} opérations`, className: 'neutral' }, 'validées', 'purple')}${metricCard('₣', 'Bénéfice net', money(margin - expenses), { text: margin - expenses >= 0 ? 'positif' : 'négatif', className: margin - expenses >= 0 ? 'up' : 'down' }, 'marge - dépenses · avec créances', 'blue')}${metricCard('₣', 'Bénéfice net encaissé', money(netCollected), { text: netCollected >= 0 ? 'positif' : 'négatif', className: netCollected >= 0 ? 'up' : 'down' }, 'hors créances', netCollected >= 0 ? 'teal' : 'red')}</div><div class="dashboard-grid equal"><section class="panel"><div class="panel-header"><div><div class="panel-title">Position financière</div><div class="panel-subtitle">Vue de synthèse · opérations validées</div></div></div><div class="panel-body"><div class="detail-grid"><div class="detail-item"><label>Achats validés</label><strong>${money(purchases)}</strong></div><div class="detail-item"><label>Valeur du stock</label><strong>${money(stockValue)}</strong></div><div class="detail-item"><label>Créances clients</label><strong>${money(credits)}</strong></div><div class="detail-item"><label>Avances clients</label><strong>${money(advances)}</strong></div><div class="detail-item"><label>Encaissements</label><strong>${money(cash + mobile + card)}</strong></div><div class="detail-item"><label>Ventes à crédit</label><strong>${money(sales.filter((s) => s.payment === 'credit').reduce((sum, s) => sum + saleTotal(s), 0))}</strong></div><div class="detail-item"><label>Résultat net · avec créances</label><strong style="color:${margin - expenses >= 0 ? 'var(--teal-dark)' : 'var(--red)'}">${money(margin - expenses)}</strong></div><div class="detail-item"><label>Marge encaissée</label><strong>${money(collected)}</strong></div><div class="detail-item"><label>Résultat net encaissé</label><strong style="color:${netCollected >= 0 ? 'var(--teal-dark)' : 'var(--red)'}">${money(netCollected)}</strong></div></div></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Encaissements par canal</div><div class="panel-subtitle">Répartition du chiffre d’affaires</div></div></div><div class="panel-body"><div class="data-list">${[['Cash', cash, 'teal'], ['Mobile Money', mobile, 'blue'], ['Carte', card, 'purple'], ['À crédit', revenue - cash - mobile - card, 'orange']].map(([label, value, tone]) => `<div class="data-row"><span class="status-dot ${tone === 'purple' ? 'blue' : tone}"></span><div class="data-row-main"><strong>${label}</strong><span>${revenue ? Math.round(value / revenue * 100) : 0}% du CA</span></div><div class="data-row-value">${money(value)}</div></div>`).join('')}</div></div></section></div><section class="panel" style="margin-top:14px"><div class="panel-header"><div><div class="panel-title">Créances clients</div><div class="panel-subtitle">Suivi des encours à recouvrer</div></div><button class="panel-link" type="button" data-view="clients">Gérer les clients →</button></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Client</th><th>Contact</th><th>Encours</th><th>Limite</th><th>Utilisation</th><th></th></tr></thead><tbody>${state.clients.filter((c) => c.receivable > 0).map((client) => `<tr><td><strong>${esc(client.name)}</strong></td><td>${esc(client.phone)}</td><td><strong>${money(client.receivable)}</strong></td><td>${money(client.creditLimit)}</td><td><span class="stock-meter"><span class="${client.receivable / client.creditLimit > .8 ? 'low' : 'ok'}" style="width:${clamp(client.receivable / client.creditLimit * 100, 3, 100)}%"></span></span>${Math.round(client.receivable / client.creditLimit * 100)}%</td><td><button class="text-button" type="button" data-action="client-history" data-id="${esc(client.id)}">Détail →</button></td></tr>`).join('') || `<tr><td colspan="6">${emptyTable('Aucune créance', 'Vos clients sont à jour.')}</td></tr>`}</tbody></table></div></section>`;
  }

  function inventoryReportLines(products = activeProducts()) {
    return products.map((product) => {
      const record = state.inventory.find((item) => item.productId === product.id);
      const theoretical = num(totalStock(product));
      const counted = !!record;
      const real = counted ? num(record.real) : null;
      return {
        id: uid('inventory-report-line'),
        productId: product.id,
        storeId: record?.storeId || product.storeId || state.settings.defaultStoreId || '',
        code: product.code,
        productName: product.name,
        categoryName: categoryName(product.categoryId),
        storeName: storeName(record?.storeId || product.storeId || state.settings.defaultStoreId || ''),
        theoretical,
        real,
        gap: counted ? real - theoretical : null,
        counted,
        inventoryDate: record?.date || ''
      };
    });
  }
  function inventoryReportSummary(reportOrLines) {
    const lines = Array.isArray(reportOrLines) ? reportOrLines : (reportOrLines?.lines || []);
    const countedLines = lines.filter((line) => line.counted || line.real != null);
    const gapLines = countedLines.filter((line) => num(line.gap) !== 0);
    const theoreticalTotal = lines.reduce((sum, line) => sum + num(line.theoretical), 0);
    const realTotal = countedLines.reduce((sum, line) => sum + num(line.real), 0);
    const gapTotal = countedLines.reduce((sum, line) => sum + num(line.gap), 0);
    return {
      totalProducts: lines.length,
      countedProducts: countedLines.length,
      gapProducts: gapLines.length,
      theoreticalTotal,
      realTotal,
      gapTotal
    };
  }
  function inventoryReportData(report) {
    const lines = (report?.lines || []).map((line) => ({
      ...line,
      productName: line.productName || productName(line.productId),
      categoryName: line.categoryName || categoryName(productById(line.productId)?.categoryId),
      storeName: line.storeName || storeName(line.storeId),
      counted: line.counted === true || line.real != null,
      theoretical: num(line.theoretical),
      real: line.real == null ? null : num(line.real),
      gap: line.gap == null ? null : num(line.gap)
    }));
    return { ...report, lines, ...inventoryReportSummary(lines) };
  }
  function showInventoryReport(report) {
    const data = inventoryReportData(report);
    const summary = inventoryReportSummary(data);
    const rows = data.lines.map((line) => `<tr><td><strong>${esc(line.code || '—')}</strong></td><td>${esc(line.productName)}</td><td>${esc(line.categoryName)}</td><td>${esc(line.storeName)}</td><td>${number(line.theoretical)} u.</td><td>${line.counted ? `${number(line.real)} u.` : '<span class="table-secondary">Non compté</span>'}</td><td>${line.counted ? `<strong style="color:${num(line.gap) === 0 ? 'var(--teal-dark)' : 'var(--orange)'}">${num(line.gap) > 0 ? '+' : ''}${number(line.gap)} u.</strong>` : '—'}</td></tr>`).join('');
    const body = `<div class="inventory-report-summary"><div class="detail-grid"><div class="detail-item"><label>Date de l’inventaire</label><strong>${shortDate(data.date)}</strong></div><div class="detail-item"><label>Produits comptés</label><strong>${number(summary.countedProducts)} / ${number(summary.totalProducts)}</strong></div><div class="detail-item"><label>Produits avec écart</label><strong>${number(summary.gapProducts)}</strong></div><div class="detail-item"><label>Écart total</label><strong style="color:${summary.gapTotal === 0 ? 'var(--teal-dark)' : 'var(--orange)'}">${summary.gapTotal > 0 ? '+' : ''}${number(summary.gapTotal)} u.</strong></div></div></div><div class="table-wrap inventory-report-table-wrap"><table class="data-table"><thead><tr><th>Code</th><th>Produit</th><th>Catégorie</th><th>Magasin</th><th>Théorique</th><th>Réel</th><th>Écart</th></tr></thead><tbody>${rows || `<tr><td colspan="7">${emptyTable('Rapport vide')}</td></tr>`}</tbody></table></div>`;
    openModal(`Rapport d’inventaire · ${esc(data.number || '—')}`, `${esc(data.title || 'Inventaire')} · ${shortDate(data.date)}`, body, 'xl', `<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button><button class="btn btn-dark" type="button" data-action="print-inventory-report" data-id="${esc(data.id)}">▣ Imprimer le rapport</button>`);
  }
  function openInventoryReportModal() {
    if (!requirePermission('inventory.manage', 'Votre profil ne peut pas générer un rapport d’inventaire.')) return;
    const lines = inventoryReportLines();
    const summary = inventoryReportSummary(lines);
    if (!summary.countedProducts) { toast('Comptage requis', 'Saisissez au moins un comptage réel avant de générer un rapport.', 'warning'); return; }
    const body = `<form id="inventory-report-form"><div class="notice info"><span>▤</span><div><strong>${number(summary.countedProducts)} produit(s) compté(s) sur ${number(summary.totalProducts)}</strong><span>Le rapport enregistre une photographie du stock théorique, du réel et des écarts à la date choisie. Les rapports enregistrés restent disponibles dans l’historique.</span></div></div><div class="form-grid"><div class="field"><label>Date de l’inventaire <em>*</em></label><input class="input-control" type="date" name="date" value="${todayKey()}" required></div><div class="field"><label>Libellé du rapport</label><input class="input-control" name="title" value="Inventaire du ${todayKey()}" maxlength="120" placeholder="Ex. Inventaire mensuel boutique"></div></div><div class="detail-grid inventory-report-draft-metrics"><div class="detail-item"><label>Stock théorique</label><strong>${number(summary.theoreticalTotal)} u.</strong></div><div class="detail-item"><label>Stock réel compté</label><strong>${number(summary.realTotal)} u.</strong></div><div class="detail-item"><label>Écart total</label><strong style="color:${summary.gapTotal === 0 ? 'var(--teal-dark)' : 'var(--orange)'}">${summary.gapTotal > 0 ? '+' : ''}${number(summary.gapTotal)} u.</strong></div></div><div class="field-hint">Les produits non comptés seront conservés dans le rapport avec l’état « Non compté ». La génération ne modifie pas le stock.</div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">✓ Générer et enregistrer</button></div></form>`;
    openModal('Générer un rapport d’inventaire', 'Enregistrez l’état du comptage avant impression ou consultation ultérieure.', body, 'lg');
    $('#inventory-report-form').addEventListener('submit', (event) => saveInventoryReport(event, lines));
  }
  function saveInventoryReport(event, lines) {
    event.preventDefault();
    if (!requirePermission('inventory.manage', 'Votre profil ne peut pas enregistrer un rapport d’inventaire.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour enregistrer un rapport d’inventaire.', 'warning'); return; }
    const data = Object.fromEntries(new FormData(event.currentTarget).entries());
    if (!data.date) { toast('Date requise', 'Indiquez la date de l’inventaire.', 'warning'); return; }
    const summary = inventoryReportSummary(lines);
    const report = { id: uid('inventory-report'), number: nextNumber('RIN', state.inventoryReports), date: data.date, title: String(data.title || '').trim() || `Inventaire du ${shortDate(data.date)}`, storeId: '', lines: lines.map((line) => ({ ...line })), ...summary, createdAt: new Date().toISOString(), userId: currentUserId() };
    const previousReports = state.inventoryReports.slice();
    const activityId = uid('act');
    state.inventoryReports.unshift(report);
    state.activities.unshift({ id: activityId, date: new Date().toISOString(), userId: currentUserId(), module: 'Inventaire', action: 'Génération d’un rapport d’inventaire', element: report.number, detail: `${number(summary.countedProducts)} produit(s) compté(s) · ${number(summary.gapProducts)} écart(s)`, oldValue: '', newValue: report.date });
    if (!saveState()) {
      state.inventoryReports = previousReports;
      state.activities = state.activities.filter((activity) => activity.id !== activityId);
      return;
    }
    closeModal();
    render();
    toast('Rapport enregistré', `${report.number} · inventaire du ${shortDate(report.date)}.`);
    showInventoryReport(report);
  }
  function printInventoryReport(report) {
    const data = inventoryReportData(report);
    const summary = inventoryReportSummary(data);
    printDocument(`Rapport d’inventaire · ${data.number || ''}`, `${data.title || 'Inventaire'} · ${shortDate(data.date)} · ${number(summary.gapProducts)} écart(s)`, { headers: ['Code', 'Produit', 'Catégorie', 'Magasin', 'Théorique', 'Réel', 'Écart'], body: data.lines.map((line) => [line.code, line.productName, line.categoryName, line.storeName, `${number(line.theoretical)} u.`, line.counted ? `${number(line.real)} u.` : 'Non compté', line.counted ? `${num(line.gap) > 0 ? '+' : ''}${number(line.gap)} u.` : '—']) });
  }
  function renderInventoryReportHistory() {
    const reports = (state.inventoryReports || []).slice().sort((left, right) => localDate(right.date || right.createdAt) - localDate(left.date || left.createdAt));
    const rows = reports.map((report) => {
      const data = inventoryReportData(report);
      const summary = inventoryReportSummary(data);
      return `<tr data-filter-row data-text="${esc(`${data.number} ${data.title} ${data.date} ${userName(data.userId)}`.toLowerCase())}"><td><strong>${esc(data.number || '—')}</strong><span class="table-secondary">${esc(data.title || 'Inventaire')}</span></td><td>${shortDate(data.date)}</td><td>${number(summary.countedProducts)} / ${number(summary.totalProducts)}</td><td><strong>${number(summary.gapProducts)}</strong></td><td><strong style="color:${summary.gapTotal === 0 ? 'var(--teal-dark)' : 'var(--orange)'}">${summary.gapTotal > 0 ? '+' : ''}${number(summary.gapTotal)} u.</strong></td><td>${esc(userName(data.userId))}</td><td><div class="table-actions"><button class="table-action" type="button" data-action="view-inventory-report" data-id="${esc(data.id)}" title="Consulter">⌕</button><button class="table-action" type="button" data-action="print-inventory-report" data-id="${esc(data.id)}" title="Imprimer">▣</button></div></td></tr>`;
    }).join('');
    return `<section class="panel inventory-reports-panel"><div class="panel-header"><div><div class="panel-title">Rapports d’inventaire enregistrés</div><div class="panel-subtitle">Historique des inventaires générés, avec leur date, leurs écarts et leur utilisateur.</div></div><span class="status-badge info">${number(reports.length)} rapport(s)</span></div>${toolbar('Référence, libellé, date ou utilisateur...', '#inventory-reports-table-body')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Rapport</th><th>Date</th><th>Comptage</th><th>Écarts</th><th>Écart total</th><th>Utilisateur</th><th></th></tr></thead><tbody id="inventory-reports-table-body">${rows ? pagedTbody('inventory-reports-table-body', rows) : `<tr><td colspan="7">${emptyTable('Aucun rapport enregistré', 'Générez un rapport après avoir saisi un comptage réel.')}</td></tr>`}</tbody></table></div><div class="table-footer"><span>${number(reports.length)} rapport(s) conservé(s) localement</span></div></section>`;
  }
  function renderInventory() {
    const products = activeProducts();
    const lastInventory = state.inventory.length ? state.inventory[0].date : '';
    const lastReport = (state.inventoryReports || []).slice().sort((left, right) => localDate(right.date || right.createdAt) - localDate(left.date || left.createdAt))[0];
    const statusText = lastReport ? `Dernier rapport : ${shortDate(lastReport.date)} · ${lastReport.number}` : 'Aucun rapport enregistré.';
    return `${pageHeading('Inventaire', 'Comparez le stock théorique au comptage réel, générez un rapport et conservez l’historique des inventaires.', `<button class="btn btn-secondary" type="button" data-action="export-inventory">⇩ Exporter</button><button class="btn btn-dark" type="button" data-action="print-inventory">▣ Imprimer la fiche</button><button class="btn btn-primary" type="button" data-action="create-inventory-report">＋ Générer le rapport</button><button class="btn btn-secondary" type="button" data-action="start-inventory">＋ Nouveau comptage</button>`)}<div class="notice info"><span>ⓘ</span><div><strong>Fiche d’inventaire</strong><span>${lastInventory ? `Dernier comptage : ${shortDate(lastInventory)}` : 'Aucun comptage physique n’a encore été saisi.'} · ${statusText}</span></div></div><section class="panel">${toolbar('Code, désignation ou catégorie...', '#inventory-table-body', '<select class="select-control" data-table-filter="state"><option value="">Tous les états</option><option value="Écart">Avec écart</option><option value="Conforme">Conforme</option><option value="Non compté">Non compté</option></select>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Produit</th><th>Catégorie</th><th>Magasin</th><th>Stock théorique</th><th>Stock réel</th><th>Écart</th><th>Date</th><th></th></tr></thead><tbody id="inventory-table-body">${pagedTbody('inventory-table-body', products.map((product) => { const record = state.inventory.find((i) => i.productId === product.id); const real = record ? record.real : '—'; const gap = record ? num(real) - totalStock(product) : null; return `<tr data-filter-row data-text="${esc(`${product.code} ${product.name} ${categoryName(product.categoryId)}`.toLowerCase())}" data-state="${record ? (gap === 0 ? 'Conforme' : 'Écart') : 'Non compté'}"><td><div class="table-product"><img class="mini-thumb" src="${productImage(product)}" alt=""><div><strong>${esc(product.name)}</strong><span class="table-secondary">${esc(product.code)}</span></div></div></td><td>${esc(categoryName(product.categoryId))}</td><td>${esc(storeName(product.storeId))}</td><td><strong>${number(totalStock(product))} u.</strong></td><td>${record ? `${number(real)} u.` : '<span class="table-secondary">Non compté</span>'}</td><td>${record ? `<strong style="color:${gap === 0 ? 'var(--teal-dark)' : 'var(--orange)'}">${gap > 0 ? '+' : ''}${number(gap)} u.</strong>` : '—'}</td><td>${record ? shortDate(record.date) : '—'}</td><td><button class="table-action" type="button" data-action="count-product" data-id="${esc(product.id)}" title="Saisir le comptage">✎</button></td></tr>`; }))}</tbody></table></div><div class="table-footer"><span>${number(products.length)} produit(s) à contrôler</span></div></section>${renderInventoryReportHistory()}`;
  }

  function renderReports() {
    const reports = [
      ['Rapport des ventes', 'Chiffre d’affaires, marges, produits et modes de paiement', 'sales-report', 'trending-up', 'teal', 'ventes'],
      ['Rapport des achats', 'Achats par fournisseur, catégorie et période', 'purchase-report', 'shopping-cart', 'orange', 'achats'],
      ['Rapport des stocks', 'État du stock, valorisation et alertes', 'inventory', 'package', 'blue', 'stocks'],
      ['Rapport des dépenses', 'Évolution, répartition et justificatifs', 'expense-report', 'receipt', 'purple', 'depenses'],
      ['Rapport des créances', 'Encours et suivi des clients débiteurs', 'accounting', 'coins', 'red', 'creances'],
      ['Rapport des bénéfices', 'Marge brute, résultat net et rentabilité', 'accounting', 'circle-dollar-sign', 'teal', 'benefices'],
      ['Rapport fournisseurs', 'Liste des produits fournis par chaque fournisseur', 'suppliers', 'truck', 'blue', 'fournisseurs']
    ];
    return `${pageHeading('Rapports', 'Générez les états utiles au pilotage et exportez-les en quelques clics.', `<button class="btn btn-secondary" type="button" data-action="show-report-filters">≡ Filtres avancés</button><button class="btn btn-primary" type="button" data-action="print-report" data-report="synthese">▣ Imprimer la synthèse</button>`)}<div class="notice success"><span>✓</span><div><strong>Rapports prêts à l’emploi</strong><span>Les données sont calculées à partir des opérations validées. Choisissez un état pour l’ouvrir ou l’imprimer.</span></div></div><div class="products-grid" style="grid-template-columns:repeat(3,minmax(0,1fr));padding:0;gap:13px">${reports.map(([title, desc, view, iconName, tone, kind]) => `<article class="panel" style="padding:17px;cursor:pointer" data-view="${view}"><div class="metric-icon" style="background:var(--${tone}-soft);color:var(--${tone})">${icon(iconName, 17)}</div><div class="panel-title" style="margin-top:13px">${title}</div><div class="panel-subtitle" style="min-height:31px">${desc}</div><div class="report-card-actions"><button class="text-button" type="button" data-view="${view}">Ouvrir le rapport →</button><button class="btn btn-secondary btn-sm" type="button" data-action="${kind === 'fournisseurs' ? 'print-supplier-products' : 'print-full-report'}" data-report="${kind}">▣ PDF</button></div></article>`).join('')}</div><section class="panel" style="margin-top:14px"><div class="panel-header"><div><div class="panel-title">Filtres disponibles</div><div class="panel-subtitle">Tous les rapports peuvent être limités par les dimensions suivantes.</div></div></div><div class="panel-body"><div class="detail-grid"><div class="detail-item"><label>Période</label><strong>Aujourd’hui · mois · personnalisé</strong></div><div class="detail-item"><label>Magasin</label><strong>${number(state.stores.length)} magasins</strong></div><div class="detail-item"><label>Catalogue</label><strong>${number(state.categories.length)} catégories · ${number(state.products.length)} produits</strong></div><div class="detail-item"><label>Partenaires</label><strong>${number(state.suppliers.length)} fournisseurs · ${number(state.clients.length)} clients</strong></div><div class="detail-item"><label>Utilisateurs</label><strong>${number(state.users.length)} utilisateurs actifs</strong></div><div class="detail-item"><label>Sortie</label><strong>Impression ou CSV</strong></div></div></div></section>`;
  }

  function renderUsers() {
    const rows = state.users.map((user) => `<tr data-filter-row data-text="${esc(`${user.name} ${user.username} ${user.profile}`.toLowerCase())}"><td><div class="table-product"><div class="avatar">${esc(user.name.split(' ').map((p) => p[0]).slice(0,2).join('').toUpperCase())}</div><div><strong>${esc(user.name)}</strong><span class="table-secondary">@${esc(user.username)}</span></div></div></td><td><span class="status-badge purple">${esc(user.profile)}</span></td><td>${user.passwordHash ? '<span class="status-badge success">Protégé</span>' : '<span class="status-badge danger">À sécuriser</span>'}</td><td>${user.active === false ? statusBadge('Inactif', { Inactif: 'danger' }) : statusBadge('Actif', { Actif: 'success' })}</td><td>${actionButtons('edit-user', user.id, `<button class="table-action" type="button" data-action="reset-password" data-id="${esc(user.id)}" title="Réinitialiser le mot de passe">↻</button>`)}</td></tr>`).join('');
    return `${pageHeading('Utilisateurs', 'Gérez les comptes, profils et accès à l’application.', `<button class="btn btn-secondary" type="button" data-action="show-security-info">▣ Sécurité</button><button class="btn btn-primary" type="button" data-action="add-user">＋ Nouvel utilisateur</button>`)}<div class="notice info"><span>◉</span><div><strong>Protection des mots de passe activée</strong><span>Les mots de passe ne sont jamais affichés dans l’application et doivent être stockés sous forme de hash en production.</span></div></div><section class="panel">${toolbar('Nom, identifiant ou profil...', '#users-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-view="roles">Gérer les profils →</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Utilisateur</th><th>Profil</th><th>Mot de passe</th><th>Statut</th><th></th></tr></thead><tbody id="users-table-body">${pagedTbody('users-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(state.users.filter((u) => u.active !== false).length)} utilisateur(s) actif(s)</span></div></section>`;
  }

  function renderRoles() {
    const permissionLabels = [
      ['sales.create', 'Créer une vente'], ['sales.validate', 'Valider une vente'], ['clients.manage', 'Gérer les clients'], ['credit.view', 'Consulter les créances'], ['credit.record', 'Enregistrer un règlement'], ['products.manage', 'Gérer les produits'], ['deliverers.manage', 'Gérer les livreurs'], ['stock.create', 'Créer un mouvement de stock'], ['stock.validate', 'Valider un mouvement de stock'], ['orders.manage', 'Gérer les commandes'], ['quotes.manage', 'Gérer les devis'], ['expenses.manage', 'Gérer les dépenses'], ['inventory.manage', 'Gérer l’inventaire'], ['reports.export', 'Exporter les rapports'], ['users.manage', 'Gérer les utilisateurs'], ['roles.manage', 'Gérer les profils'], ['settings.manage', 'Modifier les paramètres'], ['license.activate', 'Activer la licence']
    ];
    const matrixRoles = state.roles.slice(0, 5);
    const matrixRows = ROLE_MATRIX_MODULES.map(([group, modules]) => `<tr class="matrix-group-row"><td colspan="${2 + matrixRoles.length}">${esc(group)}</td></tr>${modules.map(([view, label]) => {
      const required = [VIEW_PERMISSIONS[view], ...(MODULE_MANAGE_PERMISSIONS[view] || [])].filter(Boolean);
      return `<tr><td><strong>${esc(label)}</strong></td><td>${required.map((perm) => `<code class="perm-key">${esc(perm)}</code>`).join(' ')}</td>${matrixRoles.map((role) => {
        const permissions = Array.isArray(role.permissions) ? role.permissions : [];
        return `<td><div class="matrix-badges">${required.map((perm) => (permissions.includes('*') || permissions.includes(perm) ? '<span class="status-badge success">Autorisé</span>' : '<span class="status-badge neutral">Limité</span>')).join('')}</div></td>`;
      }).join('')}</tr>`;
    }).join('')}`).join('');
    return `${pageHeading('Profils & droits', 'Les permissions sont enregistrées et contrôlées avant chaque opération sensible.', `<button class="btn btn-primary" type="button" data-action="add-role">＋ Nouveau profil</button>`)}<div class="three-column">${state.roles.map((role) => { const permissions = Array.isArray(role.permissions) ? role.permissions : []; return `<section class="panel"><div class="panel-header"><div><span class="status-badge ${role.color || 'neutral'}">${esc(role.name)}</span><div class="panel-subtitle" style="margin-top:8px">${esc(role.description)}</div></div><button class="table-action" type="button" data-action="edit-role" data-id="${esc(role.id)}">✎</button></div><div class="panel-body"><div class="data-list">${permissionLabels.slice(0, 6).map(([key, label]) => `<label class="checkbox-line"><input type="checkbox" ${permissions.includes('*') || permissions.includes(key) ? 'checked' : ''} disabled><span>${esc(label)}</span></label>`).join('')}</div><div class="field-hint" style="margin-top:13px">${number(role.users)} utilisateur(s) affecté(s) · ${permissions.includes('*') ? 'Accès complet' : `${number(permissions.length)} permission(s)`}</div></div></section>`; }).join('')}</div><section class="panel" style="margin-top:14px"><div class="panel-header"><div><div class="panel-title">Matrice d’accès</div><div class="panel-subtitle">Tous les modules du menu, groupés par section. Les règles sont appliquées sur les opérations sensibles, même si l’interface est modifiée.</div></div></div><div class="matrix-legend"><span><span class="status-badge success">Autorisé</span> droit détenu</span><span><span class="status-badge neutral">Limité</span> droit manquant</span><span>Badges dans l’ordre : ouverture du module, puis droits de gestion.</span><span>Guide utilisateur et Nous contacter exclus.</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Module</th><th>Droits requis</th>${matrixRoles.map((role) => `<th>${esc(role.name)}</th>`).join('')}</tr></thead><tbody>${matrixRows}</tbody></table></div></section>`;
  }
  function renderActivity() {
    const activities = periodItems(state.activities).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const rows = activities.map((item) => `<tr data-filter-row data-text="${esc(`${item.module} ${item.action} ${item.element} ${userName(item.userId)}`.toLowerCase())}"><td>${dateTime(item.date)}</td><td>${esc(userName(item.userId))}</td><td><span class="status-badge info">${esc(item.module)}</span></td><td><strong>${esc(item.action)}</strong><span class="table-secondary">${esc(item.element)}${item.detail ? ` · ${esc(item.detail)}` : ''}</span></td><td>${item.oldValue ? `<span class="table-secondary">${esc(item.oldValue)}</span>` : '—'}</td><td>${item.newValue ? `<span class="status-badge neutral">${esc(item.newValue)}</span>` : '—'}</td></tr>`).join('');
    return `${pageHeading("Journal d'activité", 'Chaque action importante est horodatée et rattachée à un utilisateur.', `<button class="btn btn-secondary" type="button" data-action="export-activity">⇩ Exporter</button>`)}<div class="notice info"><span>◌</span><div><strong>Journal inviolable en production</strong><span>Les événements sont persistés côté Desktop en append-only ; aucune purge utilisateur n’est proposée. Les limites d’une application locale sont documentées dans ANALYSE-CRITIQUE.md.</span></div></div>${renderBackupExports()}<section class="panel">${toolbar('Module, action ou utilisateur...', '#activity-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Date & heure</th><th>Utilisateur</th><th>Module</th><th>Action / élément</th><th>Ancienne valeur</th><th>Nouvelle valeur</th></tr></thead><tbody id="activity-table-body">${pagedTbody('activity-table-body', rows)}</tbody></table></div><div class="table-footer"><span>${number(activities.length)} événement(s) enregistré(s)</span></div></section>`;
  }

  function renderSettings() {
    const s = state.settings;
    const printer = s.ticketPrinter || { mode: 'browser', paperWidth: '80mm', baudRate: 9600, autoPrint: false, status: 'ready', deviceName: '' };
    const printerReady = printer.mode === 'browser' || printer.status === 'connected';
    const printerStatus = printer.mode === 'browser' ? 'Prêt via impression système' : printerReady ? `Connectée${printer.deviceName ? ` · ${printer.deviceName}` : ''}` : 'Non connectée';
    return `${pageHeading('Paramètres de l’entreprise', 'Personnalisez les documents, les règles de stock et les informations de la boutique.', `<button class="btn btn-primary" type="button" data-action="save-settings">✓ Enregistrer</button>`)}<form id="settings-form"><input type="hidden" name="theme" id="settings-theme" value="${esc(s.theme || 'standard')}"><div class="two-column"><section class="panel"><div class="panel-header"><div><div class="panel-title">Identité de l’entreprise</div><div class="panel-subtitle">Ces informations apparaîtront sur les tickets, devis et rapports.</div></div></div><div class="panel-body"><div class="form-grid"><div class="field"><label>Nom de la boutique / entreprise <em>*</em></label><input class="input-control" name="businessName" value="${esc(s.businessName)}" required></div><div class="field"><label>Nom du responsable</label><input class="input-control" name="manager" value="${esc(s.manager)}"></div><div class="field"><label>Contact du responsable</label><input class="input-control" name="managerPhone" value="${esc(s.managerPhone)}"></div><div class="field"><label>Contact commercial</label><input class="input-control" name="commercialPhone" value="${esc(s.commercialPhone)}"></div><div class="field full"><label>Adresse</label><input class="input-control" name="address" value="${esc(s.address)}"></div><div class="field"><label>Localisation GPS</label><input class="input-control" name="gps" value="${esc(s.gps)}"></div><div class="field"><label>Adresse e-mail</label><input class="input-control" type="email" name="email" value="${esc(s.email)}"></div><div class="field"><label>RCCM</label><input class="input-control" name="rccm" value="${esc(s.rccm)}"></div><div class="field"><label>Numéro fiscal / IFU</label><input class="input-control" name="fiscal" value="${esc(s.fiscal)}"></div></div></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Règles commerciales</div><div class="panel-subtitle">Paramètres de calcul utilisés dans l’application.</div></div></div><div class="panel-body"><div class="form-grid"><div class="field"><label>Devise</label><select class="select-control" name="currency"><option ${s.currency === 'FCFA' ? 'selected' : ''}>FCFA</option><option>EUR</option><option>USD</option></select></div><div class="field"><label>Magasin de vente par défaut</label><select class="select-control" name="defaultStoreId">${options(state.stores.filter((store) => store.active !== false), s.defaultStoreId, 'name', null)}</select><div class="field-hint">Les ventes utilisent le stock du magasin associé au produit.</div></div><div class="field"><label>Taux de TVA (%)</label><input class="input-control" type="number" name="vat" value="${num(s.vat)}" min="0" max="100"></div><div class="field"><label>Seuil d’alerte stock (%)</label><input class="input-control" type="number" name="stockAlert" value="${num(s.stockAlert)}" min="0" max="100"><div class="field-hint">Utilisé pour les alertes globales.</div></div><div class="field"><label>Verrouillage auto (minutes)</label><input class="input-control" type="number" name="inactivityLockMinutes" value="${num(s.inactivityLockMinutes ?? 15)}" min="0" max="240"><div class="field-hint">0 = jamais. Protège les postes partagés.</div></div><div class="field"><label>Autoriser le stock négatif</label><label class="checkbox-line" style="height:35px"><input type="checkbox" name="allowNegative" ${s.allowNegative ? 'checked' : ''}> Autoriser avec permission spécifique</label></div><div class="field full"><label>Logo</label><input class="input-control" type="file" id="settings-logo" accept="image/*"><div class="field-hint">PNG ou JPG · utilisé sur les documents imprimés.</div></div></div><div class="notice success" style="margin-top:14px;margin-bottom:0"><span>✓</span><div><strong>Devise par défaut : FCFA</strong><span>Les montants de la démo sont calculés en francs CFA.</span></div></div></div></section></div><section class="panel appearance-panel"><div class="panel-header"><div><div class="panel-title">Mode d’affichage</div><div class="panel-subtitle">Choisissez l’apparence de NOVA Commerce selon votre environnement de travail.</div></div><span class="status-badge info">${esc(s.theme === 'sombre' ? 'Sombre' : s.theme === 'clair' ? 'Clair' : 'Standard')}</span></div><div class="panel-body"><div class="theme-options">${[['standard', 'Mode standard', 'Interface actuelle, équilibrée et professionnelle', '◐'], ['clair', 'Mode clair', 'Interface lumineuse avec menu latéral clair', '☼'], ['sombre', 'Mode sombre', 'Confort visuel dans les environnements peu éclairés', '◑']].map(([key, label, desc, icon]) => `<button class="theme-option ${s.theme === key ? 'active' : ''}" type="button" data-action="set-theme" data-theme="${key}"><span class="theme-option-icon ${key}">${icon}</span><span><strong>${label}</strong><small>${desc}</small></span><i>${s.theme === key ? '✓' : ''}</i></button>`).join('')}</div></div></section><section class="panel printer-panel"><div class="panel-header"><div><div class="panel-title">Imprimante ticket</div><div class="panel-subtitle">Connectez une imprimante thermique ESC/POS en USB, port série ou Bluetooth lorsque le navigateur le permet.</div></div><span class="printer-status ${printerReady ? 'ready' : 'offline'}"><i></i>${esc(printerStatus)}</span></div><div class="panel-body"><div class="printer-layout"><div><div class="form-grid three"><div class="field"><label>Mode de connexion</label><select class="select-control" name="printerMode" id="printer-mode"><option value="browser" ${printer.mode === 'browser' ? 'selected' : ''}>Impression système du navigateur</option><option value="serial" ${printer.mode === 'serial' ? 'selected' : ''}>USB / port série — Web Serial</option><option value="usb" ${printer.mode === 'usb' ? 'selected' : ''}>USB direct — WebUSB</option><option value="bluetooth" ${printer.mode === 'bluetooth' ? 'selected' : ''}>Bluetooth — Web Bluetooth</option></select></div><div class="field"><label>Largeur du papier</label><select class="select-control" name="printerPaperWidth"><option value="58mm" ${printer.paperWidth === '58mm' ? 'selected' : ''}>58 mm · 32 caractères</option><option value="80mm" ${printer.paperWidth === '80mm' ? 'selected' : ''}>80 mm · 48 caractères</option></select></div><div class="field"><label>Vitesse du port série</label><select class="select-control" name="printerBaudRate"><option value="9600" ${num(printer.baudRate) === 9600 ? 'selected' : ''}>9 600 bauds</option><option value="19200" ${num(printer.baudRate) === 19200 ? 'selected' : ''}>19 200 bauds</option><option value="38400" ${num(printer.baudRate) === 38400 ? 'selected' : ''}>38 400 bauds</option><option value="115200" ${num(printer.baudRate) === 115200 ? 'selected' : ''}>115 200 bauds</option></select></div></div><label class="checkbox-line printer-auto-print"><input type="checkbox" name="printerAutoPrint" ${printer.autoPrint ? 'checked' : ''}> Imprimer automatiquement après validation d’une vente</label><div class="printer-actions"><button class="btn btn-primary btn-sm" type="button" data-action="printer-connect">⌁ Connecter l’imprimante</button><button class="btn btn-secondary btn-sm" type="button" data-action="printer-test">▣ Imprimer un ticket test</button><button class="btn btn-secondary btn-sm" type="button" data-action="printer-disconnect" ${printer.mode === 'browser' || !printerReady ? 'disabled' : ''}>Déconnecter</button></div></div><div class="printer-device-card"><div class="printer-device-icon">▤</div><div><strong>${esc(printer.deviceName || (printer.mode === 'browser' ? 'Impression système' : 'Aucun périphérique sélectionné'))}</strong><span>${printerReady ? (printer.mode === 'browser' ? 'Le dialogue d’impression de Windows ou Android sera utilisé.' : 'Les tickets seront envoyés directement en ESC/POS.') : 'Choisissez un mode puis cliquez sur Connecter.'}</span></div></div></div><div class="printer-capabilities"><span class="field-hint">Compatibilité détectée sur cet appareil :</span>${printerCapabilityMarkup()}</div><div class="notice info" style="margin-top:13px;margin-bottom:0"><span>ⓘ</span><div><strong>Recommandation</strong><span>Pour une imprimante USB classique, essayez d’abord Web Serial ou WebUSB avec Chrome / Edge sur une page HTTPS ou localhost. Si le navigateur ne prend pas en charge l’accès matériel, l’impression système reste disponible.</span></div></div></div></section></form>`;
  }

  function printerCapabilityMarkup() {
    const capabilities = [
      ['Web Serial', typeof navigator !== 'undefined' && !!navigator.serial],
      ['WebUSB', typeof navigator !== 'undefined' && !!navigator.usb],
      ['Bluetooth', typeof navigator !== 'undefined' && !!navigator.bluetooth],
      ['Impression système', typeof window !== 'undefined' && typeof window.print === 'function']
    ];
    return capabilities.map(([label, supported]) => `<span class="capability ${supported ? 'supported' : 'unsupported'}"><i>${supported ? '✓' : '—'}</i>${label}</span>`).join('');
  }

  async function activateLicense(form) {
    if (isClockTampered()) { toast('Activation bloquée', 'Une modification suspecte de l’horloge a placé l’application en lecture seule pour tous les comptes.', 'error'); return; }
    if (!requirePermission('license.activate', 'Seul l’administrateur peut activer la licence.')) return;
    const entered = String(new FormData(form).get('licenseKey') || '').trim();
    if (!entered) { toast('Clé manquante', 'Collez la clé de licence reçue par SMS depuis IAFAD Consulting.', 'error'); return; }
    const businessName = state.settings?.businessName || '';
    const deviceUuid = await ensureDeviceUuid();
    if (!deviceUuid) { toast('Appareil non identifié', 'Le code UUID de l’appareil est indisponible. Rechargez puis réessayez.', 'error'); return; }
    let valid = false;
    let activationTicket = '';
    try {
      valid = await verifyLicenceKey(entered, businessName, deviceUuid);
      if (valid && window.novaDesktop?.activateLicense) {
        const remote = await window.novaDesktop.activateLicense({ key: entered, businessName, deviceUuid });
        valid = !!remote?.ok;
        activationTicket = String(remote?.activationTicket || '');
      }
    } catch (error) {
      toast('Validation indisponible', error.message || 'La licence n’a pas pu être vérifiée.', 'error');
      return;
    }
    if (!valid) { toast('Clé invalide', 'Cette clé ne correspond pas au nom de boutique ou à cet appareil. Vérifiez la saisie ou demandez une nouvelle clé depuis « Nous contacter ».', 'error'); return; }
    state.license = { ...(state.license || {}), activated: true, licenseKey: '', businessName: normalizeBusinessName(businessName), deviceUuid: normalizeDeviceUuid(deviceUuid), key: entered.toUpperCase().replace(/[\s-]+/g, ''), activationTicket, activatedAt: new Date().toISOString(), invalidatedAt: '', invalidatedReason: '' };
    if (!saveState()) { toast('Activation non enregistrée', 'La licence a été vérifiée mais n’a pas pu être persistée.', 'error'); return; }
    addActivity('Licence', 'Activation de la licence', businessName, 'Clé d’appareil vérifiée.');
    saveState();
    render();
    toast('Licence activée', 'Le logiciel peut maintenant fonctionner indéfiniment sur cet appareil.');
  }

  function showLicenseHelp() {
    openModal('Fonctionnement de la licence', 'Activation locale de NOVA Commerce.', `<div class="data-list"><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>3 mois offerts par défaut</strong><span>La période démarre lors de la première ouverture du logiciel.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Après l’échéance</strong><span>Les données restent consultables, mais les créations, modifications et validations sont verrouillées.</span></div></div><div class="data-row"><span class="status-dot red"></span><div class="data-row-main"><strong>Contrôle de l’horloge</strong><span>Le logiciel mémorise la date la plus avancée observée. Un recul supérieur à cinq minutes déclenche la lecture seule pour tous les comptes et est conservé dans l’audit.</span></div></div><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Activation permanente</strong><span>Chaque clé est liée à votre nom de boutique et à votre appareil. Demandez-la par SMS depuis « Nous contacter », puis collez-la dans cette vue. L’activation ne peut pas contourner un verrou de sécurité.</span></div></div></div>`, 'sm', '<button class="btn btn-primary" type="button" data-close-modal>Compris</button>');
  }
  function copyContact() {
    const contact = 'IAFAD Consulting — Burkina Faso, Ouagadougou — +226 76 83 04 82';
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(contact).then(() => toast('Contact copié', 'Les coordonnées d’IAFAD Consulting sont dans votre presse-papiers.')).catch(() => toast('Contact', contact, 'success'));
    else toast('Contact IAFAD Consulting', contact, 'success');
  }

  function maskLicense(value) {
    const code = String(value || '');
    return code ? `${code.slice(0, 5)}••••••${code.slice(-4)}` : 'Licence permanente activée';
  }
  function renderLicense() {
    const info = licenseInfo();
    const license = state.license || {};
    const securityBlocked = info.state === 'clock-tampered';
    const locked = securityBlocked || info.state === 'expired';
    const tone = licenseStatusClass(info);
    const heroIcon = info.state === 'licensed' ? '✓' : info.state === 'trial' ? '⌁' : '!';
    const detectedAt = info.clockIntegrity?.detectedAt ? dateTime(info.clockIntegrity.detectedAt) : 'Date non disponible';
    const adminResetTools = !securityBlocked && info.state === 'licensed' && can('license.activate')
      ? `<div class="license-admin-tools"><div class="form-section-title">Outils administrateur</div><div class="notice warning" style="margin:0 0 12px"><span>!</span><div><strong>Actions réservées à l’administrateur</strong><span>Ces opérations modifient ou suppriment les données locales. Elles ne sont proposées qu’après une activation valide.</span></div></div><div class="license-admin-actions"><button class="btn btn-secondary" type="button" data-action="reset-demo">↺ Réinitialiser la démo</button><button class="btn btn-danger" type="button" data-action="fresh-database">⚠ Mettre à neuf la base</button></div></div>`
      : '';
    const activationPanel = securityBlocked
      ? `<div class="notice expired" style="margin:0"><span>!</span><div><strong>Activation désactivée par sécurité</strong><span>Le code de licence ne peut pas contourner un contrôle d’intégrité de l’horloge. Vérifiez la date et l’heure de l’appareil puis contactez l’assistance avant toute remise en service.</span></div></div>`
      : info.state === 'licensed'
        ? `<div class="license-code-box"><code>${esc(maskLicense(license.key))}</code><p>Licence activée le ${shortDate(info.activatedAt)}. Le logiciel peut fonctionner indéfiniment sur cet appareil.</p>${license.businessName || license.deviceUuid ? `<div class="licence-binding"><div><span>Boutique liée</span><strong>${esc(license.businessName || '—')}</strong></div><div><span>Appareil lié (UUID)</span><strong class="mono">${esc(license.deviceUuid || '—')}</strong></div></div>` : ''}</div><div class="notice success" style="margin-top:13px;margin-bottom:0"><span>✓</span><div><strong>Activation permanente confirmée</strong><span>Les modules de vente, de stock, de gestion et de paramétrage restent disponibles.</span></div></div>${adminResetTools}`
        : `<form id="license-form"><div class="form-section-title">Activer la licence permanente</div><div class="notice info" style="margin:0 0 12px"><span>ⓘ</span><div><strong>Clé personnelle d’appareil</strong><span>1. Dans « Nous contacter », envoyez votre nom de boutique et votre UUID par SMS · 2. Recevez votre clé · 3. Collez-la ci-dessous.</span></div></div><div class="field"><label>Clé de licence <em>*</em></label><input class="input-control mono" name="licenseKey" placeholder="NOVA1-XXXX-XXXX-…" autocomplete="off" autocapitalize="characters" spellcheck="false" required></div><div class="form-actions"><span class="required-note">Vérifiée hors-ligne : nom de boutique + appareil.</span><button class="btn btn-primary" type="submit">Activer le logiciel</button></div></form>`;
    const headingAction = securityBlocked ? '<span class="status-badge danger">! Contrôle de sécurité actif</span>' : info.state === 'licensed' ? '<span class="status-badge success">✓ Licence permanente</span>' : '<button class="btn btn-secondary" type="button" data-action="show-license-help">ⓘ Comment ça marche ?</button>';
    const finalNotice = info.state === 'trial'
      ? `<section class="panel" style="margin-top:14px"><div class="panel-header"><div><div class="panel-title">Calendrier de l’essai</div><div class="panel-subtitle">La période démarre lors de la première ouverture du logiciel.</div></div><span class="status-badge warning">${number(info.daysLeft)} jour(s) restant(s)</span></div><div class="panel-body"><div class="detail-grid"><div class="detail-item"><label>Début de l’essai</label><strong>${shortDate(info.trialStartedAt)}</strong></div><div class="detail-item"><label>Fin de l’essai</label><strong>${shortDate(info.endsAt)}</strong></div><div class="detail-item"><label>Durée</label><strong>${TRIAL_MONTHS} mois</strong></div></div><div class="progress-wrap" style="margin-top:16px"><div class="progress-bar"><span style="width:${clamp((1 - info.daysLeft / 90) * 100, 3, 100)}%;background:var(--orange)"></span></div><div class="progress-caption"><span>Essai en cours</span><span>Activation permanente recommandée</span></div></div></div></section>`
      : info.state === 'expired'
        ? `<div class="notice expired license-expired-notice" style="margin-top:14px;margin-bottom:0"><span>!</span><div><strong>Mode lecture seule activé</strong><span>Collez votre clé de licence ci-dessus pour réactiver immédiatement les opérations de vente, de stock et de gestion.</span></div></div>`
        : securityBlocked
          ? `<div class="notice expired license-expired-notice" style="margin-top:14px;margin-bottom:0"><span>!</span><div><strong>Mode lecture seule pour tous les comptes</strong><span>Recul détecté ou horloge incohérente le ${esc(detectedAt)}. Le verrouillage reste conservé dans l’historique et ne peut pas être levé par un compte utilisateur.</span></div></div>`
          : `<section class="panel" style="margin-top:14px"><div class="panel-body"><div class="notice success" style="margin:0"><span>✓</span><div><strong>Accès permanent</strong><span>Aucune date d’expiration n’est appliquée à cette installation.</span></div></div></div></section>`;
    return `${pageHeading('Licence', 'Gérez la période d’essai et contrôlez l’intégrité de l’horloge système.', headingAction)}<section class="license-hero"><div class="license-hero-icon ${tone === 'warning' ? 'warning' : tone === 'expired' ? 'expired' : ''}">${heroIcon}</div><div class="license-hero-copy"><strong>${esc(info.title)}</strong><span>${esc(info.description)}</span></div>${statusBadge(info.label, info.state === 'licensed' ? { [info.label]: 'success' } : info.state === 'trial' ? { [info.label]: 'warning' } : { [info.label]: 'danger' })}</section><div class="license-grid"><section class="panel"><div class="panel-header"><div><div class="panel-title">Activation</div><div class="panel-subtitle">Une clé valide supprime la limite de trois mois, mais ne contourne jamais un verrou de sécurité.</div></div></div><div class="panel-body">${activationPanel}</div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">État de l’accès</div><div class="panel-subtitle">Droits appliqués automatiquement à tous les comptes.</div></div></div><div class="panel-body"><div class="license-benefits"><div class="license-benefit"><i>✓</i><div><strong>Consultation des données</strong><span>Tableaux, historiques, rapports et inventaires accessibles.</span></div></div><div class="license-benefit ${locked ? 'locked' : ''}"><i>${locked ? '!' : '✓'}</i><div><strong>Opérations commerciales</strong><span>${locked ? 'Bloquées en mode lecture seule.' : 'Ventes, entrées, sorties et dépenses autorisées.'}</span></div></div><div class="license-benefit ${locked ? 'locked' : ''}"><i>${locked ? '!' : '✓'}</i><div><strong>Modifications de gestion</strong><span>${locked ? 'Création et modification désactivées.' : 'Catalogue, clients, fournisseurs et paramètres disponibles.'}</span></div></div><div class="license-benefit"><i>✓</i><div><strong>Impression et export</strong><span>Les tickets, rapports et exports restent disponibles.</span></div></div></div></div></section></div>${finalNotice}`;
  }

  function renderGuide() {
    const steps = [
      ['01', 'Sécuriser l’accès', 'Connectez-vous avec votre compte. Les profils et droits déterminent les modules disponibles ; les mots de passe ne sont jamais affichés en clair.', 'shield-check', 'users'],
      ['02', 'Configurer l’entreprise', 'Ouvrez Paramètres pour renseigner le nom, les coordonnées, la devise FCFA, le magasin par défaut et les options d’impression ticket.', 'settings', 'settings'],
      ['03', 'Préparer le catalogue', 'Créez les catégories, magasins, fournisseurs et produits. Renseignez les prix d’achat, prix de vente et seuils de stock.', 'package', 'products'],
      ['04', 'Initialiser le stock', 'Enregistrez les entrées validées ou réalisez un inventaire. Une opération En cours ne modifie jamais le stock.', 'arrow-down-to-line', 'entries'],
      ['05', 'Vendre et piloter', 'Ouvrez Nouvelle vente pour encaisser rapidement, rattachez les ventes à crédit à un client, puis utilisez les rapports et la comptabilité.', 'trending-up', 'sale']
    ];
    const modules = [
      { title: 'Ventes et clients', intro: 'Encaissez, retrouvez les ventes et suivez les créances.', items: [['sale', 'Nouvelle vente', 'Choisir le prix appliqué (vente, gros, promotionnel), le client et le mode de paiement.', 'plus-circle'], ['sales', 'Historique des ventes', 'Rechercher, consulter, imprimer un ticket, créer un avoir lié à une vente validée et affecter un livreur.', 'chart-line'], ['clients', 'Clients et créances', 'Gérer les fiches clients, l’encours, le journal et les règlements partiels ou successifs.', 'users'], ['deliverers', 'Livreurs', 'Enregistrer les livreurs (contacts, CIN, tarif de base) et les affecter aux ventes depuis l’historique.', 'truck']] },
      { title: 'Catalogue et partenaires', intro: 'Construisez une base propre avant les opérations quotidiennes.', items: [['products', 'Produits', 'Gérer les références, prix, images, seuils minimum/maximum et stocks par magasin.', 'package'], ['categories', 'Catégories', 'Organiser les produits pour accélérer la recherche et les analyses.', 'tags'], ['stores', 'Magasins', 'Créer les points de vente, réserves et dépôts utilisés par le stock.', 'store'], ['suppliers', 'Fournisseurs', 'Conserver les contacts, références fiscales et historiques d’achats.', 'truck']] },
      { title: 'Stocks et approvisionnement', intro: 'Chaque variation de stock doit rester explicable et historisée.', items: [['entries', 'Entrées de stock', 'Saisir achats et retours. Valider uniquement lorsque les quantités doivent entrer en stock.', 'arrow-down-to-line'], ['exits', 'Sorties de stock', 'Saisir dons, pertes ou sorties diverses avec contrôle du stock disponible.', 'arrow-up-from-line'], ['transfers', 'Transferts inter-magasins', 'Déplacer plusieurs produits entre une source et une destination, en une seule validation.', 'arrow-left-right'], ['orders', 'Commandes', 'Commandes manuelles multi-lignes ou Commande Express générée depuis les ventes et le stock.', 'clipboard-list'], ['inventory', 'Inventaire', 'Comparer le stock théorique au comptage réel et analyser les écarts.', 'scan-line']] },
      { title: 'Finance et documents', intro: 'Analysez uniquement les opérations validées et conservez les corrections liées.', items: [['quotes', 'Devis', 'Préparer un devis avec plusieurs lignes, remise, TVA et impression.', 'file-text'], ['credit-notes', 'Avoirs et annulations', 'Corriger une vente par une nouvelle opération, partielle ou complète, sans modifier l’originale.', 'rotate-ccw'], ['purchase-report', 'Bilan des achats', 'Analyser les entrées validées par période et fournisseur.', 'shopping-cart'], ['sales-report', 'Bilan des ventes', 'Analyser le chiffre d’affaires, les marges et les avoirs validés.', 'chart-pie'], ['expenses', 'Dépenses', 'Enregistrer les dépenses et leurs justificatifs.', 'receipt'], ['accounting', 'Comptabilité', 'Consulter la synthèse financière, les encaissements et les créances. Le bénéfice est présenté avec créances et encaissé (hors créances).', 'calculator']] },
      { title: 'Administration et assistance', intro: 'Protégez l’exploitation et accompagnez les utilisateurs.', items: [['reports', 'Rapports', 'Rapports PDF avec indicateurs, graphiques et tableaux sur 4 périodes, plus exports CSV.', 'files'], ['users', 'Utilisateurs', 'Créer les comptes et gérer les profils autorisés.', 'user-round'], ['roles', 'Profils et droits', 'Définir les permissions par rôle et limiter les opérations sensibles.', 'shield-check'], ['activity', 'Journal d’activité', 'Contrôler les événements, sauvegarder la base et exporter les tables en CSV.', 'history'], ['license', 'Licence', 'Consulter la période d’essai et activer la licence permanente.', 'key-round'], ['contact', 'Nous contacter', 'Retrouver les coordonnées d’IAFAD Consulting pour l’assistance. L’Espace concepteur, déverrouillé par code, pilote la disponibilité des modules du menu.', 'phone-call'], ['settings', 'Paramètres', 'Gérer l’entreprise, le thème, l’imprimante ticket et les options locales.', 'settings']] }
    ];
    const stepMarkup = steps.map(([numberValue, title, description, iconName, view]) => `<article class="guide-step"><div class="guide-step-number">${numberValue}</div><div class="guide-step-icon">${icon(iconName, 17)}</div><div class="guide-step-copy"><strong>${title}</strong><span>${description}</span><button class="text-button" type="button" data-view="${view}">Ouvrir le module →</button></div></article>`).join('');
    const moduleMarkup = modules.map((group) => `<section class="guide-module-group"><div class="guide-group-heading"><div><h3>${group.title}</h3><p>${group.intro}</p></div></div><div class="guide-module-grid">${group.items.map(([view, title, description, iconName]) => `<article class="guide-module-card"><div class="guide-module-icon">${icon(iconName, 17)}</div><div class="guide-module-copy"><strong>${title}</strong><span>${description}</span><button class="text-button" type="button" data-view="${view}">Ouvrir →</button></div></article>`).join('')}</div></section>`).join('');
    return `${pageHeading('Guide utilisateur', 'Bien débuter avec NOVA Commerce et maîtriser les modules de gestion.', '<button class="btn btn-secondary" type="button" data-action="show-shortcuts">⌨ Raccourcis clavier</button><button class="btn btn-primary" type="button" data-view="sale">＋ Commencer une vente</button>')}<section class="guide-hero"><div class="guide-hero-mark">?</div><div><span class="eyebrow">PARCOURS DE DÉMARRAGE</span><h2>Votre première journée avec NOVA</h2><p>Suivez les étapes dans l’ordre, puis ouvrez directement le module dont vous avez besoin. Les opérations restent historisées et les validations sont contrôlées.</p></div><div class="guide-hero-badge"><strong>FCFA</strong><span>Devise par défaut</span></div></section><section class="guide-start-grid">${stepMarkup}</section><div class="guide-columns"><section class="panel"><div class="panel-header"><div><div class="panel-title">Les règles à retenir</div><div class="panel-subtitle">Ces principes protègent les stocks et les données financières.</div></div></div><div class="panel-body"><div class="guide-rules"><div><span>✓</span><p><strong>En cours</strong><small>Une opération en cours ne modifie pas le stock ni les calculs financiers.</small></p></div><div><span>✓</span><p><strong>Validée une seule fois</strong><small>Une opération validée applique son effet une seule fois et devient historisée.</small></p></div><div><span>✓</span><p><strong>Corrections liées</strong><small>Un avoir ou un mouvement inverse crée une nouvelle opération sans modifier l’originale.</small></p></div><div><span>✓</span><p><strong>Contrôles de sécurité</strong><small>Les permissions, le stock négatif et l’intégrité de l’horloge sont vérifiés avant les écritures.</small></p></div></div></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Raccourcis utiles</div><div class="panel-subtitle">Accélérez les actions quotidiennes.</div></div></div><div class="panel-body"><div class="guide-shortcuts"><div><kbd>F2</kbd><span><strong>Nouvelle vente</strong><small>Ouvrir la caisse rapidement</small></span></div><div><kbd>⌘ K</kbd><span><strong>Recherche globale</strong><small>Rechercher un module ou un produit</small></span></div><div><kbd>Double-clic</kbd><span><strong>Ajout rapide</strong><small>Ajouter une unité au panier</small></span></div><div><kbd>Échap</kbd><span><strong>Fermer</strong><small>Fermer une fenêtre ouverte</small></span></div></div></div></section></div><section class="panel"><div class="panel-header"><div><div class="panel-title">Guides téléchargeables</div><div class="panel-subtitle">Lisez, imprimez ou téléchargez les guides en PDF.</div></div></div><div class="panel-body"><div style="display:flex;flex-direction:column;gap:12px"><div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;padding:14px 16px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc"><div style="min-width:220px;flex:1"><strong>Guide des indicateurs financiers</strong><br><span style="color:#5b6472;font-size:13px">Définitions, formules et exemples de calcul : CA, marges, encaissement, avances, remboursements.</span></div><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn btn-secondary" href="guides/guide-indicateurs.pdf" target="_blank" rel="noopener">Lire</a><a class="btn btn-secondary" href="guides/guide-indicateurs.pdf" download="NOVA-Commerce-Guide-Indicateurs-Financiers.pdf">Télécharger le PDF</a><button class="btn btn-primary" type="button" data-action="print-guide" data-file="guides/guide-indicateurs.pdf">Imprimer</button></div></div><div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;padding:14px 16px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc"><div style="min-width:220px;flex:1"><strong>Guide du caissier</strong><br><span style="color:#5b6472;font-size:13px">Version simplifiée : les chiffres de caisse au quotidien, checklists et phrases types.</span></div><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn btn-secondary" href="guides/guide-caissiers.pdf" target="_blank" rel="noopener">Lire</a><a class="btn btn-secondary" href="guides/guide-caissiers.pdf" download="NOVA-Commerce-Guide-Caissiers.pdf">Télécharger le PDF</a><button class="btn btn-primary" type="button" data-action="print-guide" data-file="guides/guide-caissiers.pdf">Imprimer</button></div></div></div></div></section><section class="panel guide-modules-panel"><div class="panel-header"><div><div class="panel-title">Mode d’emploi des modules</div><div class="panel-subtitle">Une vue d’ensemble des fonctionnalités disponibles dans NOVA Commerce.</div></div></div><div class="panel-body guide-modules-body">${moduleMarkup}</div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Calcul des indicateurs financiers</div><div class="panel-subtitle">D’où viennent les chiffres du Tableau de bord et de la Comptabilité.</div></div></div><div class="panel-body"><div class="form-section-title">Règles générales</div><div class="data-list"><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Validé uniquement</strong><span>Seules les opérations au statut Validée entrent dans les calculs : ventes, avoirs, entrées, règlements. Les brouillons En cours et les opérations Annulée sont exclus.</span></div></div><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Avoirs soustraits</strong><span>Un avoir validé se soustrait du chiffre d’affaires et des marges de sa période. La vente d’origine n’est jamais modifiée.</span></div></div><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Périodes</strong><span>Jour = date du jour, Mois = mois en cours. La Comptabilité et les bilans suivent le filtre Période (◷) ; sans filtre, tout l’historique est pris en compte.</span></div></div><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Marge d’une ligne</strong><span>Quantité × (prix de vente − coût). Le coût est celui enregistré sur la ligne au moment de la vente, sinon le prix d’achat actuel du produit.</span></div></div></div><div class="form-section-title">Tableau de bord</div><div class="data-list"><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>CA du jour / du mois</strong><span>Ventes validées moins avoirs validés de la période.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Bénéfice du jour</strong><span>Marges des ventes moins marges des avoirs du jour.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Encaissé du jour</strong><span>Marge des ventes au comptant à 100 % + marge des ventes à crédit au prorata des règlements, moins les avoirs au comptant.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Dépenses du mois</strong><span>Dépenses du mois non annulées, y compris celles encore En cours.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Bénéfice net du mois</strong><span>Marge brute du mois moins Dépenses du mois.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Bénéfice net encaissé</strong><span>Marge encaissée du mois moins Dépenses du mois.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Taux d’encaissement</strong><span>Marge encaissée divisée par marge brute du mois, en %, plafonné entre 0 et 100 (0 si la marge est nulle ou négative).</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Règlements reçus</strong><span>Règlements clients validés du mois, tous clients confondus.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Valeur totale du stock</strong><span>Pour chaque produit actif : stock × prix d’achat, additionnés.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Créances clients</strong><span>Somme des encours (soldes restant dus) de tous les clients.</span></div></div></div><div class="form-section-title">Comptabilité</div><div class="data-list"><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>CA · Marge brute · Marge encaissée</strong><span>Mêmes définitions que le Tableau de bord, calculées sur la période du filtre.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Dépenses</strong><span>Dépenses Validées de la période : ici, les En cours sont exclues.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Bénéfice net</strong><span>Marge brute moins Dépenses (identique au « Résultat net · avec créances »).</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Bénéfice net encaissé</strong><span>Marge encaissée moins Dépenses.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Achats validés</strong><span>Total des entrées de stock validées de la période.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Encaissements</strong><span>Cash + Mobile Money + Carte, chaque canal étant net de ses avoirs.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Ventes à crédit</strong><span>Total brut des ventes à crédit validées (avoirs non déduits).</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Canal « À crédit »</strong><span>Solde calculé : CA moins Cash moins Mobile moins Carte (ventes à crédit et autres modes comme le chèque).</span></div></div></div><div class="form-section-title">Cas particulier : l’encaissement des ventes à crédit</div><div class="data-list"><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Ordre d’imputation</strong><span>Les règlements d’un client soldent d’abord son report initial, puis ses ventes à crédit les plus anciennes, avoirs déduits. Chaque vente obtient un ratio encaissé de 0 à 100 %.</span></div></div><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Marge encaissée d’une vente</strong><span>(Marge de la vente − marge de ses avoirs) × son ratio. Les ventes au comptant comptent à 100 % ; le prorata tient compte de tous les règlements reçus, même antérieurs à la période affichée.</span></div></div></div></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">Avoirs, avances et remboursements</div><div class="panel-subtitle">Trop-perçus, sorties de caisse et soldes clients.</div></div></div><div class="panel-body"><div class="data-list"><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Avoir plafonné à la vente</strong><span>Un avoir reprend au maximum les quantités non encore corrigées de sa vente d’origine (contrôle à la saisie et à la validation ; une annulation complète reprend toutes les quantités restantes).</span></div></div><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Créance réduite automatiquement</strong><span>Un avoir validé issu d’une vente à crédit réduit l’encours du client ; un avoir au comptant réduit les canaux Cash / Mobile Money / Carte dans les rapports.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Trop-perçu signalé</strong><span>Si un avoir fait passer le solde du client sous zéro, l’excédent (Trop-perçu) devient une avance et un choix s’affiche : garder en avance ou rembourser.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Avance créée sur tout excédent</strong><span>Tout règlement supérieur à l’encours crée une avance. Elle est imputée automatiquement sur la prochaine vente à crédit.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Limite sur position nette</strong><span>Le contrôle de limite utilise l’encours net : encours − avance + nouvelle vente ≤ limite.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Remboursement depuis l’avoir</strong><span>Depuis un avoir validé, « Rembourser » enregistre une sortie (date, montant, mode, référence) liée à l’avoir.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Sortie non comptée en charges</strong><span>Le remboursement est une sortie tracée, non comptée en charges : la marge a déjà été corrigée par l’avoir.</span></div></div><div class="data-row"><span class="status-dot orange"></span><div class="data-row-main"><strong>Remboursement plafonné</strong><span>Un remboursement ne dépasse jamais le restant de l’avoir ; sur vente à crédit, il ne dépasse pas l’avance disponible du client.</span></div></div><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Journal : solde = encours − avance</strong><span>Le journal client affiche ventes (débit), avoirs et règlements (crédit), remboursements (débit). Son solde final = encours − avance.</span></div></div><div class="data-row"><span class="status-dot blue"></span><div class="data-row-main"><strong>Ratio encaissé intact</strong><span>Avances et remboursements ne gonflent pas le ratio encaissé : chaque vente reste plafonnée à 100 % (imputation FIFO sur montants nets).</span></div></div><div class="data-row"><span class="status-dot teal"></span><div class="data-row-main"><strong>Où retrouver ces montants</strong><span>Avances : fiche client, liste Clients, journal, Comptabilité. Remboursements : détail de l’avoir, journal, export CSV.</span></div></div></div></div></section><section class="panel guide-help-panel"><div class="panel-body"><div class="guide-help-content"><div class="guide-help-icon">ⓘ</div><div><strong>Vous ne savez pas par où commencer ?</strong><p>Configurez d’abord Paramètres, Magasins, Catégories et Produits. Ajoutez ensuite votre stock initial, puis réalisez une vente test. Le journal d’activité et les rapports vous permettent de vérifier les opérations.</p></div><button class="btn btn-secondary" type="button" data-view="contact">Contacter l’assistance</button></div></div></section>`;
  }

  function disabledModules() { return Array.isArray(state.settings.disabledModules) ? state.settings.disabledModules : []; }
  function isModuleDisabled(view) { return disabledModules().includes(view); }
  function designerModuleLabel(view) {
    for (const [, modules] of ROLE_MATRIX_MODULES) { const found = modules.find(([itemView]) => itemView === view); if (found) return found[1]; }
    return (VIEW_META[view] || [])[1] || view;
  }
  async function verifyDesignerCode(value) {
    const digest = await sha256Hex(DESIGNER_CODE_SALT + String(value || ''));
    if (digest.length !== DESIGNER_CODE_DIGEST.length) return false;
    let diff = 0;
    for (let i = 0; i < digest.length; i += 1) diff |= digest.charCodeAt(i) ^ DESIGNER_CODE_DIGEST.charCodeAt(i);
    return diff === 0;
  }
  async function unlockDesignerSpace(form) {
    const value = String(form.querySelector('[name="code"]')?.value || '');
    if (!await verifyDesignerCode(value)) { toast('Code incorrect', 'Le code d’accès saisi est invalide.', 'error'); return false; }
    designerUnlocked = true;
    addActivity('Concepteur', 'Déverrouillage de l’espace concepteur', currentUser?.username || 'session', 'Matrice des modules affichée');
    saveState();
    render();
    toast('Espace concepteur', 'Accès autorisé. Cochez les modules disponibles dans le menu.');
    return true;
  }
  function setModuleEnabled(view, enabled) {
    if (!requirePermission('settings.manage', 'Votre profil ne peut pas modifier la disponibilité des modules.')) return false;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier la disponibilité des modules.', 'warning'); return false; }
    const disabled = new Set(disabledModules());
    if (enabled) disabled.delete(view); else disabled.add(view);
    state.settings.disabledModules = [...disabled];
    addActivity('Concepteur', enabled ? 'Activation d’un module' : 'Désactivation d’un module', designerModuleLabel(view), enabled ? 'Visible dans le menu' : 'Masqué du menu');
    saveState();
    render();
    return true;
  }
  function setAllModulesEnabled(enabled) {
    if (!requirePermission('settings.manage', 'Votre profil ne peut pas modifier la disponibilité des modules.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier la disponibilité des modules.', 'warning'); return; }
    const allViews = ROLE_MATRIX_MODULES.reduce((list, [, modules]) => list.concat(modules.map(([itemView]) => itemView)), []);
    state.settings.disabledModules = enabled ? [] : allViews;
    addActivity('Concepteur', enabled ? 'Activation de tous les modules' : 'Désactivation de tous les modules', `${allViews.length} modules`, enabled ? 'Menu complet' : 'Menu restreint');
    saveState();
    render();
    toast('Espace concepteur', enabled ? 'Tous les modules sont de nouveau disponibles.' : 'Tous les modules ont été masqués du menu.');
  }
  function renderDesignerSpace() {
    if (!designerUnlocked) {
      return `<section class="panel designer-panel"><div class="panel-header"><div><div class="panel-title">Espace concepteur</div><div class="panel-subtitle">Zone réservée : la disponibilité des modules du menu se règle ici après saisie du code d’accès.</div></div><span class="status-badge neutral">🔒 Verrouillé</span></div><div class="panel-body"><form id="designer-form"><div class="form-grid"><div class="field"><label for="designer-code">Code d’accès <em>*</em></label><input class="input-control" type="password" id="designer-code" name="code" required autocomplete="off" placeholder="Saisissez le code spécial"></div></div><div class="field-hint" style="margin-top:8px">L’accès à cet espace est journalisé.</div><div class="form-actions"><button class="btn btn-primary" type="submit">✓ Valider le code</button></div></form></div></section>`;
    }
    const allViews = ROLE_MATRIX_MODULES.reduce((list, [, modules]) => list.concat(modules.map(([itemView]) => itemView)), []);
    const enabledCount = allViews.filter((view) => !isModuleDisabled(view)).length;
    const groups = ROLE_MATRIX_MODULES.map(([group, modules]) => `<div class="designer-group"><div class="form-section-title">${esc(group)}</div><div class="designer-grid">${modules.map(([view, label]) => `<label class="checkbox-line"><input type="checkbox" data-designer-module="${esc(view)}" ${isModuleDisabled(view) ? '' : 'checked'}> <span>${esc(label)}</span></label>`).join('')}</div></div>`).join('');
    return `<section class="panel designer-panel"><div class="panel-header"><div><div class="panel-title">Espace concepteur</div><div class="panel-subtitle">Un module coché reste disponible dans le menu ; décoché, il disparaît du menu et devient inaccessible.</div></div><span class="status-badge success">✓ Déverrouillé</span></div><div class="panel-body"><div class="notice info" style="margin-top:0"><span>ⓘ</span><div><strong>${number(enabledCount)} / ${number(allViews.length)} modules disponibles</strong><span>Guide utilisateur et Nous contacter restent toujours accessibles. Les modifications sont réservées aux profils autorisés.</span></div></div>${groups}<div class="form-actions"><button class="btn btn-secondary" type="button" data-action="designer-lock">🔒 Verrouiller</button><button class="btn btn-secondary" type="button" data-action="designer-enable-all">✓ Tout activer</button><button class="btn btn-secondary" type="button" data-action="designer-disable-all">× Tout désactiver</button></div></div></section>`;
  }
  function renderLicenceRequestCard() {
    const businessName = state.settings?.businessName || '';
    const uuid = cachedDeviceUuid || 'Chargement…';
    void ensureDeviceUuid().then((resolved) => {
      const input = document.getElementById('licence-device-uuid');
      if (input && resolved) input.value = resolved;
    });
    return `<section class="panel licence-request-panel"><div class="panel-header"><div><div class="panel-title">Demande de licence permanente</div><div class="panel-subtitle">Votre clé est générée pour votre boutique et cet appareil.</div></div><span class="status-badge info">SMS</span></div><div class="panel-body"><div class="form-grid"><div class="field"><label>Nom de la boutique / entreprise</label><div style="display:flex;gap:8px"><input class="input-control" style="flex:1" value="${esc(businessName)}" readonly><button class="btn btn-secondary" type="button" data-action="copy-business-name">▣</button></div><div class="field-hint">Modifiable dans Paramètres · renommer la boutique invalide la clé.</div></div><div class="field"><label>Code UUID de l’appareil</label><div style="display:flex;gap:8px"><input class="input-control mono" id="licence-device-uuid" style="flex:1" value="${esc(uuid)}" readonly><button class="btn btn-secondary" type="button" data-action="copy-licence-uuid">▣</button></div><div class="field-hint">Identifiant unique de cet appareil, généré automatiquement.</div></div></div><div class="contact-actions" style="margin-top:12px"><button class="btn btn-primary" type="button" data-action="request-licence-sms">✉ Demander ma licence</button><span class="table-secondary">Envoi par SMS au +226 76 83 04 82</span></div></div></section>`;
  }
  async function showLicenceSmsModal() {
    const uuid = await ensureDeviceUuid();
    if (!uuid) { toast('Appareil non identifié', 'Le code UUID est indisponible. Rechargez puis réessayez.', 'error'); return; }
    const businessName = state.settings?.businessName || '';
    const message = buildLicenceSms(businessName, uuid);
    openModal('Demander ma licence', 'Envoyez ces informations à IAFAD Consulting.', `<div class="field"><label>Message à envoyer au +226 76 83 04 82</label><textarea class="input-control mono" id="licence-sms-text" rows="4" readonly>${esc(message)}</textarea><div class="field-hint">Vous recevrez votre clé personnelle par SMS. Collez-la ensuite dans la vue Licence.</div></div>`, 'sm', `<a class="btn btn-primary" href="${esc(smsLicenceHref(businessName, uuid))}">✉ Ouvrir l’appli SMS</a><button class="btn btn-secondary" type="button" data-action="copy-sms-text">▣ Copier</button><button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>`);
  }
  function renderContact() {
    const company = 'IAFAD Consulting';
    const country = 'Burkina Faso';
    const city = 'Ouagadougou';
    const phone = '+226 76 83 04 82';
    return `${pageHeading('Nous contacter', 'Une question, un besoin d’accompagnement ou une demande de service ?', '<button class="btn btn-secondary" type="button" data-action="copy-contact">▣ Copier le contact</button>')}<section class="contact-hero"><div class="contact-brand-mark">IC</div><div class="contact-hero-copy"><span class="eyebrow">CONCEPTEUR DE L’APPLICATION</span><h2>${company}</h2><p>Votre partenaire pour la conception, le déploiement et l’accompagnement de solutions numériques.</p></div><div class="contact-hero-location"><span>⌂</span><strong>${city}</strong><small>${country}</small></div></section><div class="contact-grid"><section class="panel"><div class="panel-header"><div><div class="panel-title">Coordonnées</div><div class="panel-subtitle">Les informations officielles du concepteur.</div></div></div><div class="panel-body"><div class="contact-details"><a class="contact-detail" href="tel:+22676830482"><span class="contact-detail-icon teal">☎</span><span><small>Contact principal</small><strong>${phone}</strong><em>Appeler maintenant →</em></span></a><div class="contact-detail"><span class="contact-detail-icon orange">◎</span><span><small>Pays</small><strong>${country}</strong><em>Afrique de l’Ouest</em></span></div><div class="contact-detail"><span class="contact-detail-icon purple">⌂</span><span><small>Ville</small><strong>${city}</strong><em>Burkina Faso</em></span></div></div></div></section><section class="panel"><div class="panel-header"><div><div class="panel-title">À votre service</div><div class="panel-subtitle">IAFAD Consulting accompagne votre projet.</div></div><div class="contact-spark">✦</div></div><div class="panel-body"><div class="contact-message"><strong>Pour tout besoin, merci de nous contacter.</strong><p>Nous sommes disponibles et à votre service pour répondre à vos questions, vous accompagner dans l’utilisation de NOVA Commerce et étudier vos besoins d’évolution.</p></div><div class="contact-actions"><a class="btn btn-primary" href="tel:+22676830482">☎ Appeler IAFAD Consulting</a><button class="btn btn-secondary" type="button" data-action="copy-contact">▣ Copier le numéro</button></div></div></section></div>${renderLicenceRequestCard()}<section class="panel contact-services"><div class="panel-header"><div><div class="panel-title">Nos domaines d’accompagnement</div><div class="panel-subtitle">Une assistance adaptée à votre activité.</div></div></div><div class="panel-body"><div class="contact-service-grid"><div class="contact-service"><span>◈</span><div><strong>Installation</strong><small>Configuration et mise en service du logiciel.</small></div></div><div class="contact-service"><span>♧</span><div><strong>Formation</strong><small>Prise en main des modules et des opérations.</small></div></div><div class="contact-service"><span>⚙</span><div><strong>Personnalisation</strong><small>Adaptation aux besoins de votre entreprise.</small></div></div><div class="contact-service"><span>◌</span><div><strong>Assistance</strong><small>Support et accompagnement dans la durée.</small></div></div></div></div></section>${renderDesignerSpace()}`;
  }

  function renderView(view) {
    switch (view) {
      case 'sale': return renderSale(); case 'sales': return renderSales(); case 'clients': return renderClients(); case 'products': return renderProducts(); case 'categories': return renderCategories(); case 'stores': return renderStores(); case 'suppliers': return renderSuppliers(); case 'deliverers': return renderDeliverers(); case 'entries': return renderEntries(); case 'exits': return renderExits(); case 'transfers': return renderTransfers(); case 'orders': return renderOrders(); case 'quotes': return renderQuotes(); case 'credit-notes': return renderCreditNotes(); case 'purchase-report': return renderPurchaseReport(); case 'sales-report': return renderSalesReport(); case 'expenses': return renderExpenses(); case 'expense-report': return renderExpenseReport(); case 'accounting': return renderAccounting(); case 'inventory': return renderInventory(); case 'reports': return renderReports(); case 'users': return renderUsers(); case 'roles': return renderRoles(); case 'activity': return renderActivity(); case 'license': return renderLicense(); case 'guide': return renderGuide(); case 'contact': return renderContact(); case 'settings': return renderSettings(); default: return renderDashboard();
    }
  }

  function renderLicenseNotice() {
    const info = licenseInfo();
    if (info.state === 'licensed') return '';
    const securityBlocked = info.state === 'clock-tampered';
    const tone = info.state === 'expired' || securityBlocked ? 'expired' : 'warning';
    const title = securityBlocked ? 'Lecture seule de sécurité' : info.state === 'expired' ? 'Mode lecture seule' : `Période d’essai · ${number(info.daysLeft)} jour(s) restant(s)`;
    const message = securityBlocked ? 'Une modification suspecte de la date système a été détectée. Le verrouillage s’applique à tous les comptes.' : info.state === 'expired' ? 'Les opérations de modification et de validation sont bloquées. Activez la licence pour continuer à travailler.' : `Le logiciel reste entièrement actif jusqu’au ${shortDate(info.endsAt)}.`;
    return `<div class="license-banner ${tone}"><div class="license-banner-icon"></div><div class="license-banner-copy"><strong>${title}</strong><span>${message}</span></div><button class="text-button" type="button" data-view="license">${securityBlocked ? 'Voir le contrôle →' : info.state === 'expired' ? 'Activer maintenant →' : 'Voir la licence →'}</button></div>`;
  }

  function applySidebarVisibility() {
    $$('.nav-link').forEach((link) => {
      const permission = VIEW_PERMISSIONS[link.dataset.view];
      const allowed = (!permission || can(permission)) && !isModuleDisabled(link.dataset.view);
      link.hidden = !allowed;
      link.classList.toggle('active', link.dataset.view === activeView);
      const label = link.querySelector('span:not(.nav-icon):not(.nav-count)');
      link.title = sidebarCollapsed && label ? label.textContent.trim() : '';
    });
    $$('.nav-group').forEach((group) => {
      const links = [...group.querySelectorAll('.nav-link')];
      group.hidden = links.length > 0 && links.every((link) => link.hidden);
    });
  }
  function render() {
    pagedRowStore = {};
    if (!currentUser) { showLogin(); return; }
    if (VIEW_PERMISSIONS[activeView] && !can(VIEW_PERMISSIONS[activeView])) activeView = 'dashboard';
    if (isModuleDisabled(activeView)) activeView = isModuleDisabled('dashboard') ? 'contact' : 'dashboard';
    const view = $('#view');
    if (!view) return;
    if (document.body) document.body.dataset.theme = state.settings.theme || 'standard';
    updateCurrentUserChrome();
    view.innerHTML = `${renderLicenseNotice()}${renderView(activeView)}`;
    hydrateIcons(document);
    const sidebar = $('#sidebar');
    if (sidebar) sidebar.classList.toggle('collapsed', sidebarCollapsed);
    const collapseButton = $('.sidebar-collapse-button');
    if (collapseButton) { collapseButton.innerHTML = icon(sidebarCollapsed ? 'panel-left-open' : 'panel-left-close', 16); collapseButton.title = sidebarCollapsed ? 'Afficher les libellés' : 'Masquer les libellés'; collapseButton.setAttribute?.('aria-label', collapseButton.title); }
    const themeButton = $('.theme-switcher');
    if (themeButton) { const themeLabels = { standard: 'Mode standard', clair: 'Mode clair', sombre: 'Mode sombre' }; themeButton.innerHTML = icon(state.settings.theme === 'clair' ? 'sun' : state.settings.theme === 'sombre' ? 'moon' : 'contrast', 16); themeButton.title = `${themeLabels[state.settings.theme] || themeLabels.standard} · cliquer pour changer`; themeButton.setAttribute?.('aria-label', themeButton.title); }
    const meta = VIEW_META[activeView] || VIEW_META.dashboard;
    $('#breadcrumb-section').textContent = meta[0];
    $('#breadcrumb-current').textContent = meta[1];
    $('#sidebar-business-name').textContent = state.settings.businessName || 'NOVA Boutique';
    const pending = state.stockEntries.filter((entry) => entry.status === 'En cours').length;
    const pendingCorrections = (state.creditNotes || []).filter((note) => note.status === 'En cours').length;
    const pendingTransfers = (state.stockTransfers || []).filter((transfer) => transfer.status === 'En cours').length;
    $('#pending-entries-count').textContent = pending + pendingTransfers + pendingCorrections;
    $('#pending-entries-count').style.display = pending + pendingTransfers + pendingCorrections ? 'grid' : 'none';
    $('#notification-dot').style.display = (pending || pendingCorrections || pendingTransfers || activeProducts().some((p) => ['out','low'].includes(productStockState(p).key) || (p.expiry && daysUntil(p.expiry) < 0))) ? 'block' : 'none';
    const info = licenseInfo();
    const licenseChip = $('#license-chip');
    const licenseChipText = $('#license-chip-text');
    if (licenseChip && licenseChipText) { licenseChip.className = `license-chip ${info.state === 'trial' ? 'warning' : ['expired', 'clock-tampered'].includes(info.state) ? 'expired' : ''}`; licenseChipText.textContent = info.state === 'licensed' ? 'Licence active' : info.state === 'trial' ? `${number(info.daysLeft)} j. d’essai` : info.state === 'clock-tampered' ? 'Sécurité · lecture seule' : 'Lecture seule'; }
    const licenseBadge = $('#license-nav-badge');
    if (licenseBadge) { licenseBadge.textContent = info.state === 'licensed' ? 'Active' : info.state === 'trial' ? `${number(info.daysLeft)} j.` : info.state === 'clock-tampered' ? 'Sécurité' : 'Bloqué'; licenseBadge.className = `nav-count license-count ${info.state === 'trial' ? 'warning' : ['expired', 'clock-tampered'].includes(info.state) ? 'expired' : ''}`; }
    applySidebarVisibility();
    bindViewEvents();
  }

  function bindViewEvents() {
    const root = $('#view');
    if (!root) return;
    $$('[data-filter-input]', root).forEach((input) => input.addEventListener('input', () => filterTarget(input)));
    $$('[data-filter-select]', root).forEach((select) => select.addEventListener('change', () => filterTarget(select)));
    $$('[data-table-filter]', root).forEach((select) => select.addEventListener('change', () => filterTable(select)));
    const client = $('#sale-client');
    if (client) client.addEventListener('change', () => { if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour préparer une nouvelle vente.', 'warning'); render(); return; } saleDraft.clientId = client.value; render(); });
    $$('[data-price-type-checkbox]', root).forEach((box) => box.addEventListener('change', () => setSalePriceType(box.dataset.priceTypeCheckbox)));
    $$('[data-express-check]', root).forEach((box) => box.addEventListener('change', () => updateExpressLine(box.dataset.expressCheck, { checked: box.checked })));
    $$('[data-express-qty]', root).forEach((input) => input.addEventListener('change', () => updateExpressLine(input.dataset.expressQty, { quantity: Math.max(1, Math.floor(num(input.value))) })));
    const expressCheckAll = $('#express-check-all');
    if (expressCheckAll) expressCheckAll.addEventListener('change', () => toggleExpressAll(expressCheckAll.checked));
    const supplierLinkForm = $('#supplier-product-link-form');
    const supplierLinkSelect = $('#supplier-link-supplier');
    if (supplierLinkForm && supplierLinkSelect) {
      supplierLinkSelect.addEventListener('change', () => { supplierLinkSupplierId = supplierLinkSelect.value; renderSupplierLinkProducts(); });
      $('#supplier-link-search')?.addEventListener('input', filterSupplierLinkProducts);
      $('#supplier-link-products')?.addEventListener('change', updateSupplierLinkCount);
      supplierLinkForm.addEventListener('submit', (event) => { event.preventDefault(); saveSupplierProductLinks(); });
      renderSupplierLinkProducts();
    }
    const settings = $('#settings-form');
    if (settings) settings.addEventListener('submit', (event) => { event.preventDefault(); saveSettingsFromForm(settings); });
    const licenseForm = $('#license-form');
    if (licenseForm) licenseForm.addEventListener('submit', (event) => { event.preventDefault(); activateLicense(licenseForm); });
    const printerMode = $('#printer-mode');
    const baudRate = settings?.querySelector('[name="printerBaudRate"]');
    if (printerMode && baudRate) { const toggleBaud = () => { baudRate.disabled = printerMode.value !== 'serial'; }; printerMode.addEventListener('change', toggleBaud); toggleBaud(); }
    $$('[data-cart-input]', root).forEach((input) => input.addEventListener('change', () => setCartQuantity(input.dataset.id, input.value)));
    const designerForm = $('#designer-form');
    if (designerForm) designerForm.addEventListener('submit', async (event) => { event.preventDefault(); await unlockDesignerSpace(designerForm); });
    $$('[data-designer-module]', root).forEach((box) => box.addEventListener('change', () => { if (!setModuleEnabled(box.dataset.designerModule, box.checked)) box.checked = !box.checked; }));
    $$('tbody[id]', root).forEach((tbody) => paginateTable(tbody));
  }
  function applyRowVisibility(row) {
    const matches = row.dataset.searchMatch !== '0' && row.dataset.selectMatch !== '0';
    row.dataset.filtered = matches ? '0' : '1';
    return matches;
  }
  function decodeEntities(value) {
    return String(value ?? '').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  }
  function splitTableRows(html) {
    const rows = [];
    const text = String(html || '');
    let depth = 0;
    let start = -1;
    let i = 0;
    while (i < text.length) {
      if (text.startsWith('<tr', i) && /[\s>]/.test(text[i + 3] || '')) {
        if (depth === 0) start = i;
        depth += 1;
        i += 3;
        continue;
      }
      if (text.startsWith('</tr>', i)) {
        depth -= 1;
        if (depth === 0 && start >= 0) { rows.push(text.slice(start, i + 5)); start = -1; }
        i += 5;
        continue;
      }
      i += 1;
    }
    return rows;
  }
  function pagedRowMeta(html) {
    const textAttr = /data-text="([^"]*)"/.exec(html);
    const catAttr = /data-category="([^"]*)"/.exec(html);
    const stateAttr = /data-state="([^"]*)"/.exec(html);
    const badges = [];
    const badgeRe = /status-badge[^"]*">([^<]*)/g;
    let badgeMatch = null;
    while ((badgeMatch = badgeRe.exec(html)) !== null) badges.push(decodeEntities(badgeMatch[1]).toLowerCase());
    return {
      html,
      text: textAttr ? decodeEntities(textAttr[1]).toLowerCase() : html.replace(/<[^>]*>/g, ' ').toLowerCase(),
      category: catAttr ? decodeEntities(catAttr[1]).toLowerCase() : '',
      state: stateAttr ? decodeEntities(stateAttr[1]).toLowerCase() : '',
      badges,
      searchMatch: true,
      selectMatch: true
    };
  }
  function pagedVisible(key) {
    return (pagedRowStore[key] || []).filter((row) => row.searchMatch && row.selectMatch);
  }
  function pagedSlice(key, page) {
    const visible = pagedVisible(key);
    return visible.slice((page - 1) * PAGED_TABLE_SIZE, page * PAGED_TABLE_SIZE).map((row) => row.html).join('');
  }
  function pagedTbody(key, rows) {
    const list = Array.isArray(rows) ? rows : splitTableRows(rows);
    pagedRowStore[key] = list.map(pagedRowMeta);
    const totalPages = Math.max(1, Math.ceil(pagedVisible(key).length / PAGED_TABLE_SIZE));
    const current = Math.min(totalPages, Math.max(1, Number(tablePages[key] || 1)));
    tablePages[key] = current;
    return pagedSlice(key, current);
  }
  function pageButtonList(current, total) {
    if (total <= 7) return Array.from({ length: total }, (_, index) => index + 1);
    const pages = [...new Set([1, 2, current - 1, current, current + 1, total - 1, total].filter((page) => page >= 1 && page <= total))].sort((a, b) => a - b);
    const list = [];
    pages.forEach((page, index) => {
      if (index > 0 && page - pages[index - 1] > 1) list.push('…');
      list.push(page);
    });
    return list;
  }
  function renderTableFooter(tbody, resultCount, current, totalPages) {
    const panelNode = tbody.closest('.panel');
    if (!panelNode) return;
    const key = tbody.id;
    let footer = panelNode.querySelector('.table-footer');
    if (!footer) { footer = document.createElement('div'); footer.className = 'table-footer'; panelNode.appendChild(footer); }
    let count = footer.querySelector('.table-count');
    if (!count) { count = document.createElement('span'); count.className = 'table-count'; footer.prepend(count); }
    count.textContent = `${number(resultCount)} résultat(s) · page ${number(current)} / ${number(totalPages)}`;
    let pagination = footer.querySelector('.pagination');
    if (!pagination) { pagination = document.createElement('div'); pagination.className = 'pagination'; footer.appendChild(pagination); }
    pagination.innerHTML = totalPages > 1 ? `<button class="page-btn" type="button" data-table-page="${esc(key)}" data-page="${current - 1}" ${current <= 1 ? 'disabled' : ''}>‹</button>${pageButtonList(current, totalPages).map((page) => page === '…' ? '<span class="page-ellipsis">…</span>' : `<button class="page-btn ${page === current ? 'active' : ''}" type="button" data-table-page="${esc(key)}" data-page="${page}">${page}</button>`).join('')}<button class="page-btn" type="button" data-table-page="${esc(key)}" data-page="${current + 1}" ${current >= totalPages ? 'disabled' : ''}>›</button>` : '';
  }
  function renderPagedTbody(tbody) {
    const key = tbody.id;
    if (!pagedRowStore[key] || !pagedRowStore[key].length) return;
    const visible = pagedVisible(key);
    const totalPages = Math.max(1, Math.ceil(visible.length / PAGED_TABLE_SIZE));
    const current = Math.min(totalPages, Math.max(1, Number(tablePages[key] || 1)));
    tablePages[key] = current;
    tbody.innerHTML = pagedSlice(key, current);
    renderTableFooter(tbody, visible.length, current, totalPages);
  }
  function paginateTable(tbody, requestedPage = null) {
    if (!tbody) return;
    if (tbody.id && pagedRowStore[tbody.id]) {
      if (requestedPage) tablePages[tbody.id] = requestedPage;
      renderPagedTbody(tbody);
      return;
    }
    const rows = $$('[data-filter-row]', tbody);
    if (!rows.length) return;
    const pageSize = PAGED_TABLE_SIZE;
    const key = tbody.id || `table-${Math.random().toString(36).slice(2)}`;
    if (!tbody.id) tbody.id = key;
    const filtered = rows.filter((row) => row.dataset.filtered !== '1');
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    const current = Math.min(totalPages, Math.max(1, Number(requestedPage || tablePages[key] || 1)));
    tablePages[key] = current;
    rows.forEach((row) => { row.style.display = 'none'; });
    filtered.slice((current - 1) * pageSize, current * pageSize).forEach((row) => { row.style.display = ''; });
    renderTableFooter(tbody, filtered.length, current, totalPages);
  }
  function filterTarget(input) {
    const target = $(input.dataset.filterTarget);
    if (!target) return;
    const query = input.matches('select[data-filter-select]') ? '' : (input.value || '').toLowerCase().trim();
    const category = $('#sale-category-filter')?.value || '';
    $$('[data-product-card]', target).forEach((card) => { card.style.display = (!query || card.dataset.text.includes(query)) && (!category || card.dataset.category === category) ? '' : 'none'; });
    if (target.matches('tbody') && target.id && pagedRowStore[target.id]) {
      pagedRowStore[target.id].forEach((row) => { row.searchMatch = !query || row.text.includes(query); });
      tablePages[target.id] = 1;
      renderPagedTbody(target);
      return;
    }
    $$('[data-filter-row]', target).forEach((row) => { row.dataset.searchMatch = !query || (row.dataset.text || '').includes(query) ? '1' : '0'; applyRowVisibility(row); });
    if (target.matches('tbody')) { tablePages[target.id] = 1; paginateTable(target, 1); }
  }
  function filterTable(select) {
    const panel = select.closest('.panel');
    if (!panel) return;
    const tbody = panel.querySelector('tbody');
    const value = select.value.toLowerCase();
    const mode = select.dataset.tableFilter || '';
    if (tbody && tbody.id && pagedRowStore[tbody.id]) {
      pagedRowStore[tbody.id].forEach((row) => {
        const categoryMatch = !value || !mode.includes('category') || row.category === value;
        const statusMatch = !value || !mode.includes('status') || row.text.includes(value) || row.badges.some((badge) => badge.includes(value));
        const stateMatch = !value || !mode.includes('state') || row.state === value;
        row.selectMatch = categoryMatch && statusMatch && stateMatch;
      });
      tablePages[tbody.id] = 1;
      renderPagedTbody(tbody);
      return;
    }
    const rows = $$('[data-filter-row]', panel);
    rows.forEach((row) => {
      const categoryMatch = !value || !select.dataset.tableFilter.includes('category') || row.dataset.category === value;
      const statusMatch = !value || !select.dataset.tableFilter.includes('status') || (row.dataset.text || '').includes(value) || row.querySelector('.status-badge')?.textContent.toLowerCase().includes(value);
      const stateMatch = !value || !select.dataset.tableFilter.includes('state') || row.dataset.state?.toLowerCase() === value;
      row.dataset.selectMatch = categoryMatch && statusMatch && stateMatch ? '1' : '0';
      applyRowVisibility(row);
    });
    if (tbody) { tablePages[tbody.id] = 1; paginateTable(tbody, 1); }
  }

  function setTheme(theme, notify = true) {
    if (!['standard', 'clair', 'sombre'].includes(theme)) theme = 'standard';
    state.settings.theme = theme;
    saveState();
    render();
    if (notify) toast('Mode d’affichage changé', theme === 'standard' ? 'Mode standard activé.' : theme === 'clair' ? 'Mode clair activé.' : 'Mode sombre activé.');
  }
  function cycleTheme() {
    const themes = ['standard', 'clair', 'sombre'];
    const next = themes[(themes.indexOf(state.settings.theme || 'standard') + 1) % themes.length];
    setTheme(next);
  }
  function toggleSidebarCollapse() {
    sidebarCollapsed = !sidebarCollapsed;
    appStorage.setItem('nova-sidebar-collapsed', sidebarCollapsed ? '1' : '0');
    render();
  }
  function navigate(view) {
    if (!currentUser) { showLogin(); return; }
    if (!VIEW_META[view]) view = 'dashboard';
    if (isModuleDisabled(view)) { toast('Module indisponible', 'Ce module a été masqué dans l’Espace concepteur.', 'warning'); return; }
    const permission = VIEW_PERMISSIONS[view];
    if (permission && !requirePermission(permission, 'Votre profil ne peut pas ouvrir ce module.')) return;
    activeView = view;
    appStorage.setItem('nova-active-view', activeView);
    $('#sidebar')?.classList.remove('open');
    $('#mobile-overlay')?.classList.remove('visible');
    render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function toast(title, message = '', type = 'success') {
    const stack = $('#toast-stack');
    const item = document.createElement('div');
    item.className = `toast ${type}`;
    item.innerHTML = `<div class="toast-icon">${type === 'success' ? '✓' : type === 'warning' ? '!' : '×'}</div><div class="toast-copy"><strong>${esc(title)}</strong>${message ? `<span>${esc(message)}</span>` : ''}</div><button class="toast-close" type="button">×</button>`;
    stack.appendChild(item);
    item.querySelector('.toast-close').addEventListener('click', () => item.remove());
    setTimeout(() => item.remove(), 4300);
  }
  function closeModal() { $('#modal-root').innerHTML = ''; }
  // Convention XSS « HTML DE CONFIANCE » : ce helper reçoit du HTML déjà composé par
  // l’appelant et ne l’échappe PAS. Toute donnée utilisateur/serveur doit passer dans
  // esc() AVANT l’appel (appelants vérifiés sûrs par audit le 21/09/2026).
  function openModal(title, subtitle, body, size = '', footer = '') {
    $('#modal-root').innerHTML = `<div class="modal-backdrop" data-modal-backdrop><section class="modal ${size ? `modal-${size}` : ''}" role="dialog" aria-modal="true"><div class="modal-header"><div><h2>${title}</h2>${subtitle ? `<p>${subtitle}</p>` : ''}</div><button type="button" class="modal-close" data-close-modal aria-label="Fermer">×</button></div><div class="modal-body">${body}</div>${footer ? `<div class="modal-footer">${footer}</div>` : ''}</section></div>`;
    const focusable = $('#modal-root input, #modal-root select, #modal-root textarea');
    if (focusable) setTimeout(() => focusable.focus(), 30);
  }

  function addActivity(module, action, element, detail, oldValue = '', newValue = '') {
    state.activities.unshift({ id: uid('act'), date: new Date().toISOString(), userId: currentUserId(), module, action, element, detail, oldValue, newValue });
  }
  function nextNumber(prefix, collection) {
    const date = dateCode(0);
    const count = (collection || []).filter((item) => String(item.number || '').includes(date)).length + 1;
    return `${prefix}-${date}-${String(count).padStart(3, '0')}`;
  }

  function addToCart(productId, quantity = 1) {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour enregistrer une vente.', 'warning'); return; }
    const product = productById(productId);
    if (!product) return;
    const qty = Math.max(1, Math.floor(num(quantity)));
    const existing = saleCart.find((line) => line.productId === productId);
    const storeId = existing?.storeId || productSaleStore(product);
    const available = stockFor(product, storeId);
    const requested = (existing?.quantity || 0) + qty;
    if (!state.settings.allowNegative && requested > available) { toast('Stock insuffisant', `${product.name} · ${number(available)} unité(s) disponible(s) dans ${storeName(storeId)}.`, 'warning'); return; }
    if (existing) existing.quantity = requested; else saleCart.push({ productId, storeId, quantity: qty, unitPrice: productPriceForSale(product) });
    render();
    toast('Produit ajouté', `${product.name} a été ajouté au panier.`);
  }
  function setCartQuantity(productId, value) {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier le panier.', 'warning'); render(); return; }
    const product = productById(productId);
    const line = saleCart.find((item) => item.productId === productId);
    if (!line || !product) return;
    const quantity = Math.max(1, Math.floor(num(value)));
    const available = stockFor(product, line.storeId || productSaleStore(product));
    if (!state.settings.allowNegative && quantity > available) { toast('Stock insuffisant', `Maximum disponible : ${number(available)} dans ${storeName(line.storeId || productSaleStore(product))}.`, 'warning'); render(); return; }
    line.quantity = quantity; render();
  }
  function updateCart(productId, delta) {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier le panier.', 'warning'); return; }
    const line = saleCart.find((item) => item.productId === productId);
    const product = productById(productId);
    if (!line || !product) return;
    const next = line.quantity + delta;
    const available = stockFor(product, line.storeId || productSaleStore(product));
    if (next <= 0) saleCart = saleCart.filter((item) => item.productId !== productId);
    else if (!state.settings.allowNegative && next > available) { toast('Stock insuffisant', `La quantité demandée dépasse le stock disponible dans ${storeName(line.storeId || productSaleStore(product))}.`, 'warning'); return; }
    else line.quantity = next;
    render();
  }
  function validateSale() {
    if (!requirePermission('sales.validate', 'Votre profil ne peut pas valider une vente.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour valider une vente.', 'warning'); return; }
    if (!saleCart.length) { toast('Panier vide', 'Ajoutez au moins un produit avant de valider.', 'warning'); return; }
    if (saleDraft.payment === 'credit' && saleDraft.clientId === 'counter') { toast('Client obligatoire', 'Une vente à crédit doit être rattachée à un client enregistré.', 'error'); return; }
    const invalid = saleCart.find((line) => !state.settings.allowNegative && line.quantity > stockFor(line.productId, line.storeId || productSaleStore(productById(line.productId))));
    if (invalid) { toast('Stock insuffisant', `Vérifiez ${productName(invalid.productId)} dans ${storeName(invalid.storeId)}.`, 'error'); return; }
    const total = saleCart.reduce((sum, line) => sum + line.quantity * line.unitPrice, 0);
    if (saleDraft.payment === 'credit') {
      const client = state.clients.find((item) => item.id === saleDraft.clientId);
      if (!client) { toast('Client introuvable', 'Sélectionnez un client enregistré.', 'error'); return; }
      if (num(client.creditLimit) > 0 && (num(client.receivable) - num(client.advance)) + total > num(client.creditLimit)) { toast('Limite de crédit dépassée', `${client.name} ne peut pas dépasser ${money(client.creditLimit)} d’encours net (avance déduite).`, 'error'); return; }
    }
    const sale = { id: uid('sale'), number: nextNumber('VTE', state.sales), date: new Date().toISOString(), storeId: saleDraft.storeId || state.settings.defaultStoreId || state.stores[0]?.id || '', clientId: saleDraft.clientId, clientName: clientName(saleDraft.clientId), items: saleCart.map((line) => ({ ...line, storeId: line.storeId || productSaleStore(productById(line.productId)), costPrice: num(productById(line.productId)?.purchasePrice) })), total, payment: saleDraft.payment, priceType: saleDraft.priceType || 'retail', priceLabel: salePriceTypeLabel(saleDraft.priceType), status: 'Validée', userId: currentUserId() };
    sale.items.forEach((item) => { const product = productById(item.productId); if (product) changeStock(product, item.storeId, -num(item.quantity)); });
    state.sales.unshift(sale);
    refreshClientReceivables();
    addActivity('Ventes', 'Validation d’une vente', sale.number, `${money(sale.total)} · ${paymentLabel(sale.payment)} · ${sale.priceLabel}`, '', 'Validée');
    saveState();
    saleCart = [];
    saleDraft = { clientId: 'counter', payment: 'cash', storeId: '', priceType: 'retail' };
    render();
    toast('Vente validée', `${sale.number} · ${money(sale.total)}.`);
    setTimeout(() => { if (state.settings.ticketPrinter?.autoPrint) printSaleWithConfiguredPrinter(sale, true); else showReceipt(sale); }, 120);
  }
  function receiptMarkup(sale, includeId = false) {
    return `<div class="receipt"${includeId ? ' id="receipt-preview"' : ''}><div class="receipt-head"><div class="receipt-logo">◆</div><h3>${esc(state.settings.businessName)}</h3><p>${esc(state.settings.address)}<br>${esc(state.settings.commercialPhone || state.settings.managerPhone)}</p></div><div class="receipt-meta"><span>${esc(sale.number)}<br>${dateTime(sale.date)}</span><span style="text-align:right">${esc(clientName(sale.clientId))}<br>${esc(paymentLabel(sale.payment))}</span></div><div class="receipt-items">${(sale.items || []).map((item) => `<div class="receipt-item"><span>${esc(productName(item.productId))}</span><strong>${money(item.quantity * item.unitPrice)}</strong><small>${number(item.quantity)} × ${money(item.unitPrice)}</small></div>`).join('')}</div><div class="receipt-total"><div><span>Sous-total</span><span>${money(sale.total)}</span></div><div class="grand"><span>Total</span><span>${money(sale.total)}</span></div></div><div class="receipt-thanks">Merci pour votre confiance · À bientôt</div></div>`;
  }
  function showReceipt(sale) {
    const direct = state.settings.ticketPrinter?.mode && state.settings.ticketPrinter.mode !== 'browser';
    const label = direct && state.settings.ticketPrinter.status === 'connected' ? 'Envoyer à l’imprimante' : 'Imprimer le ticket';
    openModal('Ticket de caisse', 'Vente enregistrée · prêt à imprimer', receiptMarkup(sale, true), 'sm', `<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button><button class="btn btn-primary" type="button" data-action="print-receipt" data-id="${esc(sale.id)}">▣ ${label}</button>`);
  }

  function openQuantityModal(productId) {
    const product = productById(productId);
    if (!product) return;
    openModal('Ajouter au panier', product.name, `<form id="quantity-form"><div class="table-product" style="margin-bottom:16px"><img class="mini-thumb" style="width:52px;height:52px" src="${productImage(product)}" alt=""><div><strong>${esc(product.name)}</strong><span class="table-secondary">${money(productPriceForSale(product))} · ${salePriceTypeLabel(saleDraft.priceType)} · ${number(stockFor(product, productSaleStore(product)))} en stock</span></div></div><div class="field"><label>Quantité <em>*</em></label><input class="input-control" name="quantity" type="number" value="1" min="1" max="${stockFor(product, productSaleStore(product)) || 9999}" required></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">Ajouter au panier</button></div></form>`);
    $('#quantity-form').addEventListener('submit', (event) => { event.preventDefault(); const qty = num(new FormData(event.currentTarget).get('quantity')); closeModal(); addToCart(productId, qty); });
  }

  function openProductModal(productId = '') {
    const product = productId ? productById(productId) : null;
    const p = product || { code: '', name: '', categoryId: '', brand: '', model: '', supplierId: '', storeId: state.stores[0]?.id || '', purchasePrice: '', salePrice: '', wholesalePrice: '', promoPrice: '', stock: 0, minStock: 5, maxStock: 50, presentation: 'Pièce', batch: '', expiry: '', active: true };
    const title = product ? 'Modifier le produit' : 'Nouveau produit';
    const body = `<form id="product-form" data-id="${esc(productId)}"><div class="form-section-title">Informations générales</div><div class="form-grid"><div class="field"><label>Code produit <em>*</em></label><input class="input-control" name="code" value="${esc(p.code)}" required></div><div class="field"><label>Désignation <em>*</em></label><input class="input-control" name="name" value="${esc(p.name)}" required></div><div class="field"><label>Catégorie <em>*</em></label><select class="select-control" name="categoryId" required>${options(state.categories.filter((c) => c.active !== false), p.categoryId)}</select></div><div class="field"><label>Marque</label><input class="input-control" name="brand" value="${esc(p.brand)}"></div><div class="field"><label>Modèle</label><input class="input-control" name="model" value="${esc(p.model)}"></div><div class="field"><label>Fournisseur principal</label><select class="select-control" name="supplierId">${options(state.suppliers.filter((s) => s.active !== false), p.supplierId)}</select></div><div class="field"><label>Magasin</label><select class="select-control" name="storeId">${options(state.stores.filter((s) => s.active !== false), p.storeId)}</select></div><div class="field"><label>Présentation</label><select class="select-control" name="presentation">${['Pièce','Carton','Boîte','Sac','Bidon','Flacon','Bouteille','Sachet','Unité'].map((x) => `<option ${p.presentation === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div></div><div class="form-section-title" style="margin-top:20px">Prix et stock</div><div class="form-grid four"><div class="field"><label>Prix d’achat <em>*</em></label><input class="input-control" type="number" name="purchasePrice" value="${num(p.purchasePrice)}" min="0" required></div><div class="field"><label>Prix de vente <em>*</em></label><input class="input-control" type="number" name="salePrice" value="${num(p.salePrice)}" min="0" required></div><div class="field"><label>Prix de gros</label><input class="input-control" type="number" name="wholesalePrice" value="${num(p.wholesalePrice)}" min="0"></div><div class="field"><label>Prix promotionnel</label><input class="input-control" type="number" name="promoPrice" value="${num(p.promoPrice)}" min="0"></div><div class="field"><label>Stock total ${product ? '(géré par mouvements)' : ''}</label><input class="input-control" type="number" name="stock" value="${number(totalStock(p))}" min="0" ${product ? 'readonly' : ''}><div class="field-hint">${product ? 'Le stock d’un produit existant se modifie par une entrée, une sortie ou un transfert validé.' : 'Le stock initial sera affecté au magasin choisi.'}</div></div><div class="field"><label>Stock minimum</label><input class="input-control" type="number" name="minStock" value="${num(p.minStock)}" min="0"></div><div class="field"><label>Stock maximum</label><input class="input-control" type="number" name="maxStock" value="${num(p.maxStock)}" min="0"></div><div class="field"><label>Numéro de lot</label><input class="input-control" name="batch" value="${esc(p.batch)}"></div><div class="field"><label>Date d’expiration</label><input class="input-control" type="date" name="expiry" value="${esc(p.expiry || '')}"></div><div class="field full"><label>Image du produit</label><input class="input-control" type="file" name="imageFile" accept="image/*"><div class="field-hint">Une illustration automatique est utilisée si aucune image n’est importée.</div></div></div><div class="form-actions"><span class="required-note">* Champs obligatoires</span><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${product ? 'Enregistrer les modifications' : 'Créer le produit'}</button></div></form>`;
    openModal(title, product ? 'Les modifications seront historisées.' : 'Ajoutez une référence à votre catalogue.', body, 'lg');
    $('#product-form').addEventListener('submit', (event) => submitProduct(event, product));
  }
  async function submitProduct(event, existing) {
    event.preventDefault();
    const form = event.currentTarget; const data = Object.fromEntries(new FormData(form).entries());
    const duplicate = state.products.find((p) => p.code.toLowerCase() === data.code.toLowerCase() && p.id !== existing?.id);
    if (duplicate) { toast('Code déjà utilisé', 'Chaque code produit doit être unique.', 'error'); return; }
    let image = existing?.image || '';
    const file = form.querySelector('[name="imageFile"]').files[0];
    if (file) { const loaded = await readFileAsDataURL(file); if (loaded) image = loaded; }
    const selectedStoreId = data.storeId || state.settings.defaultStoreId || state.stores[0]?.id || '';
    const stockByStore = existing ? { ...(existing.stockByStore || {}) } : { [selectedStoreId]: Math.max(0, num(data.stock)) };
    const item = { id: existing?.id || uid('prod'), code: data.code.trim(), name: data.name.trim(), categoryId: data.categoryId, brand: data.brand.trim(), model: data.model.trim(), supplierId: data.supplierId, storeId: selectedStoreId, purchasePrice: num(data.purchasePrice), salePrice: num(data.salePrice), wholesalePrice: num(data.wholesalePrice), promoPrice: num(data.promoPrice), stockByStore, stock: Object.values(stockByStore).reduce((sum, value) => sum + num(value), 0), minStock: Math.max(0, num(data.minStock)), maxStock: Math.max(0, num(data.maxStock)), presentation: data.presentation, batch: data.batch.trim(), expiry: data.expiry, active: existing?.active !== false, ...(image ? { image } : {}) };
    if (existing) { const old = productById(existing.id); state.products[state.products.findIndex((p) => p.id === existing.id)] = item; addActivity('Produits', 'Modification d’un produit', item.code, item.name, `${money(old.salePrice)}`, `${money(item.salePrice)}`); toast('Produit mis à jour', item.name); }
    else { state.products.unshift(item); addActivity('Produits', 'Création d’un produit', item.code, item.name, '', 'Actif'); toast('Produit créé', item.name); }
    saveState(); closeModal(); render();
  }
  function readFileAsDataURL(file, maxBytes = MAX_IMAGE_BYTES) {
    return new Promise((resolve) => {
      if (file && file.size > maxBytes) { toast('Fichier trop volumineux', `Taille maximale : ${Math.round(maxBytes / 1024)} Ko. Réduisez l’image avant de l’importer.`, 'error'); resolve(''); return; }
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => resolve('');
      reader.readAsDataURL(file);
    });
  }

  function openClientModal(clientId = '') {
    const client = clientId ? state.clients.find((item) => item.id === clientId) : null;
    const c = client || { name: '', phone: '', email: '', address: '', creditLimit: 0, openingReceivable: 0, receivable: 0, active: true };
    const openingField = client ? `<div class="field"><label>Solde initial</label><input class="input-control" type="number" value="${num(c.openingReceivable)}" min="0" readonly><div class="field-hint">Report initial conservé dans le journal.</div></div>` : `<div class="field"><label>Solde initial</label><input class="input-control" type="number" name="openingReceivable" value="0" min="0"><div class="field-hint">Report d’une créance antérieure, avant les ventes enregistrées ici.</div></div>`;
    const body = `<form id="client-form" data-id="${esc(clientId)}"><div class="form-grid"><div class="field full"><label>Nom du client <em>*</em></label><input class="input-control" name="name" value="${esc(c.name)}" required></div><div class="field"><label>Contact principal</label><input class="input-control" name="phone" value="${esc(c.phone)}"></div><div class="field"><label>Adresse e-mail</label><input class="input-control" type="email" name="email" value="${esc(c.email)}"></div><div class="field full"><label>Adresse</label><input class="input-control" name="address" value="${esc(c.address)}"></div><div class="field"><label>Limite de crédit</label><input class="input-control" type="number" name="creditLimit" value="${num(c.creditLimit)}" min="0"></div>${openingField}<div class="field full"><label>Encours actuel</label><input class="input-control" type="number" name="receivable" value="${num(c.receivable)}" min="0" readonly><div class="field-hint">Calculé à partir du solde initial, des ventes à crédit validées et des règlements, avances et remboursements.</div></div><div class="field full"><label>Avance disponible</label><input class="input-control" type="number" value="${num(client?.advance)}" min="0" readonly><div class="field-hint">Trop-perçu imputé automatiquement sur la prochaine vente à crédit.</div></div></div><div class="form-actions"><span class="required-note">* Champs obligatoires</span><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${client ? 'Enregistrer' : 'Créer le client'}</button></div></form>`;
    openModal(client ? 'Modifier le client' : 'Nouveau client', 'Les ventes à crédit nécessitent une fiche client.', body);
    $('#client-form').addEventListener('submit', (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget).entries()); const item = { id: client?.id || uid('client'), name: data.name.trim(), phone: data.phone.trim(), email: data.email.trim(), address: data.address.trim(), creditLimit: num(data.creditLimit), openingReceivable: client ? num(client.openingReceivable) : Math.max(0, num(data.openingReceivable)), receivable: client ? num(client.receivable) : 0, active: client?.active !== false }; if (client) state.clients[state.clients.findIndex((x) => x.id === client.id)] = item; else state.clients.unshift(item); refreshClientReceivables(); addActivity('Clients', client ? 'Modification d’un client' : 'Création d’un client', item.name, item.phone); saveState(); closeModal(); render(); toast(client ? 'Client mis à jour' : 'Client créé', item.name); });
  }

  function openCustomerPaymentModal(clientId) {
    if (!requirePermission('credit.record', 'Votre profil ne peut pas enregistrer un règlement.')) return;
    const client = state.clients.find((item) => item.id === clientId);
    if (!client) return;
    refreshClientReceivables();
    // Les avances sont autorisées : un règlement reste possible à encours nul.
    const body = `<form id="customer-payment-form"><div class="notice info"><span>₣</span><div><strong>Encours actuel : ${money(client.receivable)}${num(client.advance) > 0 ? ` · Avance : ${money(client.advance)}` : ''}</strong><span>Montant supérieur à l’encours : l’excédent devient une avance, imputée automatiquement.</span></div></div><div class="form-grid"><div class="field"><label>Date du règlement <em>*</em></label><input class="input-control" type="date" name="date" value="${todayKey()}" required></div><div class="field"><label>Montant encaissé <em>*</em></label><input class="input-control" type="number" name="amount" id="customer-payment-amount" min="1" step="1" required><div class="field-hint" id="customer-payment-hint"></div></div><div class="field"><label>Mode de règlement</label><select class="select-control" name="method"><option value="cash">Cash</option><option value="mobile">Mobile Money</option><option value="card">Carte</option><option value="cheque">Chèque</option></select></div><div class="field"><label>Référence</label><input class="input-control" name="reference" placeholder="N° transaction, chèque…"></div><div class="field full"><label>Note</label><textarea class="textarea-control" name="note" placeholder="Observation facultative"></textarea></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">Enregistrer le règlement</button></div></form>`;
    openModal(`Règlement · ${esc(client.name)}`, 'Le règlement sera historisé : imputé à la créance, excédent en avance.', body, 'lg');
    const amountInput = document.getElementById('customer-payment-amount');
    const amountHint = document.getElementById('customer-payment-hint');
    const updateAmountHint = () => {
      const value = Math.max(0, num(amountInput?.value));
      const excess = value - num(client.receivable);
      amountHint.textContent = value <= 0 ? '' : excess > 0 ? `Dont ${money(excess)} en avance client` : 'Montant imputé à l’encours';
    };
    amountInput?.addEventListener('input', updateAmountHint);
    $('#customer-payment-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(event.currentTarget).entries());
      refreshClientReceivables();
      const amount = Math.max(0, num(data.amount));
      if (!amount) { toast('Montant invalide', 'Indiquez un montant d’au moins 1 FCFA.', 'error'); return; }
      const imputed = Math.min(amount, num(client.receivable));
      const advancePart = amount - imputed;
      const item = { id: uid('payment'), number: nextNumber('REG', state.customerPayments), clientId, date: data.date, amount, method: data.method, reference: String(data.reference || '').trim(), note: String(data.note || '').trim(), status: 'Validé', userId: currentUserId(), createdAt: new Date().toISOString() };
      state.customerPayments.unshift(item);
      refreshClientReceivables();
      addActivity('Créances', 'Enregistrement d’un règlement', item.number, `${client.name} · ${money(amount)} · ${paymentLabel(item.method)}`);
      saveState(); closeModal(); render(); toast('Règlement enregistré', advancePart > 0 ? `${money(amount)} · ${money(imputed)} imputés, ${money(advancePart)} en avance.` : `${money(amount)} imputés à ${client.name}.`);
    });
  }

  function openSupplierModal(supplierId = '') {
    const supplier = supplierId ? state.suppliers.find((item) => item.id === supplierId) : null;
    const s = supplier || { name: '', type: 'Entreprise', manager: '', phone: '', secondary: '', fiscal: '', address: '', active: true };
    const body = `<form id="supplier-form"><div class="form-grid"><div class="field full"><label>Nom du fournisseur <em>*</em></label><input class="input-control" name="name" value="${esc(s.name)}" required></div><div class="field"><label>Type</label><select class="select-control" name="type">${['Entreprise','Particulier','Institution','Autre'].map((x) => `<option ${s.type === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div class="field"><label>Nom du responsable</label><input class="input-control" name="manager" value="${esc(s.manager)}"></div><div class="field"><label>Contact principal</label><input class="input-control" name="phone" value="${esc(s.phone)}"></div><div class="field"><label>Contact secondaire</label><input class="input-control" name="secondary" value="${esc(s.secondary)}"></div><div class="field"><label>N° IFU / fiscal</label><input class="input-control" name="fiscal" value="${esc(s.fiscal)}"></div><div class="field full"><label>Adresse</label><input class="input-control" name="address" value="${esc(s.address)}"></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${supplier ? 'Enregistrer' : 'Créer le fournisseur'}</button></div></form>`;
    openModal(supplier ? 'Modifier le fournisseur' : 'Nouveau fournisseur', 'Conservez les contacts et l’identité fiscale.', body);
    $('#supplier-form').addEventListener('submit', (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget).entries()); const item = { id: supplier?.id || uid('sup'), name: data.name.trim(), type: data.type, manager: data.manager.trim(), phone: data.phone.trim(), secondary: data.secondary.trim(), fiscal: data.fiscal.trim(), address: data.address.trim(), active: supplier?.active !== false }; if (supplier) state.suppliers[state.suppliers.findIndex((x) => x.id === supplier.id)] = item; else state.suppliers.unshift(item); addActivity('Fournisseurs', supplier ? 'Modification d’un fournisseur' : 'Création d’un fournisseur', item.name, item.phone); saveState(); closeModal(); render(); toast(supplier ? 'Fournisseur mis à jour' : 'Fournisseur créé', item.name); });
  }

  function openDelivererModal(delivererId = '') {
    const deliverer = delivererId ? state.deliverers.find((item) => item.id === delivererId) : null;
    const d = deliverer || { lastName: '', firstName: '', phone: '', secondary: '', address: '', baseRate: 0, cin: '', notes: '', active: true };
    const body = `<form id="deliverer-form"><div class="form-grid"><div class="field"><label>Nom <em>*</em></label><input class="input-control" name="lastName" value="${esc(d.lastName)}" required></div><div class="field"><label>Prénoms <em>*</em></label><input class="input-control" name="firstName" value="${esc(d.firstName)}" required></div><div class="field"><label>Contact principal <em>*</em></label><input class="input-control" name="phone" value="${esc(d.phone)}" required></div><div class="field"><label>Contact secondaire</label><input class="input-control" name="secondary" value="${esc(d.secondary)}"></div><div class="field full"><label>Adresse</label><input class="input-control" name="address" value="${esc(d.address)}"></div><div class="field"><label>Tarif de base (FCFA)</label><input class="input-control" type="number" name="baseRate" value="${num(d.baseRate)}" min="0"></div><div class="field"><label>Numéro CIN</label><input class="input-control" name="cin" value="${esc(d.cin)}"></div><div class="field full"><label>Autre information</label><textarea class="textarea-control" name="notes">${esc(d.notes)}</textarea></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${deliverer ? 'Enregistrer' : 'Créer le livreur'}</button></div></form>`;
    openModal(deliverer ? 'Modifier le livreur' : 'Nouveau livreur', 'Identité, contacts, tarif de base et pièce d’identité.', body);
    $('#deliverer-form').addEventListener('submit', (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget).entries()); const cin = String(data.cin || '').trim(); const duplicate = cin && state.deliverers.find((x) => String(x.cin || '').trim().toLowerCase() === cin.toLowerCase() && x.id !== deliverer?.id); if (duplicate) { toast('CIN déjà utilisé', 'Ce numéro CIN est déjà enregistré pour un autre livreur.', 'error'); return; } const item = { id: deliverer?.id || uid('liv'), lastName: String(data.lastName || '').trim(), firstName: String(data.firstName || '').trim(), phone: String(data.phone || '').trim(), secondary: String(data.secondary || '').trim(), address: String(data.address || '').trim(), baseRate: Math.max(0, num(data.baseRate)), cin, notes: String(data.notes || '').trim(), active: deliverer?.active !== false }; if (deliverer) state.deliverers[state.deliverers.findIndex((x) => x.id === deliverer.id)] = item; else state.deliverers.unshift(item); addActivity('Livreurs', deliverer ? 'Modification d’un livreur' : 'Création d’un livreur', `${item.firstName} ${item.lastName}`.trim(), item.phone); saveState(); closeModal(); render(); toast(deliverer ? 'Livreur mis à jour' : 'Livreur créé', `${item.firstName} ${item.lastName}`.trim()); });
  }
  function assignDelivery(saleId, delivererId, fee) {
    const sale = state.sales.find((item) => item.id === saleId);
    const deliverer = state.deliverers.find((item) => item.id === delivererId);
    if (!sale || !deliverer) return false;
    if (!Array.isArray(state.deliveries)) state.deliveries = [];
    const existing = state.deliveries.find((item) => item.saleId === saleId);
    const item = { id: existing?.id || uid('dlv'), saleId, saleNumber: sale.number, delivererId, fee: Math.max(0, num(fee)), assignedAt: new Date().toISOString(), assignedBy: currentUserId() };
    if (existing) state.deliveries[state.deliveries.findIndex((x) => x.id === existing.id)] = item; else state.deliveries.unshift(item);
    addActivity('Livraisons', existing ? 'Réaffectation d’un livreur' : 'Affectation d’un livreur', sale.number, `${delivererName(delivererId)} · ${money(item.fee)}`);
    return true;
  }
  function openDeliveryModal(saleId) {
    const sale = state.sales.find((item) => item.id === saleId);
    if (!sale) return;
    if (!requirePermission('sales.validate', 'Votre profil ne peut pas affecter un livreur.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour affecter un livreur.', 'warning'); return; }
    const deliverers = state.deliverers.filter((item) => item.active !== false);
    const current = deliveryForSale(saleId);
    if (!deliverers.length) {
      openModal(`Livraison · ${esc(sale.number)}`, 'Affectation d’un livreur à une vente réalisée.', `<div class="notice warning" style="margin-top:0"><span>!</span><div><strong>Aucun livreur actif</strong><span>Créez d’abord un livreur dans le module Livreurs, puis revenez affecter la vente ${esc(sale.number)}.</span></div></div><div class="form-actions" style="border-top:0;padding-top:0"><button class="btn btn-secondary" type="button" data-close-modal>Fermer</button><button class="btn btn-primary" type="button" data-action="add-deliverer">＋ Nouveau livreur</button></div>`);
      return;
    }
    const selected = deliverers.find((item) => item.id === current?.delivererId) || deliverers[0];
    const list = deliverers.map((item) => `<label class="data-row" style="cursor:pointer"><input type="radio" name="delivererId" value="${esc(item.id)}" ${item.id === selected.id ? 'checked' : ''} style="accent-color:var(--teal-dark);margin-top:3px"><div class="data-row-main"><strong>${esc(item.firstName)} ${esc(item.lastName)}</strong><span>${esc(item.phone || 'Sans contact')} · ${esc(item.address || 'Sans adresse')}</span></div><div class="data-row-value">${money(item.baseRate)}<br><span class="table-secondary">tarif de base</span></div></label>`).join('');
    const body = `<form id="delivery-form"><div class="notice info" style="margin-top:0"><span>ⓘ</span><div><strong>Vente ${esc(sale.number)} · ${money(saleTotal(sale))}</strong><span>${esc(clientName(sale.clientId))} · ${dateTime(sale.date)}${current ? ` · livreur actuel : ${esc(delivererName(current.delivererId))}` : ''}</span></div></div><div class="form-section-title">Choisir le livreur</div><div class="data-list">${list}</div><div class="form-grid" style="margin-top:14px"><div class="field"><label>Frais de livraison (FCFA)</label><input class="input-control" type="number" id="delivery-fee" name="fee" value="${num(current ? current.fee : selected.baseRate)}" min="0"></div><div class="field"><label>Tarif de base du livreur</label><input class="input-control" id="delivery-base-rate" value="${money(selected.baseRate)}" disabled></div></div><div class="field-hint" style="margin-top:8px">Les frais sont proposés depuis le tarif de base et restent modifiables avant validation. La vente validée n’est jamais modifiée : l’affectation est historisée comme une opération liée.</div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">✓ Valider le livreur</button></div></form>`;
    openModal(`Livraison · ${esc(sale.number)}`, 'Choisissez un livreur puis validez l’affectation.', body);
    const rates = Object.fromEntries(deliverers.map((item) => [item.id, num(item.baseRate)]));
    document.querySelectorAll('#delivery-form input[name="delivererId"]').forEach((radio) => radio.addEventListener('change', () => { $('#delivery-fee').value = rates[radio.value] ?? 0; $('#delivery-base-rate').value = money(rates[radio.value] ?? 0); }));
    $('#delivery-form').addEventListener('submit', (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget).entries()); if (!assignDelivery(saleId, data.delivererId, data.fee)) { toast('Affectation impossible', 'Vente ou livreur introuvable.', 'error'); return; } saveState(); closeModal(); render(); toast(current ? 'Livreur réaffecté' : 'Livreur affecté', `${sale.number} → ${delivererName(data.delivererId)}`); });
  }
  function openCategoryModal(categoryId = '') {
    const category = categoryId ? state.categories.find((item) => item.id === categoryId) : null;
    const c = category || { name: '', code: '', description: '', active: true };
    const body = `<form id="category-form"><div class="form-grid"><div class="field"><label>Nom de la catégorie <em>*</em></label><input class="input-control" name="name" value="${esc(c.name)}" required></div><div class="field"><label>Code catégorie <em>*</em></label><input class="input-control" name="code" value="${esc(c.code)}" required></div><div class="field full"><label>Description</label><textarea class="textarea-control" name="description">${esc(c.description)}</textarea></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${category ? 'Enregistrer' : 'Créer la catégorie'}</button></div></form>`;
    openModal(category ? 'Modifier la catégorie' : 'Nouvelle catégorie', 'Le code doit être unique.', body);
    $('#category-form').addEventListener('submit', (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget).entries()); const duplicate = state.categories.find((x) => x.code.toLowerCase() === data.code.toLowerCase() && x.id !== category?.id); if (duplicate) { toast('Code déjà utilisé', 'Choisissez un autre code catégorie.', 'error'); return; } const item = { id: category?.id || uid('cat'), name: data.name.trim(), code: data.code.trim().toUpperCase(), description: data.description.trim(), active: category?.active !== false }; if (category) state.categories[state.categories.findIndex((x) => x.id === category.id)] = item; else state.categories.unshift(item); addActivity('Catégories', category ? 'Modification d’une catégorie' : 'Création d’une catégorie', item.code, item.name); saveState(); closeModal(); render(); toast(category ? 'Catégorie mise à jour' : 'Catégorie créée', item.name); });
  }

  function openStoreModal(storeId = '') {
    const store = storeId ? state.stores.find((item) => item.id === storeId) : null;
    const s = store || { name: '', code: '', type: 'Point de vente', manager: '', active: true };
    const body = `<form id="store-form"><div class="form-grid"><div class="field"><label>Nom du magasin <em>*</em></label><input class="input-control" name="name" value="${esc(s.name)}" required></div><div class="field"><label>Code du magasin <em>*</em></label><input class="input-control" name="code" value="${esc(s.code)}" required></div><div class="field"><label>Type de magasin</label><select class="select-control" name="type">${['Point de vente','Réserve','Dépôt','Autre'].map((x) => `<option ${s.type === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div class="field"><label>Responsable</label><input class="input-control" name="manager" value="${esc(s.manager)}"></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${store ? 'Enregistrer' : 'Créer le magasin'}</button></div></form>`;
    openModal(store ? 'Modifier le magasin' : 'Nouveau magasin', 'Le code magasin doit être unique.', body);
    $('#store-form').addEventListener('submit', (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget).entries()); const duplicate = state.stores.find((x) => x.code.toLowerCase() === data.code.toLowerCase() && x.id !== store?.id); if (duplicate) { toast('Code déjà utilisé', 'Choisissez un autre code magasin.', 'error'); return; } const item = { id: store?.id || uid('store'), name: data.name.trim(), code: data.code.trim().toUpperCase(), type: data.type, manager: data.manager.trim(), active: store?.active !== false }; if (store) state.stores[state.stores.findIndex((x) => x.id === store.id)] = item; else state.stores.unshift(item); addActivity('Magasins', store ? 'Modification d’un magasin' : 'Création d’un magasin', item.code, item.name); saveState(); closeModal(); render(); toast(store ? 'Magasin mis à jour' : 'Magasin créé', item.name); });
  }

  function renderCreditNoteDraftLines() {
    const container = $('#credit-note-lines');
    const totalNode = $('#credit-note-total');
    const countNode = $('#credit-note-count');
    const submit = $('#credit-note-form button[type="submit"]');
    if (!container) return;
    container.innerHTML = creditNoteDraftLines.length ? creditNoteDraftLines.map((line, index) => `<div class="order-line-row"><div class="order-line-number">${String(index + 1).padStart(2, '0')}</div><div class="order-line-product"><strong>${esc(productName(line.productId))}</strong><span>Disponible pour correction : ${number(line.available)} · ${money(line.unitPrice)}</span></div><div class="order-line-field"><label>Qté à reprendre</label><input class="input-control" type="number" min="0" max="${number(line.available)}" value="${number(line.quantity)}" data-credit-note-field="quantity" data-index="${index}"></div><strong class="order-line-total">${money(num(line.quantity) * num(line.unitPrice))}</strong></div>`).join('') : emptyState('Aucune ligne disponible', 'Cette vente a déjà été entièrement corrigée par des avoirs.');
    const total = creditNoteDraftLines.reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0);
    if (totalNode) totalNode.textContent = money(total);
    if (countNode) countNode.textContent = `${number(creditNoteDraftLines.filter((line) => num(line.quantity) > 0).length)} ligne(s) · ${number(creditNoteDraftLines.reduce((sum, line) => sum + num(line.quantity), 0))} unité(s)`;
    if (submit) submit.disabled = !creditNoteDraftLines.some((line) => num(line.quantity) > 0);
  }
  function updateCreditNoteLine(index, value) {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour créer un avoir.', 'warning'); renderCreditNoteDraftLines(); return; }
    const line = creditNoteDraftLines[num(index)];
    if (!line) return;
    line.quantity = clamp(Math.floor(num(value)), 0, num(line.available));
    renderCreditNoteDraftLines();
  }
  function openCreditNoteModal(sale) {
    if (!sale || sale.status !== 'Validée') return;
    if (!requirePermission('sales.reverse', 'Votre profil ne peut pas créer un avoir ou annuler une vente.')) return;
    const availableLines = (sale.items || []).map((line) => ({ productId: line.productId, storeId: line.storeId || sale.storeId || productSaleStore(productById(line.productId)), available: availableSaleQuantity(sale, line), quantity: availableSaleQuantity(sale, line), unitPrice: num(line.unitPrice), costPrice: num(line.costPrice ?? productById(line.productId)?.purchasePrice) })).filter((line) => line.available > 0);
    if (!availableLines.length) { toast('Vente déjà corrigée', 'Toutes les quantités de cette vente ont déjà été reprises par des avoirs.', 'warning'); return; }
    creditNoteDraftLines = availableLines;
    const body = `<form id="credit-note-form"><div class="notice warning"><span>!</span><div><strong>La vente d’origine restera inchangée</strong><span>Cette opération crée un nouvel avoir historisé. Aucun effacement ni modification de ${esc(sale.number)} ne sera effectué.</span></div></div><div class="form-grid"><div class="field"><label>Date de l’opération <em>*</em></label><input class="input-control" type="date" name="date" value="${todayKey()}" required></div><div class="field"><label>Nature de la correction</label><select class="select-control" name="type" id="credit-note-type"><option>Avoir partiel</option><option>Annulation complète</option></select></div><div class="field"><label>Statut</label><select class="select-control" name="status"><option>En cours</option><option>Validée</option></select></div><div class="field"><label>Retour physique au stock</label><label class="checkbox-line" style="height:35px"><input type="checkbox" name="restock" checked> Remettre les articles retournés en stock</label></div><div class="field full"><label>Motif obligatoire <em>*</em></label><textarea class="textarea-control" name="reason" minlength="3" required placeholder="Produit retourné, erreur de facturation, annulation client…"></textarea></div></div><div class="form-section-title" style="margin-top:20px">Lignes de l’avoir · vente ${esc(sale.number)}</div><div class="order-cart"><div class="order-cart-header"><div><strong>Quantités à corriger</strong><span id="credit-note-count">0 ligne(s) · 0 unité(s)</span></div><strong id="credit-note-total">0 FCFA</strong></div><div id="credit-note-lines"></div></div><div class="notice info" style="margin-top:14px;margin-bottom:0"><span>ⓘ</span><div><strong>Opération traçable</strong><span>Un avoir validé réduit le chiffre d’affaires et l’encours client si la vente était à crédit. Le stock n’est réintégré que si l’option de retour est cochée.</span></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit" disabled>Créer l’avoir</button></div></form>`;
    openModal(`Avoir / annulation · ${esc(sale.number)}`, 'Corrigez la vente par une nouvelle opération historisée.', body, 'lg');
    const type = $('#credit-note-type');
    if (type) type.addEventListener('change', () => { if (type.value === 'Annulation complète') creditNoteDraftLines.forEach((line) => { line.quantity = line.available; }); renderCreditNoteDraftLines(); });
    $('#credit-note-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(event.currentTarget).entries());
      const lines = creditNoteDraftLines.filter((line) => num(line.quantity) > 0).map((line) => ({ productId: line.productId, storeId: line.storeId, quantity: Math.floor(num(line.quantity)), unitPrice: num(line.unitPrice), costPrice: num(line.costPrice) }));
      if (!lines.length) { toast('Aucune quantité', 'Indiquez au moins une quantité à corriger.', 'warning'); return; }
      const sourceByProduct = new Map(availableLines.map((line) => [line.productId, line]));
      if (lines.some((line) => line.quantity > num(sourceByProduct.get(line.productId)?.available))) { toast('Quantité excessive', 'La quantité corrigée ne peut pas dépasser la quantité encore disponible de la vente.', 'error'); return; }
      if (data.type === 'Annulation complète' && lines.some((line) => line.quantity !== num(sourceByProduct.get(line.productId)?.available))) { toast('Annulation incomplète', 'Pour une annulation complète, reprenez toutes les quantités encore disponibles.', 'error'); return; }
      const note = { id: uid('credit-note'), number: nextNumber('AVO', state.creditNotes), date: data.date, type: data.type, originalSaleId: sale.id, originalSaleNumber: sale.number, clientId: sale.clientId, clientName: sale.clientName || clientName(sale.clientId), payment: sale.payment, lines, total: lines.reduce((sum, line) => sum + line.quantity * line.unitPrice, 0), restock: data.restock === 'on', status: data.status === 'Validée' ? 'Validée' : 'En cours', stockApplied: false, reason: String(data.reason || '').trim(), userId: currentUserId(), createdAt: new Date().toISOString() };
      if (note.status === 'Validée' && !applyCreditNoteStock(note)) { toast('Avoir impossible', 'Le retour en stock n’a pas pu être appliqué.', 'error'); return; }
      const previousAdvance = num(((state.clients || []).find((item) => item.id === note.clientId) || {}).advance);
      state.creditNotes.unshift(note);
      refreshClientReceivables();
      const overpayment = noteOverpayment(note, previousAdvance);
      addActivity('Ventes', note.status === 'Validée' ? 'Validation d’un avoir' : 'Création d’un avoir', note.number, `${note.originalSaleNumber} · ${money(note.total)} · ${note.reason}`, '', note.status);
      saveState(); closeModal(); creditNoteDraftLines = []; render(); if (overpayment > 0) openOverpaymentChoiceModal(note, overpayment); else toast(note.status === 'Validée' ? 'Avoir validé' : 'Avoir enregistré', `${note.number} · ${money(note.total)}.`);
    });
    renderCreditNoteDraftLines();
  }
  function applyCreditNoteStock(note) {
    if (!note || note.stockApplied || !note.restock) { if (note && !note.restock) note.stockApplied = true; return true; }
    for (const line of note.lines || []) if (!productById(line.productId) || !state.stores.some((store) => store.id === line.storeId)) return false;
    (note.lines || []).forEach((line) => changeStock(line.productId, line.storeId, num(line.quantity)));
    note.stockApplied = true;
    return true;
  }
  function validateCreditNote(noteId) {
    if (!requirePermission('sales.validate', 'Votre profil ne peut pas valider un avoir.')) return;
    const note = (state.creditNotes || []).find((item) => item.id === noteId);
    if (!note || note.status !== 'En cours') return;
    if (!applyCreditNoteStock(note)) { toast('Validation impossible', 'Le produit ou le magasin de retour est invalide.', 'error'); return; }
    const previousAdvance = num(((state.clients || []).find((item) => item.id === note.clientId) || {}).advance);
    note.status = 'Validée';
    refreshClientReceivables();
    const overpayment = noteOverpayment(note, previousAdvance);
    addActivity('Ventes', 'Validation d’un avoir', note.number, `${note.originalSaleNumber} · ${money(note.total)}`, 'En cours', 'Validée');
    saveState(); render(); if (overpayment > 0) openOverpaymentChoiceModal(note, overpayment); else toast('Avoir validé', `${note.number} · les montants et le stock ont été corrigés.`);
  }
  function openRefundModal(noteId, presetAmount = 0) {
    if (!requirePermission('sales.reverse', 'Votre profil ne peut pas rembourser un avoir.')) return;
    const note = (state.creditNotes || []).find((item) => item.id === noteId);
    if (!note || note.status !== 'Validée') { toast('Remboursement impossible', 'Seul un avoir validé peut être remboursé.', 'error'); return; }
    refreshClientReceivables();
    const max = noteRefundableMax(note);
    if (!(max > 0)) { toast('Remboursement impossible', noteBelongsToCredit(note) ? 'Aucune avance disponible à rembourser pour ce client.' : 'Cet avoir est déjà intégralement remboursé.', 'warning'); return; }
    const suggested = Math.min(max, Math.max(0, num(presetAmount)) || max);
    const refunded = creditNoteRefunded(note.id);
    const body = `<form id="refund-form"><div class="notice info"><span>₣</span><div><strong>${esc(note.number)} · ${money(creditNoteTotal(note))}</strong><span>Déjà remboursé : ${money(refunded)} · Remboursable : ${money(max)}${noteBelongsToCredit(note) ? ' (limité à l’avance du client)' : ''}</span></div></div><div class="form-grid"><div class="field"><label>Date du remboursement <em>*</em></label><input class="input-control" type="date" name="date" value="${todayKey()}" required></div><div class="field"><label>Montant remboursé <em>*</em></label><input class="input-control" type="number" name="amount" min="1" max="${max}" step="1" value="${suggested}" required></div><div class="field"><label>Mode de remboursement</label><select class="select-control" name="method"><option value="cash">Cash</option><option value="mobile">Mobile Money</option><option value="card">Carte</option><option value="cheque">Chèque</option></select></div><div class="field"><label>Référence</label><input class="input-control" name="reference" placeholder="N° transaction, chèque…"></div><div class="field full"><label>Note</label><textarea class="textarea-control" name="note" placeholder="Observation facultative"></textarea></div></div><div class="notice warning" style="margin-top:14px;margin-bottom:0"><span>!</span><div><strong>Sortie tracée, non comptée en charges</strong><span>La marge a déjà été corrigée par l’avoir : ce remboursement trace la sortie sans toucher les dépenses.</span></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">Enregistrer le remboursement</button></div></form>`;
    openModal(`Remboursement · ${esc(note.number)}`, 'La sortie est liée à l’avoir et historisée.', body);
    document.getElementById('refund-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(event.currentTarget).entries());
      refreshClientReceivables();
      const amount = Math.max(0, num(data.amount));
      const validation = refundValidation(note, amount);
      if (!validation.ok) { toast('Remboursement impossible', validation.error, 'error'); return; }
      const item = { id: uid('refund'), number: nextNumber('REM', state.refunds), date: data.date, noteId: note.id, noteNumber: note.number, notePayment: note.payment, clientId: note.clientId, amount, method: data.method, reference: String(data.reference || '').trim(), note: String(data.note || '').trim(), status: 'Validée', userId: currentUserId(), createdAt: new Date().toISOString() };
      state.refunds.unshift(item);
      refreshClientReceivables();
      addActivity('Ventes', 'Remboursement d’un avoir', item.number, `${note.number} · ${money(amount)} · ${paymentLabel(item.method)}`);
      saveState(); closeModal(); render();
      toast('Remboursement enregistré', `${item.number} · ${money(amount)}.`);
      showCreditNoteDetail(note);
    });
  }
  function openOverpaymentChoiceModal(note, excess) {
    const client = (state.clients || []).find((item) => item.id === note.clientId);
    const body = `<div class="notice warning"><span>!</span><div><strong>Trop-perçu de ${money(excess)}</strong><span>Les règlements de ${esc(client?.name || 'ce client')} dépassent le net de ses ventes : l’excédent est enregistré en avance client.</span></div></div><div class="detail-grid" style="margin-top:14px"><div class="detail-item"><label>Avoir</label><strong>${esc(note.number)}</strong></div><div class="detail-item"><label>Encours après avoir</label><strong>${money(num(client?.receivable))}</strong></div><div class="detail-item"><label>Avance disponible</label><strong>${money(num(client?.advance))}</strong></div></div>`;
    const footer = `<button class="btn btn-secondary" type="button" data-close-modal>Garder en avance</button><button class="btn btn-primary" type="button" data-action="refund-credit-note" data-id="${esc(note.id)}" data-amount="${excess}">Rembourser ${money(excess)}</button>`;
    openModal('Trop-perçu détecté', 'Choisissez le traitement de l’excédent.', body, 'sm', footer);
  }
  function showCreditNoteDetail(note) {
    if (!note) return;
    refreshClientReceivables();
    const noteRefunds = validRefunds().filter((refund) => refund.noteId === note.id);
    const refundedTotal = noteRefunds.reduce((sum, refund) => sum + num(refund.amount), 0);
    const refundSection = `<div class="form-section-title" style="margin-top:20px">Remboursements</div>${noteRefunds.length ? `<div class="table-wrap"><table class="data-table" style="min-width:0"><thead><tr><th>Référence</th><th>Date</th><th>Montant</th><th>Mode</th><th>Référence</th></tr></thead><tbody>${noteRefunds.map((refund) => `<tr><td><strong>${esc(refund.number)}</strong></td><td>${shortDate(refund.date)}</td><td><strong>${money(refund.amount)}</strong></td><td>${esc(paymentLabel(refund.method))}</td><td>${esc(refund.reference || '—')}</td></tr>`).join('')}</tbody></table></div><div class="summary-total" style="margin-top:15px"><span>Remboursé</span><strong>${money(refundedTotal)} / ${money(creditNoteTotal(note))}</strong></div>` : `<div class="notice" style="margin-top:12px;margin-bottom:0"><span>₣</span><div><strong>Aucun remboursement enregistré</strong><span>Depuis un avoir validé, utilisez « Rembourser » pour tracer une sortie.</span></div></div>`}`;
    const rows = (note.lines || []).map((line) => `<tr><td>${esc(productName(line.productId))}</td><td>${number(line.quantity)}</td><td>${money(line.unitPrice)}</td><td>${money(num(line.quantity) * num(line.unitPrice))}</td></tr>`).join('');
    const body = `<div class="detail-grid"><div class="detail-item"><label>Référence</label><strong>${esc(note.number)}</strong></div><div class="detail-item"><label>Vente d’origine</label><strong>${esc(note.originalSaleNumber)}</strong></div><div class="detail-item"><label>Client</label><strong>${esc(clientName(note.clientId))}</strong></div><div class="detail-item"><label>Statut</label><strong>${esc(note.status)}</strong></div><div class="detail-item"><label>Nature</label><strong>${esc(note.type)}</strong></div><div class="detail-item"><label>Retour au stock</label><strong>${note.restock ? 'Oui' : 'Non'}</strong></div></div><div class="notice ${note.status === 'Validée' ? 'success' : 'warning'}" style="margin-top:14px"><span>${note.status === 'Validée' ? '✓' : '!'}</span><div><strong>${note.status === 'Validée' ? 'Correction appliquée' : 'Correction en attente de validation'}</strong><span>${esc(note.reason)}</span></div></div><div class="table-wrap"><table class="data-table" style="min-width:0"><thead><tr><th>Produit</th><th>Qté</th><th>Prix unitaire</th><th>Montant</th></tr></thead><tbody>${rows}</tbody></table></div><div class="summary-total" style="margin-top:15px"><span>Total de l’avoir</span><strong>${money(creditNoteTotal(note))}</strong></div>${refundSection}`;
    const footer = `<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>${note.status === 'En cours' ? `<button class="btn btn-primary" type="button" data-action="validate-credit-note" data-id="${esc(note.id)}">✓ Valider la correction</button>` : ''}`;
    openModal(`Avoir ${esc(note.number)}`, 'Une correction historisée, liée à la vente d’origine.', body, 'lg', footer + (note.status === 'Validée' && noteRefundableMax(note) > 0 ? `<button class="btn btn-dark" type="button" data-action="refund-credit-note" data-id="${esc(note.id)}">₣ Rembourser</button>` : ''));
  }
  function renderCreditNotes() {
    const notes = periodItems(state.creditNotes || []).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const pending = notes.filter((note) => note.status === 'En cours').length;
    const rows = notes.map((note) => `<tr data-filter-row data-text="${esc(`${note.number} ${note.originalSaleNumber} ${clientName(note.clientId)} ${note.type} ${note.reason} ${note.status}`.toLowerCase())}"><td><strong>${esc(note.number)}</strong><span class="table-secondary">${dateTime(note.date)}</span></td><td>${esc(note.originalSaleNumber)}</td><td>${esc(clientName(note.clientId))}</td><td>${esc(note.type)}</td><td><strong>${money(creditNoteTotal(note))}</strong><span class="table-secondary">${note.restock ? 'Retour stock' : 'Sans retour stock'}</span>${creditNoteRefunded(note.id) > 0 ? `<span class="table-secondary">remboursé ${money(creditNoteRefunded(note.id))}</span>` : ''}</td><td>${statusBadge(note.status)}</td><td><div class="table-actions">${note.status === 'En cours' ? `<button class="table-action" type="button" data-action="validate-credit-note" data-id="${esc(note.id)}" title="Valider">✓</button>` : ''}<button class="table-action" type="button" data-action="view-credit-note" data-id="${esc(note.id)}" title="Détail">✎</button></div></td></tr>`).join('');
    return `${pageHeading('Avoirs & annulations', 'Corrigez une vente par une nouvelle opération liée et historisée.', `<button class="btn btn-secondary" type="button" data-action="export-credit-notes">⇩ Exporter</button><button class="btn btn-secondary" type="button" data-action="export-refunds">⇩ Remboursements</button><button class="btn btn-secondary" type="button" data-view="sales">Historique des ventes →</button>`)}<div class="notice ${pending ? 'warning' : 'info'}"><span>ⓘ</span><div><strong>${pending ? `${pending} correction(s) en attente de validation` : 'Les ventes restent immuables'}</strong><span>Un avoir ou une annulation ne modifie jamais la vente d’origine : il crée une opération indépendante avec son motif, ses lignes et son utilisateur.</span></div></div><section class="panel">${toolbar('Référence, vente, client ou motif...', '#credit-notes-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button><select class="select-control" data-table-filter="status"><option value="">Tous les statuts</option><option value="En cours">En cours</option><option value="Validée">Validée</option></select>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Avoir</th><th>Vente d’origine</th><th>Client</th><th>Nature</th><th>Montant</th><th>Statut</th><th></th></tr></thead><tbody id="credit-notes-table-body">${rows ? pagedTbody('credit-notes-table-body', rows) : `<tr><td colspan="7">${emptyTable('Aucun avoir ou annulation')}</td></tr>`}</tbody></table></div><div class="table-footer"><span>${number(notes.length)} correction(s) · ${number(pending)} en attente</span></div></section>`;
  }

  function renderTransferDraftLines() {
    const container = $('#transfer-lines');
    const countNode = $('#transfer-count');
    const submit = $('#transfer-form button[type="submit"]');
    if (!container) return;
    container.innerHTML = transferDraftLines.length ? transferDraftLines.map((line, index) => `<div class="order-line-row"><div class="order-line-number">${String(index + 1).padStart(2, '0')}</div><div class="order-line-product"><strong>${esc(productName(line.productId))}</strong><span>${esc(storeName(line.sourceStoreId))} → ${esc(storeName(line.destinationStoreId))} · disponible : ${number(stockFor(line.productId, line.sourceStoreId))}</span></div><div class="order-line-field"><label>Quantité</label><input class="input-control" type="number" min="1" value="${number(line.quantity)}" data-transfer-line-field="quantity" data-index="${index}"></div><button class="table-action danger" type="button" data-action="remove-transfer-line" data-id="${index}" title="Retirer la ligne">×</button></div>`).join('') : emptyState('Aucune ligne de transfert', 'Sélectionnez un produit et une quantité à déplacer.');
    if (countNode) countNode.textContent = `${number(transferDraftLines.length)} ligne(s) · ${number(transferDraftLines.reduce((sum, line) => sum + num(line.quantity), 0))} unité(s)`;
    if (submit) submit.disabled = transferDraftLines.length === 0;
  }
  function addTransferLineFromForm() {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour créer un transfert.', 'warning'); return; }
    const productId = $('#transfer-line-product')?.value;
    const sourceStoreId = $('#transfer-source-store')?.value;
    const destinationStoreId = $('#transfer-destination-store')?.value;
    const quantity = Math.max(1, Math.floor(num($('#transfer-line-quantity')?.value)));
    const product = productById(productId);
    if (!product || !sourceStoreId || !destinationStoreId) { toast('Ligne incomplète', 'Sélectionnez le produit, le magasin source et le magasin destination.', 'warning'); return; }
    if (sourceStoreId === destinationStoreId) { toast('Magasins identiques', 'Le magasin source et le magasin destination doivent être différents.', 'error'); return; }
    const existing = transferDraftLines.find((line) => line.productId === productId);
    if (existing) existing.quantity += quantity;
    else transferDraftLines.push({ productId, sourceStoreId, destinationStoreId, quantity, unitPrice: num(product.purchasePrice) });
    $('#transfer-line-product').value = '';
    $('#transfer-line-quantity').value = 1;
    renderTransferDraftLines();
    toast('Ligne ajoutée', `${product.name} · ${number(quantity)} unité(s).`);
  }
  function updateTransferLine(index, value) {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier un transfert.', 'warning'); renderTransferDraftLines(); return; }
    const line = transferDraftLines[num(index)];
    if (!line) return;
    line.quantity = Math.max(1, Math.floor(num(value)));
    renderTransferDraftLines();
  }
  function openTransferModal(transferId = '') {
    const transfer = transferId ? (state.stockTransfers || []).find((item) => item.id === transferId) : null;
    const t = transfer || { date: todayKey(), sourceStoreId: state.stores[0]?.id || '', destinationStoreId: state.stores[1]?.id || '', note: '', status: 'En cours' };
    transferDraftLines = (transfer?.lines || []).map((line) => ({ ...line, quantity: Math.max(1, num(line.quantity)), sourceStoreId: transfer.sourceStoreId, destinationStoreId: transfer.destinationStoreId }));
    const body = `<form id="transfer-form"><div class="notice info"><span>⇄</span><div><strong>Transfert dédié et équilibré</strong><span>Une validation diminue le magasin source et augmente le magasin destination une seule fois. Un transfert « En cours » ne modifie pas le stock.</span></div></div><div class="form-grid"><div class="field"><label>Date du transfert <em>*</em></label><input class="input-control" type="date" name="date" value="${esc((t.date || '').slice(0, 10))}" required></div><div class="field"><label>Magasin source <em>*</em></label><select class="select-control" name="sourceStoreId" id="transfer-source-store" required>${options(state.stores.filter((store) => store.active !== false), t.sourceStoreId, 'name', null)}</select></div><div class="field"><label>Magasin destination <em>*</em></label><select class="select-control" name="destinationStoreId" id="transfer-destination-store" required>${options(state.stores.filter((store) => store.active !== false), t.destinationStoreId, 'name', null)}</select></div><div class="field"><label>Statut</label><select class="select-control" name="status"><option ${t.status === 'En cours' ? 'selected' : ''}>En cours</option><option ${t.status === 'Validé' ? 'selected' : ''}>Validé</option></select></div><div class="field full"><label>Motif / note</label><input class="input-control" name="note" value="${esc(t.note || '')}" placeholder="Rééquilibrage, approvisionnement du point de vente…"></div></div><div class="form-section-title" style="margin-top:20px">Ajouter des produits</div><div class="order-line-adder"><div class="field"><label>Produit <em>*</em></label><select class="select-control" id="transfer-line-product"><option value="">Sélectionner un produit</option>${activeProducts().map((product) => `<option value="${esc(product.id)}">${esc(product.code)} · ${esc(product.name)}</option>`).join('')}</select></div><div class="field"><label>Quantité <em>*</em></label><input class="input-control" id="transfer-line-quantity" type="number" min="1" value="1"></div><button class="btn btn-primary btn-sm" type="button" data-action="add-transfer-line">＋ Ajouter le produit</button></div><div class="order-cart"><div class="order-cart-header"><div><strong>Lignes du transfert</strong><span id="transfer-count">0 ligne(s) · 0 unité(s)</span></div></div><div id="transfer-lines"></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit" disabled>${transfer ? 'Enregistrer le transfert' : 'Créer le transfert'}</button></div></form>`;
    openModal(transfer ? 'Modifier le transfert' : 'Nouveau transfert inter-magasins', 'Déplacez plusieurs références entre deux magasins sans créer une fausse entrée ou sortie.', body, 'lg');
    $('#transfer-form').addEventListener('submit', (event) => {
      event.preventDefault();
      if (!transferDraftLines.length) { toast('Transfert vide', 'Ajoutez au moins une ligne avant de valider.', 'warning'); return; }
      const data = Object.fromEntries(new FormData(event.currentTarget).entries());
      if (data.sourceStoreId === data.destinationStoreId) { toast('Magasins identiques', 'Choisissez deux magasins différents.', 'error'); return; }
      const lines = transferDraftLines.map((line) => ({ productId: line.productId, quantity: Math.max(1, Math.floor(num(line.quantity))), unitPrice: num(line.unitPrice) }));
      if (data.status === 'Validé' && !state.settings.allowNegative && lines.some((line) => stockFor(line.productId, data.sourceStoreId) < line.quantity)) { toast('Stock insuffisant', 'Le magasin source ne possède pas les quantités nécessaires pour ce transfert.', 'error'); return; }
      const item = { id: transfer?.id || uid('transfer'), number: transfer?.number || nextNumber('TRF', state.stockTransfers), date: data.date, sourceStoreId: data.sourceStoreId, destinationStoreId: data.destinationStoreId, lines, note: String(data.note || '').trim(), status: data.status === 'Validé' ? 'Validé' : 'En cours', stockApplied: false, userId: transfer?.userId || currentUserId(), createdAt: transfer?.createdAt || new Date().toISOString() };
      if (item.status === 'Validé' && !applyTransferStock(item)) { toast('Transfert impossible', 'Le stock source est insuffisant ou un magasin est invalide.', 'error'); return; }
      if (transfer) state.stockTransfers[state.stockTransfers.findIndex((x) => x.id === transfer.id)] = item; else state.stockTransfers.unshift(item);
      addActivity('Stocks', item.status === 'Validé' ? 'Validation d’un transfert' : 'Création d’un transfert', item.number, `${storeName(item.sourceStoreId)} → ${storeName(item.destinationStoreId)} · ${number(item.lines.length)} ligne(s)`, transfer?.status || '', item.status);
      saveState(); closeModal(); transferDraftLines = []; render(); toast(item.status === 'Validé' ? 'Transfert validé' : 'Transfert enregistré', `${item.number} · stock déplacé une seule fois.`);
    });
    renderTransferDraftLines();
  }
  function applyTransferStock(transfer) {
    if (!transfer || transfer.stockApplied) return !!transfer?.stockApplied;
    if (!state.stores.some((store) => store.id === transfer.sourceStoreId) || !state.stores.some((store) => store.id === transfer.destinationStoreId)) return false;
    if (!state.settings.allowNegative && (transfer.lines || []).some((line) => stockFor(line.productId, transfer.sourceStoreId) < num(line.quantity))) return false;
    (transfer.lines || []).forEach((line) => { changeStock(line.productId, transfer.sourceStoreId, -num(line.quantity)); changeStock(line.productId, transfer.destinationStoreId, num(line.quantity)); });
    transfer.stockApplied = true;
    return true;
  }
  function validateTransfer(transferId) {
    if (!requirePermission('stock.validate', 'Votre profil ne peut pas valider un transfert.')) return;
    const transfer = (state.stockTransfers || []).find((item) => item.id === transferId);
    if (!transfer || transfer.status !== 'En cours') return;
    if (!applyTransferStock(transfer)) { toast('Transfert impossible', 'Le stock source est insuffisant ou un magasin est invalide.', 'error'); return; }
    transfer.status = 'Validé';
    addActivity('Stocks', 'Validation d’un transfert', transfer.number, `${storeName(transfer.sourceStoreId)} → ${storeName(transfer.destinationStoreId)}`, 'En cours', 'Validé');
    saveState(); render(); toast('Transfert validé', `${transfer.number} · les deux stocks ont été mis à jour.`);
  }
  function showTransferDetail(transfer) {
    if (!transfer) return;
    const rows = (transfer.lines || []).map((line) => `<tr><td>${esc(productName(line.productId))}</td><td>${number(line.quantity)}</td><td>${money(num(line.quantity) * num(line.unitPrice))}</td></tr>`).join('');
    const body = `<div class="detail-grid"><div class="detail-item"><label>Référence</label><strong>${esc(transfer.number)}</strong></div><div class="detail-item"><label>Date</label><strong>${dateTime(transfer.date)}</strong></div><div class="detail-item"><label>Source</label><strong>${esc(storeName(transfer.sourceStoreId))}</strong></div><div class="detail-item"><label>Destination</label><strong>${esc(storeName(transfer.destinationStoreId))}</strong></div><div class="detail-item"><label>Statut</label><strong>${esc(transfer.status)}</strong></div><div class="detail-item"><label>Motif</label><strong>${esc(transfer.note || '—')}</strong></div></div><div class="notice ${transfer.status === 'Validé' ? 'success' : 'warning'}" style="margin-top:14px"><span>${transfer.status === 'Validé' ? '✓' : '!'}</span><div><strong>${transfer.status === 'Validé' ? 'Stock déplacé une fois' : 'Aucun impact stock'}</strong><span>Le transfert reste historisé comme une opération distincte.</span></div></div><div class="table-wrap"><table class="data-table" style="min-width:0"><thead><tr><th>Produit</th><th>Quantité</th><th>Valeur</th></tr></thead><tbody>${rows}</tbody></table></div>`;
    const footer = `<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>${transfer.status === 'En cours' ? `<button class="btn btn-primary" type="button" data-action="validate-transfer" data-id="${esc(transfer.id)}">✓ Valider le transfert</button>` : ''}`;
    openModal(`Transfert ${esc(transfer.number)}`, 'Déplacement entre deux magasins.', body, 'lg', footer);
  }
  function renderTransfers() {
    const transfers = periodItems(state.stockTransfers || []).slice().sort((a, b) => localDate(b.date) - localDate(a.date));
    const pending = transfers.filter((transfer) => transfer.status === 'En cours').length;
    const rows = transfers.map((transfer) => `<tr data-filter-row data-text="${esc(`${transfer.number} ${storeName(transfer.sourceStoreId)} ${storeName(transfer.destinationStoreId)} ${transfer.note} ${transfer.status}`.toLowerCase())}"><td><strong>${esc(transfer.number)}</strong><span class="table-secondary">${dateTime(transfer.date)}</span></td><td>${esc(storeName(transfer.sourceStoreId))}</td><td>${esc(storeName(transfer.destinationStoreId))}</td><td>${number((transfer.lines || []).length)} ligne(s)<span class="table-secondary">${number((transfer.lines || []).reduce((sum, line) => sum + num(line.quantity), 0))} unité(s)</span></td><td>${statusBadge(transfer.status)}</td><td><div class="table-actions">${transfer.status === 'En cours' ? `<button class="table-action" type="button" data-action="validate-transfer" data-id="${esc(transfer.id)}" title="Valider">✓</button><button class="table-action" type="button" data-action="edit-transfer" data-id="${esc(transfer.id)}" title="Modifier">✎</button>` : `<button class="table-action" type="button" data-action="view-transfer" data-id="${esc(transfer.id)}" title="Détail">✎</button>`}</div></td></tr>`).join('');
    return `${pageHeading('Transferts inter-magasins', 'Déplacez les stocks entre magasins avec une opération dédiée, équilibrée et historisée.', `<button class="btn btn-secondary" type="button" data-action="export-transfers">⇩ Exporter</button><button class="btn btn-primary" type="button" data-action="add-transfer">＋ Nouveau transfert</button>`)}<div class="notice ${pending ? 'warning' : 'success'}"><span>⇄</span><div><strong>${pending ? `${pending} transfert(s) en attente de validation` : 'Stocks inter-magasins équilibrés'}</strong><span>Le stock source diminue et le stock destination augmente uniquement à la validation. Les deux magasins sont enregistrés sur la même opération.</span></div></div><section class="panel">${toolbar('Référence, magasin ou motif...', '#transfers-table-body', '<button class="btn btn-secondary btn-sm" type="button" data-action="show-date-filter">◷ Période</button><select class="select-control" data-table-filter="status"><option value="">Tous les statuts</option><option value="En cours">En cours</option><option value="Validé">Validé</option></select>')}<div class="table-wrap"><table class="data-table"><thead><tr><th>Référence</th><th>Source</th><th>Destination</th><th>Lignes / quantités</th><th>Statut</th><th></th></tr></thead><tbody id="transfers-table-body">${rows ? pagedTbody('transfers-table-body', rows) : `<tr><td colspan="6">${emptyTable('Aucun transfert inter-magasins')}</td></tr>`}</tbody></table></div><div class="table-footer"><span>${number(transfers.length)} transfert(s) · ${number(pending)} en attente</span></div></section>`;
  }
  function createReverseMovement(item, type) {
    if (!item || item.status !== 'Validé') return;
    if (!requirePermission('stock.create', 'Votre profil ne peut pas créer un mouvement inverse.')) return;
    const reason = `Correction du mouvement ${item.number}`;
    if (type === 'entry') openExitModal('', { date: todayKey(), type: 'Mouvement inverse', beneficiary: reason, storeId: item.storeId, productId: item.productId, quantity: item.quantity, unitPrice: item.unitPrice, status: 'En cours', reversalOf: item.number, correctionReason: reason });
    else openEntryModal('', { date: todayKey(), type: 'Mouvement inverse', supplierId: '', invoice: reason, storeId: item.storeId, productId: item.productId, quantity: item.quantity, unitPrice: item.unitPrice, status: 'En cours', reversalOf: item.number, correctionReason: reason });
  }

  function openEntryModal(entryId = '', defaults = null) {
    const entry = entryId ? state.stockEntries.find((item) => item.id === entryId) : null;
    const e = entry || defaults || { date: todayKey(), type: 'Achat', supplierId: '', invoice: '', storeId: state.stores[0]?.id || '', productId: '', quantity: 1, unitPrice: 0, status: 'En cours', reversalOf: '', correctionReason: '' };
    const body = `<form id="entry-form"><div class="form-grid"><div class="field"><label>Date de l’entrée <em>*</em></label><input class="input-control" type="date" name="date" value="${esc((e.date || '').slice(0, 10))}" required></div><div class="field"><label>Type</label><select class="select-control" name="type"><option ${e.type === 'Achat' ? 'selected' : ''}>Achat</option><option ${e.type === 'Retour produit' ? 'selected' : ''}>Retour produit</option><option ${e.type === 'Mouvement inverse' ? 'selected' : ''}>Mouvement inverse</option></select></div><div class="field"><label>Fournisseur</label><select class="select-control" name="supplierId">${options(state.suppliers.filter((s) => s.active !== false), e.supplierId)}</select></div><div class="field"><label>Référence de facture</label><input class="input-control" name="invoice" value="${esc(e.invoice)}"></div><div class="field"><label>Magasin concerné</label><select class="select-control" name="storeId" required>${options(state.stores.filter((s) => s.active !== false), e.storeId)}</select></div><div class="field"><label>Produit <em>*</em></label><select class="select-control" name="productId" required>${options(activeProducts(), e.productId)}</select></div><div class="field"><label>Quantité <em>*</em></label><input class="input-control" type="number" name="quantity" value="${num(e.quantity)}" min="1" required></div><div class="field"><label>Prix unitaire <em>*</em></label><input class="input-control" type="number" name="unitPrice" value="${num(e.unitPrice)}" min="0" required></div><div class="field"><label>Statut</label><select class="select-control" name="status"><option ${e.status === 'En cours' ? 'selected' : ''}>En cours</option><option ${e.status === 'Validé' ? 'selected' : ''}>Validé</option></select></div><div class="field full"><label>Motif / référence de correction</label><input class="input-control" name="correctionReason" value="${esc(e.correctionReason || '')}" placeholder="Facultatif, obligatoire pour un mouvement inverse"><input type="hidden" name="reversalOf" value="${esc(e.reversalOf || '')}"></div></div><div class="notice warning" style="margin-top:14px;margin-bottom:0"><span>!</span><div><strong>Règle d’incrémentation</strong><span>Seule la transition vers « Validé » ajoute la quantité au stock. Une entrée déjà validée ne sera jamais ajoutée deux fois.</span></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${entry ? 'Enregistrer l’entrée' : 'Créer l’entrée'}</button></div></form>`;
    openModal(entry ? 'Modifier l’entrée de stock' : 'Nouvelle entrée de stock', 'Achat ou retour de produit.', body);
    $('#entry-form').addEventListener('submit', (event) => submitEntry(event, entry));
  }
  function submitEntry(event, existing) {
    event.preventDefault();
    if (!requirePermission('stock.create', 'Votre profil ne peut pas créer ou modifier une entrée.')) return;
    const data = Object.fromEntries(new FormData(event.currentTarget).entries());
    if (existing && (existing.status === 'Validé' || existing.stockApplied)) {
      toast('Modification bloquée', 'Une entrée validée est immuable. Créez une correction ou un mouvement inverse.', 'error');
      return;
    }
    const product = productById(data.productId);
    const store = state.stores.find((item) => item.id === data.storeId && item.active !== false);
    if (!product || !store) { toast('Mouvement incomplet', 'Sélectionnez un produit et un magasin actifs.', 'error'); return; }
    const quantity = Math.max(1, num(data.quantity));
    const status = data.status === 'Validé' ? 'Validé' : 'En cours';
    if (data.type === 'Mouvement inverse' && !String(data.reversalOf || '').trim()) { toast('Référence manquante', 'Un mouvement inverse doit être lié à une opération d’origine.', 'error'); return; }
    const item = { id: existing?.id || uid('entry'), number: existing?.number || nextNumber('ENT', state.stockEntries), date: data.date, type: data.type, supplierId: data.supplierId, invoice: data.invoice.trim(), storeId: data.storeId, productId: data.productId, quantity, unitPrice: num(data.unitPrice), total: quantity * num(data.unitPrice), status, stockApplied: false, reversalOf: String(data.reversalOf || '').trim(), correctionReason: String(data.correctionReason || '').trim(), userId: existing?.userId || currentUserId() };
    if (status === 'Validé' && !applyEntryStock(item)) { toast('Entrée impossible', 'Le produit ou le magasin est invalide.', 'error'); return; }
    if (existing) state.stockEntries[state.stockEntries.findIndex((x) => x.id === existing.id)] = item; else state.stockEntries.unshift(item);
    addActivity('Stocks', status === 'Validé' ? 'Validation d’une entrée' : 'Création d’une entrée', item.number, `${number(item.quantity)} unités · ${store.name}`, existing?.status || '', item.status);
    saveState(); closeModal(); render(); toast(status === 'Validé' ? 'Entrée validée' : 'Entrée enregistrée', `${item.number} · ${number(item.quantity)} unité(s) dans ${store.name}.`);
  }
  function applyEntryStock(entry) {
    if (!entry || entry.stockApplied) return !!entry?.stockApplied;
    const product = productById(entry.productId);
    if (!product || !state.stores.some((store) => store.id === entry.storeId)) return false;
    changeStock(product, entry.storeId, num(entry.quantity));
    entry.stockApplied = true;
    return true;
  }
  function validateEntry(entryId) {
    if (!requirePermission('stock.validate', 'Votre profil ne peut pas valider une entrée.')) return;
    const entry = state.stockEntries.find((item) => item.id === entryId);
    if (!entry || entry.status !== 'En cours') return;
    if (!applyEntryStock(entry)) { toast('Entrée impossible', 'Le produit ou le magasin est invalide.', 'error'); return; }
    entry.status = 'Validé';
    addActivity('Stocks', 'Validation d’une entrée', entry.number, `${number(entry.quantity)} unités · ${storeName(entry.storeId)}`, 'En cours', 'Validé');
    saveState(); render(); toast('Entrée validée', `${productName(entry.productId)} · stock augmenté dans ${storeName(entry.storeId)}.`);
  }

  function openExitModal(exitId = '', defaults = null) {
    const exit = exitId ? state.stockExits.find((item) => item.id === exitId) : null;
    const e = exit || defaults || { date: todayKey(), type: 'Don', beneficiary: '', storeId: state.stores[0]?.id || '', productId: '', quantity: 1, unitPrice: 0, status: 'En cours', reversalOf: '', correctionReason: '' };
    const body = `<form id="exit-form"><div class="form-grid"><div class="field"><label>Date de sortie <em>*</em></label><input class="input-control" type="date" name="date" value="${esc((e.date || '').slice(0, 10))}" required></div><div class="field"><label>Type</label><select class="select-control" name="type">${['Vente','Don','Perte','Vol','Mouvement inverse'].map((x) => `<option ${e.type === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div class="field"><label>Bénéficiaire</label><input class="input-control" name="beneficiary" value="${esc(e.beneficiary)}"></div><div class="field"><label>Magasin concerné</label><select class="select-control" name="storeId">${options(state.stores.filter((s) => s.active !== false), e.storeId)}</select></div><div class="field"><label>Produit <em>*</em></label><select class="select-control" name="productId" required>${options(activeProducts(), e.productId)}</select></div><div class="field"><label>Quantité <em>*</em></label><input class="input-control" type="number" name="quantity" value="${num(e.quantity)}" min="1" required></div><div class="field"><label>Prix unitaire</label><input class="input-control" type="number" name="unitPrice" value="${num(e.unitPrice)}" min="0"></div><div class="field"><label>Statut</label><select class="select-control" name="status"><option ${e.status === 'En cours' ? 'selected' : ''}>En cours</option><option ${e.status === 'Validé' ? 'selected' : ''}>Validé</option></select></div><div class="field full"><label>Motif / référence de correction</label><input class="input-control" name="correctionReason" value="${esc(e.correctionReason || '')}" placeholder="Facultatif, obligatoire pour un mouvement inverse"><input type="hidden" name="reversalOf" value="${esc(e.reversalOf || '')}"></div></div><div class="notice info" style="margin-top:14px;margin-bottom:0"><span>ⓘ</span><div><strong>Stock négatif interdit</strong><span>La validation sera refusée si la quantité dépasse le stock disponible, sauf autorisation dans les paramètres.</span></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${exit ? 'Enregistrer la sortie' : 'Créer la sortie'}</button></div></form>`;
    openModal(exit ? 'Modifier la sortie de stock' : 'Nouvelle sortie de stock', 'Don, perte, vol ou autre mouvement.', body);
    $('#exit-form').addEventListener('submit', (event) => submitExit(event, exit));
  }
  function submitExit(event, existing) {
    event.preventDefault();
    if (!requirePermission('stock.create', 'Votre profil ne peut pas créer ou modifier une sortie.')) return;
    const data = Object.fromEntries(new FormData(event.currentTarget).entries());
    if (existing && (existing.status === 'Validé' || existing.stockApplied)) {
      toast('Modification bloquée', 'Une sortie validée est immuable. Créez une correction ou un mouvement inverse.', 'error');
      return;
    }
    const quantity = Math.max(1, num(data.quantity));
    const product = productById(data.productId);
    const store = state.stores.find((item) => item.id === data.storeId && item.active !== false);
    const status = data.status === 'Validé' ? 'Validé' : 'En cours';
    if (!product || !store) { toast('Mouvement incomplet', 'Sélectionnez un produit et un magasin actifs.', 'error'); return; }
    if (status === 'Validé' && !state.settings.allowNegative && stockFor(product, data.storeId) < quantity) { toast('Stock insuffisant', `${product.name} · ${number(stockFor(product, data.storeId))} unité(s) disponible(s) dans ${store.name}.`, 'error'); return; }
    if (data.type === 'Mouvement inverse' && !String(data.reversalOf || '').trim()) { toast('Référence manquante', 'Un mouvement inverse doit être lié à une opération d’origine.', 'error'); return; }
    const item = { id: existing?.id || uid('exit'), number: existing?.number || nextNumber('SOR', state.stockExits), date: data.date, type: data.type, beneficiary: data.beneficiary.trim(), storeId: data.storeId, productId: data.productId, quantity, unitPrice: num(data.unitPrice), total: quantity * num(data.unitPrice), status, stockApplied: false, reversalOf: String(data.reversalOf || '').trim(), correctionReason: String(data.correctionReason || '').trim(), userId: existing?.userId || currentUserId() };
    if (status === 'Validé' && !applyExitStock(item)) { toast('Sortie impossible', 'Le produit ou le magasin est invalide.', 'error'); return; }
    if (existing) state.stockExits[state.stockExits.findIndex((x) => x.id === existing.id)] = item; else state.stockExits.unshift(item);
    addActivity('Stocks', status === 'Validé' ? 'Validation d’une sortie' : 'Création d’une sortie', item.number, `${number(quantity)} unités · ${store.name}`, existing?.status || '', status);
    saveState(); closeModal(); render(); toast(status === 'Validé' ? 'Sortie validée' : 'Sortie enregistrée', `${item.number} · ${number(quantity)} unité(s) dans ${store.name}.`);
  }
  function applyExitStock(exit) {
    if (!exit || exit.stockApplied) return !!exit?.stockApplied;
    const product = productById(exit.productId);
    if (!product || !state.stores.some((store) => store.id === exit.storeId)) return false;
    changeStock(product, exit.storeId, -num(exit.quantity));
    exit.stockApplied = true;
    return true;
  }
  function validateExit(exitId) {
    if (!requirePermission('stock.validate', 'Votre profil ne peut pas valider une sortie.')) return;
    const exit = state.stockExits.find((item) => item.id === exitId);
    const product = productById(exit?.productId);
    if (!exit || exit.status !== 'En cours') return;
    if (!product || !state.settings.allowNegative && stockFor(product, exit.storeId) < exit.quantity) { toast('Stock insuffisant', `La sortie ne peut pas être validée dans ${storeName(exit.storeId)}.`, 'error'); return; }
    if (!applyExitStock(exit)) { toast('Sortie impossible', 'Le produit ou le magasin est invalide.', 'error'); return; }
    exit.status = 'Validé';
    addActivity('Stocks', 'Validation d’une sortie', exit.number, `${number(exit.quantity)} unités · ${storeName(exit.storeId)}`, 'En cours', 'Validé');
    saveState(); render(); toast('Sortie validée', `${productName(exit.productId)} · stock diminué dans ${storeName(exit.storeId)}.`);
  }

  function receiveOrder(orderId) {
    if (!requirePermission('orders.manage', 'Votre profil ne peut pas gérer les commandes.')) return;
    if (!requirePermission('stock.validate', 'Votre profil ne peut pas valider une réception de stock.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour réceptionner une commande.', 'warning'); return; }
    const order = (state.orders || []).find((item) => item.id === orderId);
    if (!order) { toast('Commande introuvable', 'La commande sélectionnée n’existe plus.', 'error'); return; }
    if (isOrderReceived(order)) { toast('Commande déjà réceptionnée', `${order.number} a déjà alimenté le stock.`, 'warning'); render(); return; }
    const lines = (order.lines || []).map((line) => ({ productId: line.productId, quantity: Math.max(1, Math.floor(num(line.quantity))), unitPrice: Math.max(0, num(line.unitPrice)) }));
    const store = state.stores.find((item) => item.id === order.storeId && item.active !== false);
    const invalidLine = lines.find((line) => !productById(line.productId));
    if (!lines.length) { toast('Commande vide', 'Cette commande ne contient aucune ligne à réceptionner.', 'error'); return; }
    if (!store) { toast('Magasin introuvable', 'Le magasin de la commande n’est plus actif ou n’existe plus.', 'error'); return; }
    if (invalidLine) { toast('Produit introuvable', 'Un produit de la commande n’existe plus dans le catalogue.', 'error'); return; }
    const totalUnits = lines.reduce((sum, line) => sum + num(line.quantity), 0);
    if (!window.confirm(`Réceptionner ${order.number} ? ${number(lines.length)} produit(s), ${number(totalUnits)} unité(s) seront ajoutés au stock de ${store.name}.`)) return;
    const oldStatus = order.status;
    const previousStocks = new Map();
    lines.forEach((line) => {
      const product = productById(line.productId);
      if (!previousStocks.has(product.id)) previousStocks.set(product.id, { stock: product.stock, stockByStore: { ...(product.stockByStore || {}) } });
    });
    const entryPrefix = nextNumber('ENT', state.stockEntries);
    const entries = lines.map((line, index) => ({
      id: uid('entry'),
      number: `${entryPrefix}-${String(index + 1).padStart(2, '0')}`,
      date: todayKey(),
      type: 'Réception de commande',
      supplierId: order.supplierId,
      invoice: order.number,
      storeId: order.storeId,
      productId: line.productId,
      quantity: line.quantity,
      unitPrice: line.unitPrice,
      total: line.quantity * line.unitPrice,
      status: 'Validé',
      stockApplied: false,
      reversalOf: '',
      correctionReason: `Réception de la commande ${order.number}`,
      userId: currentUserId()
    }));
    for (const entry of entries) {
      if (!applyEntryStock(entry)) {
        entries.forEach((item) => { const product = productById(item.productId); const before = previousStocks.get(item.productId); if (product && before) { product.stock = before.stock; product.stockByStore = { ...before.stockByStore }; } });
        toast('Réception impossible', 'Le stock n’a pas pu être mis à jour pour un produit de la commande.', 'error');
        return;
      }
    }
    state.stockEntries.unshift(...entries.slice().reverse());
    order.status = 'Réceptionnée';
    const activityId = uid('act');
    state.activities.unshift({ id: activityId, date: new Date().toISOString(), userId: currentUserId(), module: 'Stocks', action: 'Réception d’une commande', element: order.number, detail: `${number(lines.length)} ligne(s) · ${number(totalUnits)} unité(s) · ${store.name}`, oldValue: oldStatus || '', newValue: 'Réceptionnée' });
    if (!saveState()) {
      const entryIds = new Set(entries.map((entry) => entry.id));
      state.stockEntries = state.stockEntries.filter((entry) => !entryIds.has(entry.id));
      lines.forEach((line) => { const product = productById(line.productId); const before = previousStocks.get(line.productId); if (product && before) { product.stock = before.stock; product.stockByStore = { ...before.stockByStore }; } });
      order.status = oldStatus;
      state.activities = state.activities.filter((activity) => activity.id !== activityId);
      render();
      return;
    }
    render();
    toast('Réception enregistrée', `${order.number} · ${number(totalUnits)} unité(s) ajoutée(s) dans ${store.name}.`);
  }

  function openExpenseModal(expenseId = '') {
    const expense = expenseId ? state.expenses.find((item) => item.id === expenseId) : null;
    const e = expense || { date: todayKey(), label: '', amount: '', authorizedBy: 'Administrateur', executedBy: 'Administrateur', receipt: '', status: 'Validée' };
    const body = `<form id="expense-form"><div class="form-grid"><div class="field"><label>Date de la dépense <em>*</em></label><input class="input-control" type="date" name="date" value="${esc((e.date || '').slice(0, 10))}" required></div><div class="field"><label>Montant <em>*</em></label><input class="input-control" type="number" name="amount" value="${num(e.amount)}" min="0" required></div><div class="field full"><label>Désignation <em>*</em></label><input class="input-control" name="label" value="${esc(e.label)}" required></div><div class="field"><label>Autorisé par</label><input class="input-control" name="authorizedBy" value="${esc(e.authorizedBy)}"></div><div class="field"><label>Exécuté par</label><input class="input-control" name="executedBy" value="${esc(e.executedBy)}"></div><div class="field full"><label>Reçu justificatif</label><input class="input-control" type="file" name="receiptFile" accept="image/*,.pdf"><div class="field-hint">${e.receipt ? 'Un justificatif est déjà associé.' : 'Image ou PDF · facultatif.'}</div></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${expense ? 'Enregistrer' : 'Enregistrer la dépense'}</button></div></form>`;
    openModal(expense ? 'Modifier la dépense' : 'Nouvelle dépense', 'Les dépenses validées alimentent automatiquement la comptabilité.', body);
    $('#expense-form').addEventListener('submit', async (event) => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget).entries()); let receipt = expense?.receipt || ''; const file = event.currentTarget.querySelector('[name="receiptFile"]').files[0]; if (file) { const loadedReceipt = await readFileAsDataURL(file, MAX_RECEIPT_BYTES); if (loadedReceipt) receipt = loadedReceipt; } const item = { id: expense?.id || uid('expense'), number: expense?.number || nextNumber('DEP', state.expenses), date: data.date, label: data.label.trim(), amount: num(data.amount), authorizedBy: data.authorizedBy.trim(), executedBy: data.executedBy.trim(), receipt, status: 'Validée' }; if (expense) state.expenses[state.expenses.findIndex((x) => x.id === expense.id)] = item; else state.expenses.unshift(item); addActivity('Dépenses', expense ? 'Modification d’une dépense' : 'Création d’une dépense', item.number, `${money(item.amount)} · ${item.label}`); saveState(); closeModal(); render(); toast(expense ? 'Dépense mise à jour' : 'Dépense enregistrée', money(item.amount)); });
  }

  function renderOrderDraftLines() {
    const container = $('#order-cart-lines');
    const totalNode = $('#order-cart-total');
    const countNode = $('#order-cart-count');
    const submit = $('#order-form button[type="submit"]');
    if (!container) return;
    container.innerHTML = orderDraftLines.length ? orderDraftLines.map((line, index) => `<div class="order-line-row"><div class="order-line-number">${String(index + 1).padStart(2, '0')}</div><div class="order-line-product"><strong>${esc(productName(line.productId))}</strong><span>${esc(categoryName(productById(line.productId)?.categoryId))} · ${esc(productById(line.productId)?.code || '')}</span></div><div class="order-line-field"><label>Quantité</label><input class="input-control" type="number" min="1" value="${num(line.quantity)}" data-order-line-field="quantity" data-index="${index}"></div><div class="order-line-field"><label>Prix unitaire</label><input class="input-control" type="number" min="0" value="${num(line.unitPrice)}" data-order-line-field="unitPrice" data-index="${index}"></div><strong class="order-line-total">${money(num(line.quantity) * num(line.unitPrice))}</strong><button class="table-action danger" type="button" data-action="remove-order-line" data-id="${index}" title="Retirer la ligne">×</button></div>`).join('') : emptyState('Aucune ligne de commande', 'Sélectionnez un produit, indiquez une quantité puis ajoutez-le au panier.');
    const total = orderDraftLines.reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0);
    if (totalNode) totalNode.textContent = money(total);
    if (countNode) countNode.textContent = `${number(orderDraftLines.length)} ligne${orderDraftLines.length > 1 ? 's' : ''} · ${number(orderDraftLines.reduce((sum, line) => sum + num(line.quantity), 0))} unité(s)`;
    if (submit) submit.disabled = orderDraftLines.length === 0;
  }
  function addOrderLineFromForm() {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier une commande.', 'warning'); return; }
    const productId = $('#order-line-product')?.value;
    const quantity = Math.max(1, Math.floor(num($('#order-line-quantity')?.value)));
    const unitPrice = Math.max(0, num($('#order-line-unit-price')?.value));
    const product = productById(productId);
    if (!product) { toast('Produit requis', 'Sélectionnez un produit avant de l’ajouter.', 'warning'); return; }
    const existing = orderDraftLines.find((line) => line.productId === productId);
    if (existing) { existing.quantity += quantity; existing.unitPrice = unitPrice; }
    else orderDraftLines.push({ productId, quantity, unitPrice });
    $('#order-line-product').value = '';
    $('#order-line-quantity').value = 1;
    $('#order-line-unit-price').value = '';
    renderOrderDraftLines();
    toast('Ligne ajoutée', `${product.name} · ${number(quantity)} unité(s).`);
  }
  function updateOrderLine(index, field, value) {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier une commande.', 'warning'); renderOrderDraftLines(); return; }
    const line = orderDraftLines[num(index)];
    if (!line) return;
    line[field] = field === 'quantity' ? Math.max(1, Math.floor(num(value))) : Math.max(0, num(value));
    renderOrderDraftLines();
  }
  function expressSupplierOf(product) {
    const supplier = state.suppliers.find((item) => item.id === product?.supplierId);
    return supplier && supplier.active !== false ? supplier : null;
  }
  function computeExpressLines(products, sales, analysisDays, coverageDays, storeId) {
    const days = Math.max(1, Math.floor(num(analysisDays)) || 30);
    const coverage = Math.max(1, Math.floor(num(coverageDays)) || 21);
    const since = Date.now() - days * 86400000;
    const soldByProduct = {};
    (sales || []).forEach((sale) => {
      if (sale.status !== 'Validée' || localDate(sale.date).getTime() < since) return;
      (sale.items || []).forEach((item) => { soldByProduct[item.productId] = num(soldByProduct[item.productId]) + num(item.quantity); });
    });
    const rank = { rupture: 0, 'sous-seuil': 1, 'couverture-faible': 2 };
    return (products || [])
      .filter((product) => product && product.active !== false)
      .map((product) => {
        const stock = storeId ? stockFor(product, storeId) : totalStock(product);
        const sold = num(soldByProduct[product.id]);
        const avgDaily = sold / days;
        const minStock = num(product.minStock);
        let reason = '';
        if (stock <= 0) reason = 'rupture';
        else if (stock <= minStock) reason = 'sous-seuil';
        else if (avgDaily > 0 && stock / avgDaily < coverage) reason = 'couverture-faible';
        else return null;
        const suggested = avgDaily > 0
          ? Math.ceil(avgDaily * coverage + minStock - stock)
          : Math.ceil((num(product.maxStock) > 0 ? num(product.maxStock) : minStock * 2) - stock);
        if (suggested <= 0) return null;
        const supplier = expressSupplierOf(product);
        return { productId: product.id, supplierId: supplier?.id || '', stock, sold, avgDaily, coverDays: avgDaily > 0 ? stock / avgDaily : null, suggested, quantity: suggested, unitPrice: num(product.purchasePrice), checked: !!supplier, reason };
      })
      .filter(Boolean)
      .sort((a, b) => rank[a.reason] - rank[b.reason] || (a.coverDays ?? 9999) - (b.coverDays ?? 9999));
  }
  function analyzeExpressOrder() {
    const analysisDays = clamp(Math.floor(num($('#express-analysis-days')?.value)) || 30, 7, 180);
    const coverageDays = clamp(Math.floor(num($('#express-coverage-days')?.value)) || 21, 1, 120);
    const storeId = $('#express-store')?.value || '';
    const lines = computeExpressLines(activeProducts(), state.sales, analysisDays, coverageDays, storeId);
    expressOrderDraft = { analysisDays, coverageDays, storeId, generatedAt: new Date().toISOString(), lines };
    render();
    if (!lines.length) toast('Analyse terminée', 'Aucun besoin de réassort détecté sur cette période.', 'success');
    else {
      const suppliers = new Set(lines.filter((line) => line.supplierId).map((line) => line.supplierId)).size;
      toast('Propositions prêtes', `${number(lines.length)} produit(s) · ${number(suppliers)} fournisseur(s). Validez puis générez les bons.`);
    }
  }
  function updateExpressLine(productId, patch) {
    if (!requirePermission('orders.manage', 'Votre profil ne peut pas préparer une commande.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour préparer une commande.', 'warning'); render(); return; }
    const line = expressOrderDraft?.lines.find((item) => item.productId === productId);
    if (!line) return;
    Object.assign(line, patch);
    render();
  }
  function toggleExpressAll(checked) {
    if (!requirePermission('orders.manage', 'Votre profil ne peut pas préparer une commande.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour préparer une commande.', 'warning'); render(); return; }
    (expressOrderDraft?.lines || []).forEach((line) => { if (line.supplierId) line.checked = checked; });
    render();
  }
  function generateExpressOrders() {
    const draft = expressOrderDraft;
    const selectable = (draft?.lines || []).filter((line) => line.checked && line.supplierId && num(line.quantity) > 0);
    if (!selectable.length) { toast('Aucune ligne à commander', 'Cochez au moins un produit avec un fournisseur actif et une quantité positive.', 'warning'); return; }
    const skipped = (draft.lines || []).filter((line) => line.checked && !line.supplierId).length;
    const groups = new Map();
    selectable.forEach((line) => {
      if (!groups.has(line.supplierId)) groups.set(line.supplierId, []);
      groups.get(line.supplierId).push({ productId: line.productId, quantity: Math.max(1, Math.floor(num(line.quantity))), unitPrice: Math.max(0, num(line.unitPrice)) });
    });
    const storeId = draft.storeId || state.settings.defaultStoreId || state.stores[0]?.id || '';
    const units = selectable.reduce((sum, line) => sum + Math.max(1, Math.floor(num(line.quantity))), 0);
    if (!window.confirm(`Générer ${number(groups.size)} bon(s) de commande pour ${number(units)} unité(s) ? Les commandes seront créées au statut Brouillon.`)) return;
    const created = [];
    groups.forEach((lines, supplierId) => {
      const item = { id: uid('order'), number: nextNumber('CMD', state.orders), date: todayKey(), type: 'Prévisionnelle', supplierId, storeId, lines, total: lines.reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0), status: 'Brouillon', express: true };
      state.orders.unshift(item);
      created.push(item);
      addActivity('Commandes', 'Création d’une commande express', item.number, `${supplierName(supplierId)} · ${number(lines.length)} ligne(s) · ${money(item.total)}`);
    });
    if (!saveState()) return;
    expressOrderDraft = null;
    render();
    showExpressSuccess(created, skipped);
  }
  function showExpressSuccess(created, skipped) {
    const body = `<div class="notice success" style="margin-top:0"><span>✓</span><div><strong>${number(created.length)} bon(s) de commande créé(s) au statut Brouillon</strong><span>Imprimez chaque bon ou retrouvez-les dans la liste des commandes.${skipped ? ` ${number(skipped)} ligne(s) sans fournisseur actif ont été ignorées.` : ''}</span></div></div><div class="data-list">${created.map((order) => `<div class="data-row"><div class="data-row-main"><strong>${esc(order.number)} · ${esc(supplierName(order.supplierId))}</strong><span>${number(order.lines.length)} ligne(s) · ${number(order.lines.reduce((sum, line) => sum + num(line.quantity), 0))} unité(s)</span></div><div class="data-row-value">${money(order.total)}</div><div class="table-actions"><button class="table-action" type="button" data-action="view-order" data-id="${esc(order.id)}" title="Consulter">✎</button><button class="table-action" type="button" data-action="print-order" data-id="${esc(order.id)}" title="Imprimer le bon">▣</button></div></div>`).join('')}</div>`;
    openModal('Commande Express générée', 'Bons de commande prêts à être envoyés.', body, 'lg', '<button class="btn btn-primary" type="button" data-close-modal>Terminer</button>');
  }
  function renderExpressOrder() {
    const draft = expressOrderDraft;
    const analysisDays = draft?.analysisDays || 30;
    const coverageDays = draft?.coverageDays || 21;
    const storeId = draft?.storeId || '';
    const params = `<div class="express-params"><div class="field"><label>Ventes analysées</label><select class="select-control" id="express-analysis-days">${[7, 14, 30, 60, 90].map((days) => `<option value="${days}" ${analysisDays === days ? 'selected' : ''}>${days} derniers jours</option>`).join('')}</select></div><div class="field"><label>Couverture cible</label><select class="select-control" id="express-coverage-days">${[7, 14, 21, 30, 45].map((days) => `<option value="${days}" ${coverageDays === days ? 'selected' : ''}>${days} jours de stock</option>`).join('')}</select></div><div class="field"><label>Magasin</label><select class="select-control" id="express-store"><option value="">Tous les magasins</option>${state.stores.filter((s) => s.active !== false).map((s) => `<option value="${esc(s.id)}" ${storeId === s.id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select></div><div class="express-actions"><button class="btn btn-primary btn-sm" type="button" data-action="express-analyze">◈ Analyser et proposer</button>${draft ? '<button class="btn btn-secondary btn-sm" type="button" data-action="express-reset">Effacer</button>' : ''}</div></div>`;
    const context = draft ? `Analyse du ${dateTime(draft.generatedAt)} · ${draft.analysisDays} derniers jours · couverture ${draft.coverageDays} jours · ${draft.storeId ? esc(storeName(draft.storeId)) : 'tous magasins'}.` : 'Analyse des ventes et du stock, puis propositions de réassort par fournisseur.';
    if (!draft) return `<section class="panel express-panel"><div class="panel-header"><div><div class="panel-title">Commande Express</div><div class="panel-subtitle">${context}</div></div></div>${params}<div class="express-empty"><p>Lancez l’analyse pour obtenir des propositions de quantités à commander, ajustez-les puis générez un bon de commande par fournisseur.</p></div></section>`;
    if (!draft.lines.length) return `<section class="panel express-panel"><div class="panel-header"><div><div class="panel-title">Commande Express</div><div class="panel-subtitle">${context}</div></div></div>${params}<div class="express-empty"><p>✓ Aucun besoin de réassort détecté : les stocks couvrent la demande analysée.</p></div></section>`;
    const groups = new Map();
    draft.lines.forEach((line) => { const key = line.supplierId || ''; if (!groups.has(key)) groups.set(key, []); groups.get(key).push(line); });
    const reasonLabel = { rupture: 'Rupture', 'sous-seuil': 'Sous le seuil', 'couverture-faible': 'Couverture faible' };
    const rows = [...groups.entries()].map(([supplierId, lines]) => {
      const subtotal = lines.filter((item) => item.checked).reduce((sum, item) => sum + num(item.quantity) * num(item.unitPrice), 0);
      const head = `<tr class="express-group-row"><td colspan="8"><strong>${supplierId ? esc(supplierName(supplierId)) : '⚠ Sans fournisseur actif'}</strong><span>${number(lines.length)} produit(s) · ${money(subtotal)} sélectionné(s)</span></td></tr>`;
      return head + lines.map((line) => {
        const product = productById(line.productId);
        const noSupplier = !line.supplierId;
        return `<tr><td><input type="checkbox" data-express-check="${esc(line.productId)}" ${line.checked ? 'checked' : ''} ${noSupplier ? 'disabled title="Renseignez le fournisseur principal sur la fiche produit"' : ''}></td><td><strong>${esc(product?.name || 'Produit')}</strong><span class="table-secondary">${esc(product?.code || '')} · ${esc(categoryName(product?.categoryId))}</span></td><td><strong>${number(line.stock)}</strong><span class="table-secondary">${statusBadge(reasonLabel[line.reason], { 'Rupture': 'danger', 'Sous le seuil': 'warning', 'Couverture faible': 'info' })}</span></td><td><strong>${number(line.sold)}</strong><span class="table-secondary">${line.avgDaily > 0 ? `${line.avgDaily.toFixed(1)} / jour` : 'aucune vente'}</span></td><td>${line.coverDays == null ? '—' : `${number(Math.floor(line.coverDays))} j`}</td><td><input class="input-control express-qty" type="number" min="1" value="${num(line.quantity)}" data-express-qty="${esc(line.productId)}" ${noSupplier ? 'disabled' : ''}></td><td>${money(line.unitPrice)}<span class="table-secondary">achat</span></td><td><strong>${money(num(line.quantity) * num(line.unitPrice))}</strong></td></tr>`;
      }).join('');
    }).join('');
    const checked = draft.lines.filter((item) => item.checked && item.supplierId);
    const total = checked.reduce((sum, item) => sum + num(item.quantity) * num(item.unitPrice), 0);
    const allChecked = draft.lines.filter((item) => item.supplierId).every((item) => item.checked);
    return `<section class="panel express-panel"><div class="panel-header"><div><div class="panel-title">Commande Express</div><div class="panel-subtitle">${context}</div></div><span class="status-badge info">${number(draft.lines.length)} proposition(s)</span></div>${params}<div class="express-summary"><div class="strip-item"><span>Produits proposés</span><strong>${number(draft.lines.length)}</strong></div><div class="strip-item"><span>Lignes sélectionnées</span><strong>${number(checked.length)}</strong></div><div class="strip-item"><span>Fournisseurs concernés</span><strong>${number(new Set(checked.map((item) => item.supplierId)).size)}</strong></div><div class="strip-item"><span>Montant estimé</span><strong>${money(total)}</strong></div></div><div class="table-wrap express-table-wrap"><table class="data-table"><thead><tr><th><input type="checkbox" id="express-check-all" ${allChecked ? 'checked' : ''} title="Tout sélectionner"></th><th>Produit</th><th>Stock</th><th>Vendus</th><th>Couverture</th><th>Qté à commander</th><th>Prix d’achat</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table></div><div class="express-footer"><span>Un bon de commande sera généré par fournisseur, au statut Brouillon.</span><button class="btn btn-primary" type="button" data-action="express-generate" ${checked.length ? '' : 'disabled'}>▣ Générer le(s) bon(s) de commande</button></div></section>`;
  }
  function openOrderModal(orderId = '') {
    const order = orderId ? state.orders.find((item) => item.id === orderId) : null;
    const o = order || { date: todayKey(), type: 'Prévisionnelle', supplierId: '', storeId: state.stores[0]?.id || '' };
    orderDraftLines = (order?.lines || []).map((line) => ({ productId: line.productId, quantity: Math.max(1, num(line.quantity)), unitPrice: num(line.unitPrice) }));
    const body = `<form id="order-form"><div class="form-section-title">Informations générales</div><div class="form-grid"><div class="field"><label>Date de la commande <em>*</em></label><input class="input-control" type="date" name="date" value="${esc(o.date)}" required></div><div class="field"><label>Type</label><select class="select-control" name="type">${['Prévisionnelle','Urgente','Complémentaire','Autre'].map((x) => `<option ${o.type === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div class="field"><label>Fournisseur <em>*</em></label><select class="select-control" name="supplierId" required>${options(state.suppliers.filter((s) => s.active !== false), o.supplierId)}</select></div><div class="field"><label>Magasin concerné</label><select class="select-control" name="storeId">${options(state.stores.filter((s) => s.active !== false), o.storeId)}</select></div></div><div class="form-section-title" style="margin-top:20px">Ajouter des produits</div><div class="order-line-adder"><div class="field"><label>Produit <em>*</em></label><select class="select-control" id="order-line-product"><option value="">Sélectionner un produit</option>${activeProducts().map((product) => `<option value="${esc(product.id)}">${esc(product.code)} · ${esc(product.name)}</option>`).join('')}</select></div><div class="field"><label>Quantité <em>*</em></label><input class="input-control" id="order-line-quantity" type="number" min="1" value="1"></div><div class="field"><label>Prix unitaire</label><input class="input-control" id="order-line-unit-price" type="number" min="0" placeholder="Prix d’achat"></div><button class="btn btn-primary btn-sm" type="button" data-action="add-order-line">＋ Ajouter le produit</button></div><div class="order-cart"><div class="order-cart-header"><div><strong>Lignes de la commande</strong><span id="order-cart-count">0 ligne · 0 unité(s)</span></div><strong id="order-cart-total">0 FCFA</strong></div><div id="order-cart-lines"></div></div><div class="notice info" style="margin-top:14px;margin-bottom:0"><span>ⓘ</span><div><strong>Panier multi-lignes</strong><span>Ajoutez autant de produits que nécessaire dans la même commande. Un produit déjà présent est regroupé automatiquement.</span></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit" disabled>${order ? 'Enregistrer la commande' : 'Valider la commande'}</button></div></form>`;
    openModal(order ? 'Modifier la commande' : 'Nouvelle commande fournisseur', 'Préparez un approvisionnement avec plusieurs produits.', body, 'lg');
    const productSelect = $('#order-line-product');
    if (productSelect) productSelect.addEventListener('change', () => { const product = productById(productSelect.value); const price = $('#order-line-unit-price'); if (product && price && !price.value) price.value = num(product.purchasePrice); });
    $('#order-form').addEventListener('submit', (event) => {
      event.preventDefault();
      if (!orderDraftLines.length) { toast('Commande vide', 'Ajoutez au moins une ligne avant de valider.', 'warning'); return; }
      const data = Object.fromEntries(new FormData(event.currentTarget).entries());
      const item = { id: order?.id || uid('order'), number: order?.number || nextNumber('CMD', state.orders), date: data.date, type: data.type, supplierId: data.supplierId, storeId: data.storeId, lines: orderDraftLines.map((line) => ({ ...line })), total: orderDraftLines.reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0), status: order?.status || 'Brouillon' };
      if (order) state.orders[state.orders.findIndex((x) => x.id === order.id)] = item; else state.orders.unshift(item);
      addActivity('Commandes', order ? 'Modification d’une commande' : 'Création d’une commande', item.number, `${number(item.lines.length)} ligne(s) · ${number(item.lines.reduce((sum, line) => sum + num(line.quantity), 0))} unités`);
      saveState(); closeModal(); orderDraftLines = []; render(); toast(order ? 'Commande mise à jour' : 'Commande enregistrée', `${item.number} · ${number(item.lines.length)} ligne(s).`);
    });
    renderOrderDraftLines();
  }

  function renderQuoteDraftLines() {
    const container = $('#quote-cart-lines');
    const countNode = $('#quote-cart-count');
    const subtotalNode = $('#quote-subtotal');
    const discountNode = $('#quote-discount-total');
    const vatNode = $('#quote-vat');
    const totalNode = $('#quote-total');
    const submit = $('#quote-form button[type="submit"]');
    if (!container) return;
    container.innerHTML = quoteDraftLines.length ? quoteDraftLines.map((line, index) => `<div class="quote-line-row"><div class="quote-line-number">${String(index + 1).padStart(2, '0')}</div><div class="quote-line-product"><strong>${esc(productName(line.productId))}</strong><span>${esc(categoryName(productById(line.productId)?.categoryId))} · ${esc(productById(line.productId)?.code || '')}</span></div><div class="quote-line-field"><label>Quantité</label><input class="input-control" type="number" min="1" value="${num(line.quantity)}" data-quote-line-field="quantity" data-index="${index}"></div><div class="quote-line-field"><label>Prix unitaire</label><input class="input-control" type="number" min="0" value="${num(line.unitPrice)}" data-quote-line-field="unitPrice" data-index="${index}"></div><strong class="quote-line-total">${money(num(line.quantity) * num(line.unitPrice))}</strong><button class="table-action danger" type="button" data-action="remove-quote-line" data-id="${index}" title="Retirer la ligne">×</button></div>`).join('') : emptyState('Aucune ligne de devis', 'Sélectionnez un produit, indiquez une quantité puis ajoutez-le au panier.');
    const subtotal = quoteDraftLines.reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0);
    const discountInput = $('#quote-discount');
    const discount = Math.min(Math.max(0, num(discountInput?.value)), subtotal);
    const taxable = Math.max(0, subtotal - discount);
    const vat = taxable * num(state.settings.vat) / 100;
    const total = taxable + vat;
    if (countNode) countNode.textContent = `${number(quoteDraftLines.length)} ligne${quoteDraftLines.length > 1 ? 's' : ''} · ${number(quoteDraftLines.reduce((sum, line) => sum + num(line.quantity), 0))} unité(s)`;
    if (subtotalNode) subtotalNode.textContent = money(subtotal);
    if (discountNode) discountNode.textContent = money(discount);
    if (vatNode) vatNode.textContent = money(vat);
    if (totalNode) totalNode.textContent = money(total);
    if (submit) submit.disabled = quoteDraftLines.length === 0;
  }
  function addQuoteLineFromForm() {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier un devis.', 'warning'); return; }
    const productId = $('#quote-line-product')?.value;
    const quantity = Math.max(1, Math.floor(num($('#quote-line-quantity')?.value)));
    const priceInput = $('#quote-line-unit-price')?.value;
    const product = productById(productId);
    if (!product) { toast('Produit requis', 'Sélectionnez un produit avant de l’ajouter.', 'warning'); return; }
    const unitPrice = priceInput === '' ? num(product.salePrice) : Math.max(0, num(priceInput));
    const existing = quoteDraftLines.find((line) => line.productId === productId);
    if (existing) { existing.quantity += quantity; existing.unitPrice = unitPrice; }
    else quoteDraftLines.push({ productId, quantity, unitPrice });
    $('#quote-line-product').value = '';
    $('#quote-line-quantity').value = 1;
    $('#quote-line-unit-price').value = '';
    renderQuoteDraftLines();
    toast('Ligne ajoutée', `${product.name} · ${number(quantity)} unité(s).`);
  }
  function updateQuoteLine(index, field, value) {
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier un devis.', 'warning'); renderQuoteDraftLines(); return; }
    const line = quoteDraftLines[num(index)];
    if (!line) return;
    line[field] = field === 'quantity' ? Math.max(1, Math.floor(num(value))) : Math.max(0, num(value));
    renderQuoteDraftLines();
  }
  function openQuoteModal(quoteId = '') {
    const quote = quoteId ? state.quotes.find((item) => item.id === quoteId) : null;
    const q = quote || { date: todayKey(), clientName: '', clientContact: '', clientAddress: '', discount: 0 };
    quoteDraftLines = (quote?.lines || []).map((line) => ({ productId: line.productId, quantity: Math.max(1, num(line.quantity)), unitPrice: num(line.unitPrice) }));
    const body = `<form id="quote-form"><div class="form-section-title">Informations client</div><div class="form-grid"><div class="field"><label>Date du devis <em>*</em></label><input class="input-control" type="date" name="date" value="${esc(q.date)}" required></div><div class="field"><label>Nom du client <em>*</em></label><input class="input-control" name="clientName" value="${esc(q.clientName)}" required></div><div class="field"><label>Contact</label><input class="input-control" name="clientContact" value="${esc(q.clientContact)}"></div><div class="field"><label>Adresse</label><input class="input-control" name="clientAddress" value="${esc(q.clientAddress)}"></div></div><div class="form-section-title" style="margin-top:20px">Ajouter des produits</div><div class="quote-line-adder"><div class="field"><label>Produit <em>*</em></label><select class="select-control" id="quote-line-product"><option value="">Sélectionner un produit</option>${activeProducts().map((product) => `<option value="${esc(product.id)}">${esc(product.code)} · ${esc(product.name)}</option>`).join('')}</select></div><div class="field"><label>Quantité <em>*</em></label><input class="input-control" id="quote-line-quantity" type="number" min="1" value="1"></div><div class="field"><label>Prix unitaire</label><input class="input-control" id="quote-line-unit-price" type="number" min="0" placeholder="Prix de vente"></div><button class="btn btn-primary btn-sm" type="button" data-action="add-quote-line">＋ Ajouter le produit</button></div><div class="quote-cart"><div class="quote-cart-header"><div><strong>Lignes du devis</strong><span id="quote-cart-count">0 ligne · 0 unité(s)</span></div></div><div id="quote-cart-lines"></div><div class="quote-summary"><div class="quote-discount-field"><label for="quote-discount">Remise</label><input class="input-control" id="quote-discount" name="discount" type="number" min="0" value="${num(q.discount)}"><span>FCFA</span></div><div class="summary-line"><span>Sous-total</span><strong id="quote-subtotal">0 FCFA</strong></div><div class="summary-line"><span>Remise</span><strong id="quote-discount-total">0 FCFA</strong></div><div class="summary-line"><span>TVA (${num(state.settings.vat)}%)</span><strong id="quote-vat">0 FCFA</strong></div><div class="summary-total"><span>Total général</span><strong id="quote-total">0 FCFA</strong></div></div></div><div class="notice info" style="margin-top:14px;margin-bottom:0"><span>ⓘ</span><div><strong>Panier multi-produits</strong><span>Ajoutez plusieurs références dans le même devis. Un produit déjà présent est regroupé automatiquement.</span></div></div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit" disabled>${quote ? 'Enregistrer le devis' : 'Valider le devis'}</button></div></form>`;
    openModal(quote ? 'Modifier le devis' : 'Nouveau devis', 'Créez une proposition avec plusieurs produits et un calcul automatique.', body, 'lg');
    const productSelect = $('#quote-line-product');
    if (productSelect) productSelect.addEventListener('change', () => { const product = productById(productSelect.value); const price = $('#quote-line-unit-price'); if (product && price && !price.value) price.value = num(product.salePrice); });
    const discountInput = $('#quote-discount');
    if (discountInput) discountInput.addEventListener('input', renderQuoteDraftLines);
    $('#quote-form').addEventListener('submit', (event) => {
      event.preventDefault();
      if (!quoteDraftLines.length) { toast('Devis vide', 'Ajoutez au moins une ligne avant de valider.', 'warning'); return; }
      const data = Object.fromEntries(new FormData(event.currentTarget).entries());
      const subtotal = quoteDraftLines.reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0);
      const discount = Math.min(Math.max(0, num(data.discount)), subtotal);
      const taxable = Math.max(0, subtotal - discount);
      const vat = taxable * num(state.settings.vat) / 100;
      const item = { id: quote?.id || uid('quote'), number: quote?.number || nextNumber('DEV', state.quotes), date: data.date, clientName: data.clientName.trim(), clientContact: data.clientContact.trim(), clientAddress: data.clientAddress.trim(), lines: quoteDraftLines.map((line) => ({ ...line })), subtotal, vat, discount, total: taxable + vat, status: quote?.status || 'Brouillon' };
      if (quote) state.quotes[state.quotes.findIndex((x) => x.id === quote.id)] = item; else state.quotes.unshift(item);
      addActivity('Devis', quote ? 'Modification d’un devis' : 'Création d’un devis', item.number, `${number(item.lines.length)} ligne(s) · ${money(item.total)} · ${item.clientName}`);
      saveState(); closeModal(); quoteDraftLines = []; render(); toast(quote ? 'Devis mis à jour' : 'Devis enregistré', `${item.number} · ${number(item.lines.length)} ligne(s).`);
    });
    renderQuoteDraftLines();
  }

  function openUserModal(userId = '') {
    const user = userId ? state.users.find((item) => item.id === userId) : null;
    const u = user || { name: '', username: '', profile: state.roles[0]?.name || 'Administrateur', active: true };
    const passwordField = user
      ? '<div class="field"><label>Nouveau mot de passe</label><input class="input-control" type="password" name="password" minlength="8" autocomplete="new-password"><div class="field-hint">Laissez vide pour conserver le mot de passe actuel.</div></div>'
      : '<div class="field"><label>Mot de passe initial <em>*</em></label><input class="input-control" type="password" name="password" required minlength="8" autocomplete="new-password"><div class="field-hint">8 caractères minimum · sera stocké sous forme de hachage PBKDF2.</div></div>';
    const body = `<form id="user-form"><div class="form-grid"><div class="field full"><label>Nom et prénom / identité <em>*</em></label><input class="input-control" name="name" value="${esc(u.name)}" required></div><div class="field"><label>Nom d’utilisateur <em>*</em></label><input class="input-control" name="username" value="${esc(u.username)}" required autocomplete="username"></div><div class="field"><label>Profil</label><select class="select-control" name="profile">${state.roles.map((role) => `<option ${u.profile === role.name ? 'selected' : ''}>${esc(role.name)}</option>`).join('')}</select></div>${passwordField}</div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${user ? 'Enregistrer' : 'Créer l’utilisateur'}</button></div></form>`;
    openModal(user ? 'Modifier l’utilisateur' : 'Nouvel utilisateur', 'Les mots de passe sont hachés avant leur enregistrement.', body);
    $('#user-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(event.currentTarget).entries());
      const username = String(data.username || '').trim();
      const password = String(data.password || '');
      if (!username || !data.name?.trim()) { toast('Informations incomplètes', 'Renseignez l’identité et le nom d’utilisateur.', 'error'); return; }
      if (state.users.some((item) => item.id !== user?.id && String(item.username || '').toLowerCase() === username.toLowerCase())) { toast('Nom d’utilisateur déjà utilisé', 'Choisissez un autre identifiant de connexion.', 'error'); return; }
      if ((!user && password.length < 8) || (user && password && password.length < 8)) { toast('Mot de passe trop court', 'Utilisez au moins 8 caractères.', 'error'); return; }
      let passwordHash = user?.passwordHash || SEED_PASSWORD_HASHES[user?.id] || '';
      try { if (password) passwordHash = await hashPassword(password); } catch (error) { toast('Hachage indisponible', error.message || 'Impossible de sécuriser le mot de passe.', 'error'); return; }
      const item = { id: user?.id || uid('user'), name: data.name.trim(), username, profile: data.profile, active: user?.active !== false, passwordHash };
      if (user) state.users[state.users.findIndex((x) => x.id === user.id)] = item; else state.users.unshift(item);
      if (currentUser?.id === item.id) { currentUser = { ...currentUser, ...item }; updateCurrentUserChrome(); }
      addActivity('Utilisateurs', user ? 'Modification d’un utilisateur' : 'Création d’un utilisateur', item.username, item.profile);
      saveState(); closeModal(); render(); toast(user ? 'Utilisateur mis à jour' : 'Utilisateur créé', item.name);
    });
  }

  function openRoleModal(roleId = '') {
    const role = roleId ? state.roles.find((item) => item.id === roleId) : null;
    const r = role || { name: '', description: '', users: 0, color: 'teal', permissions: [] };
    const permissionLabels = [
      ['dashboard.view', 'Consulter le tableau de bord'], ['sales.view', 'Consulter les ventes'], ['sales.create', 'Créer une vente'], ['sales.validate', 'Valider une vente'], ['clients.view', 'Consulter les clients'], ['clients.manage', 'Gérer les clients'], ['deliverers.view', 'Consulter les livreurs'], ['deliverers.manage', 'Gérer les livreurs'], ['credit.view', 'Consulter le journal des créances'], ['credit.record', 'Enregistrer un règlement client'], ['products.view', 'Consulter les produits'], ['products.manage', 'Gérer les produits'], ['catalog.manage', 'Gérer le catalogue'], ['stock.view', 'Consulter le stock'], ['stock.create', 'Créer un mouvement de stock'], ['stock.validate', 'Valider un mouvement de stock'], ['orders.view', 'Consulter les commandes'], ['orders.manage', 'Gérer les commandes'], ['inventory.view', 'Consulter l’inventaire'], ['inventory.manage', 'Gérer l’inventaire'], ['quotes.view', 'Consulter les devis'], ['quotes.manage', 'Gérer les devis'], ['expenses.view', 'Consulter les dépenses'], ['expenses.manage', 'Gérer les dépenses'], ['accounting.view', 'Consulter la comptabilité'], ['reports.view', 'Consulter les rapports'], ['reports.export', 'Exporter les rapports'], ['users.manage', 'Gérer les utilisateurs'], ['roles.manage', 'Gérer les profils'], ['audit.view', 'Consulter le journal'], ['audit.manage', 'Administrer le journal'], ['settings.view', 'Consulter les paramètres'], ['settings.manage', 'Modifier les paramètres'], ['license.view', 'Consulter la licence'], ['license.activate', 'Activer la licence']
    ];
    const initialPermissions = Array.isArray(r.permissions) && r.permissions.length ? r.permissions : (DEFAULT_ROLE_PERMISSIONS[r.name] || []);
    const body = `<form id="role-form"><div class="form-grid"><div class="field"><label>Nom du profil <em>*</em></label><input class="input-control" name="name" value="${esc(r.name)}" required></div><div class="field"><label>Couleur</label><select class="select-control" name="color">${['teal','blue','orange','purple','red'].map((x) => `<option ${r.color === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div class="field full"><label>Description</label><textarea class="textarea-control" name="description">${esc(r.description)}</textarea></div></div><div class="form-section-title" style="margin-top:18px">Permissions effectives</div><div class="detail-grid">${permissionLabels.map(([key, label]) => `<label class="checkbox-line"><input type="checkbox" name="permissions" value="${esc(key)}" ${initialPermissions.includes('*') || initialPermissions.includes(key) ? 'checked' : ''}> ${esc(label)}</label>`).join('')}</div><div class="field-hint" style="margin-top:13px">Les cases cochées seront contrôlées avant l’ouverture d’un module et avant chaque écriture métier.</div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">${role ? 'Enregistrer' : 'Créer le profil'}</button></div></form>`;
    openModal(role ? 'Modifier le profil' : 'Nouveau profil', 'Les autorisations sont réellement appliquées aux actions.', body, 'lg');
    $('#role-form').addEventListener('submit', (event) => { event.preventDefault(); const formData = new FormData(event.currentTarget); const data = Object.fromEntries(formData.entries()); const permissions = formData.getAll('permissions'); const item = { id: role?.id || uid('role'), name: data.name.trim(), description: data.description.trim(), users: role?.users || 0, color: data.color, permissions }; if (role) state.roles[state.roles.findIndex((x) => x.id === role.id)] = item; else state.roles.push(item); addActivity('Profils', role ? 'Modification d’un profil' : 'Création d’un profil', item.name, `${number(permissions.length)} permission(s)`); saveState(); closeModal(); render(); toast(role ? 'Profil mis à jour' : 'Profil créé', item.name); });
  }
  function openInventoryCount(productId) {
    const product = productById(productId); if (!product) return;
    const existing = state.inventory.find((item) => item.productId === productId);
    const body = `<form id="count-form"><div class="table-product" style="margin-bottom:16px"><img class="mini-thumb" style="width:52px;height:52px" src="${productImage(product)}" alt=""><div><strong>${esc(product.name)}</strong><span class="table-secondary">Stock théorique : ${number(totalStock(product))} u. · ${esc(storeName(product.storeId))}</span></div></div><div class="field"><label>Stock réel compté <em>*</em></label><input class="input-control" type="number" name="real" value="${existing ? num(existing.real) : num(totalStock(product))}" min="0" required></div><div class="field-hint">L’écart sera calculé sans modifier automatiquement le stock théorique.</div><div class="form-actions"><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">Enregistrer le comptage</button></div></form>`;
    openModal('Saisir un comptage', product.name, body);
    $('#count-form').addEventListener('submit', (event) => { event.preventDefault(); const real = num(new FormData(event.currentTarget).get('real')); const item = { id: existing?.id || uid('inv'), productId, storeId: product.storeId || state.settings.defaultStoreId, real, date: todayKey(), userId: currentUserId() }; if (existing) state.inventory[state.inventory.findIndex((x) => x.id === existing.id)] = item; else state.inventory.unshift(item); addActivity('Inventaire', 'Saisie d’un comptage', product.code, `${number(real)} réel · ${number(totalStock(product))} théorique`); saveState(); closeModal(); render(); toast('Comptage enregistré', `${product.name} · écart ${real - totalStock(product) > 0 ? '+' : ''}${number(real - totalStock(product))}.`); });
  }

  function saveSettingsFromForm(form) {
    if (!requirePermission('settings.manage', 'Seul un profil autorisé peut modifier les paramètres.')) return;
    const data = Object.fromEntries(new FormData(form).entries());
    const currentPrinter = state.settings.ticketPrinter || {};
    state.settings = { ...state.settings, businessName: data.businessName.trim(), manager: data.manager.trim(), managerPhone: data.managerPhone.trim(), commercialPhone: data.commercialPhone.trim(), address: data.address.trim(), gps: data.gps.trim(), email: data.email.trim(), rccm: data.rccm.trim(), fiscal: data.fiscal.trim(), currency: data.currency, defaultStoreId: state.stores.some((store) => store.id === data.defaultStoreId) ? data.defaultStoreId : state.settings.defaultStoreId, theme: ['standard', 'clair', 'sombre'].includes(data.theme) ? data.theme : state.settings.theme, vat: num(data.vat), stockAlert: num(data.stockAlert), inactivityLockMinutes: clamp(Math.round(num(data.inactivityLockMinutes ?? 15)), 0, 240), allowNegative: form.querySelector('[name="allowNegative"]').checked, ticketPrinter: { ...currentPrinter, mode: data.printerMode || currentPrinter.mode || 'browser', paperWidth: data.printerPaperWidth || currentPrinter.paperWidth || '80mm', baudRate: num(data.printerBaudRate) || currentPrinter.baudRate || 9600, autoPrint: form.querySelector('[name="printerAutoPrint"]')?.checked || false } };
    const file = $('#settings-logo')?.files[0];
    const finish = (logo) => { if (logo) state.settings.logo = logo; addActivity('Paramètres', 'Modification des paramètres', state.settings.businessName, 'Informations de l’entreprise et impression ticket'); saveState(); render(); toast('Paramètres enregistrés', 'Les documents et tickets utiliseront les nouvelles informations.'); };
    if (file) readFileAsDataURL(file).then(finish); else finish('');
  }

  function printerSafeText(value) {
    return String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x09\x0A\x0D\x20-\x7E]/g, '?');
  }
  function printerLine(left, right, width) {
    const l = printerSafeText(left);
    const r = printerSafeText(right);
    const available = Math.max(1, width - r.length - 1);
    return `${l.slice(0, available).padEnd(available, ' ')} ${r.slice(-Math.max(1, width - available - 1)).padStart(Math.max(1, width - available - 1), ' ')}`.slice(0, width);
  }
  function escPosReceipt(sale) {
    const width = state.settings.ticketPrinter?.paperWidth === '58mm' ? 32 : 48;
    const bytes = [];
    const text = (value = '') => { bytes.push(...new TextEncoder().encode(`${printerSafeText(value)}\n`)); };
    const raw = (...values) => bytes.push(...values);
    raw(0x1b, 0x40); // initialize printer
    raw(0x1b, 0x61, 0x01); // center
    raw(0x1b, 0x45, 0x01);
    text(state.settings.businessName || 'NOVA Boutique');
    raw(0x1b, 0x45, 0x00);
    text(state.settings.address || '');
    text(state.settings.commercialPhone || state.settings.managerPhone || '');
    raw(0x1b, 0x61, 0x00); // left
    text('');
    text(`${printerSafeText(sale.number)}  ${printerSafeText(dateTime(sale.date))}`);
    text(`Client: ${printerSafeText(clientName(sale.clientId))}`);
    text(`Paiement: ${printerSafeText(paymentLabel(sale.payment))}`);
    text('-'.repeat(width));
    (sale.items || []).forEach((item) => {
      const label = `${number(item.quantity)} x ${productName(item.productId)}`;
      text(printerLine(label, money(item.quantity * item.unitPrice), width));
    });
    text('-'.repeat(width));
    raw(0x1b, 0x45, 0x01);
    text(printerLine('TOTAL', money(sale.total), width));
    raw(0x1b, 0x45, 0x00);
    text('');
    raw(0x1b, 0x61, 0x01);
    text('Merci pour votre confiance');
    text('A bientot');
    text('');
    raw(0x1d, 0x56, 0x00); // cut paper on printers that support it
    return new Uint8Array(bytes);
  }
  function printerDraftFromForm() {
    const form = $('#settings-form');
    const current = state.settings.ticketPrinter || {};
    return { ...current, mode: form?.querySelector('[name="printerMode"]')?.value || current.mode || 'browser', paperWidth: form?.querySelector('[name="printerPaperWidth"]')?.value || current.paperWidth || '80mm', baudRate: num(form?.querySelector('[name="printerBaudRate"]')?.value) || current.baudRate || 9600, autoPrint: form?.querySelector('[name="printerAutoPrint"]')?.checked ?? current.autoPrint ?? false };
  }
  function printerErrorMessage(error) {
    if (error?.name === 'NotFoundError' || error?.name === 'AbortError') return 'La sélection du périphérique a été annulée.';
    if (error?.name === 'SecurityError') return 'Le navigateur exige une page HTTPS ou localhost pour accéder au matériel.';
    return error?.message || 'Vérifiez le câble, le Bluetooth et les autorisations du navigateur.';
  }
  async function releasePrinterSession() {
    try {
      if (printerSession.serialPort) {
        if (printerSession.serialPort.readable || printerSession.serialPort.writable) await printerSession.serialPort.close();
      }
    } catch (_) {}
    try {
      if (printerSession.usbDevice) {
        if (printerSession.usbInterface !== null) await printerSession.usbDevice.releaseInterface(printerSession.usbInterface);
        await printerSession.usbDevice.close();
      }
    } catch (_) {}
    try {
      if (printerSession.bluetoothDevice?.gatt?.connected) printerSession.bluetoothDevice.gatt.disconnect();
    } catch (_) {}
    printerSession = { serialPort: null, usbDevice: null, usbInterface: null, usbEndpoint: null, bluetoothDevice: null, bluetoothCharacteristic: null };
  }
  async function connectSerialPrinter() {
    if (!navigator.serial) throw new Error('Web Serial n’est pas disponible dans ce navigateur. Utilisez Chrome ou Edge.');
    const port = await navigator.serial.requestPort();
    await port.open({ baudRate: num(state.settings.ticketPrinter.baudRate) || 9600 });
    printerSession.serialPort = port;
  }
  async function connectUsbPrinter() {
    if (!navigator.usb) throw new Error('WebUSB n’est pas disponible dans ce navigateur. Utilisez Chrome ou Edge.');
    const device = await navigator.usb.requestDevice({ filters: [{ classCode: 7 }] });
    await device.open();
    if (!device.configuration) await device.selectConfiguration(device.configurations?.[0]?.configurationValue || 1);
    let found = null;
    for (const iface of device.configuration?.interfaces || []) {
      for (const alternate of iface.alternates || []) {
        const endpoint = (alternate.endpoints || []).find((item) => item.direction === 'out' && ['bulk', 'interrupt'].includes(item.type));
        if (endpoint) { found = { interfaceNumber: iface.interfaceNumber, endpointNumber: endpoint.endpointNumber }; break; }
      }
      if (found) break;
    }
    if (!found) { await device.close(); throw new Error('Aucun endpoint USB de sortie compatible avec ESC/POS n’a été trouvé.'); }
    await device.claimInterface(found.interfaceNumber);
    printerSession.usbDevice = device;
    printerSession.usbInterface = found.interfaceNumber;
    printerSession.usbEndpoint = found.endpointNumber;
  }
  async function connectBluetoothPrinter() {
    if (!navigator.bluetooth) throw new Error('Web Bluetooth n’est pas disponible dans ce navigateur.');
    const optionalServices = ['0000ffe0-0000-1000-8000-00805f9b34fb', '0000fff0-0000-1000-8000-00805f9b34fb', '000018f0-0000-1000-8000-00805f9b34fb'];
    const device = await navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices });
    const server = await device.gatt.connect();
    let service = null;
    for (const uuid of optionalServices) { try { service = await server.getPrimaryService(uuid); break; } catch (_) {} }
    if (!service) throw new Error('Service Bluetooth d’impression introuvable. Vérifiez le mode Bluetooth de l’imprimante.');
    const characteristics = await service.getCharacteristics();
    const characteristic = characteristics.find((item) => item.properties.writeWithoutResponse || item.properties.write);
    if (!characteristic) throw new Error('Caractéristique Bluetooth écrivable introuvable.');
    printerSession.bluetoothDevice = device;
    printerSession.bluetoothCharacteristic = characteristic;
    device.addEventListener('gattserverdisconnected', () => {
      state.settings.ticketPrinter.status = 'disconnected';
      state.settings.ticketPrinter.deviceName = '';
      saveState();
      if (activeView === 'settings') render();
    });
  }
  async function connectPrinter() {
    const draft = printerDraftFromForm();
    await releasePrinterSession();
    state.settings.ticketPrinter = { ...draft, status: draft.mode === 'browser' ? 'ready' : 'disconnected', deviceName: draft.mode === 'browser' ? 'Impression système' : '' };
    if (draft.mode === 'browser') { saveState(); render(); toast('Imprimante prête', 'Les tickets utiliseront l’impression système de Windows ou Android.'); return; }
    try {
      if (draft.mode === 'serial') await connectSerialPrinter();
      if (draft.mode === 'usb') await connectUsbPrinter();
      if (draft.mode === 'bluetooth') await connectBluetoothPrinter();
      state.settings.ticketPrinter.status = 'connected';
      state.settings.ticketPrinter.deviceName = printerSession.usbDevice?.productName || printerSession.bluetoothDevice?.name || 'Périphérique ticket';
      saveState(); render();
      toast('Imprimante connectée', `${printerModeLabel(draft.mode)} · prête à recevoir des tickets.`);
    } catch (error) {
      await releasePrinterSession();
      state.settings.ticketPrinter.status = 'disconnected';
      state.settings.ticketPrinter.deviceName = '';
      saveState(); render();
      toast('Connexion impossible', printerErrorMessage(error), 'error');
    }
  }
  function printerModeLabel(mode) { return ({ browser: 'Impression système', serial: 'Web Serial', usb: 'WebUSB', bluetooth: 'Bluetooth' }[mode] || mode); }
  async function disconnectPrinter() {
    await releasePrinterSession();
    const printer = state.settings.ticketPrinter;
    printer.status = printer.mode === 'browser' ? 'ready' : 'disconnected';
    printer.deviceName = printer.mode === 'browser' ? 'Impression système' : '';
    saveState(); render(); toast('Imprimante déconnectée', 'Vous pouvez reconnecter un périphérique à tout moment.');
  }
  async function writePrinterBytes(bytes) {
    const printer = state.settings.ticketPrinter;
    if (printer.mode === 'serial') {
      if (!printerSession.serialPort?.writable) throw new Error('Le port série n’est plus disponible.');
      const writer = printerSession.serialPort.writable.getWriter();
      try { await writer.write(bytes); } finally { writer.releaseLock(); }
      return;
    }
    if (printer.mode === 'usb') {
      if (!printerSession.usbDevice || printerSession.usbEndpoint === null) throw new Error('Le périphérique USB n’est plus disponible.');
      await printerSession.usbDevice.transferOut(printerSession.usbEndpoint, bytes);
      return;
    }
    if (printer.mode === 'bluetooth') {
      if (!printerSession.bluetoothCharacteristic) throw new Error('La connexion Bluetooth n’est plus disponible.');
      const chunkSize = 180;
      for (let index = 0; index < bytes.length; index += chunkSize) {
        const chunk = bytes.slice(index, index + chunkSize);
        if (printerSession.bluetoothCharacteristic.writeValueWithoutResponse) await printerSession.bluetoothCharacteristic.writeValueWithoutResponse(chunk);
        else await printerSession.bluetoothCharacteristic.writeValue(chunk);
      }
      return;
    }
    throw new Error('Le mode d’impression système ne transmet pas de données ESC/POS directes.');
  }
  async function printSaleWithConfiguredPrinter(sale, automatic = false) {
    const printer = state.settings.ticketPrinter || {};
    if (printer.mode === 'browser') { printReceipt(sale); return; }
    if (printer.status !== 'connected') {
      toast('Imprimante non connectée', 'Le ticket reste disponible via l’impression système.', 'warning');
      if (!automatic) printReceipt(sale);
      return;
    }
    try {
      await writePrinterBytes(escPosReceipt(sale));
      if (!automatic) closeModal();
      toast('Ticket envoyé', `${sale.number} · ${printerModeLabel(printer.mode)}.`);
    } catch (error) {
      printer.status = 'disconnected';
      saveState();
      toast('Échec d’impression', printerErrorMessage(error), 'error');
      if (!automatic) printReceipt(sale);
    }
  }
  async function testPrinter() {
    const testSale = { id: 'printer-test', number: 'TEST-NOVA', date: new Date().toISOString(), clientId: 'counter', items: [{ productId: activeProducts()[0]?.id || 'prod-01', quantity: 1, unitPrice: productById(activeProducts()[0]?.id || 'prod-01')?.salePrice || 900 }], total: productById(activeProducts()[0]?.id || 'prod-01')?.salePrice || 900, payment: 'cash' };
    const printer = state.settings.ticketPrinter || {};
    if (printer.mode === 'browser') { showReceipt(testSale); return; }
    if (printer.status !== 'connected') { toast('Imprimante non connectée', 'Connectez d’abord un périphérique ticket.', 'warning'); return; }
    await printSaleWithConfiguredPrinter(testSale);
  }

  function showSaleDetail(sale) {
    if (!sale) return;
    const notes = creditNotesForSale(sale.id);
    const delivery = deliveryForSale(sale.id);
    const remaining = (sale.items || []).reduce((sum, line) => sum + availableSaleQuantity(sale, line), 0);
    const noteRows = notes.map((note) => `<tr><td><strong>${esc(note.number)}</strong></td><td>${esc(note.type)}</td><td>${shortDate(note.date)}</td><td>${money(creditNoteTotal(note))}</td><td>${statusBadge(note.status)}</td></tr>`).join('');
    const body = `<div class="detail-grid"><div class="detail-item"><label>Numéro</label><strong>${esc(sale.number)}</strong></div><div class="detail-item"><label>Date & heure</label><strong>${dateTime(sale.date)}</strong></div><div class="detail-item"><label>Client</label><strong>${esc(clientName(sale.clientId))}</strong></div><div class="detail-item"><label>Paiement</label><strong>${paymentLabel(sale.payment)}</strong></div><div class="detail-item"><label>Prix appliqué</label><strong>${esc(sale.priceLabel || salePriceTypeLabel(sale.priceType))}</strong></div><div class="detail-item"><label>Utilisateur</label><strong>${esc(userName(sale.userId))}</strong></div><div class="detail-item"><label>Statut</label><strong>${sale.status}</strong></div><div class="detail-item"><label>Livreur</label><strong>${delivery ? `${esc(delivererName(delivery.delivererId))} · ${money(delivery.fee)}` : 'Non affecté'}</strong></div></div><div class="form-section-title" style="margin-top:20px">Articles vendus</div><div class="table-wrap"><table class="data-table" style="min-width:0"><thead><tr><th>Produit</th><th>Qté</th><th>Prix unitaire</th><th>Sous-total</th></tr></thead><tbody>${sale.items.map((item) => `<tr><td><strong>${esc(productName(item.productId))}</strong></td><td>${number(item.quantity)}</td><td>${money(item.unitPrice)}</td><td><strong>${money(item.quantity * item.unitPrice)}</strong></td></tr>`).join('')}</tbody></table></div><div class="summary-total" style="margin-top:15px"><span>Total de la vente</span><strong>${money(saleTotal(sale))}</strong></div><div class="form-section-title" style="margin-top:20px">Corrections liées</div><div class="table-wrap"><table class="data-table" style="min-width:0"><thead><tr><th>Avoir</th><th>Nature</th><th>Date</th><th>Montant</th><th>Statut</th></tr></thead><tbody>${noteRows || `<tr><td colspan="5">${emptyTable('Aucun avoir ou annulation lié à cette vente')}</td></tr>`}</tbody></table></div><div class="notice ${remaining ? 'info' : 'success'}" style="margin-top:14px;margin-bottom:0"><span>${remaining ? 'ⓘ' : '✓'}</span><div><strong>${remaining ? `${number(remaining)} unité(s) encore corrigeable(s)` : 'Vente entièrement corrigée'}</strong><span>La vente originale reste immuable. Les corrections sont enregistrées comme de nouvelles opérations.</span></div></div>`;
    const footer = `<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>${remaining && sale.status === 'Validée' ? `<button class="btn btn-primary" type="button" data-action="create-credit-note" data-id="${esc(sale.id)}">↩ Créer un avoir / annuler</button>` : ''}<button class="btn btn-secondary" type="button" data-action="assign-delivery" data-id="${esc(sale.id)}">🚚 Affecter un livreur</button><button class="btn btn-secondary" type="button" data-action="print-sale" data-id="${esc(sale.id)}">▣ Réimprimer le ticket</button>`;
    openModal(`Vente ${esc(sale.number)}`, 'Détail de l’opération validée et de ses corrections.', body, 'lg', footer);
  }
  function showMovementDetail(item, type) {
    if (!item) return;
    const isEntry = type === 'entry';
    const reverseAction = isEntry ? 'reverse-entry' : 'reverse-exit';
    const origin = item.reversalOf ? `<div class="detail-item"><label>Correction de</label><strong>${esc(item.reversalOf)}</strong></div>` : '';
    const reason = item.correctionReason ? `<div class="detail-item"><label>Motif de correction</label><strong>${esc(item.correctionReason)}</strong></div>` : '';
    const body = `<div class="detail-grid"><div class="detail-item"><label>Référence</label><strong>${esc(item.number)}</strong></div><div class="detail-item"><label>Date</label><strong>${dateTime(item.date)}</strong></div><div class="detail-item"><label>Produit</label><strong>${esc(productName(item.productId))}</strong></div><div class="detail-item"><label>Quantité</label><strong>${number(item.quantity)} unités</strong></div><div class="detail-item"><label>Magasin</label><strong>${esc(storeName(item.storeId))}</strong></div><div class="detail-item"><label>Statut</label><strong>${item.status}</strong></div>${origin}${reason}</div><div class="notice ${item.status === 'Validé' ? 'success' : 'warning'}" style="margin-top:14px;margin-bottom:0"><span>${item.status === 'Validé' ? '✓' : '!'}</span><div><strong>${item.status === 'Validé' ? `Stock ${isEntry ? 'incrémenté' : 'décrémenté'} une fois` : 'Aucun impact stock'}</strong><span>Montant total : ${money(item.total)} · ${isEntry ? `Fournisseur : ${esc(supplierName(item.supplierId))}` : `Bénéficiaire : ${esc(item.beneficiary || '—')}`}</span></div></div>`;
    const footer = `<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>${item.status === 'Validé' ? `<button class="btn btn-primary" type="button" data-action="${reverseAction}" data-id="${esc(item.id)}">↩ Créer le mouvement inverse</button>` : ''}`;
    openModal(`${isEntry ? 'Entrée' : 'Sortie'} ${esc(item.number)}`, 'Détail de la traçabilité stock. Une correction crée une nouvelle opération.', body, 'lg', footer);
  }
  function showOrderDetail(order) { if (!order) return; const body = `<div class="detail-grid"><div class="detail-item"><label>Numéro</label><strong>${esc(order.number)}</strong></div><div class="detail-item"><label>Date</label><strong>${shortDate(order.date)}</strong></div><div class="detail-item"><label>Fournisseur</label><strong>${esc(supplierName(order.supplierId))}</strong></div><div class="detail-item"><label>Statut</label><strong>${order.status}</strong></div></div><div class="form-section-title" style="margin-top:20px">Lignes</div>${order.lines.map((line) => `<div class="data-row" style="padding:8px 0"><div class="data-row-main"><strong>${esc(productName(line.productId))}</strong><span>${number(line.quantity)} × ${money(line.unitPrice)}</span></div><div class="data-row-value">${money(line.quantity * line.unitPrice)}</div></div>`).join('')}<div class="summary-total" style="margin-top:12px"><span>Total commande</span><strong>${money(order.total)}</strong></div>`; openModal(`Commande ${esc(order.number)}`, 'Détail de la commande fournisseur.', body, 'lg', '<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>'); }
  function showQuoteDetail(quote) { if (!quote) return; const body = `<div class="detail-grid"><div class="detail-item"><label>Numéro</label><strong>${esc(quote.number)}</strong></div><div class="detail-item"><label>Date</label><strong>${shortDate(quote.date)}</strong></div><div class="detail-item"><label>Client</label><strong>${esc(quote.clientName)}</strong></div><div class="detail-item"><label>Statut</label><strong>${quote.status}</strong></div></div><div class="form-section-title" style="margin-top:20px">Produits du devis</div><div class="data-list">${(quote.lines || []).map((line, index) => `<div class="data-row"><span class="rank">${String(index + 1).padStart(2, '0')}</span><div class="data-row-main"><strong>${esc(productName(line.productId))}</strong><span>${number(line.quantity)} × ${money(line.unitPrice)}</span></div><div class="data-row-value">${money(line.quantity * line.unitPrice)}</div></div>`).join('') || emptyState('Aucune ligne')}</div><div class="form-section-title" style="margin-top:20px">Détail financier</div><div class="data-list"><div class="summary-line"><span>Sous-total</span><strong>${money(quote.subtotal)}</strong></div><div class="summary-line"><span>Remise</span><strong>${money(quote.discount)}</strong></div><div class="summary-line"><span>TVA</span><strong>${money(quote.vat)}</strong></div><div class="summary-total"><span>Total général</span><strong>${money(quote.total)}</strong></div></div>`; openModal(`Devis ${esc(quote.number)}`, 'Détail du devis, de ses produits et de la TVA.', body, 'lg', '<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>'); }
  function showClientHistory(clientId) {
    const client = state.clients.find((x) => x.id === clientId);
    if (!client) return;
    refreshClientReceivables();
    const ledger = clientLedger(clientId);
    let balance = 0;
    const rows = ledger.map((entry) => {
      balance += num(entry.debit) - num(entry.credit);
      return `<tr><td>${entry.date ? shortDate(entry.date) : '—'}</td><td><strong>${esc(entry.type)}</strong><span class="table-secondary">${esc(entry.reference)} · ${esc(entry.detail)}</span></td><td>${entry.debit ? money(entry.debit) : '—'}</td><td>${entry.credit ? money(entry.credit) : '—'}</td><td><strong>${money(balance)}</strong></td><td>${esc(entry.method)}</td><td>${esc(entry.user || '—')}</td></tr>`;
    }).join('');
    const payments = (state.customerPayments || []).filter((payment) => payment.clientId === clientId && payment.status === 'Validé');
    const body = `<div class="detail-grid"><div class="detail-item"><label>Client</label><strong>${esc(client.name)}</strong></div><div class="detail-item"><label>Encours actuel</label><strong>${money(client.receivable)}</strong></div><div class="detail-item"><label>Avance disponible</label><strong>${money(num(client.advance))}</strong></div><div class="detail-item"><label>Limite de crédit</label><strong>${money(client.creditLimit)}</strong></div><div class="detail-item"><label>Règlements enregistrés</label><strong>${number(payments.length)}</strong></div></div><div class="form-section-title" style="margin-top:20px">Journal de la créance</div><div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Opération</th><th>Débit</th><th>Crédit</th><th>Solde</th><th>Mode</th><th>Utilisateur</th></tr></thead><tbody>${rows || `<tr><td colspan="7">${emptyTable('Aucune opération')}</td></tr>`}</tbody></table></div><div class="notice info" style="margin-top:14px;margin-bottom:0"><span>ⓘ</span><div><strong>Solde calculé</strong><span>Le solde est reconstitué à partir du report initial, des ventes à crédit, avoirs, règlements et remboursements validés.</span></div></div>`;
    const footer = `<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button><button class="btn btn-primary" type="button" data-action="record-payment" data-id="${esc(client.id)}">₣ Enregistrer un règlement</button>`;
    openModal(`Journal · ${esc(client.name)}`, 'Créances, ventes à crédit et règlements partiels.', body, 'lg', footer);
  }
  function showSupplierHistory(supplierId) { const supplier = state.suppliers.find((x) => x.id === supplierId); if (!supplier) return; const entries = state.stockEntries.filter((e) => e.supplierId === supplierId); const body = `<div class="detail-grid"><div class="detail-item"><label>Fournisseur</label><strong>${esc(supplier.name)}</strong></div><div class="detail-item"><label>Entrées</label><strong>${number(entries.length)}</strong></div><div class="detail-item"><label>Total validé</label><strong>${money(entries.filter((e) => e.status === 'Validé').reduce((s, e) => s + num(e.total), 0))}</strong></div></div><div class="form-section-title" style="margin-top:20px">Historique des achats</div><div class="data-list">${entries.map((entry) => `<div class="data-row"><div class="data-row-main"><strong>${esc(entry.number)}</strong><span>${shortDate(entry.date)} · ${esc(productName(entry.productId))}</span></div><div class="data-row-value">${money(entry.total)}<br>${statusBadge(entry.status)}</div></div>`).join('') || emptyState('Aucune entrée')}</div>`; openModal(`Historique · ${esc(supplier.name)}`, 'Achats et entrées enregistrés chez ce fournisseur.', body, 'lg', '<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>'); }

  function printReceipt(sale) {
    const printRoot = $('#print-root');
    printRoot.innerHTML = `<div class="print-sheet">${receiptMarkup(sale)}</div>`;
    printCurrentPage(() => { printRoot.innerHTML = ''; });
  }
  function printDocument(title, subtitle, rows, summary = '') {
    $('#print-root').innerHTML = `<div class="print-sheet"><h1>${esc(title)}</h1><div class="print-muted">${esc(state.settings.businessName)} · ${esc(new Date().toLocaleDateString('fr-FR'))} · ${esc(subtitle)}</div><table><thead><tr>${rows.headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.body.map((line) => `<tr>${line.map((cell) => `<td>${esc(cell)}</td>`).join('')}</tr>`).join('')}</tbody></table>${summary ? `<div class="print-summary">${summary}</div>` : ''}</div>`;
    printCurrentPage(() => { $('#print-root').innerHTML = ''; });
  }
  function printCommercialDocument(kind, documentData) {
    if (!documentData) return;
    const isQuote = kind === 'quote';
    const partnerName = isQuote ? documentData.clientName : supplierName(documentData.supplierId);
    const partnerContact = isQuote ? documentData.clientContact : (state.suppliers.find((item) => item.id === documentData.supplierId)?.phone || '');
    const partnerAddress = isQuote ? documentData.clientAddress : (state.suppliers.find((item) => item.id === documentData.supplierId)?.address || '');
    const lines = (documentData.lines || []).map((line) => `<tr><td>${esc(productById(line.productId)?.code || '')}</td><td><strong>${esc(productName(line.productId))}</strong></td><td class="num">${number(line.quantity)}</td><td class="num">${money(line.unitPrice)}</td><td class="num">${money(num(line.quantity) * num(line.unitPrice))}</td></tr>`).join('');
    const subtotal = num(documentData.subtotal) || (documentData.lines || []).reduce((sum, line) => sum + num(line.quantity) * num(line.unitPrice), 0);
    const discount = num(documentData.discount);
    const vat = num(documentData.vat);
    const total = num(documentData.total) || subtotal - discount + vat;
    const company = state.settings || {};
    const printRoot = $('#print-root');
    printRoot.innerHTML = `<div class="print-sheet commercial-document"><div class="print-company"><div><h1>${esc(company.businessName || 'NOVA Commerce')}</h1><div>${esc(company.address || '')}</div><div>${esc(company.commercialPhone || company.managerPhone || '')}${company.email ? ` · ${esc(company.email)}` : ''}</div><div>${company.rccm ? `RCCM : ${esc(company.rccm)}` : ''}${company.fiscal ? ` · IFU : ${esc(company.fiscal)}` : ''}</div></div><div class="print-document-title"><h2>${isQuote ? 'DEVIS' : 'BON DE COMMANDE'}</h2><strong>${esc(documentData.number)}</strong><span>${shortDate(documentData.date)}</span><span>${esc(documentData.status)}</span></div></div><div class="print-parties"><div><b>${isQuote ? 'Client' : 'Fournisseur'}</b><strong>${esc(partnerName || '—')}</strong><span>${esc(partnerContact || '—')}</span><span>${esc(partnerAddress || '—')}</span></div><div><b>Émis par</b><strong>${esc(company.manager || 'NOVA Commerce')}</strong><span>${isQuote ? `Validité : ${esc(documentData.validity || 'à confirmer')}` : `Magasin : ${esc(storeName(documentData.storeId))}`}</span><span>Statut : ${esc(documentData.status)}</span></div></div><table><thead><tr><th>Code</th><th>Désignation</th><th class="num">Quantité</th><th class="num">Prix unitaire</th><th class="num">Montant</th></tr></thead><tbody>${lines || `<tr><td colspan="5">Aucune ligne</td></tr>`}</tbody></table><div class="print-totals"><div><span>Sous-total</span><strong>${money(subtotal)}</strong></div>${discount ? `<div><span>Remise</span><strong>− ${money(discount)}</strong></div>` : ''}${isQuote ? `<div><span>TVA</span><strong>${money(vat)}</strong></div>` : ''}<div class="grand"><span>Total ${isQuote ? 'TTC' : 'commande'}</span><strong>${money(total)}</strong></div></div><div class="print-signatures"><span>Signature / cachet ${isQuote ? 'du client' : 'du fournisseur'}</span><span>Signature ${isQuote ? 'commerciale' : 'responsable'}</span></div></div>`;
    printCurrentPage(() => { printRoot.innerHTML = ''; });
  }
  function backupFileStamp(date = new Date()) {
    const pad = (value) => String(value).padStart(2, '0');
    return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}`;
  }
  function buildBackupPayload(source = state) {
    const json = JSON.stringify({ app: 'NOVA Commerce', appVersion: APP_VERSION, schemaVersion: BACKUP_SCHEMA_VERSION, kind: 'sauvegarde-base', exportedAt: new Date().toISOString(), exportedBy: currentUser?.username || '', state: source });
    return { filename: `nova-commerce-sauvegarde-${backupFileStamp()}.json`, json };
  }
  function validateBackupData(data) {
    if (!data || typeof data !== 'object') return 'Le fichier sélectionné n’est pas une sauvegarde valide.';
    const payload = data.state && typeof data.state === 'object' ? data.state : data;
    const missing = ['products', 'sales', 'clients', 'suppliers', 'stores', 'categories', 'orders', 'settings'].filter((key) => payload[key] === undefined);
    if (missing.length) return `Sauvegarde incomplète : ${missing.join(', ')} manquant(s).`;
    if (!Array.isArray(payload.products) || !Array.isArray(payload.sales)) return 'Le fichier sélectionné n’est pas une sauvegarde valide.';
    const schema = data.schemaVersion ?? payload.schemaVersion;
    if (schema !== undefined && schema !== null && Number(schema) > BACKUP_SCHEMA_VERSION) return 'Sauvegarde créée par une version plus récente de NOVA Commerce. Mettez à jour le logiciel avant de la restaurer.';
    return '';
  }
  function downloadBackup() {
    if (!requirePermission('settings.manage', 'Votre profil ne peut pas sauvegarder la base.')) return;
    const { filename, json } = buildBackupPayload();
    state.settings.lastBackupAt = new Date().toISOString();
    addActivity('Sauvegarde', 'Sauvegarde de la base', filename, `${number(state.products.length)} produits · ${number(state.sales.length)} ventes`);
    saveState(); render();
    saveTextFile(filename, json, 'application/json;charset=utf-8').then((result) => { if (result?.browser) toast('Sauvegarde téléchargée', filename); });
  }
  function restoreBackup(file) {
    if (!file) return;
    if (!requirePermission('settings.manage', 'Votre profil ne peut pas restaurer la base.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour restaurer une sauvegarde.', 'warning'); return; }
    const reader = new FileReader();
    reader.onload = () => {
      let data = null;
      try { data = JSON.parse(String(reader.result || '')); } catch (_) { data = null; }
      const error = validateBackupData(data);
      if (error) { toast('Restauration impossible', error, 'error'); return; }
      const payload = data.state && typeof data.state === 'object' ? data.state : data;
      const products = Array.isArray(payload.products) ? payload.products.length : 0;
      const sales = Array.isArray(payload.sales) ? payload.sales.length : 0;
      if (!window.confirm(`Restaurer cette sauvegarde ? La base actuelle sera remplacée (${number(products)} produits · ${number(sales)} ventes). Pensez à télécharger une sauvegarde de sécurité avant.`)) return;
      const currentLicense = state.license;
      state = { ...payload, license: currentLicense };
      if (!Array.isArray(state.deliverers)) state.deliverers = [];
      if (!Array.isArray(state.deliveries)) state.deliveries = [];
      enforceProtectedAdministrator();
      normalizeAllProductStocks();
      refreshClientReceivables();
      addActivity('Sauvegarde', 'Restauration d’une sauvegarde', file.name || 'fichier', `${number(products)} produits · ${number(sales)} ventes`);
      saveState(); closeModal(); render();
      toast('Base restaurée', 'La sauvegarde a été appliquée. Vérifiez le journal.');
    };
    reader.readAsText(file);
  }
  function renderBackupExports() {
    const backupAllowed = can('settings.manage');
    const lastBackup = state.settings.lastBackupAt ? dateTime(state.settings.lastBackupAt) : 'Jamais effectuée';
    const tables = [['export-sales', 'Ventes'], ['export-products', 'Produits'], ['export-stock', 'Stocks par magasin'], ['export-clients', 'Clients'], ['export-payments', 'Règlements'], ['export-suppliers', 'Fournisseurs'], ['export-deliverers', 'Livreurs'], ['export-entries', 'Entrées'], ['export-exits', 'Sorties'], ['export-orders', 'Commandes'], ['export-quotes', 'Devis'], ['export-expenses', 'Dépenses'], ['export-activity', 'Journal']];
    const usage = storageUsage();
    const usagePercent = Math.round(usage.ratio * 100);
    const meterTone = usage.ratio >= STORAGE_WARN_RATIO ? 'warning' : 'success';
    const storageMarkup = `<div class="notice ${meterTone}" style="margin:2px 0 14px"><span>${usage.ratio >= STORAGE_WARN_RATIO ? '⚠' : '⛁'}</span><div><strong>Stockage local utilisé : ${number(usagePercent)} %</strong><span>${number(Math.round(usage.used / 1024))} Ko sur ${number(Math.round(usage.budget / 1024))} Ko disponibles. ${usage.ratio >= STORAGE_WARN_RATIO ? 'Téléchargez une sauvegarde et supprimez d’anciennes données pour libérer de la place.' : 'Journal d’activité : ' + number(Array.isArray(state.activities) ? state.activities.length : 0) + ' entrée(s) conservée(s).'}</span><div style="margin-top:9px"><button class="btn btn-secondary btn-sm" type="button" data-action="purge-activity">🧹 Purger le journal d’activité</button></div></div></div>`;
    return `<section class="panel backup-panel"><div class="panel-header"><div><div class="panel-title">Sauvegarde et exports</div><div class="panel-subtitle">Protégez la base locale et extrayez les tables importantes en CSV (compatible Excel).</div></div></div><div class="backup-grid"><div class="backup-card"><div class="backup-card-icon">⛁</div><div><strong>Sauvegarde complète de la base</strong><span>Télécharge toute la base (produits, ventes, stocks, utilisateurs, journal) dans un fichier JSON horodaté. Dernière sauvegarde : ${esc(lastBackup)}.</span></div><div class="backup-card-actions">${backupAllowed ? `<button class="btn btn-primary btn-sm" type="button" data-action="backup-download">⇩ Télécharger</button><label class="btn btn-secondary btn-sm backup-restore-label">↻ Restaurer<input type="file" id="backup-restore-file" accept="application/json,.json" hidden></label>` : '<span class="table-secondary">Réservé aux profils autorisés (paramètres).</span>'}</div></div></div>${storageMarkup}<div class="form-section-title" style="margin:4px 17px 0">Exports CSV des tables importantes (ouvrables dans Excel)</div><p class="backup-hint">Les exports respectent la période active et les filtres saisis.</p><div class="export-grid">${tables.map(([action, label]) => `<button class="btn btn-secondary btn-sm" type="button" data-action="${action}">⇩ ${label}</button>`).join('')}</div></section>`;
  }
  function purgeActivityLog() {
    if (!requirePermission('settings.manage', 'Votre profil ne peut pas purger le journal.')) return;
    if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour modifier la base.', 'warning'); return; }
    const total = Array.isArray(state.activities) ? state.activities.length : 0;
    if (total <= 200) { toast('Rien à purger', 'Le journal contient déjà peu d’entrées.', 'success'); return; }
    if (!window.confirm(`Purger le journal d’activité ? Les ${number(total - 200)} entrée(s) les plus anciennes seront supprimées ; les 200 dernières sont conservées.`)) return;
    state.activities = state.activities.slice(0, 200);
    addActivity('Administration', 'Purge du journal d’activité', 'Journal d’activité', `${number(total)} entrées ramenées à 200`);
    if (!saveState()) return;
    render();
    toast('Journal purgé', `Espace libéré. ${number(200)} entrée(s) conservée(s).`, 'success');
  }
  function sanitizeCsvCell(value) {
    const text = String(value ?? '');
    return /^[=+\-@|\t\r]/.test(text) ? `'${text}` : text;
  }
  function csvExport(filename, headers, rows) {
    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${sanitizeCsvCell(cell).replace(/"/g, '""')}"`).join(';')).join('\n');
    // Excel ouvre nativement ce CSV (séparateur « ; », BOM UTF-8).
    saveTextFile(filename, `\ufeff${csv}`, 'text/csv;charset=utf-8').then((result) => { if (result?.browser) toast('Export terminé', filename); });
  }
  function exportFiltered(items, textBuilder = () => '') {
    const root = $('#view');
    const query = String(root?.querySelector('[data-filter-input]')?.value || '').toLowerCase().trim();
    const select = root?.querySelector('[data-table-filter]');
    const selected = String(select?.value || '').toLowerCase();
    return periodItems(items).filter((item) => {
      const text = String(textBuilder(item) || '').toLowerCase();
      if (query && !text.includes(query)) return false;
      if (selected && select?.dataset.tableFilter === 'category' && item.categoryId !== select.value) return false;
      if (selected && select?.dataset.tableFilter !== 'category' && !text.includes(selected)) return false;
      return true;
    });
  }
  function printGuidePdf(file) {
    if (!file) return;
    const frame = document.createElement('iframe');
    frame.style.position = 'fixed';
    frame.style.right = '0';
    frame.style.bottom = '0';
    frame.style.width = '0';
    frame.style.height = '0';
    frame.style.border = '0';
    frame.setAttribute('aria-hidden', 'true');
    const cleanup = () => { frame.remove(); };
    const timer = window.setTimeout(cleanup, 60000);
    frame.onload = () => {
      try {
        frame.contentWindow.onafterprint = () => { window.clearTimeout(timer); cleanup(); };
        frame.contentWindow.focus();
        frame.contentWindow.print();
      } catch (error) {
        window.clearTimeout(timer);
        cleanup();
        window.open(file, '_blank', 'noopener');
      }
    };
    frame.onerror = () => { window.clearTimeout(timer); cleanup(); window.open(file, '_blank', 'noopener'); };
    frame.src = file;
    document.body.appendChild(frame);
  }
  function exportCurrent(type) {
    switch (type) {
      case 'sales': return csvExport('ventes-nova.csv', ['Numéro','Date','Client','Montant','Paiement','Statut'], exportFiltered(state.sales, (s) => `${s.number} ${clientName(s.clientId)} ${paymentLabel(s.payment)} ${s.status}`).map((s) => [s.number, dateTime(s.date), clientName(s.clientId), saleTotal(s), paymentLabel(s.payment), s.status]));
      case 'sales-report': return csvExport('bilan-ventes-nova.csv', ['Référence','Date','Client','Montant','Nature','Paiement','Statut'], [...exportFiltered(validSales(), (s) => `${s.number} ${clientName(s.clientId)} ${paymentLabel(s.payment)} ${s.status}`).map((s) => [s.number, dateTime(s.date), clientName(s.clientId), saleTotal(s), 'Vente', paymentLabel(s.payment), s.status]), ...exportFiltered(validCreditNotes(), (note) => `${note.number} ${note.originalSaleNumber} ${clientName(note.clientId)} Avoir ${note.status}`).map((note) => [note.number, dateTime(note.date), clientName(note.clientId), -creditNoteTotal(note), 'Avoir', 'Avoir', note.status])]);
      case 'credit-notes': return csvExport('avoirs-annulations-nova.csv', ['Référence','Date','Vente d’origine','Client','Nature','Montant','Retour stock','Remboursé','Statut','Motif'], exportFiltered(state.creditNotes || [], (note) => `${note.number} ${note.originalSaleNumber} ${clientName(note.clientId)} ${note.type} ${note.reason} ${note.status}`).map((note) => [note.number, dateTime(note.date), note.originalSaleNumber, clientName(note.clientId), note.type, creditNoteTotal(note), note.restock ? 'Oui' : 'Non', creditNoteRefunded(note.id), note.status, note.reason]));
      case 'transfers': return csvExport('transferts-inter-magasins-nova.csv', ['Référence','Date','Source','Destination','Lignes','Quantités','Statut','Motif'], exportFiltered(state.stockTransfers || [], (transfer) => `${transfer.number} ${storeName(transfer.sourceStoreId)} ${storeName(transfer.destinationStoreId)} ${transfer.note} ${transfer.status}`).map((transfer) => [transfer.number, dateTime(transfer.date), storeName(transfer.sourceStoreId), storeName(transfer.destinationStoreId), (transfer.lines || []).length, (transfer.lines || []).reduce((sum, line) => sum + num(line.quantity), 0), transfer.status, transfer.note]));
      case 'clients': return csvExport('clients-nova.csv', ['Nom','Téléphone','E-mail','Adresse','Créance','Avance'], exportFiltered(state.clients, (c) => `${c.name} ${c.phone} ${c.email} ${c.address}`).map((c) => [c.name, c.phone, c.email, c.address, c.receivable, num(c.advance)]));
      case 'payments': return csvExport('reglements-clients-nova.csv', ['Référence','Date','Client','Montant','Mode','Référence externe','Utilisateur','Statut'], exportFiltered(state.customerPayments, (p) => `${p.number} ${clientName(p.clientId)} ${paymentLabel(p.method)} ${p.reference} ${p.status}`).map((p) => [p.number, p.date, clientName(p.clientId), p.amount, paymentLabel(p.method), p.reference, userName(p.userId), p.status]));
      case 'refunds': return csvExport('remboursements-nova.csv', ['Référence','Date','Avoir','Client','Montant','Mode','Référence externe','Utilisateur'], exportFiltered(state.refunds || [], (r) => `${r.number} ${r.noteNumber} ${clientName(r.clientId)} ${paymentLabel(r.method)} ${r.reference}`).map((r) => [r.number, r.date, r.noteNumber, clientName(r.clientId), r.amount, paymentLabel(r.method), r.reference, userName(r.userId)]));
      case 'products': return csvExport('produits-nova.csv', ['Code','Produit','Catégorie','Magasin','Stock','Prix achat','Prix vente','Expiration'], exportFiltered(state.products, (p) => `${p.code} ${p.name} ${p.brand} ${categoryName(p.categoryId)} ${supplierName(p.supplierId)}`).map((p) => [p.code, p.name, categoryName(p.categoryId), storeName(p.storeId), totalStock(p), p.purchasePrice, p.salePrice, p.expiry]));
      case 'entries': return csvExport('entrees-stock-nova.csv', ['Référence','Date','Fournisseur','Produit','Quantité','Montant','Statut'], exportFiltered(state.stockEntries, (e) => `${e.number} ${e.type} ${supplierName(e.supplierId)} ${productName(e.productId)} ${e.status}`).map((e) => [e.number, e.date, supplierName(e.supplierId), productName(e.productId), e.quantity, e.total, e.status]));
      case 'exits': return csvExport('sorties-stock-nova.csv', ['Référence','Date','Type','Produit','Quantité','Montant','Statut'], exportFiltered(state.stockExits, (e) => `${e.number} ${e.type} ${e.beneficiary} ${productName(e.productId)} ${e.status}`).map((e) => [e.number, e.date, e.type, productName(e.productId), e.quantity, e.total, e.status]));
      case 'expenses': return csvExport('depenses-nova.csv', ['Référence','Date','Désignation','Montant','Autorisé par','Exécuté par'], exportFiltered(state.expenses, (e) => `${e.number} ${e.label} ${e.authorizedBy} ${e.executedBy} ${e.status}`).map((e) => [e.number, e.date, e.label, e.amount, e.authorizedBy, e.executedBy]));
      case 'orders': return csvExport('commandes-nova.csv', ['Numéro','Date','Fournisseur','Type','Montant','Statut'], exportFiltered(state.orders, (o) => `${o.number} ${supplierName(o.supplierId)} ${o.type} ${o.status}`).map((o) => [o.number, o.date, supplierName(o.supplierId), o.type, o.total, o.status]));
      case 'quotes': return csvExport('devis-nova.csv', ['Numéro','Date','Client','Sous-total','TVA','Total','Statut'], exportFiltered(state.quotes, (q) => `${q.number} ${q.clientName} ${q.status}`).map((q) => [q.number, q.date, q.clientName, q.subtotal, q.vat, q.total, q.status]));
      case 'categories': return csvExport('categories-nova.csv', ['Nom','Code','Description'], exportFiltered(state.categories, (c) => `${c.name} ${c.code} ${c.description}`).map((c) => [c.name, c.code, c.description]));
      case 'stores': return csvExport('magasins-nova.csv', ['Nom','Code','Type','Responsable'], exportFiltered(state.stores, (s) => `${s.name} ${s.code} ${s.type} ${s.manager}`).map((s) => [s.name, s.code, s.type, s.manager]));
      case 'suppliers': return csvExport('fournisseurs-nova.csv', ['Nom','Type','Responsable','Contact','IFU'], exportFiltered(state.suppliers, (s) => `${s.name} ${s.type} ${s.manager} ${s.phone} ${s.fiscal}`).map((s) => [s.name, s.type, s.manager, s.phone, s.fiscal]));
      case 'deliverers': return csvExport('livreurs-nova.csv', ['Nom','Prénoms','Contact principal','Contact secondaire','Adresse','Tarif de base','CIN','Informations','Statut'], exportFiltered(state.deliverers, (d) => `${d.lastName} ${d.firstName} ${d.phone} ${d.cin}`).map((d) => [d.lastName, d.firstName, d.phone, d.secondary, d.address, d.baseRate, d.cin, d.notes, d.active === false ? 'Inactif' : 'Actif']));
      case 'activity': return csvExport('journal-nova.csv', ['Date','Utilisateur','Module','Action','Élément'], exportFiltered(state.activities, (a) => `${a.module} ${a.action} ${a.element} ${userName(a.userId)}`).map((a) => [a.date, userName(a.userId), a.module, a.action, a.element]));
      case 'inventory': return csvExport('inventaire-nova.csv', ['Code','Produit','Catégorie','Magasin','Théorique','Réel','Écart'], activeProducts().map((p) => { const i = state.inventory.find((x) => x.productId === p.id); return [p.code, p.name, categoryName(p.categoryId), storeName(p.storeId), totalStock(p), i?.real ?? '', i ? i.real - totalStock(p) : '']; }));
      case 'stock': return csvExport('stocks-magasins-nova.csv', ['Code','Produit','Catégorie','Magasin','Stock','Stock mini','Stock maxi','État'], state.stores.filter((store) => store.active !== false).flatMap((store) => activeProducts().map((p) => { const qty = stockFor(p, store.id); return [p.code, p.name, categoryName(p.categoryId), store.name, qty, p.minStock, p.maxStock, qty <= 0 ? 'Rupture' : qty <= num(p.minStock) ? 'Stock faible' : 'Stock normal']; })));
      default: return toast('Export disponible', 'Utilisez les boutons du module pour exporter les données.');
    }
  }

  function showNotifications() {
    const alerts = activeProducts().filter((p) => productStockState(p).key === 'out' || productStockState(p).key === 'low' || (p.expiry && daysUntil(p.expiry) < 0)).slice(0, 8);
    const pending = state.stockEntries.filter((e) => e.status === 'En cours');
    const pendingTransfers = (state.stockTransfers || []).filter((transfer) => transfer.status === 'En cours');
    const pendingNotes = (state.creditNotes || []).filter((note) => note.status === 'En cours');
    const body = `<div class="data-list">${[...pending.map((e) => ({ title: `Entrée ${e.number} à valider`, text: `${productName(e.productId)} · ${number(e.quantity)} unités`, type: 'warning' })), ...pendingTransfers.map((transfer) => ({ title: `Transfert ${transfer.number} à valider`, text: `${storeName(transfer.sourceStoreId)} → ${storeName(transfer.destinationStoreId)}`, type: 'warning' })), ...pendingNotes.map((note) => ({ title: `Avoir ${note.number} à valider`, text: `${note.originalSaleNumber} · ${money(creditNoteTotal(note))}`, type: 'warning' })), ...alerts.map((p) => ({ title: p.name, text: productStockState(p).key === 'out' ? 'Rupture de stock' : p.expiry && daysUntil(p.expiry) < 0 ? 'Produit périmé' : `${number(totalStock(p))} en stock · seuil min ${number(p.minStock)}`, type: productStockState(p).key === 'out' ? 'danger' : 'warning' }))].map((item) => `<div class="data-row"><span class="status-dot ${item.type === 'danger' ? 'red' : 'orange'}"></span><div class="data-row-main"><strong>${esc(item.title)}</strong><span>${esc(item.text)}</span></div></div>`).join('') || emptyState('Aucune notification', 'Tout est sous contrôle.')}</div>`;
    openModal('Notifications', 'Alertes stock, péremption et opérations en attente.', body, 'sm', '<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>');
  }
  function showShortcuts() { openModal('Raccourcis NOVA', 'Gagnez du temps sur les opérations courantes.', `<div class="data-list"><div class="data-row"><kbd>F2</kbd><div class="data-row-main"><strong>Nouvelle vente</strong><span>Ouvrir la caisse en un geste</span></div></div><div class="data-row"><kbd>⌘ K</kbd><div class="data-row-main"><strong>Recherche globale</strong><span>Rechercher un module ou un produit</span></div></div><div class="data-row"><kbd>Double-clic</kbd><div class="data-row-main"><strong>Ajout rapide</strong><span>Ajouter une unité directement au panier</span></div></div><div class="data-row"><kbd>Échap</kbd><div class="data-row-main"><strong>Fermer une fenêtre</strong><span>Revenir à l’écran précédent</span></div></div></div>`, '', '<button class="btn btn-primary" type="button" data-close-modal>Compris</button>'); }

  document.addEventListener('submit', (event) => {
    const formId = event.target?.id || '';
    const permission = FORM_PERMISSIONS[formId];
    if (permission && !requirePermission(permission)) { event.preventDefault(); event.stopImmediatePropagation(); return; }
    if (isReadOnly() && formId !== 'date-filter-form' && formId !== 'login-form' && !(formId === 'license-form' && !isClockTampered())) { event.preventDefault(); event.stopImmediatePropagation(); toast(isClockTampered() ? 'Blocage de sécurité' : 'Mode lecture seule', isClockTampered() ? 'La licence ne peut pas contourner le verrouillage de l’horloge système.' : 'Activez la licence pour enregistrer ou modifier des données.', 'warning'); }
  }, true);

  document.addEventListener('click', (event) => {
    if (!currentUser && !event.target.closest('#login-screen, #first-run-screen')) return;
    // Android WebView ne lit ni ne télécharge les PDF embarqués : on délègue au système.
    const pdfLink = isPdfLink(event.target);
    if (pdfLink && openEmbeddedDocument(pdfLink)) { event.preventDefault(); return; }
    const pageButton = event.target.closest('[data-table-page]');
    if (pageButton) { const tbody = document.getElementById(pageButton.dataset.tablePage); if (tbody && !pageButton.disabled) paginateTable(tbody, Number(pageButton.dataset.page)); return; }
    const nav = event.target.closest('[data-view]');
    const nestedAction = event.target.closest('[data-action]');
    if (nav && !(nestedAction && nav.contains(nestedAction))) { event.preventDefault(); navigate(nav.dataset.view); return; }
    if (event.target.closest('[data-close-modal]')) { closeModal(); return; }
    if (event.target.matches('[data-modal-backdrop]')) { closeModal(); return; }
    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) {
      const card = event.target.closest('[data-product-card]');
      if (card && activeView === 'sale') { if (isReadOnly()) { toast('Mode lecture seule', 'Activez la licence pour enregistrer une vente.', 'warning'); return; } clearTimeout(clickTimer); if (event.detail === 1) clickTimer = setTimeout(() => openQuantityModal(card.dataset.productId), 235); if (event.detail === 2) { clearTimeout(clickTimer); addToCart(card.dataset.productId, 1); } }
      return;
    }
    const action = actionEl.dataset.action; const id = actionEl.dataset.id;
    const permission = ACTION_PERMISSIONS[action];
    if (permission && !requirePermission(permission)) return;
    if (isReadOnly() && READ_ONLY_ACTIONS.has(action)) { toast('Mode lecture seule', 'Activez la licence pour réactiver les opérations de modification.', 'warning'); return; }
    switch (action) {
      case 'choose-database': chooseInitialDatabase(actionEl.dataset.databaseMode); break;
      case 'toggle-sidebar': $('#sidebar')?.classList.toggle('open'); $('#mobile-overlay')?.classList.toggle('visible'); break;
      case 'toggle-sidebar-collapse': toggleSidebarCollapse(); break;
      case 'cycle-theme': cycleTheme(); break;
      case 'set-theme': setTheme(actionEl.dataset.theme); break;
      case 'toggle-store-menu': toast('Multi-magasin', 'Le sélecteur de magasin sera disponible avec la synchronisation serveur.', 'warning'); break;
      case 'show-notifications': showNotifications(); break;
      case 'show-shortcuts': showShortcuts(); break;
      case 'show-license-help': showLicenseHelp(); break;
      case 'copy-contact': copyContact(); break;
      case 'copy-business-name': copyTextToClipboard(state.settings?.businessName || '', 'Nom de boutique copié', 'Le nom de la boutique est dans votre presse-papiers.'); break;
      case 'copy-licence-uuid': void ensureDeviceUuid().then((uuid) => copyTextToClipboard(uuid, 'UUID copié', 'Le code UUID de l’appareil est dans votre presse-papiers.')); break;
      case 'request-licence-sms': void showLicenceSmsModal(); break;
      case 'copy-sms-text': copyTextToClipboard(document.getElementById('licence-sms-text')?.value || '', 'Message copié', 'Collez-le dans votre application SMS vers le +226 76 83 04 82.'); break;
      case 'designer-enable-all': setAllModulesEnabled(true); break; case 'designer-disable-all': setAllModulesEnabled(false); break; case 'designer-lock': designerUnlocked = false; render(); toast('Espace concepteur', 'L’espace a été verrouillé.'); break;
      case 'show-profile': openModal('Mon profil', 'Session active', `<div class="detail-grid"><div class="detail-item"><label>Identité</label><strong>${esc(currentUser?.name || '—')}</strong></div><div class="detail-item"><label>Nom d’utilisateur</label><strong>@${esc(currentUser?.username || '—')}</strong></div><div class="detail-item"><label>Profil</label><strong>${esc(currentUser?.profile || '—')}</strong></div></div>`, 'sm', '<button class="btn btn-secondary" type="button" data-close-modal>Fermer</button>'); break;
      case 'logout': logout(); break;
      case 'show-receipt-help': showReceipt({ id: 'preview', number: 'VTE-EXEMPLE', date: new Date().toISOString(), clientId: 'counter', items: [{ productId: 'prod-01', quantity: 1, unitPrice: 900 }], total: 900, payment: 'cash' }); break;
      case 'quick-add': addToCart(id, 1); break;
      case 'select-product': openQuantityModal(id); break;
      case 'cart-increase': updateCart(id, 1); break;
      case 'cart-decrease': updateCart(id, -1); break;
      case 'cart-remove': saleCart = saleCart.filter((line) => line.productId !== id); render(); break;
      case 'clear-cart': saleCart = []; render(); break;
      case 'set-payment': saleDraft.payment = actionEl.dataset.payment; render(); break;
      case 'validate-sale': validateSale(); break;
      case 'add-product': openProductModal(); break; case 'edit-product': openProductModal(id); break;
      case 'toggle-product': { const product = productById(id); if (product) { product.active = product.active === false; addActivity('Produits', product.active ? 'Activation d’un produit' : 'Désactivation d’un produit', product.code, product.name); saveState(); render(); toast(product.active ? 'Produit activé' : 'Produit désactivé', product.name); } break; }
      case 'add-client': openClientModal(); break; case 'edit-client': openClientModal(id); break; case 'record-payment': openCustomerPaymentModal(id); break; case 'client-history': showClientHistory(id); break;
      case 'add-supplier': openSupplierModal(); break; case 'edit-supplier': openSupplierModal(id); break; case 'supplier-history': showSupplierHistory(id); break;
      case 'add-deliverer': openDelivererModal(); break; case 'edit-deliverer': openDelivererModal(id); break; case 'toggle-deliverer': { const deliverer = state.deliverers.find((x) => x.id === id); if (deliverer) { deliverer.active = deliverer.active === false; addActivity('Livreurs', deliverer.active ? 'Activation d’un livreur' : 'Désactivation d’un livreur', delivererName(deliverer.id), deliverer.phone); saveState(); render(); toast(deliverer.active ? 'Livreur activé' : 'Livreur désactivé', delivererName(deliverer.id)); } break; }
      case 'add-category': openCategoryModal(); break; case 'edit-category': openCategoryModal(id); break;
      case 'add-store': openStoreModal(); break; case 'edit-store': openStoreModal(id); break;
      case 'add-entry': openEntryModal(); break; case 'view-entry': showMovementDetail(state.stockEntries.find((x) => x.id === id), 'entry'); break; case 'validate-entry': validateEntry(id); break; case 'reverse-entry': createReverseMovement(state.stockEntries.find((x) => x.id === id), 'entry'); break;
      case 'add-exit': openExitModal(); break; case 'view-exit': showMovementDetail(state.stockExits.find((x) => x.id === id), 'exit'); break; case 'validate-exit': validateExit(id); break; case 'reverse-exit': createReverseMovement(state.stockExits.find((x) => x.id === id), 'exit'); break;
      case 'add-transfer': openTransferModal(); break; case 'add-transfer-line': addTransferLineFromForm(); break; case 'remove-transfer-line': transferDraftLines.splice(num(id), 1); renderTransferDraftLines(); break; case 'edit-transfer': openTransferModal(id); break; case 'validate-transfer': validateTransfer(id); break; case 'view-transfer': showTransferDetail((state.stockTransfers || []).find((x) => x.id === id)); break;
      case 'add-order': openOrderModal(); break; case 'receive-order': receiveOrder(id); break; case 'add-order-line': addOrderLineFromForm(); break; case 'remove-order-line': orderDraftLines.splice(num(id), 1); renderOrderDraftLines(); break; case 'express-analyze': analyzeExpressOrder(); break; case 'express-generate': generateExpressOrders(); break; case 'express-reset': expressOrderDraft = null; render(); break; case 'view-order': showOrderDetail(state.orders.find((x) => x.id === id)); break;
      case 'add-quote': openQuoteModal(); break; case 'add-quote-line': addQuoteLineFromForm(); break; case 'remove-quote-line': quoteDraftLines.splice(num(id), 1); renderQuoteDraftLines(); break; case 'view-quote': showQuoteDetail(state.quotes.find((x) => x.id === id)); break;
      case 'add-expense': openExpenseModal(); break; case 'edit-expense': openExpenseModal(id); break;
      case 'count-product': openInventoryCount(id); break; case 'start-inventory': navigate('inventory'); toast('Inventaire prêt', 'Saisissez le comptage réel sur chaque ligne.'); break; case 'create-inventory-report': openInventoryReportModal(); break; case 'view-inventory-report': { const report = (state.inventoryReports || []).find((item) => item.id === id); if (report) showInventoryReport(report); break; } case 'print-inventory-report': { const report = (state.inventoryReports || []).find((item) => item.id === id); if (report) printInventoryReport(report); break; }
      case 'add-user': openUserModal(); break; case 'edit-user': openUserModal(id); break; case 'reset-password': toast('Réinitialisation', 'Un lien de réinitialisation sécurisé sera généré en production.', 'warning'); break;
      case 'add-role': openRoleModal(); break; case 'edit-role': openRoleModal(id); break;
      case 'view-sale': showSaleDetail(state.sales.find((x) => x.id === id)); break; case 'assign-delivery': openDeliveryModal(id); break; case 'create-credit-note': openCreditNoteModal(state.sales.find((x) => x.id === id)); break; case 'view-credit-note': showCreditNoteDetail((state.creditNotes || []).find((x) => x.id === id)); break; case 'validate-credit-note': validateCreditNote(id); break; case 'refund-credit-note': closeModal(); openRefundModal(id, num(actionEl.dataset.amount)); break; case 'print-sale': { const sale = state.sales.find((x) => x.id === id); if (sale) { closeModal(); showReceipt(sale); } break; }
      case 'print-receipt': printSaleWithConfiguredPrinter(state.sales.find((x) => x.id === id) || { id, number: 'VTE-EXEMPLE', date: new Date().toISOString(), clientId: 'counter', items: [], total: 0, payment: 'cash' }); break;
      case 'printer-connect': connectPrinter(); break;
      case 'printer-disconnect': disconnectPrinter(); break;
      case 'printer-test': testPrinter(); break;
      case 'print-order': printCommercialDocument('order', state.orders.find((x) => x.id === id)); break; case 'print-quote': printCommercialDocument('quote', state.quotes.find((x) => x.id === id)); break;
      case 'save-settings': $('#settings-form')?.requestSubmit(); break; case 'reset-demo': resetDemo(); break; case 'fresh-database': freshDatabase(); break;
      case 'purge-activity': purgeActivityLog(); break;
      case 'export-sales': exportCurrent('sales'); break; case 'export-credit-notes': exportCurrent('credit-notes'); break; case 'export-transfers': exportCurrent('transfers'); break; case 'export-clients': exportCurrent('clients'); break; case 'export-payments': exportCurrent('payments'); break; case 'export-refunds': exportCurrent('refunds'); break; case 'print-guide': printGuidePdf(actionEl.dataset.file); break; case 'export-products': exportCurrent('products'); break; case 'export-entries': exportCurrent('entries'); break; case 'export-exits': exportCurrent('exits'); break; case 'export-expenses': exportCurrent('expenses'); break; case 'export-orders': exportCurrent('orders'); break; case 'export-quotes': exportCurrent('quotes'); break; case 'export-categories': exportCurrent('categories'); break; case 'export-stores': exportCurrent('stores'); break; case 'export-suppliers': exportCurrent('suppliers'); break; case 'export-deliverers': exportCurrent('deliverers'); break; case 'export-activity': exportCurrent('activity'); break; case 'export-inventory': exportCurrent('inventory'); break; case 'export-stock': exportCurrent('stock'); break; case 'backup-download': downloadBackup(); break;
      case 'export-purchases': exportCurrent('entries'); break; case 'export-sales-report': exportCurrent('sales-report'); break; case 'export-accounting': exportCurrent('sales-report'); break;
      case 'print-inventory': printInventory(); break; case 'print-report': printReport(actionEl.dataset.report); break; case 'print-full-report': printFullReport(actionEl.dataset.report); break; case 'print-supplier-products': printSupplierProducts(); break;
      case 'show-date-filter': openDateFilter(); break; case 'clear-date-filter': activeDateFilter = { from: '', to: '' }; tablePages = {}; closeModal(); render(); toast('Filtre réinitialisé', 'Toutes les périodes sont de nouveau affichées.'); break; case 'show-filter-info': toast('Filtres actifs', `La recherche et la période ${periodLabel()} modifient les données visibles et les extractions.`, 'success'); break; case 'show-stock-filter': toast('État du stock', 'Utilisez les indicateurs de stock du tableau pour repérer les ruptures et seuils faibles.', 'warning'); break; case 'show-report-filters': openDateFilter(); break; case 'show-vat-info': toast('TVA configurée', `Le taux actuel est de ${num(state.settings.vat)} %.`, 'success'); break; case 'show-security-info': toast('Sécurité', 'Les nouveaux mots de passe sont hachés avec PBKDF2-SHA-256 et un sel individuel.', 'success'); break;
    }
  });
  document.addEventListener('change', (event) => {
    if (event.target.id === 'settings-logo') return;
    if (event.target.matches('[data-cart-input]')) setCartQuantity(event.target.dataset.id, event.target.value);
    if (event.target.matches('[data-order-line-field]')) updateOrderLine(event.target.dataset.index, event.target.dataset.orderLineField, event.target.value);
    if (event.target.matches('[data-quote-line-field]')) updateQuoteLine(event.target.dataset.index, event.target.dataset.quoteLineField, event.target.value);
    if (event.target.matches('[data-credit-note-field]')) updateCreditNoteLine(event.target.dataset.index, event.target.value);
    if (event.target.matches('[data-transfer-line-field]')) updateTransferLine(event.target.dataset.index, event.target.value);
    if (event.target.id === 'backup-restore-file') { restoreBackup(event.target.files[0]); event.target.value = ''; }
  });
  document.addEventListener('keydown', (event) => {
    if (!currentUser) return;
    if (event.key === 'Escape') closeModal();
    if (event.key === 'F2') { event.preventDefault(); navigate('sale'); }
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); $('#global-search')?.focus(); }
    if (event.target.id === 'global-search' && event.key === 'Enter') { const query = event.target.value.trim(); if (query) { navigate('products'); setTimeout(() => { const input = $('#view [data-filter-input]'); if (input) { input.value = query; filterTarget(input); input.focus(); } }, 50); } }
  });
  $('#mobile-overlay')?.addEventListener('click', () => { $('#sidebar')?.classList.remove('open'); $('#mobile-overlay')?.classList.remove('visible'); });

  function resetDemo() {
    if (!state.license?.activated || !requirePermission('demo.reset', 'Seul l’administrateur après activation peut réinitialiser la démo.')) { toast('Activation requise', 'Saisissez d’abord le code spécial dans Licence → Activation.', 'warning'); return; }
    if (isClockTampered()) { toast('Action bloquée', 'L’intégrité de l’horloge empêche toute modification.', 'error'); return; }
    if (!window.confirm('Réinitialiser toutes les données de démonstration ? Les données actuelles seront remplacées par les données d’exemple.')) return;
    const auditHistory = Array.isArray(state.activities) ? state.activities.slice() : [];
    const license = { ...(state.license || {}) };
    state = seedState();
    state.initialSetupCompleted = true;
    state.blankDatabase = false;
    state.license = license;
    state.activities = auditHistory;
    enforceProtectedAdministrator();
    state.roles = normalizeRoles(state.roles, seedState().roles);
    normalizeAllProductStocks();
    refreshClientReceivables();
    state.settings.defaultStoreId = state.stores[0]?.id || '';
    addActivity('Administration', 'Réinitialisation de la démo', 'Données de démonstration', 'Les données d’exemple ont été restaurées.');
    saleCart = []; saleDraft = { clientId: 'counter', payment: 'cash', storeId: '', priceType: 'retail' }; creditNoteDraftLines = []; transferDraftLines = [];
    state.__resetDemo = true;
    const persisted = saveState();
    delete state.__resetDemo;
    if (!persisted) return;
    navigate('dashboard');
    toast('Démo réinitialisée', 'Les données d’exemple sont de nouveau disponibles.');
  }

  function freshDatabase() {
    if (!state.license?.activated || !requirePermission('license.activate', 'Seul l’administrateur après activation peut mettre la base à neuf.')) { toast('Activation requise', 'Saisissez d’abord le code spécial dans Licence → Activation.', 'warning'); return; }
    if (isClockTampered()) { toast('Action bloquée', 'L’intégrité de l’horloge empêche toute modification.', 'error'); return; }
    if (!window.confirm('Mettre à neuf la base ? Toutes les ventes, stocks, produits, clients, fournisseurs, livreurs, commandes, devis, dépenses et données métier seront supprimés. Le compte Administrateur sera conservé.')) return;
    const license = { ...(state.license || {}) };
    const fresh = seedState();
    state = {
      ...fresh,
      initialSetupCompleted: true,
      blankDatabase: true,
      license,
      categories: [], stores: [], suppliers: [], supplierProducts: [], products: [], clients: [], customerPayments: [], sales: [], creditNotes: [], refunds: [], stockEntries: [], stockExits: [], stockTransfers: [], expenses: [], orders: [], quotes: [], inventory: [], inventoryReports: [], deliverers: [], deliveries: [], activities: [],
      users: [],
      roles: []
    };
    enforceProtectedAdministrator();
    state.settings.defaultStoreId = '';
    normalizeAllProductStocks();
    refreshClientReceivables();
    addActivity('Administration', 'Mise à neuf de la base', 'Base locale', 'Toutes les données métier ont été supprimées ; le compte Administrateur a été conservé.', 'Base existante', 'Base vide');
    saleCart = []; saleDraft = { clientId: 'counter', payment: 'cash', storeId: '', priceType: 'retail' }; creditNoteDraftLines = []; transferDraftLines = [];
    const persisted = saveState();
    if (!persisted) return;
    navigate('dashboard');
    toast('Base mise à neuf', 'Les données métier ont été supprimées. Le compte Administrateur reste actif.');
  }
  function openDateFilter() {
    const body = `<form id="date-filter-form"><div class="notice info"><span>◷</span><div><strong>Période active : ${esc(periodLabel())}</strong><span>La période s’appliquera aux listes, indicateurs, exports et impressions compatibles.</span></div></div><div class="form-grid"><div class="field"><label>Du</label><input class="input-control" type="date" name="from" value="${esc(activeDateFilter.from)}"></div><div class="field"><label>Au</label><input class="input-control" type="date" name="to" value="${esc(activeDateFilter.to)}"></div></div><div class="field-hint">Laissez les deux champs vides pour afficher et exporter toute la période disponible.</div><div class="form-actions"><button class="btn btn-secondary" type="button" data-action="clear-date-filter">Réinitialiser</button><button class="btn btn-secondary" type="button" data-close-modal>Annuler</button><button class="btn btn-primary" type="submit">Appliquer le filtre</button></div></form>`;
    openModal('Filtrer par période', 'Préparez votre état avant export ou impression.', body);
    $('#date-filter-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(event.currentTarget).entries());
      if (data.from && data.to && data.from > data.to) { toast('Période invalide', 'La date de début doit précéder la date de fin.', 'error'); return; }
      activeDateFilter = { from: String(data.from || ''), to: String(data.to || '') };
      tablePages = {};
      closeModal();
      render();
      toast('Filtre appliqué', `Période active : ${periodLabel()}. Les listes, exports et impressions ont été actualisés.`, 'success');
    });
  }
  function printInventory() { printDocument('Fiche d’inventaire', 'Stock théorique et comptage physique', { headers: ['Code','Produit','Catégorie','Magasin','Théorique','Réel','Écart'], body: activeProducts().map((p) => { const i = state.inventory.find((x) => x.productId === p.id); return [p.code, p.name, categoryName(p.categoryId), storeName(p.storeId), `${totalStock(p)} u.`, i ? `${i.real} u.` : '—', i ? `${i.real - totalStock(p)} u.` : '—']; }) }); }
  function reportPeriodDefs(refDate = new Date()) {
    const y = refDate.getFullYear();
    const m = refDate.getMonth();
    const prev = new Date(y, m - 1, 1);
    const cap = (text) => text.charAt(0).toUpperCase() + text.slice(1);
    const labelOf = (d) => cap(d.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' }));
    const keyOf = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    return [
      { id: 'lastMonth', label: labelOf(prev), month: keyOf(prev), year: null },
      { id: 'currentMonth', label: labelOf(new Date(y, m, 1)), month: keyOf(new Date(y, m, 1)), year: null },
      { id: 'currentYear', label: `Année ${y}`, month: null, year: y },
      { id: 'lastYear', label: `Année ${y - 1}`, month: null, year: y - 1 }
    ];
  }
  function inReportPeriod(dateValue, def) {
    if (!dateValue || !def) return false;
    if (def.month) return monthKey(dateValue) === def.month;
    return localDate(dateValue).getFullYear() === def.year;
  }
  function lastMonths(count, refDate = new Date()) {
    const out = [];
    for (let k = count - 1; k >= 0; k -= 1) {
      const d = new Date(refDate.getFullYear(), refDate.getMonth() - k, 1);
      const label = d.toLocaleDateString('fr-FR', { month: 'short' }).replace('.', '');
      out.push({ key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`, label: label.charAt(0).toUpperCase() + label.slice(1) });
    }
    return out;
  }
  function reportEvo(current, previous) {
    const cur = num(current);
    const prev = num(previous);
    if (!prev) return { text: cur ? 'première activité' : '—', down: false };
    const pct = Math.round((cur - prev) / Math.abs(prev) * 100);
    return { text: `${pct > 0 ? '+' : pct < 0 ? '−' : ''}${Math.abs(pct)} % vs mois passé`, down: pct < 0 };
  }
  function fmtReportValue(value, fmt) {
    if (fmt === 'money') return money(value);
    if (fmt === 'number') return number(value);
    return String(value ?? '');
  }
  function computeFullReport(kind, refDate = new Date()) {
    const defs = reportPeriodDefs(refDate);
    const inDefs = (date) => defs.map((def) => inReportPeriod(date, def));
    if (kind === 'ventes') {
      const sales = validSales();
      const notes = validCreditNotes();
      const profitCollection = creditCollectionRatios();
      const per = defs.map((def) => {
        const s = sales.filter((x) => inReportPeriod(x.date, def));
        const n = notes.filter((x) => inReportPeriod(x.date, def));
        const revenue = s.reduce((t, x) => t + saleTotal(x), 0) - n.reduce((t, x) => t + creditNoteTotal(x), 0);
        const margin = s.reduce((t, x) => t + saleMargin(x), 0) - n.reduce((t, x) => t + creditNoteMargin(x), 0);
        const collected = collectedMarginOf(s, n, profitCollection);
        const qty = s.reduce((t, x) => t + (x.items || []).reduce((a, i) => a + num(i.quantity), 0), 0) - n.reduce((t, x) => t + (x.lines || []).reduce((a, i) => a + num(i.quantity), 0), 0);
        return { revenue, count: s.length, qty, margin, collected, basket: s.length ? revenue / s.length : 0 };
      });
      const evo = reportEvo(per[1].revenue, per[0].revenue);
      const months = lastMonths(6, refDate).map((mk) => {
        const s = sales.filter((x) => monthKey(x.date) === mk.key);
        const n = notes.filter((x) => monthKey(x.date) === mk.key);
        return { label: mk.label, value: s.reduce((t, x) => t + saleTotal(x), 0) - n.reduce((t, x) => t + creditNoteTotal(x), 0) };
      });
      const ySales = sales.filter((x) => inReportPeriod(x.date, defs[2]));
      const yNotes = notes.filter((x) => inReportPeriod(x.date, defs[2]));
      const yRevenue = ySales.reduce((t, x) => t + saleTotal(x), 0) - yNotes.reduce((t, x) => t + creditNoteTotal(x), 0);
      const byPayment = ['cash', 'mobile', 'card', 'credit'].map((payment) => {
        const total = ySales.filter((x) => x.payment === payment).reduce((t, x) => t + saleTotal(x), 0) - yNotes.filter((x) => x.payment === payment).reduce((t, x) => t + creditNoteTotal(x), 0);
        return { payment, total, share: yRevenue ? Math.round(total / yRevenue * 100) : 0 };
      });
      const ranking = productSalesRanking(ySales).slice(0, 8);
      const caBy = {};
      ySales.forEach((s) => (s.items || []).forEach((it) => { caBy[it.productId] = num(caBy[it.productId]) + num(it.quantity) * num(it.unitPrice); }));
      const recent = sales.slice().sort((a, b) => localDate(b.date) - localDate(a.date)).slice(0, 8);
      return {
        kind, title: 'Rapport des ventes',
        kpis: [
          { label: 'CA net · ' + defs[1].label, value: money(per[1].revenue), sub: evo.text, down: evo.down },
          { label: 'Ventes · ' + defs[1].label, value: number(per[1].count), sub: `${number(per[1].qty)} unités` },
          { label: 'CA net · ' + defs[0].label, value: money(per[0].revenue), sub: `${number(per[0].count)} ventes` },
          { label: 'CA net · ' + defs[2].label, value: money(per[2].revenue), sub: `marge ${money(per[2].margin)} · encaissée ${money(per[2].collected)}` }
        ],
        defs,
        periodRows: [
          { label: 'Chiffre d’affaires net', values: per.map((p) => p.revenue), fmt: 'money' },
          { label: 'Nombre de ventes', values: per.map((p) => p.count), fmt: 'number' },
          { label: 'Quantités vendues', values: per.map((p) => p.qty), fmt: 'number' },
          { label: 'Panier moyen', values: per.map((p) => p.basket), fmt: 'money' },
          { label: 'Marge brute', values: per.map((p) => p.margin), fmt: 'money' },
          { label: 'Marge brute encaissée', values: per.map((p) => p.collected), fmt: 'money' }
        ],
        charts: [
          { title: 'Chiffre d’affaires net — 6 derniers mois', bars: months.map((m) => ({ label: m.label, value: m.value, display: money(m.value) })) },
          { title: 'CA net par mode de paiement — ' + defs[2].label, bars: byPayment.map((b) => ({ label: `${paymentLabel(b.payment)} · ${b.share} %`, value: b.total, display: money(b.total) })) }
        ],
        tables: [
          { title: 'Produits les plus vendus — ' + defs[2].label, headers: ['Produit', 'Quantités', 'CA estimé'], nums: [false, true, true], rows: ranking.map((r) => [`${r.product.code} · ${r.product.name}`, number(r.quantity), money(num(caBy[r.product.id]))]) },
          { title: 'Dernières ventes', headers: ['Numéro', 'Date', 'Client', 'Montant', 'Paiement'], nums: [false, false, false, true, false], rows: recent.map((s) => [s.number, shortDate(s.date), clientName(s.clientId), money(saleTotal(s)), paymentLabel(s.payment)]) }
        ]
      };
    }
    if (kind === 'achats') {
      const entries = (state.stockEntries || []).filter((e) => e.status === 'Validé');
      const per = defs.map((def) => {
        const list = entries.filter((x) => inReportPeriod(x.date, def));
        return { total: list.reduce((t, x) => t + num(x.total), 0), count: list.length, qty: list.reduce((t, x) => t + num(x.quantity), 0) };
      });
      const evo = reportEvo(per[1].total, per[0].total);
      const months = lastMonths(6, refDate).map((mk) => ({ label: mk.label, value: entries.filter((x) => monthKey(x.date) === mk.key).reduce((t, x) => t + num(x.total), 0) }));
      const yEntries = entries.filter((x) => inReportPeriod(x.date, defs[2]));
      const bySupplier = state.suppliers.map((s) => {
        const list = yEntries.filter((x) => x.supplierId === s.id);
        return { name: s.name, count: list.length, qty: list.reduce((t, x) => t + num(x.quantity), 0), total: list.reduce((t, x) => t + num(x.total), 0) };
      }).filter((s) => s.total > 0).sort((a, b) => b.total - a.total);
      const recent = entries.slice().sort((a, b) => localDate(b.date) - localDate(a.date)).slice(0, 8);
      return {
        kind, title: 'Rapport des achats',
        kpis: [
          { label: 'Achats · ' + defs[1].label, value: money(per[1].total), sub: evo.text, down: evo.down },
          { label: 'Entrées · ' + defs[1].label, value: number(per[1].count), sub: `${number(per[1].qty)} unités` },
          { label: 'Achats · ' + defs[0].label, value: money(per[0].total), sub: `${number(per[0].count)} entrées` },
          { label: 'Achats · ' + defs[2].label, value: money(per[2].total), sub: `${number(bySupplier.length)} fournisseurs` }
        ],
        defs,
        periodRows: [
          { label: 'Montant des achats', values: per.map((p) => p.total), fmt: 'money' },
          { label: 'Entrées validées', values: per.map((p) => p.count), fmt: 'number' },
          { label: 'Quantités achetées', values: per.map((p) => p.qty), fmt: 'number' }
        ],
        charts: [
          { title: 'Achats — 6 derniers mois', bars: months.map((m) => ({ label: m.label, value: m.value, display: money(m.value), color: '#f19a52' })) },
          { title: 'Achats par fournisseur — ' + defs[2].label, bars: bySupplier.slice(0, 6).map((s) => ({ label: s.name, value: s.total, display: money(s.total), color: '#f19a52' })) }
        ],
        tables: [
          { title: 'Fournisseurs — ' + defs[2].label, headers: ['Fournisseur', 'Entrées', 'Quantités', 'Montant'], nums: [false, true, true, true], rows: bySupplier.map((s) => [s.name, number(s.count), number(s.qty), money(s.total)]) },
          { title: 'Dernières entrées validées', headers: ['Référence', 'Date', 'Fournisseur', 'Produit', 'Quantité', 'Montant'], nums: [false, false, false, false, true, true], rows: recent.map((e) => [e.number, shortDate(e.date), supplierName(e.supplierId), productName(e.productId), number(e.quantity), money(e.total)]) }
        ]
      };
    }
    if (kind === 'stocks') {
      const products = activeProducts();
      const entries = (state.stockEntries || []).filter((e) => e.status === 'Validé');
      const exits = (state.stockExits || []).filter((e) => e.status === 'Validé');
      const valuation = products.reduce((s, p) => s + totalStock(p) * num(p.purchasePrice), 0);
      const ruptures = products.filter((p) => totalStock(p) <= 0);
      const faibles = products.filter((p) => totalStock(p) > 0 && totalStock(p) <= num(p.minStock));
      const per = defs.map((def) => {
        const en = entries.filter((x) => inReportPeriod(x.date, def));
        const ex = exits.filter((x) => inReportPeriod(x.date, def));
        const enQty = en.reduce((t, x) => t + num(x.quantity), 0);
        const exQty = ex.reduce((t, x) => t + num(x.quantity), 0);
        return { enQty, enVal: en.reduce((t, x) => t + num(x.total), 0), exQty, exVal: ex.reduce((t, x) => t + num(x.total), 0), net: enQty - exQty };
      });
      const byCategory = state.categories.map((c) => {
        const list = products.filter((p) => p.categoryId === c.id);
        return { name: c.name, value: list.reduce((t, p) => t + totalStock(p) * num(p.purchasePrice), 0), qty: list.reduce((t, p) => t + totalStock(p), 0) };
      }).filter((c) => c.qty > 0 || c.value > 0).sort((a, b) => b.value - a.value);
      const byStore = state.stores.filter((s) => s.active !== false).map((s) => {
        const vals = products.map((p) => ({ qty: stockFor(p, s.id), val: stockFor(p, s.id) * num(p.purchasePrice) }));
        return { name: s.name, refs: vals.filter((v) => v.qty > 0).length, qty: vals.reduce((t, v) => t + v.qty, 0), value: vals.reduce((t, v) => t + v.val, 0) };
      });
      const alerts = [...ruptures.map((p) => ({ p, state: 'Rupture' })), ...faibles.map((p) => ({ p, state: 'Stock faible' }))].slice(0, 12);
      return {
        kind, title: 'Rapport des stocks',
        kpis: [
          { label: 'Valorisation (coût d’achat)', value: money(valuation), sub: `${number(products.length)} références actives` },
          { label: 'Unités en stock', value: number(products.reduce((s, p) => s + totalStock(p), 0)), sub: `${number(byStore.length)} magasin(s)` },
          { label: 'Ruptures', value: number(ruptures.length), sub: ruptures.length ? 'à réapprovisionner' : 'aucune rupture', down: ruptures.length > 0 },
          { label: 'Stocks faibles', value: number(faibles.length), sub: 'sous le seuil mini', down: faibles.length > 0 }
        ],
        defs,
        periodRows: [
          { label: 'Entrées (quantités)', values: per.map((p) => p.enQty), fmt: 'number' },
          { label: 'Entrées (valeur)', values: per.map((p) => p.enVal), fmt: 'money' },
          { label: 'Sorties (quantités)', values: per.map((p) => p.exQty), fmt: 'number' },
          { label: 'Sorties (valeur)', values: per.map((p) => p.exVal), fmt: 'money' },
          { label: 'Solde (quantités)', values: per.map((p) => p.net), fmt: 'number' }
        ],
        charts: [
          { title: 'Valorisation par catégorie — situation actuelle', bars: byCategory.map((c) => ({ label: c.name, value: c.value, display: money(c.value), color: '#4e87df' })) },
          { title: 'Mouvements par période (quantités)', duo: true, aLabel: 'Entrées', bLabel: 'Sorties', pairs: defs.map((def, i) => ({ label: def.label, aValue: per[i].enQty, aDisplay: number(per[i].enQty), bValue: per[i].exQty, bDisplay: number(per[i].exQty) })) }
        ],
        tables: [
          { title: 'Alertes stock — situation actuelle', headers: ['Code', 'Produit', 'Stock', 'Mini', 'État'], nums: [false, false, true, true, false], rows: alerts.map((a) => [a.p.code, a.p.name, number(totalStock(a.p)), number(a.p.minStock), a.state]) },
          { title: 'Valorisation par magasin — situation actuelle', headers: ['Magasin', 'Références', 'Unités', 'Valeur'], nums: [false, true, true, true], rows: byStore.map((s) => [s.name, number(s.refs), number(s.qty), money(s.value)]) }
        ]
      };
    }
    if (kind === 'depenses') {
      const expenses = (state.expenses || []).filter((e) => e.status === 'Validée');
      const per = defs.map((def) => {
        const list = expenses.filter((x) => inReportPeriod(x.date, def));
        const total = list.reduce((t, x) => t + num(x.amount), 0);
        return { total, count: list.length, avg: list.length ? total / list.length : 0 };
      });
      const evo = reportEvo(per[1].total, per[0].total);
      const months = lastMonths(6, refDate).map((mk) => ({ label: mk.label, value: expenses.filter((x) => monthKey(x.date) === mk.key).reduce((t, x) => t + num(x.amount), 0) }));
      const yExpenses = expenses.filter((x) => inReportPeriod(x.date, defs[2]));
      const byLabel = new Map();
      yExpenses.forEach((x) => { const key = (x.label || 'Sans libellé').trim(); byLabel.set(key, num(byLabel.get(key)) + num(x.amount)); });
      const topLabels = [...byLabel.entries()].map(([label, total]) => ({ label, total })).sort((a, b) => b.total - a.total).slice(0, 6);
      const biggest = yExpenses.slice().sort((a, b) => num(b.amount) - num(a.amount)).slice(0, 8);
      return {
        kind, title: 'Rapport des dépenses',
        kpis: [
          { label: 'Dépenses · ' + defs[1].label, value: money(per[1].total), sub: evo.text, down: evo.down && per[1].total > per[0].total },
          { label: 'Opérations · ' + defs[1].label, value: number(per[1].count), sub: `moyenne ${money(per[1].avg)}` },
          { label: 'Dépenses · ' + defs[0].label, value: money(per[0].total), sub: `${number(per[0].count)} opérations` },
          { label: 'Dépenses · ' + defs[2].label, value: money(per[2].total), sub: `${number(yExpenses.filter((x) => x.receipt).length)} justificatifs` }
        ],
        defs,
        periodRows: [
          { label: 'Total des dépenses', values: per.map((p) => p.total), fmt: 'money' },
          { label: 'Opérations', values: per.map((p) => p.count), fmt: 'number' },
          { label: 'Dépense moyenne', values: per.map((p) => p.avg), fmt: 'money' }
        ],
        charts: [
          { title: 'Dépenses — 6 derniers mois', bars: months.map((m) => ({ label: m.label, value: m.value, display: money(m.value), color: '#8270dc' })) },
          { title: 'Principaux postes — ' + defs[2].label, bars: topLabels.map((t) => ({ label: t.label, value: t.total, display: money(t.total), color: '#8270dc' })) }
        ],
        tables: [
          { title: 'Plus grosses dépenses — ' + defs[2].label, headers: ['Date', 'Référence', 'Désignation', 'Montant', 'Exécuté par'], nums: [false, false, false, true, false], rows: biggest.map((e) => [shortDate(e.date), e.number, e.label, money(e.amount), e.executedBy || '—']) },
          { title: 'Dernières dépenses validées', headers: ['Date', 'Désignation', 'Montant', 'Justificatif'], nums: [false, false, true, false], rows: expenses.slice().sort((a, b) => localDate(b.date) - localDate(a.date)).slice(0, 8).map((e) => [shortDate(e.date), e.label, money(e.amount), e.receipt ? 'Joint' : '—']) }
        ]
      };
    }
    if (kind === 'creances') {
      refreshClientReceivables();
      const creditSales = validSales().filter((s) => s.payment === 'credit');
      const payments = (state.customerPayments || []).filter((p) => p.status === 'Validé');
      const creditNotes = validCreditNotes().filter((n) => n.payment === 'credit');
      const per = defs.map((def) => {
        const credit = creditSales.filter((x) => inReportPeriod(x.date, def)).reduce((t, x) => t + saleTotal(x), 0);
        const paid = payments.filter((x) => inReportPeriod(x.date, def)).reduce((t, x) => t + num(x.amount), 0);
        const notes = creditNotes.filter((x) => inReportPeriod(x.date, def)).reduce((t, x) => t + creditNoteTotal(x), 0);
        const refunds = validRefunds().filter((x) => inReportPeriod(x.date, def) && x.notePayment === 'credit').reduce((t, x) => t + num(x.amount), 0);
        return { credit, paid, notes, refunds, net: credit - paid - notes + refunds };
      });
      const debtors = state.clients.filter((c) => num(c.receivable) > 0).sort((a, b) => num(b.receivable) - num(a.receivable));
      const outstanding = debtors.reduce((t, c) => t + num(c.receivable), 0);
      const advanceTotal = state.clients.reduce((t, c) => t + num(c.advance), 0);
      const months = lastMonths(6, refDate).map((mk) => ({
        label: mk.label,
        credit: creditSales.filter((x) => monthKey(x.date) === mk.key).reduce((t, x) => t + saleTotal(x), 0),
        paid: payments.filter((x) => monthKey(x.date) === mk.key).reduce((t, x) => t + num(x.amount), 0)
      }));
      const recentPayments = payments.slice().sort((a, b) => localDate(b.date) - localDate(a.date)).slice(0, 8);
      return {
        kind, title: 'Rapport des créances',
        kpis: [
          { label: 'Encours total à recouvrer', value: money(outstanding), sub: `${number(debtors.length)} client(s) débiteur(s)`, down: outstanding > 0 },
          { label: 'Ventes à crédit · ' + defs[1].label, value: money(per[1].credit), sub: `règlements ${money(per[1].paid)}` },
          { label: 'Règlements · ' + defs[2].label, value: money(per[2].paid), sub: `crédits ${money(per[2].credit)}` },
          { label: 'Solde net · ' + defs[2].label, value: money(per[2].net), sub: 'crédits − règlements − avoirs + remboursements', down: per[2].net > 0 },
          { label: 'Avances clients', value: money(advanceTotal), sub: 'trop-perçus imputables', down: false }
        ],
        defs,
        periodRows: [
          { label: 'Ventes à crédit', values: per.map((p) => p.credit), fmt: 'money' },
          { label: 'Règlements encaissés', values: per.map((p) => p.paid), fmt: 'money' },
          { label: 'Avoirs sur crédit', values: per.map((p) => p.notes), fmt: 'money' },
          { label: 'Remboursements', values: per.map((p) => p.refunds), fmt: 'money' },
          { label: 'Solde net', values: per.map((p) => p.net), fmt: 'money' }
        ],
        charts: [
          { title: 'Crédits accordés vs règlements — 6 derniers mois', duo: true, aLabel: 'Ventes à crédit', bLabel: 'Règlements', pairs: months.map((m) => ({ label: m.label, aValue: m.credit, aDisplay: money(m.credit), bValue: m.paid, bDisplay: money(m.paid) })) },
          { title: 'Principaux débiteurs — situation actuelle', bars: debtors.slice(0, 6).map((c) => ({ label: c.name, value: num(c.receivable), display: money(c.receivable), color: '#db5d66' })) }
        ],
        tables: [
          { title: 'Clients débiteurs — situation actuelle', headers: ['Client', 'Contact', 'Encours', 'Limite', 'Utilisation'], nums: [false, false, true, true, true], rows: debtors.map((c) => [c.name, c.phone || '—', money(c.receivable), num(c.creditLimit) > 0 ? money(c.creditLimit) : '—', num(c.creditLimit) > 0 ? `${Math.round(num(c.receivable) / num(c.creditLimit) * 100)} %` : '—']) },
          { title: 'Derniers règlements', headers: ['Date', 'Référence', 'Client', 'Montant', 'Mode'], nums: [false, false, false, true, false], rows: recentPayments.map((p) => [shortDate(p.date), p.number, clientName(p.clientId), money(p.amount), paymentLabel(p.method)]) }
        ]
      };
    }
    if (kind === 'benefices') {
      const sales = validSales();
      const notes = validCreditNotes();
      const expenses = (state.expenses || []).filter((e) => e.status === 'Validée');
      const profitCollection = creditCollectionRatios();
      const per = defs.map((def) => {
        const s = sales.filter((x) => inReportPeriod(x.date, def));
        const n = notes.filter((x) => inReportPeriod(x.date, def));
        const revenue = s.reduce((t, x) => t + saleTotal(x), 0) - n.reduce((t, x) => t + creditNoteTotal(x), 0);
        const margin = s.reduce((t, x) => t + saleMargin(x), 0) - n.reduce((t, x) => t + creditNoteMargin(x), 0);
        const collected = collectedMarginOf(s, n, profitCollection);
        const exp = expenses.filter((x) => inReportPeriod(x.date, def)).reduce((t, x) => t + num(x.amount), 0);
        return { revenue, margin, collected, expenses: exp, result: margin - exp, resultCollected: collected - exp, rate: revenue ? `${Math.round(margin / revenue * 100)} %` : '—' };
      });
      const evo = reportEvo(per[1].result, per[0].result);
      const months = lastMonths(6, refDate).map((mk) => {
        const s = sales.filter((x) => monthKey(x.date) === mk.key);
        const n = notes.filter((x) => monthKey(x.date) === mk.key);
        const margin = s.reduce((t, x) => t + saleMargin(x), 0) - n.reduce((t, x) => t + creditNoteMargin(x), 0);
        const collected = collectedMarginOf(s, n, profitCollection);
        const exp = expenses.filter((x) => monthKey(x.date) === mk.key).reduce((t, x) => t + num(x.amount), 0);
        return { label: mk.label, value: margin - exp, valueCollected: collected - exp };
      });
      const year = refDate.getFullYear();
      const monthly = [];
      for (let m = 0; m < 12; m += 1) {
        const key = `${year}-${String(m + 1).padStart(2, '0')}`;
        const label = new Date(year, m, 1).toLocaleDateString('fr-FR', { month: 'long' });
        const s = sales.filter((x) => monthKey(x.date) === key);
        const n = notes.filter((x) => monthKey(x.date) === key);
        const revenue = s.reduce((t, x) => t + saleTotal(x), 0) - n.reduce((t, x) => t + creditNoteTotal(x), 0);
        const margin = s.reduce((t, x) => t + saleMargin(x), 0) - n.reduce((t, x) => t + creditNoteMargin(x), 0);
        const collected = collectedMarginOf(s, n, profitCollection);
        const exp = expenses.filter((x) => monthKey(x.date) === key).reduce((t, x) => t + num(x.amount), 0);
        monthly.push({ label: label.charAt(0).toUpperCase() + label.slice(1), revenue, margin, collected, expenses: exp, result: margin - exp, resultCollected: collected - exp });
      }
      return {
        kind, title: 'Rapport des bénéfices',
        kpis: [
          { label: 'Résultat net · ' + defs[1].label, value: money(per[1].result), sub: evo.text, down: per[1].result < 0 },
          { label: 'Marge brute · ' + defs[2].label, value: money(per[2].margin), sub: `taux ${per[2].rate}` },
          { label: 'Dépenses · ' + defs[2].label, value: money(per[2].expenses), sub: `CA ${money(per[2].revenue)}` },
          { label: 'Résultat net · ' + defs[2].label, value: money(per[2].result), sub: 'marge brute − dépenses', down: per[2].result < 0 },
          { label: 'Marge brute encaissée · ' + defs[2].label, value: money(per[2].collected), sub: 'hors créances' },
          { label: 'Résultat net encaissé · ' + defs[2].label, value: money(per[2].resultCollected), sub: 'marge encaissée − dépenses', down: per[2].resultCollected < 0 }
        ],
        defs,
        periodRows: [
          { label: 'Chiffre d’affaires net', values: per.map((p) => p.revenue), fmt: 'money' },
          { label: 'Marge brute', values: per.map((p) => p.margin), fmt: 'money' },
          { label: 'Dépenses', values: per.map((p) => p.expenses), fmt: 'money' },
          { label: 'Résultat net', values: per.map((p) => p.result), fmt: 'money' },
          { label: 'Marge brute encaissée', values: per.map((p) => p.collected), fmt: 'money' },
          { label: 'Résultat net encaissé', values: per.map((p) => p.resultCollected), fmt: 'money' },
          { label: 'Taux de marge', values: per.map((p) => p.rate), fmt: 'raw' }
        ],
        charts: [
          { title: 'Résultat net vs encaissé — 6 derniers mois', duo: true, aLabel: 'Résultat net', bLabel: 'Résultat net encaissé', pairs: months.map((m) => ({ label: m.label, aValue: m.value, aDisplay: money(m.value), bValue: m.valueCollected, bDisplay: money(m.valueCollected) })) },
          { title: 'Structure du résultat — ' + defs[2].label, bars: [{ label: 'CA net', value: per[2].revenue, display: money(per[2].revenue), color: '#0f9f91' }, { label: 'Marge brute', value: per[2].margin, display: money(per[2].margin), color: '#4e87df' }, { label: 'Dépenses', value: per[2].expenses, display: money(per[2].expenses), color: '#8270dc' }, { label: 'Résultat net', value: per[2].result, display: money(per[2].result), color: per[2].result < 0 ? '#db5d66' : '#0f9f91' }, { label: 'Marge encaissée', value: per[2].collected, display: money(per[2].collected), color: '#f19a52' }, { label: 'Résultat encaissé', value: per[2].resultCollected, display: money(per[2].resultCollected), color: per[2].resultCollected < 0 ? '#db5d66' : '#f19a52' }] }
        ],
        tables: [
          { title: 'Détail mensuel — ' + defs[2].label, headers: ['Mois', 'CA net', 'Marge brute', 'Dépenses', 'Résultat net', 'Marge encaissée', 'Résultat encaissé'], nums: [false, true, true, true, true, true, true], rows: monthly.map((m) => [m.label, money(m.revenue), money(m.margin), money(m.expenses), money(m.result), money(m.collected), money(m.resultCollected)]) }
        ]
      };
    }
    return null;
  }
  function fullReportHTML(data) {
    const company = state.settings || {};
    const kpis = data.kpis.map((k) => `<div class="rpt-kpi"><span>${esc(k.label)}</span><strong>${esc(k.value)}</strong>${k.sub ? `<em${k.down ? ' class="down"' : ''}>${esc(k.sub)}</em>` : ''}</div>`).join('');
    const periodTable = `<table class="rpt-table"><thead><tr><th>Indicateur</th>${data.defs.map((d) => `<th class="num">${esc(d.label)}</th>`).join('')}</tr></thead><tbody>${data.periodRows.map((r) => `<tr><td>${esc(r.label)}</td>${r.values.map((v) => `<td class="num">${esc(fmtReportValue(v, r.fmt))}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    const charts = data.charts.map((chart) => {
      if (chart.duo) {
        const max = Math.max(...chart.pairs.flatMap((p) => [num(p.aValue), num(p.bValue)]), 1);
        const rows = chart.pairs.map((p) => {
          const wa = num(p.aValue) > 0 ? Math.max(2, Math.round(num(p.aValue) / max * 100)) : 0;
          const wb = num(p.bValue) > 0 ? Math.max(2, Math.round(num(p.bValue) / max * 100)) : 0;
          return `<div class="rpt-bar-row"><span class="rpt-bar-label">${esc(p.label)}</span><div class="rpt-bar-duo"><div class="rpt-bar-track thin"><div class="rpt-bar-fill" style="width:${wa}%;background:#0f9f91"></div></div><div class="rpt-bar-track thin"><div class="rpt-bar-fill" style="width:${wb}%;background:#f19a52"></div></div></div><span class="rpt-bar-value">${esc(p.aDisplay)} · ${esc(p.bDisplay)}</span></div>`;
        }).join('');
        return `<div class="rpt-chart-title">${esc(chart.title)}</div><div class="rpt-duo-legend"><span><i style="background:#0f9f91"></i>${esc(chart.aLabel)}</span><span><i style="background:#f19a52"></i>${esc(chart.bLabel)}</span></div><div class="rpt-bars">${rows}</div>`;
      }
      const max = Math.max(...chart.bars.map((b) => Math.abs(num(b.value))), 1);
      const rows = chart.bars.map((b) => {
        const width = num(b.value) !== 0 ? Math.max(2, Math.round(Math.abs(num(b.value)) / max * 100)) : 0;
        return `<div class="rpt-bar-row"><span class="rpt-bar-label">${esc(b.label)}</span><div class="rpt-bar-track"><div class="rpt-bar-fill" style="width:${width}%;${b.color ? `background:${b.color}` : ''}"></div></div><span class="rpt-bar-value">${esc(b.display)}</span></div>`;
      }).join('');
      return `<div class="rpt-chart-title">${esc(chart.title)}</div><div class="rpt-bars">${rows || '<div class="rpt-bar-row"><span class="rpt-bar-label">Aucune donnée</span></div>'}</div>`;
    }).join('');
    const tables = data.tables.map((t) => `<div class="rpt-chart-title">${esc(t.title)}</div><table class="rpt-table"><thead><tr>${t.headers.map((h, i) => `<th${t.nums[i] ? ' class="num"' : ''}>${esc(h)}</th>`).join('')}</tr></thead><tbody>${t.rows.map((r) => `<tr>${r.map((cell, i) => `<td${t.nums[i] ? ' class="num"' : ''}>${esc(cell)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${t.headers.length}">Aucune donnée</td></tr>`}</tbody></table>`).join('');
    return `<div class="print-sheet commercial-document rpt-sheet"><div class="print-company"><div><h1>${esc(company.businessName || 'NOVA Commerce')}</h1><div>${esc(company.address || '')}</div><div>${esc(company.commercialPhone || company.managerPhone || '')}${company.email ? ` · ${esc(company.email)}` : ''}</div></div><div class="print-document-title"><h2>${esc(data.title.toUpperCase())}</h2><strong>Périodes comparées</strong><span>Édité le ${esc(new Date().toLocaleDateString('fr-FR'))}</span><span>Par ${esc(currentUser?.name || '—')}</span></div></div><div class="rpt-meta">Mois passé · Mois en cours · Année en cours · Année passée — Opérations validées uniquement — Données arrêtées au ${esc(dateTime(new Date().toISOString()))}</div><div class="rpt-section-title">Indicateurs clés</div><div class="rpt-kpis">${kpis}</div><div class="rpt-section-title">Comparaison des périodes</div>${periodTable}<div class="rpt-section-title">Graphiques</div>${charts}<div class="rpt-section-title">Tableaux de détail</div>${tables}<div class="rpt-footer"><span>Document généré par NOVA Commerce · ${esc(company.businessName || '')}</span><span>${esc(data.title)} · ${esc(new Date().toLocaleDateString('fr-FR'))}</span></div></div>`;
  }
  function printFullReport(kind) {
    const data = computeFullReport(kind);
    if (!data) { toast('Rapport inconnu', 'Le type de rapport demandé n’existe pas.', 'error'); return; }
    $('#print-root').innerHTML = fullReportHTML(data);
    printCurrentPage(() => { $('#print-root').innerHTML = ''; });
  }
  function computeSupplierProducts() {
    const links = state.supplierProducts || [];
    const groups = (state.suppliers || []).map((supplier) => {
      const linkedIds = new Set(links.filter((link) => link.supplierId === supplier.id).map((link) => link.productId));
      const items = (state.products || [])
        .filter((product) => linkedIds.has(product.id) || product.supplierId === supplier.id)
        .sort((a, b) => String(a.name).localeCompare(String(b.name), 'fr'));
      return { supplier, items };
    }).sort((a, b) => String(a.supplier.name).localeCompare(String(b.supplier.name), 'fr'));
    const linkedProductIds = new Set();
    groups.forEach((group) => group.items.forEach((product) => linkedProductIds.add(product.id)));
    const orphaned = (state.products || [])
      .filter((product) => !linkedProductIds.has(product.id))
      .sort((a, b) => String(a.name).localeCompare(String(b.name), 'fr'));
    return { groups, orphaned };
  }
  function supplierProductsReportHTML() {
    const computed = computeSupplierProducts();
    const cell = (v) => esc(v);
    const headers = ['Référence', 'Produit', 'Catégorie', 'Prix d’achat', 'Prix de vente', 'Stock', 'Statut'];
    const tableFor = (items) => items.length
      ? '<table><thead><tr>' + headers.map((h) => '<th>' + cell(h) + '</th>').join('') + '</tr></thead><tbody>' + items.map((item) => '<tr><td>' + cell(item.code || '—') + '</td><td>' + cell(item.name) + '</td><td>' + cell(categoryName(item.categoryId)) + '</td><td class="num">' + cell(money(item.purchasePrice)) + '</td><td class="num">' + cell(money(item.salePrice)) + '</td><td class="num">' + cell(number(item.stock)) + '</td><td>' + (item.active === false ? 'Inactif' : 'Actif') + '</td></tr>').join('') + '</tbody></table>'
      : '<div class="print-muted" style="margin:8px 0 4px">Aucun produit référencé.</div>';
    const sections = computed.groups.map((group) => {
      const contact = [group.supplier.type, group.supplier.phone].filter(Boolean).join(' · ');
      return '<div class="rpt-section-title">' + cell(group.supplier.name) + ' · ' + number(group.items.length) + ' produit(s)' + (contact ? ' — ' + cell(contact) : '') + '</div>' + tableFor(group.items);
    }).join('');
    const orphans = computed.orphaned.length ? '<div class="rpt-section-title">Sans fournisseur attitré · ' + number(computed.orphaned.length) + ' produit(s)</div>' + tableFor(computed.orphaned) : '';
    const total = computed.groups.reduce((sum, group) => sum + group.items.length, 0);
    return '<div class="print-sheet"><h1>Produits par fournisseur</h1><div class="print-muted">' + cell(state.settings.businessName) + ' · ' + cell(new Date().toLocaleDateString('fr-FR')) + ' · ' + number(computed.groups.length) + ' fournisseur(s) · ' + number(total) + ' produit(s) référencé(s)</div>' + sections + orphans + '</div>';
  }
  function printSupplierProducts() {
    document.getElementById('print-root').innerHTML = supplierProductsReportHTML();
    printCurrentPage(() => { document.getElementById('print-root').innerHTML = ''; });
  }
  function printReport(type) {
    const period = periodLabel();
    const config = type === 'achats'
      ? { title: 'Rapport des achats', subtitle: `Entrées validées · ${period}`, headers: ['Référence','Date','Fournisseur','Produit','Quantité','Montant'], body: periodItems(state.stockEntries).filter((e) => e.status === 'Validé').map((e) => [e.number, shortDate(e.date), supplierName(e.supplierId), productName(e.productId), number(e.quantity), money(e.total)]) }
      : type === 'depenses'
        ? { title: 'Rapport des dépenses', subtitle: `Dépenses validées · ${period}`, headers: ['Date','Référence','Désignation','Montant','Exécuté par','Statut'], body: periodItems(state.expenses).filter((e) => e.status === 'Validée').map((e) => [shortDate(e.date), e.number, e.label, money(e.amount), e.executedBy, e.status]) }
        : { title: type === 'comptabilite' ? 'Synthèse comptable' : 'Rapport des ventes', subtitle: `Opérations validées · ${period}`, headers: ['Référence','Date','Client','Montant net','Paiement','Statut'], body: [...periodItems(validSales()).map((s) => [s.number, shortDate(s.date), clientName(s.clientId), money(saleTotal(s)), paymentLabel(s.payment), s.status]), ...periodItems(validCreditNotes()).map((note) => [note.number, shortDate(note.date), clientName(note.clientId), `−${money(creditNoteTotal(note))}`, 'Avoir', note.status])] };
    printDocument(config.title, config.subtitle, { headers: config.headers, body: config.body });
  }

  function reportUnexpectedError(reason) {
    try {
      const detail = String(reason?.message || reason || 'Erreur inconnue').slice(0, 180);
      console.error('NOVA: erreur inattendue', reason);
      if (!currentUser) return;
      toast('Erreur inattendue', 'L’opération a échoué. Réessayez ou rechargez la page.', 'error');
      addActivity('Système', 'Erreur inattendue', activeView || '', detail);
      saveState();
    } catch (_) {}
  }
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('service-worker.js').catch(() => {}));
  bindAuthentication();
  bindInactivityMonitor();
  window.addEventListener('error', (event) => reportUnexpectedError(event.message || event.error));
  window.addEventListener('unhandledrejection', (event) => reportUnexpectedError(event.reason));
  const finishNovaStartup = () => {
    void bootNovaApplication();
  };
  async function bootNovaApplication() {
    try { await Promise.race([enforceLicenceBinding(), new Promise((resolve) => setTimeout(resolve, 3000))]); } catch (_) { /* jamais bloquant */ }
    try { await ensureDeviceUuid(); } catch (_) { /* UUID résolu à la demande */ }
    const loading = $('#nova-loading-screen');
    if (loading) loading.remove();
    if (initialSetupPending) showInitialSetup(); else showLogin();
  }
  const novaLoading = $('#nova-loading-screen');
  if (novaLoading) window.setTimeout(finishNovaStartup, 4000); else finishNovaStartup();
  synchronizeDesktopClockIntegrity();
  startClockIntegrityMonitor();
})();
